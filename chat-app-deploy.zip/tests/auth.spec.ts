import { test, expect } from '@playwright/test';

/**
 * 用户认证功能测试套件
 * 测试用户注册、登录、登出等核心认证流程
 */
test.describe('用户认证功能', () => {
  
  /**
   * 测试前清理本地存储
   */
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
      // 清理IndexedDB
      if ('indexedDB' in window) {
        indexedDB.deleteDatabase('wechat-app');
      }
    });
  });

  /**
   * 测试用户注册流程
   */
  test('用户注册流程', async ({ page }) => {
    await page.goto('/');
    
    // 应该重定向到登录页面
    await expect(page).toHaveURL('/login');
    
    // 点击注册链接
    await page.click('text=立即注册');
    await expect(page).toHaveURL('/register');
    
    // 填写注册表单
    await page.fill('input[name="username"]', 'testuser');
    await page.fill('input[name="password"]', 'Test123456');
    await page.fill('input[name="confirmPassword"]', 'Test123456');
    
    // 提交注册表单
    await page.click('button[type="submit"]');
    
    // 验证注册成功后跳转到主页面
    await expect(page).toHaveURL('/app/chats', { timeout: 10000 });
    
    // 验证用户信息显示
    await page.click('text=我');
    await page.waitForTimeout(1000); // 等待页面加载
    await expect(page.locator('h2').filter({ hasText: 'testuser' })).toBeVisible();
  });

  /**
   * 测试用户登录流程
   */
  test('用户登录流程', async ({ page }) => {
    // 先注册一个用户
    await page.goto('/register');
    await page.fill('input[name="username"]', 'logintest');
    await page.fill('input[name="password"]', '123456');
    await page.fill('input[name="confirmPassword"]', '123456');
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到聊天页面
    await page.waitForURL('/app/chats', { timeout: 10000 });
    
    // 验证用户已经在聊天页面
    await expect(page).toHaveURL('/app/chats');
    
    // 等待一段时间确保用户状态完全同步
    await page.waitForTimeout(2000);
    
    // 退出登录 - 直接导航到个人页面
    await page.goto('/app/profile');
    
    // 等待页面加载完成
    await page.waitForLoadState('networkidle');
    
    // 检查是否被重定向到登录页面（说明用户状态有问题）
    if (page.url().includes('/login')) {
      // 如果被重定向到登录页面，说明用户状态丢失，重新登录
      await page.fill('input[name="username"]', 'logintest');
      await page.fill('input[name="password"]', '123456');
      await page.click('button[type="submit"]');
      
      // 等待登录成功并跳转到聊天页面
      await page.waitForURL('/app/chats', { timeout: 10000 });
      
      // 再次导航到个人页面
      await page.goto('/app/profile');
      await page.waitForLoadState('networkidle');
    }
    
    // 确保在个人页面
    await page.waitForURL('/app/profile', { timeout: 10000 });
    
    // 确保个人页面的关键元素已加载
    await page.waitForSelector('text=个人信息', { timeout: 10000 });
    
    // 滚动到退出登录按钮位置
    await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
    
    // 使用更精确的选择器定位退出登录按钮
    await page.waitForSelector('button:has-text("退出登录")', { timeout: 10000 });
    await page.locator('button:has-text("退出登录")').scrollIntoViewIfNeeded();
    await page.locator('button:has-text("退出登录")').click({ force: true });
    
    // 等待确认对话框出现
    await page.waitForSelector('text=确认退出登录？', { timeout: 10000 });
    
    // 点击"退出"按钮
    await page.locator('button:has-text("退出")').click();
    
    // 验证跳转到登录页面
    await page.waitForURL('/login', { timeout: 10000 });
    
    // 现在测试登录流程
    await page.fill('input[name="username"]', 'logintest');
    await page.fill('input[name="password"]', '123456');
    await page.click('button[type="submit"]');
    
    // 验证登录成功后跳转到聊天页面
    await page.waitForURL('/app/chats', { timeout: 10000 });
    expect(page.url()).toContain('/app/chats');
  });

  /**
   * 测试登录表单验证
   */
  test('登录表单验证', async ({ page }) => {
    await page.goto('/login');
    
    // 测试空表单提交
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1000); // 等待错误信息显示
    // 检查是否有错误信息容器出现
    await expect(page.locator('div.bg-red-50')).toBeVisible();
    await expect(page.locator('div.bg-red-50 p')).toContainText('请输入用户名');
    
    // 清空表单并测试无效用户名格式
    await page.fill('input[name="username"]', '');
    await page.fill('input[name="password"]', '');
    await page.fill('input[name="username"]', 'a');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1000); // 等待错误信息显示
    await expect(page.locator('div.bg-red-50 p')).toContainText('用户名格式不正确');
    
    // 清空表单并测试密码长度验证
    await page.fill('input[name="username"]', '');
    await page.fill('input[name="password"]', '');
    await page.fill('input[name="username"]', 'testuser');
    await page.fill('input[name="password"]', '123');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1000); // 等待错误信息显示
    await expect(page.locator('div.bg-red-50 p')).toContainText('密码长度不能少于6位');
  });

  /**
   * 测试注册表单验证
   */
  test('注册表单验证', async ({ page }) => {
    await page.goto('/register');
    
    // 测试密码不匹配
    await page.fill('input[name="username"]', 'testuser');
    await page.fill('input[name="password"]', 'Test123456');
    await page.fill('input[name="confirmPassword"]', 'Different123');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1000); // 等待错误信息显示
    await expect(page.locator('p.text-sm.text-red-600')).toContainText('两次输入的密码不一致');
    
    // 清空表单并测试用户名长度验证
    await page.fill('input[name="username"]', '');
    await page.fill('input[name="password"]', '');
    await page.fill('input[name="confirmPassword"]', '');
    await page.fill('input[name="username"]', 'a');
    await page.fill('input[name="password"]', 'Test123456');
    await page.fill('input[name="confirmPassword"]', 'Test123456');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1000); // 等待错误信息显示
    await expect(page.locator('p.text-sm.text-red-600')).toContainText('用户名格式不正确');
  });

  /**
   * 测试自动登录功能
   */
  test('自动登录功能', async ({ page }) => {
    // 先注册一个用户
    await page.goto('/register');
    await page.fill('input[name="username"]', 'autouser');
    await page.fill('input[name="password"]', '123456');
    await page.fill('input[name="confirmPassword"]', '123456');
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到聊天页面
    await page.waitForURL('/app/chats');
    
    // 刷新页面测试自动登录
    await page.reload();
    
    // 验证仍然在聊天页面（自动登录成功）
    await page.waitForURL('/app/chats');
    expect(page.url()).toContain('/app/chats');
  });

  test('用户登出功能', async ({ page }) => {
    // 先注册一个用户
    await page.goto('/register');
    await page.fill('input[name="username"]', 'logouttest');
    await page.fill('input[name="password"]', '123456');
    await page.fill('input[name="confirmPassword"]', '123456');
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到聊天页面
    await page.waitForURL('/app/chats', { timeout: 10000 });
    
    // 验证用户已经在聊天页面
    await expect(page).toHaveURL('/app/chats');
    
    // 等待一段时间确保用户状态完全同步
    await page.waitForTimeout(2000);
    
    // 导航到个人页面 - 直接导航
    await page.goto('/app/profile');
    
    // 等待页面加载完成
    await page.waitForLoadState('networkidle');
    
    // 检查是否被重定向到登录页面（说明用户状态有问题）
    if (page.url().includes('/login')) {
      // 如果被重定向到登录页面，说明用户状态丢失，重新登录
      await page.fill('input[name="username"]', 'logouttest');
      await page.fill('input[name="password"]', '123456');
      await page.click('button[type="submit"]');
      
      // 等待登录成功并跳转到聊天页面
      await page.waitForURL('/app/chats', { timeout: 10000 });
      
      // 再次导航到个人页面
      await page.goto('/app/profile');
      await page.waitForLoadState('networkidle');
    }
    
    // 确保在个人页面
    await page.waitForURL('/app/profile', { timeout: 10000 });
    
    // 确保个人页面的关键元素已加载
    await page.waitForSelector('text=个人信息', { timeout: 10000 });
    
    // 滚动到退出登录按钮位置
    await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
    
    // 使用更精确的选择器定位退出登录按钮
    await page.waitForSelector('button:has-text("退出登录")', { timeout: 10000 });
    await page.locator('button:has-text("退出登录")').scrollIntoViewIfNeeded();
    await page.locator('button:has-text("退出登录")').click({ force: true });
    
    // 等待确认对话框出现
    await page.waitForSelector('text=确认退出登录？', { timeout: 10000 });
    
    // 点击"退出"按钮
    await page.locator('button:has-text("退出")').click();
    
    // 验证跳转到登录页面
    await page.waitForURL('/login', { timeout: 10000 });
    expect(page.url()).toContain('/login');
  });
});