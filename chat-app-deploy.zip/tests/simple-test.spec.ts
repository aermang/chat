import { test, expect } from '@playwright/test';

/**
 * 简化的用药提醒页面测试
 * 用于诊断基本功能问题
 */

test.describe('用药提醒页面基本测试', () => {
  
  test('页面能够正常加载', async ({ page }) => {
    // 导航到用药提醒页面
    await page.goto('http://localhost:5173/app/special-medicine/reminders');
    
    // 等待页面加载
    await page.waitForLoadState('networkidle');
    
    // 截图记录页面状态
    await page.screenshot({ path: 'test-results/page-loaded.png' });
    
    // 检查页面是否包含基本元素
    const pageContent = await page.content();
    console.log('页面内容长度:', pageContent.length);
    
    // 检查是否有错误信息
    const errorElements = await page.locator('text=Error, text=错误, text=Unexpected Application Error').count();
    console.log('错误元素数量:', errorElements);
    
    if (errorElements > 0) {
      const errorText = await page.locator('text=Error, text=错误, text=Unexpected Application Error').first().textContent();
      console.log('错误信息:', errorText);
    }
    
    // 检查页面标题或主要内容
    const hasTitle = await page.locator('h1, h2, h3').count();
    console.log('标题元素数量:', hasTitle);
    
    if (hasTitle > 0) {
      const titleText = await page.locator('h1, h2, h3').first().textContent();
      console.log('页面标题:', titleText);
    }
    
    // 基本断言 - 页面应该加载成功
    expect(pageContent.length).toBeGreaterThan(100);
  });

  test('检查页面路由和导航', async ({ page }) => {
    // 先导航到主页
    await page.goto('http://localhost:5173/');
    await page.waitForLoadState('networkidle');
    
    // 截图记录主页状态
    await page.screenshot({ path: 'test-results/homepage.png' });
    
    // 尝试导航到用药提醒页面
    await page.goto('http://localhost:5173/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 检查当前URL
    const currentUrl = page.url();
    console.log('当前URL:', currentUrl);
    
    // 截图记录导航后的状态
    await page.screenshot({ path: 'test-results/navigation-result.png' });
    
    // 检查是否成功导航
    expect(currentUrl).toContain('reminders');
  });

  test('检查页面基本元素', async ({ page }) => {
    await page.goto('http://localhost:5173/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 等待一段时间让页面完全渲染
    await page.waitForTimeout(2000);
    
    // 检查常见的页面元素
    const elements = {
      buttons: await page.locator('button').count(),
      inputs: await page.locator('input').count(),
      divs: await page.locator('div').count(),
      links: await page.locator('a').count()
    };
    
    console.log('页面元素统计:', elements);
    
    // 检查是否有搜索框
    const searchInput = await page.locator('input[placeholder*="搜索"], input[type="search"]').count();
    console.log('搜索框数量:', searchInput);
    
    // 检查是否有按钮
    const addButton = await page.locator('button:has-text("添加"), button[title*="添加"]').count();
    console.log('添加按钮数量:', addButton);
    
    // 截图记录页面元素
    await page.screenshot({ path: 'test-results/page-elements.png' });
    
    // 基本断言
    expect(elements.divs).toBeGreaterThan(0);
  });
});