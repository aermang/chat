import { test, expect } from '@playwright/test';

/**
 * 用药提醒页面完整功能测试套件
 * 包含登录、页面加载、功能测试等完整流程
 */
test.describe('用药提醒页面完整功能测试', () => {
  
  /**
   * 测试前清理本地存储
   */
  test.beforeEach(async ({ page }) => {
    // 清理本地存储和IndexedDB
    await page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });
    
    // 清理IndexedDB
    await page.evaluate(async () => {
      if ('indexedDB' in window) {
        const databases = await indexedDB.databases();
        for (const db of databases) {
          indexedDB.deleteDatabase(db.name);
        }
      }
    });
  });

  /**
   * 辅助函数：用户注册和登录
   */
  async function registerAndLogin(page: any, username: string, password: string) {
    // 注册用户
    await page.goto('/register');
    await page.fill('input[name="username"]', username);
    await page.fill('input[name="password"]', password);
    await page.fill('input[name="confirmPassword"]', password);
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到聊天页面
    await page.waitForURL('/app/chats', { timeout: 10000 });
    
    // 验证用户已经在聊天页面
    await expect(page).toHaveURL('/app/chats');
    
    // 等待一段时间确保用户状态完全同步
    await page.waitForTimeout(2000);
  }

  /**
   * 测试1：页面基本加载测试
   */
  test('页面基本加载测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser1', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    
    // 等待页面加载完成
    await page.waitForLoadState('networkidle');
    
    // 验证页面标题
    await expect(page).toHaveTitle(/用药提醒/);
    
    // 验证页面URL
    await expect(page).toHaveURL('/app/special-medicine/reminders');
    
    // 验证页面主要元素存在
    await expect(page.locator('h1, h2').filter({ hasText: /用药提醒|提醒/ })).toBeVisible();
    
    // 验证搜索框存在
    await expect(page.locator('input[placeholder*="搜索"], input[type="search"]')).toBeVisible();
    
    // 验证添加按钮存在
    await expect(page.locator('button').filter({ hasText: /添加|新增/ })).toBeVisible();
  });

  /**
   * 测试2：用药提醒列表显示测试
   */
  test('用药提醒列表显示测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser2', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 检查是否有提醒列表容器
    const listContainer = page.locator('[data-testid="reminders-list"], .reminders-list, .reminder-item').first();
    
    // 如果没有数据，应该显示空状态
    const hasReminders = await listContainer.count() > 0;
    
    if (!hasReminders) {
      // 验证空状态显示
      await expect(page.locator('text=/暂无|没有|空/').or(page.locator('.empty-state'))).toBeVisible();
    } else {
      // 验证列表项显示
      await expect(listContainer).toBeVisible();
      
      // 验证列表项包含基本信息
      const firstItem = listContainer.first();
      await expect(firstItem).toBeVisible();
    }
  });

  /**
   * 测试3：搜索功能测试
   */
  test('搜索功能测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser3', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 找到搜索框
    const searchInput = page.locator('input[placeholder*="搜索"], input[type="search"]').first();
    await expect(searchInput).toBeVisible();
    
    // 测试搜索功能
    await searchInput.fill('阿司匹林');
    await page.waitForTimeout(1000); // 等待搜索结果
    
    // 验证搜索结果或空状态
    const searchResults = page.locator('.reminder-item, [data-testid="reminder-item"]');
    const resultCount = await searchResults.count();
    
    if (resultCount === 0) {
      // 验证无搜索结果的提示
      await expect(page.locator('text=/未找到|没有找到|无结果/').or(page.locator('.no-results'))).toBeVisible();
    }
    
    // 清空搜索框
    await searchInput.clear();
    await page.waitForTimeout(1000);
  });

  /**
   * 测试4：状态过滤功能测试
   */
  test('状态过滤功能测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser4', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 查找状态过滤器
    const statusFilters = page.locator('button, select, input[type="radio"]').filter({ hasText: /全部|已完成|未完成|状态/ });
    
    if (await statusFilters.count() > 0) {
      // 测试状态过滤
      const firstFilter = statusFilters.first();
      await firstFilter.click();
      await page.waitForTimeout(1000);
      
      // 验证过滤结果
      const filteredResults = page.locator('.reminder-item, [data-testid="reminder-item"]');
      // 过滤后的结果应该是可见的或显示空状态
      const hasResults = await filteredResults.count() > 0;
      if (!hasResults) {
        await expect(page.locator('text=/暂无|没有|空/').or(page.locator('.empty-state'))).toBeVisible();
      }
    }
  });

  /**
   * 测试5：添加提醒按钮测试
   */
  test('添加提醒按钮测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser5', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 找到添加按钮
    const addButton = page.locator('button').filter({ hasText: /添加|新增/ }).first();
    await expect(addButton).toBeVisible();
    
    // 点击添加按钮
    await addButton.click();
    
    // 验证是否打开了添加表单或跳转到添加页面
    await page.waitForTimeout(2000);
    
    // 检查是否出现了表单、模态框或跳转到新页面
    const hasModal = await page.locator('.modal, .dialog, [role="dialog"]').count() > 0;
    const hasForm = await page.locator('form, .form').count() > 0;
    const urlChanged = page.url() !== '/app/special-medicine/reminders';
    
    expect(hasModal || hasForm || urlChanged).toBeTruthy();
  });

  /**
   * 测试6：编辑提醒功能测试
   */
  test('编辑提醒功能测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser6', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 查找编辑按钮
    const editButtons = page.locator('button').filter({ hasText: /编辑|修改/ });
    
    if (await editButtons.count() > 0) {
      // 点击第一个编辑按钮
      await editButtons.first().click();
      await page.waitForTimeout(2000);
      
      // 验证是否打开了编辑表单
      const hasModal = await page.locator('.modal, .dialog, [role="dialog"]').count() > 0;
      const hasForm = await page.locator('form, .form').count() > 0;
      const urlChanged = page.url() !== '/app/special-medicine/reminders';
      
      expect(hasModal || hasForm || urlChanged).toBeTruthy();
    } else {
      // 如果没有编辑按钮，可能是因为没有数据
      console.log('没有找到编辑按钮，可能是因为没有提醒数据');
    }
  });

  /**
   * 测试7：删除提醒功能测试
   */
  test('删除提醒功能测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser7', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 查找删除按钮
    const deleteButtons = page.locator('button').filter({ hasText: /删除|移除/ });
    
    if (await deleteButtons.count() > 0) {
      // 点击第一个删除按钮
      await deleteButtons.first().click();
      await page.waitForTimeout(1000);
      
      // 验证是否出现确认对话框
      const confirmDialog = page.locator('.modal, .dialog, [role="dialog"]').filter({ hasText: /确认|删除/ });
      
      if (await confirmDialog.count() > 0) {
        await expect(confirmDialog).toBeVisible();
        
        // 取消删除操作
        const cancelButton = confirmDialog.locator('button').filter({ hasText: /取消|关闭/ });
        if (await cancelButton.count() > 0) {
          await cancelButton.click();
        }
      }
    } else {
      // 如果没有删除按钮，可能是因为没有数据
      console.log('没有找到删除按钮，可能是因为没有提醒数据');
    }
  });

  /**
   * 测试8：移动端响应式测试
   */
  test('移动端响应式测试', async ({ page }) => {
    // 设置移动端视口
    await page.setViewportSize({ width: 375, height: 667 });
    
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser8', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 验证页面在移动端正常显示
    await expect(page.locator('h1, h2').filter({ hasText: /用药提醒|提醒/ })).toBeVisible();
    
    // 验证搜索框在移动端可见
    const searchInput = page.locator('input[placeholder*="搜索"], input[type="search"]').first();
    await expect(searchInput).toBeVisible();
    
    // 验证添加按钮在移动端可见
    const addButton = page.locator('button').filter({ hasText: /添加|新增/ }).first();
    await expect(addButton).toBeVisible();
    
    // 测试移动端交互
    await searchInput.click();
    await expect(searchInput).toBeFocused();
  });

  /**
   * 测试9：错误处理测试
   */
  test('错误处理测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser9', '123456');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 测试网络错误处理（模拟离线状态）
    await page.context().setOffline(true);
    
    // 尝试刷新页面
    await page.reload();
    await page.waitForTimeout(3000);
    
    // 恢复网络连接
    await page.context().setOffline(false);
    
    // 再次刷新页面，验证恢复正常
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    // 验证页面正常加载
    await expect(page.locator('h1, h2').filter({ hasText: /用药提醒|提醒/ })).toBeVisible();
  });

  /**
   * 测试10：页面性能测试
   */
  test('页面性能测试', async ({ page }) => {
    // 注册并登录用户
    await registerAndLogin(page, 'reminderuser10', '123456');
    
    // 记录页面加载开始时间
    const startTime = Date.now();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 记录页面加载结束时间
    const endTime = Date.now();
    const loadTime = endTime - startTime;
    
    // 验证页面加载时间合理（小于10秒）
    expect(loadTime).toBeLessThan(10000);
    
    // 验证页面主要元素已加载
    await expect(page.locator('h1, h2').filter({ hasText: /用药提醒|提醒/ })).toBeVisible();
    
    console.log(`页面加载时间: ${loadTime}ms`);
  });
});