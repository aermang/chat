import { test, expect, Browser, BrowserContext, Page } from '@playwright/test';

/**
 * 端到端测试：两个用户互相添加好友并发送消息
 * 测试完整的用户交互流程，包括注册、登录、添加好友、发送消息等功能
 */
test.describe('端到端测试：好友添加和消息发送', () => {
  let browser: Browser;
  let context1: BrowserContext;
  let context2: BrowserContext;
  let page1: Page;
  let page2: Page;

  /**
   * 测试前准备：创建两个浏览器上下文模拟两个用户
   */
  test.beforeAll(async ({ browser: testBrowser }) => {
    browser = testBrowser;
    
    // 创建两个独立的浏览器上下文
    context1 = await browser.newContext({
      viewport: { width: 1280, height: 720 }
    });
    context2 = await browser.newContext({
      viewport: { width: 1280, height: 720 }
    });
    
    page1 = await context1.newPage();
    page2 = await context2.newPage();
  });

  /**
   * 测试后清理：关闭浏览器上下文
   */
  test.afterAll(async () => {
    await context1.close();
    await context2.close();
  });

  /**
   * 每个测试前清理数据
   */
  test.beforeEach(async () => {
    // 先导航到应用页面，然后清理数据
    await page1.goto('http://localhost:5173/');
    await page2.goto('http://localhost:5173/');
    
    // 等待页面加载完成
    await page1.waitForTimeout(1000);
    await page2.waitForTimeout(1000);
    
    // 清理两个页面的本地存储和数据库
    await page1.evaluate(() => {
      try {
        localStorage.clear();
        sessionStorage.clear();
        if ('indexedDB' in window) {
          indexedDB.deleteDatabase('wechat-app');
        }
      } catch (e) {
        console.log('清理存储时出错:', e);
      }
    });
    
    await page2.evaluate(() => {
      try {
        localStorage.clear();
        sessionStorage.clear();
        if ('indexedDB' in window) {
          indexedDB.deleteDatabase('wechat-app');
        }
      } catch (e) {
        console.log('清理存储时出错:', e);
      }
    });
  });

  /**
   * 辅助函数：用户注册
   * @param page - 页面对象
   * @param username - 用户名
   * @param password - 密码
   */
  async function registerUser(page: Page, username: string, password: string) {
    await page.goto('http://localhost:5173/');
    
    // 等待页面加载
    await page.waitForTimeout(2000);
    
    // 查找注册链接或按钮
    const registerLink = page.locator('a:has-text("立即注册")').or(page.locator('a:has-text("注册")')).or(page.locator('button:has-text("注册")')).first();
    if (await registerLink.isVisible()) {
      await registerLink.click();
    } else {
      // 直接导航到注册页面
      await page.goto('http://localhost:5173/register');
    }
    
    // 等待注册页面加载
    await page.waitForTimeout(2000);
    
    // 填写注册表单
    await page.fill('input[name="username"]', username);
    await page.fill('input[name="password"]', password);
    await page.fill('input[name="confirmPassword"]', password);
    
    // 提交注册表单
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到主页面
    await page.waitForTimeout(5000);
    
    // 验证是否成功跳转到应用页面
    const currentUrl = page.url();
    if (!currentUrl.includes('/app')) {
      // 如果没有自动跳转，手动导航到应用页面
      await page.goto('http://localhost:5173/app');
      await page.waitForTimeout(2000);
    }
  }

  /**
   * 辅助函数：用户登录
   * @param page - 页面对象
   * @param username - 用户名
   * @param password - 密码
   */
  async function loginUser(page: Page, username: string, password: string) {
    await page.goto('http://localhost:5173/');
    
    // 等待页面加载
    await page.waitForTimeout(2000);
    
    // 如果已经在登录页面，直接填写表单
    const usernameField = page.locator('input[name="username"]');
    if (await usernameField.isVisible()) {
      await usernameField.fill(username);
      await page.fill('input[name="password"]', password);
      await page.click('button[type="submit"]');
    } else {
      // 否则点击登录链接
      const loginLink = page.locator('a:has-text("立即登录")').or(page.locator('a:has-text("登录")')).or(page.locator('button:has-text("登录")')).first();
      if (await loginLink.isVisible()) {
        await loginLink.click();
        await page.waitForTimeout(1000);
        await page.fill('input[name="username"]', username);
        await page.fill('input[name="password"]', password);
        await page.click('button[type="submit"]');
      }
    }
    
    // 等待登录成功
    await page.waitForTimeout(5000);
    
    // 验证是否成功跳转到应用页面
    const currentUrl = page.url();
    if (!currentUrl.includes('/app')) {
      // 如果没有自动跳转，手动导航到应用页面
      await page.goto('http://localhost:5173/app');
      await page.waitForTimeout(2000);
    }
  }

  /**
   * 辅助函数：搜索并添加好友
   * @param page - 页面对象
   * @param searchQuery - 搜索关键词（用户名）
   */
  async function searchAndAddFriend(page: Page, searchQuery: string) {
    // 确保在应用页面
    const currentUrl = page.url();
    if (!currentUrl.includes('/app')) {
      await page.goto('http://localhost:5173/app');
      await page.waitForTimeout(2000);
    }
    
    // 进入通讯录页面
    const contactsTab = page.locator('button:has-text("通讯录")').first();
    if (await contactsTab.isVisible()) {
      await contactsTab.click();
    } else {
      await page.goto('http://localhost:5173/app/contacts');
    }
    
    // 等待页面加载
    await page.waitForTimeout(3000);
    
    // 点击添加好友按钮或新的朋友
    let addFriendClicked = false;
    
    // 尝试点击添加好友按钮
    const addFriendButton = page.locator('button:has-text("添加好友")').or(page.locator('button:has-text("添加")')).first();
    if (await addFriendButton.isVisible()) {
      await addFriendButton.click();
      addFriendClicked = true;
    }
    
    // 如果没有找到添加好友按钮，尝试点击新的朋友
    if (!addFriendClicked) {
      const newFriendsButton = page.locator('text="新的朋友"').first();
      if (await newFriendsButton.isVisible()) {
        await newFriendsButton.click();
        await page.waitForTimeout(1000);
        
        // 在新的朋友页面查找添加好友按钮
        const addButtonInNewFriends = page.locator('button:has-text("添加好友")').or(page.locator('button:has-text("添加")')).first();
        if (await addButtonInNewFriends.isVisible()) {
          await addButtonInNewFriends.click();
          addFriendClicked = true;
        }
      }
    }
    
    // 等待模态框或搜索界面打开
    await page.waitForTimeout(2000);
    
    // 在搜索框中输入搜索关键词
    const searchInput = page.locator('input[placeholder*="搜索"]').or(page.locator('input[placeholder*="用户名"]')).or(page.locator('input[type="text"]')).first();
    if (await searchInput.isVisible()) {
      await searchInput.fill(searchQuery);
      
      // 点击搜索按钮
      const searchButton = page.locator('button:has-text("搜索")').or(page.locator('button[type="submit"]')).first();
      if (await searchButton.isVisible()) {
        await searchButton.click();
      } else {
        // 如果没有搜索按钮，尝试按回车
        await searchInput.press('Enter');
      }
      
      // 等待搜索结果
      await page.waitForTimeout(3000);
      
      // 点击添加好友按钮
      const addButton = page.locator('button:has-text("添加")').or(page.locator('button:has-text("发送申请")')).first();
      if (await addButton.isVisible()) {
        await addButton.click();
        
        // 如果有消息输入框，填写申请消息
        await page.waitForTimeout(1000);
        const messageInput = page.locator('textarea[placeholder*="申请消息"], input[placeholder*="申请消息"]');
        if (await messageInput.isVisible()) {
          await messageInput.fill('你好，我想添加你为好友');
          const sendButton = page.locator('button:has-text("发送")').or(page.locator('button:has-text("确认")')).first();
          if (await sendButton.isVisible()) {
            await sendButton.click();
          }
        }
      }
    }
  }

  /**
   * 辅助函数：接受好友申请
   * @param page - 页面对象
   */
  async function acceptFriendRequest(page: Page) {
    // 确保在应用页面
    const currentUrl = page.url();
    if (!currentUrl.includes('/app')) {
      await page.goto('http://localhost:5173/app');
      await page.waitForTimeout(2000);
    }
    
    // 进入通讯录页面
    const contactsTab = page.locator('button:has-text("通讯录")').first();
    if (await contactsTab.isVisible()) {
      await contactsTab.click();
    }
    
    // 等待页面加载
    await page.waitForTimeout(3000);
    
    // 点击新的朋友
    const newFriendsButton = page.locator('text="新的朋友"').first();
    if (await newFriendsButton.isVisible()) {
      await newFriendsButton.click();
      
      // 等待好友申请列表加载
      await page.waitForTimeout(3000);
      
      // 点击接受按钮
      const acceptButton = page.locator('button:has-text("接受")').or(page.locator('button:has-text("同意")')).first();
      if (await acceptButton.isVisible()) {
        await acceptButton.click();
      }
    }
  }

  /**
   * 辅助函数：发送消息
   * @param page - 页面对象
   * @param friendName - 好友名称
   * @param message - 消息内容
   */
  async function sendMessage(page: Page, friendName: string, message: string) {
    // 确保在应用页面
    const currentUrl = page.url();
    if (!currentUrl.includes('/app')) {
      await page.goto('http://localhost:5173/app');
      await page.waitForTimeout(2000);
    }
    
    // 进入消息页面（微信标签）
    const messagesTab = page.locator('button:has-text("微信")').first();
    if (await messagesTab.isVisible()) {
      await messagesTab.click();
    } else {
      await page.goto('http://localhost:5173/app/chats');
    }
    
    // 等待页面加载
    await page.waitForTimeout(3000);
    
    // 查找好友聊天项或创建新聊天
    const friendChatItem = page.locator(`text="${friendName}"`).first();
    if (await friendChatItem.isVisible()) {
      await friendChatItem.click();
    } else {
      // 如果没有聊天记录，从通讯录进入聊天
      await page.click('button:has-text("通讯录")');
      await page.waitForTimeout(2000);
      
      const friendItem = page.locator(`text="${friendName}"`).first();
      if (await friendItem.isVisible()) {
        await friendItem.click();
        
        // 查找发消息按钮
        const chatButton = page.locator('button:has-text("发消息")').or(page.locator('button:has-text("聊天")')).first();
        if (await chatButton.isVisible()) {
          await chatButton.click();
        }
      }
    }
    
    // 等待聊天页面加载
    await page.waitForTimeout(3000);
    
    // 在消息输入框中输入消息
    const messageInput = page.locator('textarea[placeholder*="输入消息"]').or(page.locator('input[placeholder*="输入消息"]')).or(page.locator('textarea')).or(page.locator('input[type="text"]')).last();
    if (await messageInput.isVisible()) {
      await messageInput.fill(message);
      
      // 发送消息
      const sendButton = page.locator('button:has-text("发送")').or(page.locator('button[type="submit"]')).first();
      if (await sendButton.isVisible()) {
        await sendButton.click();
      } else {
        // 如果没有发送按钮，尝试按回车
        await messageInput.press('Enter');
      }
      
      // 验证消息已发送
      await page.waitForTimeout(2000);
    }
  }

  /**
   * 主测试：完整的好友添加和消息发送流程
   */
  test('完整流程：test1和test2互相添加好友并发送消息', async () => {
    console.log('开始端到端测试：两个用户互相添加好友并发送消息');
    
    // 步骤1：注册test1用户
    console.log('步骤1：注册test1用户');
    await registerUser(page1, 'test1', '123456');
    
    // 步骤2：注册test2用户
    console.log('步骤2：注册test2用户');
    await registerUser(page2, 'test2', '123456');
    
    // 步骤3：test1搜索并添加test2为好友
    console.log('步骤3：test1搜索并添加test2为好友');
    await searchAndAddFriend(page1, 'test2');
    
    // 等待一段时间确保好友申请已发送
    await page1.waitForTimeout(5000);
    
    // 步骤4：test2接受好友申请
    console.log('步骤4：test2接受好友申请');
    await acceptFriendRequest(page2);
    
    // 等待一段时间确保好友关系已建立
    await page2.waitForTimeout(5000);
    
    // 步骤5：test1发送消息给test2
    console.log('步骤5：test1发送消息给test2');
    const message1 = '你好，我是test1！';
    await sendMessage(page1, 'test2', message1);
    
    // 步骤6：test2回复消息给test1
    console.log('步骤6：test2回复消息给test1');
    const message2 = '你好test1，我是test2！';
    await sendMessage(page2, 'test1', message2);
    
    // 步骤7：验证test1能看到test2的回复
    console.log('步骤7：验证消息接收');
    await page1.reload();
    await page1.waitForTimeout(3000);
    
    // 进入与test2的聊天
    await page1.click('button:has-text("微信")');
    await page1.waitForTimeout(2000);
    const test2Chat = page1.locator('text="test2"').first();
    if (await test2Chat.isVisible()) {
      await test2Chat.click();
      await page1.waitForTimeout(2000);
      // 验证能看到test2的消息
      const messageExists = await page1.locator(`text="${message2}"`).isVisible();
      if (messageExists) {
        console.log('✓ test1成功看到test2的消息');
      }
    }
    
    // 步骤8：验证test2能看到test1的消息
    await page2.reload();
    await page2.waitForTimeout(3000);
    
    await page2.click('button:has-text("微信")');
    await page2.waitForTimeout(2000);
    const test1Chat = page2.locator('text="test1"').first();
    if (await test1Chat.isVisible()) {
      await test1Chat.click();
      await page2.waitForTimeout(2000);
      // 验证能看到test1的消息
      const messageExists = await page2.locator(`text="${message1}"`).isVisible();
      if (messageExists) {
        console.log('✓ test2成功看到test1的消息');
      }
    }
    
    console.log('端到端测试完成：所有步骤执行成功');
  });

  /**
   * 测试：验证好友列表显示
   */
  test('验证好友列表显示', async () => {
    // 先执行好友添加流程
    await registerUser(page1, 'user1', '123456');
    await registerUser(page2, 'user2', '123456');
    
    await searchAndAddFriend(page1, 'user2');
    await page1.waitForTimeout(3000);
    await acceptFriendRequest(page2);
    await page2.waitForTimeout(3000);
    
    // 验证user1的好友列表中有user2
    await page1.click('button:has-text("通讯录")');
    await page1.waitForTimeout(2000);
    const user2Exists = await page1.locator('text="user2"').isVisible();
    if (user2Exists) {
      console.log('✓ user1的好友列表中显示user2');
    }
    
    // 验证user2的好友列表中有user1
    await page2.click('button:has-text("通讯录")');
    await page2.waitForTimeout(2000);
    const user1Exists = await page2.locator('text="user1"').isVisible();
    if (user1Exists) {
      console.log('✓ user2的好友列表中显示user1');
    }
  });

  /**
   * 测试：验证消息历史记录
   */
  test('验证消息历史记录', async () => {
    // 先建立好友关系
    await registerUser(page1, 'history1', '123456');
    await registerUser(page2, 'history2', '123456');
    
    await searchAndAddFriend(page1, 'history2');
    await page1.waitForTimeout(3000);
    await acceptFriendRequest(page2);
    await page2.waitForTimeout(5000);
    
    // 发送多条消息
    const messages = [
      '第一条消息',
      '第二条消息',
      '第三条消息'
    ];
    
    for (const message of messages) {
      await sendMessage(page1, 'history2', message);
      await page1.waitForTimeout(2000);
    }
    
    // 验证消息历史记录
    await page2.reload();
    await page2.waitForTimeout(3000);
    await page2.click('button:has-text("微信")');
    await page2.waitForTimeout(2000);
    
    const chatItem = page2.locator('text="history1"').first();
    if (await chatItem.isVisible()) {
      await chatItem.click();
      await page2.waitForTimeout(2000);
      
      // 验证所有消息都能看到
      let allMessagesVisible = true;
      for (const message of messages) {
        const messageVisible = await page2.locator(`text="${message}"`).isVisible();
        if (!messageVisible) {
          allMessagesVisible = false;
          break;
        }
      }
      
      if (allMessagesVisible) {
        console.log('✓ 所有历史消息都能正确显示');
      }
    }
  });
});