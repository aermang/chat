import { test, expect } from '@playwright/test';

/**
 * 好友管理功能测试套件
 * 测试好友添加、搜索、管理等功能
 */
test.describe('好友管理功能', () => {
  
  /**
   * 测试前准备：创建测试用户并登录
   */
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
      if ('indexedDB' in window) {
        indexedDB.deleteDatabase('wechat-app');
      }
    });
    
    // 注册并登录主测试用户
    await page.goto('/register');
    await page.fill('input[type="email"]', 'user1@example.com');
    await page.fill('input[name="nickname"]', '用户一');
    await page.fill('input[type="password"]', 'User123456');
    await page.fill('input[name="confirmPassword"]', 'User123456');
    await page.click('button[type="submit"]');
    
    // 等待登录成功
    await expect(page).toHaveURL('/main/messages');
  });

  /**
   * 测试通讯录页面显示
   */
  test('通讯录页面显示', async ({ page }) => {
    // 点击通讯录标签
    await page.click('text=通讯录');
    await expect(page).toHaveURL('/main/contacts');
    
    // 验证页面标题
    await expect(page.locator('h1:has-text("通讯录")')).toBeVisible();
    
    // 验证搜索框存在
    await expect(page.locator('input[placeholder*="搜索"]')).toBeVisible();
    
    // 验证添加好友按钮存在
    await expect(page.locator('text=添加好友')).toBeVisible();
  });

  /**
   * 测试好友搜索功能
   */
  test('好友搜索功能', async ({ page }) => {
    // 先创建一些测试好友数据
    await page.evaluate(() => {
      // 模拟添加好友数据到IndexedDB
      const friends = [
        { id: '1', nickname: '张三', email: 'zhangsan@example.com', avatar: '' },
        { id: '2', nickname: '李四', email: 'lisi@example.com', avatar: '' },
        { id: '3', nickname: '王五', email: 'wangwu@example.com', avatar: '' }
      ];
      
      // 这里应该调用实际的数据库操作
      localStorage.setItem('test-friends', JSON.stringify(friends));
    });
    
    await page.goto('/main/contacts');
    
    // 测试搜索功能
    const searchInput = page.locator('input[placeholder*="搜索"]');
    await searchInput.fill('张三');
    
    // 验证搜索结果
    await expect(page.locator('text=张三')).toBeVisible();
    
    // 清空搜索，验证显示所有好友
    await searchInput.clear();
    await expect(page.locator('text=李四')).toBeVisible();
    await expect(page.locator('text=王五')).toBeVisible();
  });

  /**
   * 测试添加好友流程
   */
  test('添加好友流程', async ({ page }) => {
    await page.goto('/main/contacts');
    
    // 点击添加好友按钮
    await page.click('text=添加好友');
    
    // 验证跳转到添加好友页面或弹出搜索框
    const searchModal = page.locator('[data-testid="add-friend-modal"]');
    const searchInput = page.locator('input[placeholder*="搜索用户"]');
    
    if (await searchModal.isVisible()) {
      // 如果是模态框形式
      await expect(searchInput).toBeVisible();
      
      // 搜索用户
      await searchInput.fill('test@example.com');
      await page.click('button:has-text("搜索")');
      
      // 验证搜索结果显示
      await expect(page.locator('text=未找到用户')).toBeVisible();
    } else {
      // 如果跳转到新页面
      await expect(page).toHaveURL(/add-friend/);
      await expect(searchInput).toBeVisible();
    }
  });

  /**
   * 测试好友列表显示
   */
  test('好友列表显示', async ({ page }) => {
    await page.goto('/main/contacts');
    
    // 验证好友列表容器存在
    await expect(page.locator('[data-testid="friends-list"]')).toBeVisible();
    
    // 如果没有好友，应该显示空状态
    const emptyState = page.locator('text=暂无好友');
    const friendsList = page.locator('[data-testid="friend-item"]');
    
    const friendsCount = await friendsList.count();
    if (friendsCount === 0) {
      await expect(emptyState).toBeVisible();
    } else {
      // 验证好友项包含必要信息
      const firstFriend = friendsList.first();
      await expect(firstFriend.locator('.avatar')).toBeVisible();
      await expect(firstFriend.locator('.nickname')).toBeVisible();
    }
  });

  /**
   * 测试好友详情查看
   */
  test('好友详情查看', async ({ page }) => {
    // 先模拟添加一个好友
    await page.evaluate(() => {
      const friend = {
        id: 'friend-1',
        nickname: '测试好友',
        email: 'friend@example.com',
        avatar: '',
        signature: '这是个性签名'
      };
      localStorage.setItem('test-friend-detail', JSON.stringify(friend));
    });
    
    await page.goto('/main/contacts');
    
    // 如果有好友，点击查看详情
    const friendItem = page.locator('[data-testid="friend-item"]').first();
    if (await friendItem.isVisible()) {
      await friendItem.click();
      
      // 验证好友详情页面或模态框
      const detailModal = page.locator('[data-testid="friend-detail"]');
      if (await detailModal.isVisible()) {
        await expect(detailModal.locator('.nickname')).toBeVisible();
        await expect(detailModal.locator('.email')).toBeVisible();
      }
    }
  });

  /**
   * 测试好友分组功能（如果实现了）
   */
  test('好友分组功能', async ({ page }) => {
    await page.goto('/main/contacts');
    
    // 检查是否有分组功能
    const groupHeaders = page.locator('[data-testid="friend-group"]');
    const groupCount = await groupHeaders.count();
    
    if (groupCount > 0) {
      // 验证默认分组存在
      await expect(page.locator('text=我的好友')).toBeVisible();
      
      // 测试分组展开/收起
      const firstGroup = groupHeaders.first();
      await firstGroup.click();
      
      // 验证分组状态变化
      await expect(firstGroup).toHaveAttribute('data-expanded', 'false');
    }
  });

  /**
   * 测试好友在线状态显示
   */
  test('好友在线状态显示', async ({ page }) => {
    await page.goto('/main/contacts');
    
    // 验证在线状态指示器
    const friendItems = page.locator('[data-testid="friend-item"]');
    const friendCount = await friendItems.count();
    
    if (friendCount > 0) {
      const firstFriend = friendItems.first();
      
      // 检查在线状态指示器
      const onlineIndicator = firstFriend.locator('.online-status');
      if (await onlineIndicator.isVisible()) {
        // 验证状态样式
        await expect(onlineIndicator).toHaveClass(/online|offline/);
      }
    }
  });

  /**
   * 测试删除好友功能
   */
  test('删除好友功能', async ({ page }) => {
    // 先添加一个测试好友
    await page.evaluate(() => {
      const friend = {
        id: 'delete-test',
        nickname: '待删除好友',
        email: 'delete@example.com'
      };
      const friends = [friend];
      localStorage.setItem('friends-data', JSON.stringify(friends));
    });
    
    await page.goto('/main/contacts');
    
    // 查找好友项
    const friendItem = page.locator('[data-testid="friend-item"]:has-text("待删除好友")');
    
    if (await friendItem.isVisible()) {
      // 长按或右键点击好友项
      await friendItem.click({ button: 'right' });
      
      // 查找删除选项
      const deleteOption = page.locator('text=删除好友');
      if (await deleteOption.isVisible()) {
        await deleteOption.click();
        
        // 确认删除
        const confirmButton = page.locator('button:has-text("确认")');
        if (await confirmButton.isVisible()) {
          await confirmButton.click();
          
          // 验证好友已被删除
          await expect(friendItem).not.toBeVisible();
        }
      }
    }
  });

  /**
   * 测试好友备注功能
   */
  test('好友备注功能', async ({ page }) => {
    await page.goto('/main/contacts');
    
    // 查找好友项
    const friendItem = page.locator('[data-testid="friend-item"]').first();
    
    if (await friendItem.isVisible()) {
      // 点击进入好友详情
      await friendItem.click();
      
      // 查找编辑备注按钮
      const editRemarkButton = page.locator('button:has-text("设置备注")');
      if (await editRemarkButton.isVisible()) {
        await editRemarkButton.click();
        
        // 输入备注
        const remarkInput = page.locator('input[placeholder*="备注"]');
        await remarkInput.fill('测试备注名称');
        
        // 保存备注
        await page.click('button:has-text("保存")');
        
        // 验证备注已保存
        await expect(page.locator('text=测试备注名称')).toBeVisible();
      }
    }
  });
});