import { test, expect, Page } from '@playwright/test';

/**
 * 用药提醒页面自动化测试
 * 测试用药提醒页面的所有核心功能
 */

// 测试数据准备
const testPatient = {
  name: '测试患者',
  phone: '13800138000',
  doctor: '测试医生',
  diagnosis: '测试诊断'
};

const testReminder = {
  medicineName: '测试药品',
  dosage: '1片',
  reminderTime: '08:00',
  frequency: 'daily'
};

test.describe('用药提醒页面功能测试', () => {
  
  test.beforeEach(async ({ page }) => {
    // 每个测试前的准备工作
    await page.goto('/');
    
    // 等待页面加载完成
    await page.waitForLoadState('networkidle');
    
    // 导航到特药管理页面
    await page.click('text=特药管理');
    await page.waitForTimeout(1000);
    
    // 导航到用药提醒页面
    await page.click('text=用药提醒');
    await page.waitForTimeout(2000);
  });

  test('页面基本加载测试', async ({ page }) => {
    // 验证页面标题
    await expect(page.locator('h1, .page-title')).toContainText('用药提醒');
    
    // 验证主要UI元素存在
    await expect(page.locator('[data-testid="search-input"], input[placeholder*="搜索"]')).toBeVisible();
    await expect(page.locator('button:has-text("添加提醒"), [data-testid="add-reminder-btn"]')).toBeVisible();
    
    // 验证状态过滤按钮
    await expect(page.locator('button:has-text("全部")')).toBeVisible();
    await expect(page.locator('button:has-text("启用")')).toBeVisible();
    await expect(page.locator('button:has-text("停用")')).toBeVisible();
    
    // 截图记录
    await page.screenshot({ path: 'test-results/medication-reminders-loaded.png' });
  });

  test('用药提醒列表显示测试', async ({ page }) => {
    // 等待提醒列表加载
    await page.waitForTimeout(3000);
    
    // 检查是否有提醒列表或空状态
    const reminderList = page.locator('[data-testid="reminder-list"], .reminder-item, .medication-reminder');
    const emptyState = page.locator('text=暂无提醒, text=没有数据, .empty-state');
    
    const hasReminders = await reminderList.count() > 0;
    const hasEmptyState = await emptyState.isVisible();
    
    // 至少应该有列表或空状态之一
    expect(hasReminders || hasEmptyState).toBeTruthy();
    
    if (hasReminders) {
      // 如果有提醒，验证提醒项的基本信息
      const firstReminder = reminderList.first();
      await expect(firstReminder).toBeVisible();
      
      // 验证提醒项包含必要信息（药品名称、时间等）
      await expect(firstReminder.locator('text=/.*药.*|.*提醒.*/')).toBeVisible();
    }
    
    await page.screenshot({ path: 'test-results/medication-reminders-list.png' });
  });

  test('搜索功能测试', async ({ page }) => {
    // 等待页面加载
    await page.waitForTimeout(2000);
    
    // 查找搜索输入框
    const searchInput = page.locator('input[placeholder*="搜索"], [data-testid="search-input"]').first();
    await expect(searchInput).toBeVisible();
    
    // 输入搜索关键词
    await searchInput.fill('测试');
    await page.waitForTimeout(1000);
    
    // 验证搜索结果
    // 注意：由于可能没有匹配的数据，我们主要验证搜索功能不会报错
    await page.screenshot({ path: 'test-results/medication-reminders-search.png' });
    
    // 清空搜索
    await searchInput.clear();
    await page.waitForTimeout(1000);
  });

  test('状态过滤功能测试', async ({ page }) => {
    // 等待页面加载
    await page.waitForTimeout(2000);
    
    // 测试"全部"过滤
    const allButton = page.locator('button:has-text("全部")').first();
    if (await allButton.isVisible()) {
      await allButton.click();
      await page.waitForTimeout(1000);
    }
    
    // 测试"启用"过滤
    const activeButton = page.locator('button:has-text("启用")').first();
    if (await activeButton.isVisible()) {
      await activeButton.click();
      await page.waitForTimeout(1000);
    }
    
    // 测试"停用"过滤
    const inactiveButton = page.locator('button:has-text("停用")').first();
    if (await inactiveButton.isVisible()) {
      await inactiveButton.click();
      await page.waitForTimeout(1000);
    }
    
    await page.screenshot({ path: 'test-results/medication-reminders-filter.png' });
  });

  test('添加提醒按钮测试', async ({ page }) => {
    // 等待页面加载
    await page.waitForTimeout(2000);
    
    // 查找并点击添加提醒按钮
    const addButton = page.locator('button:has-text("添加提醒"), [data-testid="add-reminder-btn"], button:has-text("新增")').first();
    
    if (await addButton.isVisible()) {
      await addButton.click();
      await page.waitForTimeout(2000);
      
      // 验证是否打开了添加提醒的表单或页面
      const modal = page.locator('.modal, .dialog, [role="dialog"]');
      const form = page.locator('form, .form-container');
      const newPage = page.locator('h1:has-text("添加"), h1:has-text("新增")');
      
      const hasModal = await modal.isVisible();
      const hasForm = await form.isVisible();
      const hasNewPage = await newPage.isVisible();
      
      // 至少应该有其中一种形式的添加界面
      expect(hasModal || hasForm || hasNewPage).toBeTruthy();
      
      await page.screenshot({ path: 'test-results/medication-reminders-add-form.png' });
      
      // 如果是模态框，尝试关闭
      if (hasModal) {
        const closeButton = page.locator('button:has-text("取消"), button:has-text("关闭"), .close-btn, [aria-label="关闭"]').first();
        if (await closeButton.isVisible()) {
          await closeButton.click();
          await page.waitForTimeout(1000);
        }
      }
    }
  });

  test('响应式设计测试', async ({ page }) => {
    // 测试桌面端视图
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: 'test-results/medication-reminders-desktop.png' });
    
    // 测试平板端视图
    await page.setViewportSize({ width: 768, height: 1024 });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: 'test-results/medication-reminders-tablet.png' });
    
    // 测试移动端视图
    await page.setViewportSize({ width: 375, height: 667 });
    await page.waitForTimeout(1000);
    
    // 验证移动端布局
    await expect(page.locator('body')).toBeVisible();
    await page.screenshot({ path: 'test-results/medication-reminders-mobile.png' });
    
    // 恢复桌面端视图
    await page.setViewportSize({ width: 1280, height: 720 });
  });

  test('错误处理测试', async ({ page }) => {
    // 监听控制台错误
    const consoleErrors: string[] = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });
    
    // 监听页面错误
    const pageErrors: string[] = [];
    page.on('pageerror', error => {
      pageErrors.push(error.message);
    });
    
    // 等待页面完全加载
    await page.waitForTimeout(5000);
    
    // 尝试一些可能触发错误的操作
    try {
      // 快速点击多个按钮
      const buttons = await page.locator('button').all();
      for (let i = 0; i < Math.min(buttons.length, 3); i++) {
        if (await buttons[i].isVisible()) {
          await buttons[i].click();
          await page.waitForTimeout(500);
        }
      }
    } catch (error) {
      console.log('按钮点击测试中的预期错误:', error);
    }
    
    // 验证没有严重的JavaScript错误
    const criticalErrors = consoleErrors.filter(error => 
      error.includes('TypeError') || 
      error.includes('ReferenceError') || 
      error.includes('Cannot read properties of undefined')
    );
    
    const criticalPageErrors = pageErrors.filter(error => 
      error.includes('TypeError') || 
      error.includes('ReferenceError')
    );
    
    // 记录发现的错误
    if (criticalErrors.length > 0) {
      console.log('发现控制台错误:', criticalErrors);
    }
    if (criticalPageErrors.length > 0) {
      console.log('发现页面错误:', criticalPageErrors);
    }
    
    await page.screenshot({ path: 'test-results/medication-reminders-error-test.png' });
    
    // 如果有严重错误，测试应该失败
    expect(criticalErrors.length + criticalPageErrors.length).toBe(0);
  });

  test('页面性能测试', async ({ page }) => {
    // 记录页面加载时间
    const startTime = Date.now();
    
    await page.goto('/');
    await page.click('text=特药管理');
    await page.click('text=用药提醒');
    await page.waitForLoadState('networkidle');
    
    const loadTime = Date.now() - startTime;
    
    // 验证页面加载时间合理（小于10秒）
    expect(loadTime).toBeLessThan(10000);
    
    console.log(`页面加载时间: ${loadTime}ms`);
    
    await page.screenshot({ path: 'test-results/medication-reminders-performance.png' });
  });
});

test.describe('用药提醒页面移动端测试', () => {
  test.use({ 
    viewport: { width: 375, height: 667 },
    isMobile: true,
    hasTouch: true
  });

  test('移动端基本功能测试', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    // 导航到用药提醒页面
    await page.click('text=特药管理');
    await page.waitForTimeout(1000);
    await page.click('text=用药提醒');
    await page.waitForTimeout(2000);
    
    // 验证移动端布局
    await expect(page.locator('body')).toBeVisible();
    
    // 测试触摸交互
    const searchInput = page.locator('input[placeholder*="搜索"]').first();
    if (await searchInput.isVisible()) {
      await searchInput.tap();
      await page.waitForTimeout(500);
    }
    
    await page.screenshot({ path: 'test-results/medication-reminders-mobile-test.png' });
  });
});