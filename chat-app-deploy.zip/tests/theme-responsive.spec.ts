import { test, expect } from '@playwright/test';

/**
 * 主题切换和响应式设计测试套件
 * 测试深色/浅色主题切换、响应式布局、移动端适配等功能
 */
test.describe('主题切换和响应式设计', () => {
  
  /**
   * 测试前准备：创建测试用户并登录
   */
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
      if ('indexedDB' in window) {
        indexedDB.deleteDatabase('wechat-app');
      }
    });
    
    // 注册并登录测试用户
    await page.goto('/register');
    await page.fill('input[name="username"]', 'themetest');
    await page.fill('input[type="password"]', 'Theme123456');
    await page.fill('input[name="confirmPassword"]', 'Theme123456');
    await page.click('button[type="submit"]');
    
    // 等待注册成功并跳转到应用主页
    await page.waitForURL('/app/chats', { timeout: 10000 });
  });

  /**
   * 测试默认主题显示
   */
  test('默认主题显示', async ({ page }) => {
    // 验证默认主题（通常是浅色主题）
    const body = page.locator('body');
    const htmlElement = page.locator('html');
    
    // 检查是否有主题相关的类名
    const bodyClass = await body.getAttribute('class');
    const htmlClass = await htmlElement.getAttribute('class');
    
    // 验证默认主题样式
    expect(bodyClass || htmlClass).not.toContain('dark');
    
    // 验证背景色为浅色
    const backgroundColor = await body.evaluate(el => 
      window.getComputedStyle(el).backgroundColor
    );
    
    // 浅色主题背景应该是白色或浅色
    expect(backgroundColor).toMatch(/(rgb\(255, 255, 255\)|rgb\(248, 249, 250\)|white)/);
  });

  /**
   * 测试主题切换按钮存在
   */
  test('主题切换按钮存在', async ({ page }) => {
    // 导航到个人中心页面
    await page.click('button:has-text("我")');
    await page.waitForTimeout(1000);
    
    // 验证主题切换选项存在
    const themeToggle = page.locator('text=深色模式');
    await expect(themeToggle).toBeVisible();
  });

  /**
   * 测试切换到深色主题
   */
  test('切换到深色主题', async ({ page }) => {
    // 导航到个人中心页面
    await page.click('button:has-text("我")');
    await page.waitForTimeout(1000);
    
    // 查找并点击主题切换按钮
    const darkModeSwitch = page.locator('text=深色模式');
    await darkModeSwitch.click();
    
    // 等待主题切换完成
    await page.waitForTimeout(1000);
    
    // 验证深色主题已应用
    const htmlElement = page.locator('html');
    const htmlClass = await htmlElement.getAttribute('class');
    
    // 验证深色主题类名
    expect(htmlClass).toContain('dark');
  });

  /**
   * 测试主题切换持久化
   */
  test('主题切换持久化', async ({ page }) => {
    // 切换到深色主题
    await page.click('button:has-text("我")');
    await page.waitForTimeout(1000);
    
    const themeToggle = page.locator('text=深色模式');
    await themeToggle.click();
    await page.waitForTimeout(1000);
    
    // 刷新页面
    await page.reload();
    await page.waitForTimeout(2000);
    
    // 验证主题设置被保持
    const htmlElement = page.locator('html');
    const htmlClass = await htmlElement.getAttribute('class');
    
    // 验证深色主题类名仍然存在
    expect(htmlClass).toContain('dark');
  });

  /**
   * 测试桌面端响应式布局
   */
  test('桌面端响应式布局', async ({ page }) => {
    // 设置桌面端视口
    await page.setViewportSize({ width: 1920, height: 1080 });
    
    // 验证桌面端布局
    const sidebar = page.locator('[data-testid="sidebar"]');
    const mainContent = page.locator('[data-testid="main-content"]');
    const navigation = page.locator('[data-testid="navigation"]');
    
    // 桌面端应该显示侧边栏
    if (await sidebar.isVisible()) {
      await expect(sidebar).toBeVisible();
      
      // 验证侧边栏宽度
      const sidebarWidth = await sidebar.evaluate(el => el.offsetWidth);
      expect(sidebarWidth).toBeGreaterThan(200);
    }
    
    // 验证主内容区域
    if (await mainContent.isVisible()) {
      const contentWidth = await mainContent.evaluate(el => el.offsetWidth);
      expect(contentWidth).toBeGreaterThan(600);
    }
  });

  /**
   * 测试平板端响应式布局
   */
  test('平板端响应式布局', async ({ page }) => {
    // 设置平板端视口
    await page.setViewportSize({ width: 768, height: 1024 });
    
    // 验证平板端布局适配
    const container = page.locator('.container, [data-testid="app-container"]');
    
    if (await container.isVisible()) {
      const containerWidth = await container.evaluate(el => el.offsetWidth);
      expect(containerWidth).toBeLessThanOrEqual(768);
    }
    
    // 验证导航栏在平板端的显示
    const navigation = page.locator('[data-testid="navigation"]');
    if (await navigation.isVisible()) {
      // 平板端可能显示为底部导航或折叠导航
      const navPosition = await navigation.evaluate(el => 
        window.getComputedStyle(el).position
      );
      
      expect(['fixed', 'absolute', 'relative']).toContain(navPosition);
    }
  });

  /**
   * 测试移动端响应式布局
   */
  test('移动端响应式布局', async ({ page }) => {
    // 设置移动端视口
    await page.setViewportSize({ width: 375, height: 667 });
    
    // 验证移动端布局
    const body = page.locator('body');
    const bodyWidth = await body.evaluate(el => el.offsetWidth);
    
    expect(bodyWidth).toBeLessThanOrEqual(375);
    
    // 验证底部导航栏
    const bottomNav = page.locator('[data-testid="bottom-navigation"]');
    if (await bottomNav.isVisible()) {
      await expect(bottomNav).toBeVisible();
      
      // 验证底部导航的位置
      const navPosition = await bottomNav.evaluate(el => 
        window.getComputedStyle(el).position
      );
      expect(navPosition).toBe('fixed');
      
      // 验证底部导航的bottom值
      const bottomValue = await bottomNav.evaluate(el => 
        window.getComputedStyle(el).bottom
      );
      expect(bottomValue).toBe('0px');
    }
  });

  /**
   * 测试移动端触摸交互
   */
  test('移动端触摸交互', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });
    
    // 测试滑动手势
    const chatList = page.locator('[data-testid="chat-list"]');
    if (await chatList.isVisible()) {
      // 模拟向下滑动刷新
      await chatList.hover();
      await page.mouse.down();
      await page.mouse.move(375/2, 100);
      await page.mouse.up();
      
      // 验证刷新指示器或效果
      const refreshIndicator = page.locator('[data-testid="refresh-indicator"]');
      if (await refreshIndicator.isVisible()) {
        await expect(refreshIndicator).toBeVisible();
      }
    }
    
    // 测试长按手势
    const messageItem = page.locator('[data-testid="chat-item"]').first();
    if (await messageItem.isVisible()) {
      // 长按聊天项
      await messageItem.click({ button: 'right' });
      
      // 验证上下文菜单
      const contextMenu = page.locator('[data-testid="context-menu"]');
      if (await contextMenu.isVisible()) {
        await expect(contextMenu).toBeVisible();
      }
    }
  });

  /**
   * 测试横屏模式适配
   */
  test('横屏模式适配', async ({ page }) => {
    // 设置横屏视口
    await page.setViewportSize({ width: 667, height: 375 });
    
    // 验证横屏布局
    const container = page.locator('[data-testid="app-container"]');
    if (await container.isVisible()) {
      const containerHeight = await container.evaluate(el => el.offsetHeight);
      expect(containerHeight).toBeLessThanOrEqual(375);
    }
    
    // 验证导航栏在横屏模式下的适配
    const navigation = page.locator('[data-testid="navigation"]');
    if (await navigation.isVisible()) {
      // 横屏模式可能将导航栏移到侧边
      const navWidth = await navigation.evaluate(el => el.offsetWidth);
      const navHeight = await navigation.evaluate(el => el.offsetHeight);
      
      // 验证导航栏尺寸合理
      expect(navWidth).toBeGreaterThan(0);
      expect(navHeight).toBeGreaterThan(0);
    }
  });

  /**
   * 测试字体大小响应式
   */
  test('字体大小响应式', async ({ page }) => {
    // 测试不同屏幕尺寸下的字体大小
    const sizes = [
      { width: 375, height: 667, name: '移动端' },
      { width: 768, height: 1024, name: '平板端' },
      { width: 1920, height: 1080, name: '桌面端' }
    ];
    
    for (const size of sizes) {
      await page.setViewportSize({ width: size.width, height: size.height });
      
      // 检查标题字体大小
      const title = page.locator('h1').first();
      if (await title.isVisible()) {
        const fontSize = await title.evaluate(el => 
          window.getComputedStyle(el).fontSize
        );
        
        const fontSizeValue = parseInt(fontSize);
        expect(fontSizeValue).toBeGreaterThan(12);
        expect(fontSizeValue).toBeLessThan(48);
      }
      
      // 检查正文字体大小
      const bodyText = page.locator('p, span').first();
      if (await bodyText.isVisible()) {
        const fontSize = await bodyText.evaluate(el => 
          window.getComputedStyle(el).fontSize
        );
        
        const fontSizeValue = parseInt(fontSize);
        expect(fontSizeValue).toBeGreaterThan(10);
        expect(fontSizeValue).toBeLessThan(24);
      }
    }
  });

  /**
   * 测试图片响应式显示
   */
  test('图片响应式显示', async ({ page }) => {
    // 导航到朋友圈查看图片
    await page.click('text=朋友圈');
    
    // 查找图片元素
    const images = page.locator('img');
    const imageCount = await images.count();
    
    if (imageCount > 0) {
      const firstImage = images.first();
      
      // 测试不同屏幕尺寸下的图片显示
      const sizes = [375, 768, 1920];
      
      for (const width of sizes) {
        await page.setViewportSize({ width, height: 667 });
        
        if (await firstImage.isVisible()) {
          const imageWidth = await firstImage.evaluate(el => el.offsetWidth);
          const containerWidth = await page.evaluate(() => window.innerWidth);
          
          // 图片宽度不应超过容器宽度
          expect(imageWidth).toBeLessThanOrEqual(containerWidth);
          
          // 图片应该有合理的最小宽度
          expect(imageWidth).toBeGreaterThan(50);
        }
      }
    }
  });

  /**
   * 测试输入框响应式
   */
  test('输入框响应式', async ({ page }) => {
    // 进入聊天界面
    await page.goto('/chat/test-user');
    
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    
    if (await messageInput.isVisible()) {
      // 测试不同屏幕尺寸下的输入框
      const sizes = [
        { width: 375, height: 667 },
        { width: 768, height: 1024 },
        { width: 1920, height: 1080 }
      ];
      
      for (const size of sizes) {
        await page.setViewportSize(size);
        
        const inputWidth = await messageInput.evaluate(el => el.offsetWidth);
        const containerWidth = await page.evaluate(() => window.innerWidth);
        
        // 输入框宽度应该适应容器
        expect(inputWidth).toBeLessThan(containerWidth);
        expect(inputWidth).toBeGreaterThan(containerWidth * 0.5);
      }
    }
  });

  /**
   * 测试主题切换动画效果
   */
  test('主题切换动画效果', async ({ page }) => {
    // 导航到设置页面
    await page.click('text=我');
    await page.click('text=设置');
    
    // 记录切换前的样式
    const body = page.locator('body');
    const initialBackground = await body.evaluate(el => 
      window.getComputedStyle(el).backgroundColor
    );
    
    // 切换主题
    const themeToggle = page.locator('[data-testid="theme-toggle"]');
    if (await themeToggle.isVisible()) {
      await themeToggle.click();
      
      // 等待动画完成
      await page.waitForTimeout(1000);
      
      // 验证背景色已改变
      const newBackground = await body.evaluate(el => 
        window.getComputedStyle(el).backgroundColor
      );
      
      expect(newBackground).not.toBe(initialBackground);
    }
  });

  /**
   * 测试无障碍访问支持
   */
  test('无障碍访问支持', async ({ page }) => {
    // 检查重要元素的aria标签
    const buttons = page.locator('button');
    const buttonCount = await buttons.count();
    
    if (buttonCount > 0) {
      for (let i = 0; i < Math.min(buttonCount, 5); i++) {
        const button = buttons.nth(i);
        
        // 检查按钮是否有可访问的文本
        const ariaLabel = await button.getAttribute('aria-label');
        const textContent = await button.textContent();
        const title = await button.getAttribute('title');
        
        const hasAccessibleText = ariaLabel || textContent?.trim() || title;
        expect(hasAccessibleText).toBeTruthy();
      }
    }
    
    // 检查输入框的标签
    const inputs = page.locator('input, textarea');
    const inputCount = await inputs.count();
    
    if (inputCount > 0) {
      for (let i = 0; i < Math.min(inputCount, 3); i++) {
        const input = inputs.nth(i);
        
        const placeholder = await input.getAttribute('placeholder');
        const ariaLabel = await input.getAttribute('aria-label');
        const id = await input.getAttribute('id');
        
        // 输入框应该有placeholder、aria-label或关联的label
        const hasLabel = placeholder || ariaLabel || id;
        expect(hasLabel).toBeTruthy();
      }
    }
  });

  /**
   * 测试键盘导航支持
   */
  test('键盘导航支持', async ({ page }) => {
    // 测试Tab键导航
    await page.keyboard.press('Tab');
    
    // 验证焦点可见性
    const focusedElement = page.locator(':focus');
    if (await focusedElement.isVisible()) {
      // 检查焦点样式
      const outline = await focusedElement.evaluate(el => 
        window.getComputedStyle(el).outline
      );
      
      // 应该有可见的焦点指示器
      expect(outline).not.toBe('none');
    }
    
    // 测试多次Tab导航
    for (let i = 0; i < 5; i++) {
      await page.keyboard.press('Tab');
      await page.waitForTimeout(100);
    }
    
    // 验证可以通过键盘访问主要功能
    await page.keyboard.press('Enter');
    
    // 测试Escape键关闭模态框
    const modal = page.locator('[role="dialog"], .modal');
    if (await modal.isVisible()) {
      await page.keyboard.press('Escape');
      await expect(modal).not.toBeVisible();
    }
  });
});