import { test, expect } from '@playwright/test';

/**
 * 调试用药提醒页面测试
 * 用于诊断具体的功能问题
 */

test.describe('调试用药提醒页面', () => {
  
  test('检查用药提醒页面是否能正常访问', async ({ page }) => {
    // 先登录（如果需要）
    await page.goto('http://localhost:5173/login');
    await page.waitForLoadState('networkidle');
    
    // 尝试填写登录信息
    const usernameInput = await page.locator('input[type="text"], input[type="email"]').first();
    const passwordInput = await page.locator('input[type="password"]').first();
    const loginButton = await page.locator('button:has-text("登录"), button[type="submit"]').first();
    
    if (await usernameInput.isVisible()) {
      await usernameInput.fill('test@example.com');
      await passwordInput.fill('password123');
      await loginButton.click();
      await page.waitForTimeout(2000);
    }
    
    // 直接导航到用药提醒页面
    await page.goto('http://localhost:5173/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 等待页面完全加载
    await page.waitForTimeout(3000);
    
    // 截图记录页面状态
    await page.screenshot({ path: 'test-results/debug-reminders-page.png' });
    
    // 检查页面内容
    const pageContent = await page.content();
    console.log('页面内容长度:', pageContent.length);
    
    // 检查是否有错误信息
    const errorElements = await page.locator('text=Error, text=错误, text=Unexpected Application Error, text=404, text=找不到').count();
    console.log('错误元素数量:', errorElements);
    
    if (errorElements > 0) {
      const errorText = await page.locator('text=Error, text=错误, text=Unexpected Application Error, text=404, text=找不到').first().textContent();
      console.log('错误信息:', errorText);
    }
    
    // 检查页面标题
    const titleElements = await page.locator('h1, h2, h3').count();
    console.log('标题元素数量:', titleElements);
    
    if (titleElements > 0) {
      const titleText = await page.locator('h1, h2, h3').first().textContent();
      console.log('页面标题:', titleText);
    }
    
    // 检查是否有用药提醒相关的元素
    const reminderElements = await page.locator('text=用药提醒, text=提醒, text=medication, text=reminder').count();
    console.log('提醒相关元素数量:', reminderElements);
    
    // 检查是否有搜索框
    const searchInput = await page.locator('input[placeholder*="搜索"], input[type="search"]').count();
    console.log('搜索框数量:', searchInput);
    
    // 检查是否有添加按钮
    const addButton = await page.locator('button:has-text("添加"), button[title*="添加"]').count();
    console.log('添加按钮数量:', addButton);
    
    // 检查是否有列表项
    const listItems = await page.locator('[class*="reminder"], [class*="card"], [class*="item"]').count();
    console.log('列表项数量:', listItems);
    
    // 基本断言
    expect(pageContent.length).toBeGreaterThan(1000);
    expect(errorElements).toBe(0);
  });

  test('检查页面的基本交互元素', async ({ page }) => {
    await page.goto('http://localhost:5173/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(3000);
    
    // 检查所有按钮
    const buttons = await page.locator('button').all();
    console.log('页面按钮数量:', buttons.length);
    
    for (let i = 0; i < Math.min(buttons.length, 5); i++) {
      const buttonText = await buttons[i].textContent();
      const isVisible = await buttons[i].isVisible();
      console.log(`按钮 ${i + 1}: "${buttonText}" - 可见: ${isVisible}`);
    }
    
    // 检查所有输入框
    const inputs = await page.locator('input').all();
    console.log('页面输入框数量:', inputs.length);
    
    for (let i = 0; i < Math.min(inputs.length, 3); i++) {
      const placeholder = await inputs[i].getAttribute('placeholder');
      const type = await inputs[i].getAttribute('type');
      const isVisible = await inputs[i].isVisible();
      console.log(`输入框 ${i + 1}: type="${type}" placeholder="${placeholder}" - 可见: ${isVisible}`);
    }
    
    // 截图记录交互元素
    await page.screenshot({ path: 'test-results/debug-interactive-elements.png' });
  });
});