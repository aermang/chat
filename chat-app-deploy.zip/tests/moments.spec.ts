import { test, expect } from '@playwright/test';

/**
 * 朋友圈功能测试套件
 * 测试朋友圈动态发布、查看、点赞、评论等功能
 */
test.describe('朋友圈功能', () => {
  
  /**
   * 测试前准备：创建测试用户并登录
   */
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
      if ('indexedDB' in window) {
        indexedDB.deleteDatabase('wechat-app');
      }
    });
    
    // 注册并登录测试用户
    await page.goto('/register');
    await page.fill('input[type="email"]', 'moments@example.com');
    await page.fill('input[name="nickname"]', '朋友圈测试');
    await page.fill('input[type="password"]', 'Moments123456');
    await page.fill('input[name="confirmPassword"]', 'Moments123456');
    await page.click('button[type="submit"]');
    
    // 等待登录成功并导航到朋友圈
    await expect(page).toHaveURL('/main/messages');
    await page.click('text=朋友圈');
    await expect(page).toHaveURL('/main/moments');
  });

  /**
   * 测试朋友圈页面显示
   */
  test('朋友圈页面显示', async ({ page }) => {
    // 验证在朋友圈页面
    await expect(page).toHaveURL('/main/moments');
    
    // 验证页面标题
    await expect(page.locator('h1:has-text("朋友圈")')).toBeVisible();
    
    // 验证发布按钮
    await expect(page.locator('button:has-text("发布动态")')).toBeVisible();
    
    // 验证动态列表容器
    await expect(page.locator('[data-testid="moments-list"]')).toBeVisible();
  });

  /**
   * 测试空朋友圈状态
   */
  test('空朋友圈状态', async ({ page }) => {
    // 验证空状态显示
    const emptyState = page.locator('text=暂无朋友圈动态');
    const momentItems = page.locator('[data-testid="moment-item"]');
    
    const momentCount = await momentItems.count();
    if (momentCount === 0) {
      await expect(emptyState).toBeVisible();
    }
  });

  /**
   * 测试发布纯文字动态
   */
  test('发布纯文字动态', async ({ page }) => {
    // 点击发布动态按钮
    await page.click('button:has-text("发布动态")');
    
    // 验证发布弹窗显示
    await expect(page.locator('[data-testid="publish-modal"]')).toBeVisible();
    
    // 输入动态内容
    const textContent = '这是一条测试朋友圈动态，包含文字内容。';
    await page.fill('textarea[placeholder*="分享新鲜事"]', textContent);
    
    // 点击发布按钮
    await page.click('button:has-text("发布")');
    
    // 验证发布成功
    await expect(page.locator('[data-testid="publish-modal"]')).not.toBeVisible();
    
    // 验证动态显示在列表中
    await expect(page.locator(`text=${textContent}`)).toBeVisible();
    
    // 验证动态包含用户信息
    await expect(page.locator('text=朋友圈测试')).toBeVisible();
    
    // 验证时间戳
    await expect(page.locator('[data-testid="moment-time"]')).toBeVisible();
  });

  /**
   * 测试发布带图片的动态
   */
  test('发布带图片的动态', async ({ page }) => {
    await page.click('button:has-text("发布动态")');
    
    // 输入文字内容
    await page.fill('textarea[placeholder*="分享新鲜事"]', '分享一张美图');
    
    // 模拟添加图片
    const imageInput = page.locator('input[type="file"]');
    if (await imageInput.isVisible()) {
      // 创建一个测试图片文件
      const testImagePath = 'test-image.jpg';
      await imageInput.setInputFiles(testImagePath);
      
      // 验证图片预览
      await expect(page.locator('[data-testid="image-preview"]')).toBeVisible();
    } else {
      // 如果没有文件上传，点击添加图片按钮
      const addImageButton = page.locator('button:has-text("添加图片")');
      if (await addImageButton.isVisible()) {
        await addImageButton.click();
        
        // 验证图片选择界面
        await expect(page.locator('[data-testid="image-selector"]')).toBeVisible();
      }
    }
    
    // 发布动态
    await page.click('button:has-text("发布")');
    
    // 验证动态发布成功
    await expect(page.locator('text=分享一张美图')).toBeVisible();
  });

  /**
   * 测试动态点赞功能
   */
  test('动态点赞功能', async ({ page }) => {
    // 先发布一条动态
    await page.click('button:has-text("发布动态")');
    await page.fill('textarea[placeholder*="分享新鲜事"]', '测试点赞功能的动态');
    await page.click('button:has-text("发布")');
    
    // 等待动态显示
    await expect(page.locator('text=测试点赞功能的动态')).toBeVisible();
    
    // 点击点赞按钮
    const likeButton = page.locator('[data-testid="like-button"]').first();
    await likeButton.click();
    
    // 验证点赞状态变化
    await expect(likeButton).toHaveClass(/liked|active/);
    
    // 验证点赞数量显示
    const likeCount = page.locator('[data-testid="like-count"]').first();
    await expect(likeCount).toContainText('1');
    
    // 再次点击取消点赞
    await likeButton.click();
    await expect(likeButton).not.toHaveClass(/liked|active/);
    await expect(likeCount).toContainText('0');
  });

  /**
   * 测试动态评论功能
   */
  test('动态评论功能', async ({ page }) => {
    // 先发布一条动态
    await page.click('button:has-text("发布动态")');
    await page.fill('textarea[placeholder*="分享新鲜事"]', '测试评论功能的动态');
    await page.click('button:has-text("发布")');
    
    // 等待动态显示
    await expect(page.locator('text=测试评论功能的动态')).toBeVisible();
    
    // 点击评论按钮
    const commentButton = page.locator('[data-testid="comment-button"]').first();
    await commentButton.click();
    
    // 验证评论输入框显示
    const commentInput = page.locator('input[placeholder*="写评论"]');
    await expect(commentInput).toBeVisible();
    
    // 输入评论内容
    const commentText = '这是一条测试评论';
    await commentInput.fill(commentText);
    
    // 发送评论
    await page.press('input[placeholder*="写评论"]', 'Enter');
    
    // 验证评论显示
    await expect(page.locator(`text=${commentText}`)).toBeVisible();
    
    // 验证评论数量更新
    const commentCount = page.locator('[data-testid="comment-count"]').first();
    await expect(commentCount).toContainText('1');
  });

  /**
   * 测试查看评论列表
   */
  test('查看评论列表', async ({ page }) => {
    // 先发布动态并添加评论
    await page.click('button:has-text("发布动态")');
    await page.fill('textarea[placeholder*="分享新鲜事"]', '查看评论列表测试');
    await page.click('button:has-text("发布")');
    
    // 添加多条评论
    const commentButton = page.locator('[data-testid="comment-button"]').first();
    await commentButton.click();
    
    for (let i = 1; i <= 3; i++) {
      const commentInput = page.locator('input[placeholder*="写评论"]');
      await commentInput.fill(`测试评论 ${i}`);
      await page.press('input[placeholder*="写评论"]', 'Enter');
      await page.waitForTimeout(500);
    }
    
    // 验证所有评论显示
    for (let i = 1; i <= 3; i++) {
      await expect(page.locator(`text=测试评论 ${i}`)).toBeVisible();
    }
    
    // 验证评论数量
    const commentCount = page.locator('[data-testid="comment-count"]').first();
    await expect(commentCount).toContainText('3');
  });

  /**
   * 测试删除自己的动态
   */
  test('删除自己的动态', async ({ page }) => {
    // 发布一条动态
    await page.click('button:has-text("发布动态")');
    const dynamicContent = '这条动态将被删除';
    await page.fill('textarea[placeholder*="分享新鲜事"]', dynamicContent);
    await page.click('button:has-text("发布")');
    
    // 等待动态显示
    await expect(page.locator(`text=${dynamicContent}`)).toBeVisible();
    
    // 点击动态的更多选项按钮
    const moreButton = page.locator('[data-testid="moment-more"]').first();
    if (await moreButton.isVisible()) {
      await moreButton.click();
      
      // 点击删除选项
      const deleteOption = page.locator('text=删除');
      if (await deleteOption.isVisible()) {
        await deleteOption.click();
        
        // 确认删除
        const confirmButton = page.locator('button:has-text("确认删除")');
        if (await confirmButton.isVisible()) {
          await confirmButton.click();
          
          // 验证动态已被删除
          await expect(page.locator(`text=${dynamicContent}`)).not.toBeVisible();
        }
      }
    }
  });

  /**
   * 测试动态时间显示
   */
  test('动态时间显示', async ({ page }) => {
    // 发布动态
    await page.click('button:has-text("发布动态")');
    await page.fill('textarea[placeholder*="分享新鲜事"]', '时间显示测试');
    await page.click('button:has-text("发布")');
    
    // 验证时间显示
    const timeElement = page.locator('[data-testid="moment-time"]').first();
    await expect(timeElement).toBeVisible();
    
    // 验证时间格式
    const timeText = await timeElement.textContent();
    expect(timeText).toMatch(/(刚刚|分钟前|小时前|天前|\d{4}-\d{2}-\d{2})/);
  });

  /**
   * 测试动态列表滚动加载
   */
  test('动态列表滚动加载', async ({ page }) => {
    // 发布多条动态
    for (let i = 1; i <= 5; i++) {
      await page.click('button:has-text("发布动态")');
      await page.fill('textarea[placeholder*="分享新鲜事"]', `滚动测试动态 ${i}`);
      await page.click('button:has-text("发布")');
      await page.waitForTimeout(500);
    }
    
    // 验证动态列表显示
    const momentsList = page.locator('[data-testid="moments-list"]');
    await expect(momentsList).toBeVisible();
    
    // 验证最新动态在顶部
    const firstMoment = page.locator('[data-testid="moment-item"]').first();
    await expect(firstMoment.locator('text=滚动测试动态 5')).toBeVisible();
    
    // 滚动到底部
    await momentsList.evaluate(el => {
      el.scrollTop = el.scrollHeight;
    });
    
    // 验证较早的动态可见
    await expect(page.locator('text=滚动测试动态 1')).toBeVisible();
  });

  /**
   * 测试动态隐私设置
   */
  test('动态隐私设置', async ({ page }) => {
    await page.click('button:has-text("发布动态")');
    
    // 输入动态内容
    await page.fill('textarea[placeholder*="分享新鲜事"]', '隐私设置测试');
    
    // 查找隐私设置选项
    const privacyButton = page.locator('[data-testid="privacy-setting"]');
    if (await privacyButton.isVisible()) {
      await privacyButton.click();
      
      // 验证隐私选项
      await expect(page.locator('text=公开')).toBeVisible();
      await expect(page.locator('text=仅好友可见')).toBeVisible();
      await expect(page.locator('text=仅自己可见')).toBeVisible();
      
      // 选择仅好友可见
      await page.click('text=仅好友可见');
    }
    
    // 发布动态
    await page.click('button:has-text("发布")');
    
    // 验证动态发布成功
    await expect(page.locator('text=隐私设置测试')).toBeVisible();
  });

  /**
   * 测试动态搜索功能
   */
  test('动态搜索功能', async ({ page }) => {
    // 发布几条不同内容的动态
    const contents = ['搜索测试内容A', '搜索测试内容B', '其他内容'];
    
    for (const content of contents) {
      await page.click('button:has-text("发布动态")');
      await page.fill('textarea[placeholder*="分享新鲜事"]', content);
      await page.click('button:has-text("发布")');
      await page.waitForTimeout(500);
    }
    
    // 查找搜索功能
    const searchInput = page.locator('input[placeholder*="搜索朋友圈"]');
    if (await searchInput.isVisible()) {
      // 搜索特定内容
      await searchInput.fill('搜索测试内容A');
      
      // 验证搜索结果
      await expect(page.locator('text=搜索测试内容A')).toBeVisible();
      await expect(page.locator('text=其他内容')).not.toBeVisible();
      
      // 清空搜索
      await searchInput.clear();
      
      // 验证所有动态重新显示
      await expect(page.locator('text=其他内容')).toBeVisible();
    }
  });

  /**
   * 测试动态分享功能
   */
  test('动态分享功能', async ({ page }) => {
    // 发布一条动态
    await page.click('button:has-text("发布动态")');
    await page.fill('textarea[placeholder*="分享新鲜事"]', '分享功能测试');
    await page.click('button:has-text("发布")');
    
    // 查找分享按钮
    const shareButton = page.locator('[data-testid="share-button"]').first();
    if (await shareButton.isVisible()) {
      await shareButton.click();
      
      // 验证分享选项
      const shareModal = page.locator('[data-testid="share-modal"]');
      if (await shareModal.isVisible()) {
        await expect(page.locator('text=分享到聊天')).toBeVisible();
        await expect(page.locator('text=复制链接')).toBeVisible();
        
        // 测试复制链接
        await page.click('text=复制链接');
        
        // 验证复制成功提示
        await expect(page.locator('text=链接已复制')).toBeVisible();
      }
    }
  });

  /**
   * 测试动态举报功能
   */
  test('动态举报功能', async ({ page }) => {
    // 模拟其他用户的动态
    await page.evaluate(() => {
      const otherUserMoment = {
        id: 'moment-report-test',
        userId: 'other-user-id',
        userName: '其他用户',
        content: '需要举报的动态内容',
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('test-other-moment', JSON.stringify([otherUserMoment]));
    });
    
    await page.reload();
    
    // 查找其他用户的动态
    const otherMoment = page.locator('text=需要举报的动态内容');
    if (await otherMoment.isVisible()) {
      // 点击更多选项
      const moreButton = page.locator('[data-testid="moment-more"]').first();
      await moreButton.click();
      
      // 查找举报选项
      const reportOption = page.locator('text=举报');
      if (await reportOption.isVisible()) {
        await reportOption.click();
        
        // 验证举报弹窗
        const reportModal = page.locator('[data-testid="report-modal"]');
        if (await reportModal.isVisible()) {
          // 选择举报原因
          await page.click('text=不当内容');
          
          // 提交举报
          await page.click('button:has-text("提交举报")');
          
          // 验证举报成功
          await expect(page.locator('text=举报已提交')).toBeVisible();
        }
      }
    }
  });
});