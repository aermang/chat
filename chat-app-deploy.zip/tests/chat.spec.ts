import { test, expect } from '@playwright/test';

/**
 * 聊天功能测试套件
 * 测试聊天列表、消息发送接收、聊天界面等功能
 */
test.describe('聊天功能', () => {
  
  /**
   * 测试前准备：创建测试用户并登录
   */
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
      if ('indexedDB' in window) {
        indexedDB.deleteDatabase('wechat-app');
      }
    });
    
    // 注册并登录测试用户
    await page.goto('/register');
    await page.fill('input[type="email"]', 'chat@example.com');
    await page.fill('input[name="nickname"]', '聊天测试');
    await page.fill('input[type="password"]', 'Chat123456');
    await page.fill('input[name="confirmPassword"]', 'Chat123456');
    await page.click('button[type="submit"]');
    
    // 等待登录成功
    await expect(page).toHaveURL('/main/messages');
  });

  /**
   * 测试聊天列表页面显示
   */
  test('聊天列表页面显示', async ({ page }) => {
    // 验证在消息页面
    await expect(page).toHaveURL('/main/messages');
    
    // 验证页面标题
    await expect(page.locator('h1:has-text("消息")')).toBeVisible();
    
    // 验证搜索框存在
    await expect(page.locator('input[placeholder*="搜索"]')).toBeVisible();
    
    // 验证聊天列表容器存在
    await expect(page.locator('[data-testid="chat-list"]')).toBeVisible();
  });

  /**
   * 测试空聊天列表状态
   */
  test('空聊天列表状态', async ({ page }) => {
    await page.goto('/main/messages');
    
    // 验证空状态显示
    const emptyState = page.locator('text=暂无聊天记录');
    const chatItems = page.locator('[data-testid="chat-item"]');
    
    const chatCount = await chatItems.count();
    if (chatCount === 0) {
      await expect(emptyState).toBeVisible();
    }
  });

  /**
   * 测试创建新聊天
   */
  test('创建新聊天', async ({ page }) => {
    // 先创建一个好友用于聊天
    await page.evaluate(() => {
      const friend = {
        id: 'friend-chat-1',
        nickname: '聊天好友',
        email: 'chatfriend@example.com',
        avatar: ''
      };
      localStorage.setItem('test-chat-friend', JSON.stringify(friend));
    });
    
    await page.goto('/main/messages');
    
    // 查找开始聊天按钮或从通讯录进入聊天
    const newChatButton = page.locator('button:has-text("新建聊天")');
    if (await newChatButton.isVisible()) {
      await newChatButton.click();
      
      // 选择好友开始聊天
      await page.click('text=聊天好友');
      
      // 验证进入聊天界面
      await expect(page).toHaveURL(/\/chat\//);
    } else {
      // 通过通讯录进入聊天
      await page.click('text=通讯录');
      const friendItem = page.locator('text=聊天好友');
      if (await friendItem.isVisible()) {
        await friendItem.click();
        await page.click('button:has-text("发消息")');
        await expect(page).toHaveURL(/\/chat\//);
      }
    }
  });

  /**
   * 测试聊天界面显示
   */
  test('聊天界面显示', async ({ page }) => {
    // 模拟进入聊天界面
    await page.goto('/chat/test-user-id');
    
    // 验证聊天界面元素
    await expect(page.locator('[data-testid="chat-header"]')).toBeVisible();
    await expect(page.locator('[data-testid="message-list"]')).toBeVisible();
    await expect(page.locator('[data-testid="message-input"]')).toBeVisible();
    
    // 验证输入框和发送按钮
    await expect(page.locator('textarea[placeholder*="输入消息"]')).toBeVisible();
    await expect(page.locator('button:has-text("发送")')).toBeVisible();
  });

  /**
   * 测试发送文字消息
   */
  test('发送文字消息', async ({ page }) => {
    await page.goto('/chat/test-user-id');
    
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    const sendButton = page.locator('button:has-text("发送")');
    
    // 输入消息内容
    const testMessage = '这是一条测试消息';
    await messageInput.fill(testMessage);
    
    // 发送消息
    await sendButton.click();
    
    // 验证消息已发送并显示在聊天界面
    await expect(page.locator(`text=${testMessage}`)).toBeVisible();
    
    // 验证输入框已清空
    await expect(messageInput).toHaveValue('');
    
    // 验证消息气泡样式（发送的消息应该在右侧）
    const messageElement = page.locator(`[data-testid="message"]:has-text("${testMessage}")`);
    await expect(messageElement).toHaveClass(/sent|right/);
  });

  /**
   * 测试键盘快捷键发送消息
   */
  test('键盘快捷键发送消息', async ({ page }) => {
    await page.goto('/chat/test-user-id');
    
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    
    // 输入消息
    const testMessage = '快捷键发送测试';
    await messageInput.fill(testMessage);
    
    // 使用Ctrl+Enter发送消息
    await messageInput.press('Control+Enter');
    
    // 验证消息已发送
    await expect(page.locator(`text=${testMessage}`)).toBeVisible();
    await expect(messageInput).toHaveValue('');
  });

  /**
   * 测试消息时间显示
   */
  test('消息时间显示', async ({ page }) => {
    await page.goto('/chat/test-user-id');
    
    // 发送一条消息
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    await messageInput.fill('时间测试消息');
    await page.click('button:has-text("发送")');
    
    // 验证时间戳显示
    const timeElement = page.locator('[data-testid="message-time"]');
    await expect(timeElement.first()).toBeVisible();
    
    // 验证时间格式（应该显示当前时间）
    const timeText = await timeElement.first().textContent();
    expect(timeText).toMatch(/\d{2}:\d{2}/); // 匹配 HH:MM 格式
  });

  /**
   * 测试消息列表滚动
   */
  test('消息列表滚动', async ({ page }) => {
    await page.goto('/chat/test-user-id');
    
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    const messageList = page.locator('[data-testid="message-list"]');
    
    // 发送多条消息
    for (let i = 1; i <= 10; i++) {
      await messageInput.fill(`测试消息 ${i}`);
      await page.click('button:has-text("发送")');
      await page.waitForTimeout(100); // 短暂等待
    }
    
    // 验证消息列表自动滚动到底部
    const lastMessage = page.locator('text=测试消息 10');
    await expect(lastMessage).toBeVisible();
    
    // 验证滚动位置在底部
    const scrollTop = await messageList.evaluate(el => el.scrollTop);
    const scrollHeight = await messageList.evaluate(el => el.scrollHeight);
    const clientHeight = await messageList.evaluate(el => el.clientHeight);
    
    expect(scrollTop + clientHeight).toBeCloseTo(scrollHeight, 50);
  });

  /**
   * 测试消息搜索功能
   */
  test('消息搜索功能', async ({ page }) => {
    await page.goto('/main/messages');
    
    // 先发送一些测试消息
    await page.goto('/chat/test-user-id');
    const messageInput = page.locator('textarea[placeholder*="输入消息"]');
    
    await messageInput.fill('重要消息内容');
    await page.click('button:has-text("发送")');
    
    await messageInput.fill('普通消息');
    await page.click('button:has-text("发送")');
    
    // 返回消息列表
    await page.goBack();
    
    // 使用搜索功能
    const searchInput = page.locator('input[placeholder*="搜索"]');
    await searchInput.fill('重要消息');
    
    // 验证搜索结果
    await expect(page.locator('text=重要消息内容')).toBeVisible();
  });

  /**
   * 测试聊天列表项显示
   */
  test('聊天列表项显示', async ({ page }) => {
    // 模拟聊天数据
    await page.evaluate(() => {
      const chatData = {
        id: 'chat-1',
        friendId: 'friend-1',
        friendName: '测试好友',
        lastMessage: '最后一条消息',
        lastMessageTime: new Date().toISOString(),
        unreadCount: 2,
        avatar: ''
      };
      localStorage.setItem('test-chat-data', JSON.stringify([chatData]));
    });
    
    await page.goto('/main/messages');
    
    // 验证聊天列表项元素
    const chatItem = page.locator('[data-testid="chat-item"]').first();
    
    if (await chatItem.isVisible()) {
      // 验证头像
      await expect(chatItem.locator('.avatar')).toBeVisible();
      
      // 验证好友名称
      await expect(chatItem.locator('.friend-name')).toBeVisible();
      
      // 验证最后消息
      await expect(chatItem.locator('.last-message')).toBeVisible();
      
      // 验证时间
      await expect(chatItem.locator('.message-time')).toBeVisible();
      
      // 验证未读消息数量
      const unreadBadge = chatItem.locator('.unread-badge');
      if (await unreadBadge.isVisible()) {
        await expect(unreadBadge).toContainText('2');
      }
    }
  });

  /**
   * 测试点击聊天列表项进入聊天
   */
  test('点击聊天列表项进入聊天', async ({ page }) => {
    // 模拟聊天数据
    await page.evaluate(() => {
      const chatData = {
        id: 'chat-click-test',
        friendId: 'friend-click-test',
        friendName: '点击测试好友',
        lastMessage: '点击进入聊天',
        lastMessageTime: new Date().toISOString()
      };
      localStorage.setItem('test-chat-click', JSON.stringify([chatData]));
    });
    
    await page.goto('/main/messages');
    
    // 点击聊天列表项
    const chatItem = page.locator('[data-testid="chat-item"]:has-text("点击测试好友")');
    
    if (await chatItem.isVisible()) {
      await chatItem.click();
      
      // 验证进入聊天界面
      await expect(page).toHaveURL(/\/chat\//);
      
      // 验证聊天对象名称显示
      await expect(page.locator('text=点击测试好友')).toBeVisible();
    }
  });

  /**
   * 测试长按聊天列表项操作
   */
  test('长按聊天列表项操作', async ({ page }) => {
    await page.goto('/main/messages');
    
    const chatItem = page.locator('[data-testid="chat-item"]').first();
    
    if (await chatItem.isVisible()) {
      // 长按聊天项
      await chatItem.click({ button: 'right' });
      
      // 验证上下文菜单
      const contextMenu = page.locator('[data-testid="chat-context-menu"]');
      if (await contextMenu.isVisible()) {
        // 验证菜单选项
        await expect(page.locator('text=置顶聊天')).toBeVisible();
        await expect(page.locator('text=删除聊天')).toBeVisible();
        await expect(page.locator('text=标记已读')).toBeVisible();
      }
    }
  });

  /**
   * 测试删除聊天记录
   */
  test('删除聊天记录', async ({ page }) => {
    await page.goto('/main/messages');
    
    const chatItem = page.locator('[data-testid="chat-item"]').first();
    
    if (await chatItem.isVisible()) {
      // 右键点击聊天项
      await chatItem.click({ button: 'right' });
      
      // 点击删除选项
      const deleteOption = page.locator('text=删除聊天');
      if (await deleteOption.isVisible()) {
        await deleteOption.click();
        
        // 确认删除
        const confirmButton = page.locator('button:has-text("确认删除")');
        if (await confirmButton.isVisible()) {
          await confirmButton.click();
          
          // 验证聊天已被删除
          await expect(chatItem).not.toBeVisible();
        }
      }
    }
  });
});