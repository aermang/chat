import { test, expect } from '@playwright/test';

/**
 * 用药提醒页面简化功能测试套件
 * 专注于核心功能测试，避免复杂的存储操作
 */
test.describe('用药提醒页面功能测试', () => {
  
  /**
   * 辅助函数：用户注册和登录
   */
  async function registerAndLogin(page: any, username: string, password: string) {
    try {
      // 注册用户
      await page.goto('/register');
      await page.waitForLoadState('networkidle');
      
      await page.fill('input[name="username"]', username);
      await page.fill('input[name="password"]', password);
      await page.fill('input[name="confirmPassword"]', password);
      await page.click('button[type="submit"]');
      
      // 等待注册成功并跳转到聊天页面
      await page.waitForURL('/app/chats', { timeout: 15000 });
      
      // 验证用户已经在聊天页面
      await expect(page).toHaveURL('/app/chats');
      
      // 等待一段时间确保用户状态完全同步
      await page.waitForTimeout(3000);
      
      return true;
    } catch (error) {
      console.log('注册登录失败:', error);
      return false;
    }
  }

  /**
   * 测试1：页面基本访问测试
   */
  test('页面基本访问测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser1', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    
    // 等待页面加载完成
    await page.waitForLoadState('networkidle');
    
    // 验证页面URL正确
    expect(page.url()).toContain('/app/special-medicine/reminders');
    
    // 验证页面不是404错误页面
    const pageContent = await page.textContent('body');
    expect(pageContent).not.toContain('404');
    expect(pageContent).not.toContain('Not Found');
    
    // 验证页面有基本内容
    expect(pageContent).toBeTruthy();
    expect(pageContent.length).toBeGreaterThan(100);
  });

  /**
   * 测试2：页面标题和基本元素测试
   */
  test('页面标题和基本元素测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser2', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 检查页面标题
    const title = await page.title();
    console.log('页面标题:', title);
    
    // 检查页面是否包含提醒相关的内容
    const pageText = await page.textContent('body');
    const hasReminderContent = pageText.includes('提醒') || 
                              pageText.includes('用药') || 
                              pageText.includes('药品') ||
                              pageText.includes('medication') ||
                              pageText.includes('reminder');
    
    if (!hasReminderContent) {
      console.log('页面内容:', pageText.substring(0, 500));
    }
    
    // 验证页面包含相关内容或至少不是错误页面
    expect(hasReminderContent || !pageText.includes('404')).toBeTruthy();
  });

  /**
   * 测试3：搜索框存在性测试
   */
  test('搜索框存在性测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser3', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 查找搜索相关的输入框
    const searchInputs = await page.locator('input').count();
    console.log('页面输入框数量:', searchInputs);
    
    if (searchInputs > 0) {
      // 如果有输入框，检查是否有搜索相关的
      const inputs = page.locator('input');
      for (let i = 0; i < Math.min(searchInputs, 5); i++) {
        const input = inputs.nth(i);
        const placeholder = await input.getAttribute('placeholder');
        const type = await input.getAttribute('type');
        console.log(`输入框 ${i + 1}: placeholder="${placeholder}", type="${type}"`);
      }
    }
    
    // 验证页面至少可以正常访问
    expect(page.url()).toContain('/app/special-medicine/reminders');
  });

  /**
   * 测试4：按钮存在性测试
   */
  test('按钮存在性测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser4', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 查找页面上的按钮
    const buttons = await page.locator('button').count();
    console.log('页面按钮数量:', buttons);
    
    if (buttons > 0) {
      // 如果有按钮，检查按钮文本
      const buttonElements = page.locator('button');
      for (let i = 0; i < Math.min(buttons, 10); i++) {
        const button = buttonElements.nth(i);
        const text = await button.textContent();
        const isVisible = await button.isVisible();
        console.log(`按钮 ${i + 1}: "${text}", 可见: ${isVisible}`);
      }
    }
    
    // 验证页面至少可以正常访问
    expect(page.url()).toContain('/app/special-medicine/reminders');
  });

  /**
   * 测试5：页面响应性测试
   */
  test('页面响应性测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser5', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 测试页面在不同视口大小下的响应性
    const viewports = [
      { width: 1920, height: 1080 }, // 桌面端
      { width: 768, height: 1024 },  // 平板端
      { width: 375, height: 667 }    // 移动端
    ];
    
    for (const viewport of viewports) {
      await page.setViewportSize(viewport);
      await page.waitForTimeout(1000);
      
      // 验证页面在不同尺寸下都能正常显示
      const pageContent = await page.textContent('body');
      expect(pageContent).toBeTruthy();
      expect(pageContent.length).toBeGreaterThan(50);
      
      console.log(`视口 ${viewport.width}x${viewport.height}: 内容长度 ${pageContent.length}`);
    }
  });

  /**
   * 测试6：页面导航测试
   */
  test('页面导航测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser6', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 测试从聊天页面导航到用药提醒页面
    await expect(page).toHaveURL('/app/chats');
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 验证导航成功
    expect(page.url()).toContain('/app/special-medicine/reminders');
    
    // 尝试返回聊天页面
    await page.goto('/app/chats');
    await page.waitForLoadState('networkidle');
    
    // 验证可以返回
    expect(page.url()).toContain('/app/chats');
    
    // 再次导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 验证再次导航成功
    expect(page.url()).toContain('/app/special-medicine/reminders');
  });

  /**
   * 测试7：页面加载性能测试
   */
  test('页面加载性能测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser7', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 记录页面加载开始时间
    const startTime = Date.now();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 记录页面加载结束时间
    const endTime = Date.now();
    const loadTime = endTime - startTime;
    
    console.log(`页面加载时间: ${loadTime}ms`);
    
    // 验证页面加载时间合理（小于15秒）
    expect(loadTime).toBeLessThan(15000);
    
    // 验证页面成功加载
    expect(page.url()).toContain('/app/special-medicine/reminders');
  });

  /**
   * 测试8：页面内容结构测试
   */
  test('页面内容结构测试', async ({ page }) => {
    // 注册并登录用户
    const loginSuccess = await registerAndLogin(page, 'testuser8', '123456');
    expect(loginSuccess).toBeTruthy();
    
    // 导航到用药提醒页面
    await page.goto('/app/special-medicine/reminders');
    await page.waitForLoadState('networkidle');
    
    // 检查页面基本HTML结构
    const hasHeader = await page.locator('header, h1, h2, h3').count() > 0;
    const hasMain = await page.locator('main, .main, .content').count() > 0;
    const hasDiv = await page.locator('div').count() > 0;
    
    console.log('页面结构检查:');
    console.log('- 有标题元素:', hasHeader);
    console.log('- 有主要内容区:', hasMain);
    console.log('- 有div元素:', hasDiv);
    
    // 验证页面有基本的HTML结构
    expect(hasDiv).toBeTruthy(); // 至少应该有div元素
    
    // 获取页面的基本信息
    const bodyText = await page.textContent('body');
    const bodyLength = bodyText ? bodyText.length : 0;
    
    console.log('页面内容长度:', bodyLength);
    
    // 验证页面有实际内容
    expect(bodyLength).toBeGreaterThan(100);
  });
});