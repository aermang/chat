import { test, expect } from '@playwright/test';

/**
 * 基础应用测试
 * 测试应用的基本功能和路由
 */

test.describe('基础应用测试', () => {
  
  test('应用首页能够正常加载', async ({ page }) => {
    // 导航到应用首页
    await page.goto('http://localhost:5173/');
    
    // 等待页面加载
    await page.waitForLoadState('networkidle');
    
    // 截图记录页面状态
    await page.screenshot({ path: 'test-results/app-homepage.png' });
    
    // 检查页面内容
    const pageContent = await page.content();
    console.log('首页内容长度:', pageContent.length);
    
    // 检查是否有登录相关元素
    const loginElements = await page.locator('input[type="text"], input[type="email"], input[type="password"], button:has-text("登录")').count();
    console.log('登录相关元素数量:', loginElements);
    
    // 基本断言
    expect(pageContent.length).toBeGreaterThan(100);
  });

  test('登录页面功能测试', async ({ page }) => {
    await page.goto('http://localhost:5173/login');
    await page.waitForLoadState('networkidle');
    
    // 截图记录登录页面
    await page.screenshot({ path: 'test-results/login-page.png' });
    
    // 检查登录表单元素
    const usernameInput = await page.locator('input[type="text"], input[type="email"]').first();
    const passwordInput = await page.locator('input[type="password"]').first();
    const loginButton = await page.locator('button:has-text("登录"), button[type="submit"]').first();
    
    // 检查元素是否存在
    await expect(usernameInput).toBeVisible();
    await expect(passwordInput).toBeVisible();
    await expect(loginButton).toBeVisible();
    
    console.log('登录页面元素检查完成');
  });

  test('尝试登录并访问特药管理', async ({ page }) => {
    await page.goto('http://localhost:5173/login');
    await page.waitForLoadState('networkidle');
    
    // 尝试填写登录信息（使用测试账号）
    const usernameInput = await page.locator('input[type="text"], input[type="email"]').first();
    const passwordInput = await page.locator('input[type="password"]').first();
    const loginButton = await page.locator('button:has-text("登录"), button[type="submit"]').first();
    
    if (await usernameInput.isVisible()) {
      await usernameInput.fill('test@example.com');
      await passwordInput.fill('password123');
      
      // 截图记录填写后的状态
      await page.screenshot({ path: 'test-results/login-filled.png' });
      
      await loginButton.click();
      
      // 等待登录处理
      await page.waitForTimeout(2000);
      
      // 截图记录登录后的状态
      await page.screenshot({ path: 'test-results/after-login.png' });
      
      // 检查是否成功登录（URL变化或页面内容变化）
      const currentUrl = page.url();
      console.log('登录后URL:', currentUrl);
      
      // 如果登录成功，尝试访问特药管理页面
      if (!currentUrl.includes('/login')) {
        await page.goto('http://localhost:5173/app/special-medicine');
        await page.waitForLoadState('networkidle');
        await page.screenshot({ path: 'test-results/special-medicine-page.png' });
        
        // 然后尝试访问用药提醒页面
        await page.goto('http://localhost:5173/app/special-medicine/reminders');
        await page.waitForLoadState('networkidle');
        await page.screenshot({ path: 'test-results/medication-reminders-page.png' });
        
        const reminderPageContent = await page.content();
        console.log('用药提醒页面内容长度:', reminderPageContent.length);
        
        // 检查是否有404错误
        const hasError = await page.locator('text=404, text=找不到, text=Not Found').count();
        console.log('404错误数量:', hasError);
        
        expect(hasError).toBe(0);
      }
    }
  });
});