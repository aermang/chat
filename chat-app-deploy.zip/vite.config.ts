import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tsconfigPaths from "vite-tsconfig-paths";
import { traeBadgePlugin } from 'vite-plugin-trae-solo-badge';
 
export default defineConfig({
  base: './',
  build: {
    sourcemap: 'hidden',
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name]-[hash][extname]',
        chunkFileNames: 'assets/[name]-[hash].js',
        entryFileNames: 'assets/[name]-[hash].js',
      },
    },
    assetsDir: 'assets',
    outDir: 'dist',
  },
  plugins: [
    react({
      babel: {
        plugins: ['react-dev-locator'],
      },
    }),
    traeBadgePlugin({
      variant: 'dark',
      position: 'bottom-right',
      prodOnly: true,
      clickable: true,
      clickUrl: 'https://www.trae.ai/solo?showJoin=1',
      autoTheme: true,
      autoThemeTarget: '#root'
    }), 
    tsconfigPaths()
  ],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
    cors: true,
    // 核心修复：添加允许的域名列表，支持外网访问
    allowedHosts: [
      '1105kxzn15257.vicp.fun', // 花生壳外网域名
      'localhost',              // 本地开发域名
      '127.0.0.1',              // 本地回环地址
      '0.0.0.0',                // 允许所有IP访问
      '.vicp.fun'               // 允许所有vicp.fun子域名
    ],
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'SAMEORIGIN'
    },
    proxy: {},
    hmr: {
      port: 24678,
      protocol: 'ws',
      timeout: 3000,
      // 允许外网HMR连接
      host: '0.0.0.0'
    },
    // 禁用主机检查（开发环境）
    disableHostCheck: true,
  },
  // 新增全局安全配置 
  appType: 'spa',
  cacheDir: './.vite_cache',
  envPrefix: ['VITE_', 'TRAE_'] // 限定环境变量前缀
})