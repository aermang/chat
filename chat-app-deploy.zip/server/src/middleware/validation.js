/**
 * 数据验证中间件
 * 提供请求数据验证功能
 */

import { body, param, query, validationResult } from 'express-validator';

/**
 * 处理验证结果的中间件
 * 如果验证失败，返回错误信息
 */
export const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map(error => ({
      field: error.path || error.param,
      message: error.msg,
      value: error.value
    }));

    return res.status(400).json({
      success: false,
      message: '数据验证失败',
      error_code: 'VALIDATION_ERROR',
      errors: errorMessages
    });
  }
  
  next();
};

/**
 * 用户注册验证规则
 */
export const validateUserRegistration = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 20 })
    .withMessage('用户名长度必须在3-20个字符之间')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('用户名只能包含字母、数字和下划线'),
  
  body('email')
    .trim()
    .isEmail()
    .withMessage('请输入有效的邮箱地址')
    .normalizeEmail(),
  
  body('password')
    .isLength({ min: 6, max: 128 })
    .withMessage('密码长度必须在6-128个字符之间')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('密码必须包含至少一个小写字母、一个大写字母和一个数字'),
  
  body('nickname')
    .optional()
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('昵称长度必须在1-50个字符之间'),
  
  handleValidationErrors
];

/**
 * 用户登录验证规则
 */
export const validateUserLogin = [
  body('identifier')
    .trim()
    .notEmpty()
    .withMessage('用户名或邮箱不能为空'),
  
  body('password')
    .notEmpty()
    .withMessage('密码不能为空'),
  
  handleValidationErrors
];

/**
 * 密码修改验证规则
 */
export const validatePasswordChange = [
  body('current_password')
    .notEmpty()
    .withMessage('当前密码不能为空'),
  
  body('new_password')
    .isLength({ min: 6, max: 128 })
    .withMessage('新密码长度必须在6-128个字符之间')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('新密码必须包含至少一个小写字母、一个大写字母和一个数字'),
  
  body('confirm_password')
    .custom((value, { req }) => {
      if (value !== req.body.new_password) {
        throw new Error('确认密码与新密码不匹配');
      }
      return true;
    }),
  
  handleValidationErrors
];

/**
 * 用户资料更新验证规则
 */
export const validateProfileUpdate = [
  body('nickname')
    .optional()
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('昵称长度必须在1-50个字符之间'),
  
  body('bio')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('个人简介最多200个字符'),
  
  body('avatar_url')
    .optional()
    .isURL()
    .withMessage('头像URL格式不正确'),
  
  body('settings.theme')
    .optional()
    .isIn(['light', 'dark', 'auto'])
    .withMessage('主题设置必须是light、dark或auto'),
  
  body('settings.language')
    .optional()
    .isIn(['zh-CN', 'en-US'])
    .withMessage('语言设置必须是zh-CN或en-US'),
  
  handleValidationErrors
];

/**
 * 好友申请验证规则
 */
export const validateFriendRequest = [
  body('receiver_id')
    .isMongoId()
    .withMessage('接收者ID格式不正确'),
  
  body('message')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('申请消息最多100个字符'),
  
  handleValidationErrors
];

/**
 * 好友申请处理验证规则
 */
export const validateFriendRequestAction = [
  param('requestId')
    .isMongoId()
    .withMessage('申请ID格式不正确'),
  
  body('action')
    .isIn(['accept', 'reject'])
    .withMessage('操作必须是accept或reject'),
  
  body('reject_reason')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('拒绝原因最多100个字符'),
  
  handleValidationErrors
];

/**
 * 消息发送验证规则
 */
export const validateMessageSend = [
  body('receiver_id')
    .isMongoId()
    .withMessage('接收者ID格式不正确'),
  
  body('content')
    .trim()
    .notEmpty()
    .withMessage('消息内容不能为空')
    .isLength({ max: 1000 })
    .withMessage('消息内容最多1000个字符'),
  
  body('message_type')
    .optional()
    .isIn(['text', 'image', 'file', 'voice', 'video', 'location'])
    .withMessage('消息类型无效'),
  
  body('reply_to')
    .optional()
    .isMongoId()
    .withMessage('回复消息ID格式不正确'),
  
  handleValidationErrors
];

/**
 * 朋友圈动态发布验证规则
 */
export const validateMomentCreate = [
  body('content')
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage('动态内容最多1000个字符'),
  
  body('images')
    .optional()
    .isArray({ max: 9 })
    .withMessage('最多上传9张图片'),
  
  body('images.*')
    .optional()
    .isURL()
    .withMessage('图片URL格式不正确'),
  
  body('location')
    .optional()
    .isObject()
    .withMessage('位置信息格式不正确'),
  
  body('location.name')
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('位置名称长度必须在1-100个字符之间'),
  
  body('visibility')
    .optional()
    .isIn(['public', 'friends', 'private'])
    .withMessage('可见性设置必须是public、friends或private'),
  
  body('allow_comment')
    .optional()
    .isBoolean()
    .withMessage('评论设置必须是布尔值'),
  
  // 自定义验证：内容和图片至少有一个
  body().custom((value, { req }) => {
    const { content, images } = req.body;
    if (!content && (!images || images.length === 0)) {
      throw new Error('动态内容和图片至少需要提供一个');
    }
    return true;
  }),
  
  handleValidationErrors
];

/**
 * 评论发布验证规则
 */
export const validateCommentCreate = [
  body('moment_id')
    .isMongoId()
    .withMessage('动态ID格式不正确'),
  
  body('content')
    .trim()
    .notEmpty()
    .withMessage('评论内容不能为空')
    .isLength({ max: 500 })
    .withMessage('评论内容最多500个字符'),
  
  body('reply_to')
    .optional()
    .isMongoId()
    .withMessage('回复评论ID格式不正确'),
  
  body('reply_to_user')
    .optional()
    .isMongoId()
    .withMessage('回复用户ID格式不正确'),
  
  handleValidationErrors
];

/**
 * 分页参数验证规则
 */
export const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('页码必须是大于0的整数')
    .toInt(),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('每页数量必须在1-100之间')
    .toInt(),
  
  query('sort')
    .optional()
    .isIn(['created_at', 'updated_at', 'likes_count', 'comments_count'])
    .withMessage('排序字段无效'),
  
  query('order')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage('排序方向必须是asc或desc'),
  
  handleValidationErrors
];

/**
 * MongoDB ObjectId 验证规则
 */
export const validateObjectId = (paramName) => [
  param(paramName)
    .isMongoId()
    .withMessage(`${paramName}格式不正确`),
  
  handleValidationErrors
];

/**
 * 搜索参数验证规则
 */
export const validateSearch = [
  query('q')
    .trim()
    .notEmpty()
    .withMessage('搜索关键词不能为空')
    .isLength({ min: 1, max: 100 })
    .withMessage('搜索关键词长度必须在1-100个字符之间'),
  
  query('type')
    .optional()
    .isIn(['users', 'moments', 'messages'])
    .withMessage('搜索类型必须是users、moments或messages'),
  
  handleValidationErrors
];

/**
 * 邮箱验证规则
 */
export const validateEmail = [
  body('email')
    .trim()
    .isEmail()
    .withMessage('请输入有效的邮箱地址')
    .normalizeEmail(),
  
  handleValidationErrors
];

/**
 * 密码重置验证规则
 */
export const validatePasswordReset = [
  body('token')
    .notEmpty()
    .withMessage('重置令牌不能为空'),
  
  body('new_password')
    .isLength({ min: 6, max: 128 })
    .withMessage('新密码长度必须在6-128个字符之间')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('新密码必须包含至少一个小写字母、一个大写字母和一个数字'),
  
  body('confirm_password')
    .custom((value, { req }) => {
      if (value !== req.body.new_password) {
        throw new Error('确认密码与新密码不匹配');
      }
      return true;
    }),
  
  handleValidationErrors
];

/**
 * 文件上传验证中间件
 */
export const validateFileUpload = (allowedTypes = [], maxSize = 5 * 1024 * 1024) => {
  return (req, res, next) => {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: '请选择要上传的文件',
        error_code: 'FILE_REQUIRED'
      });
    }

    // 检查文件类型
    if (allowedTypes.length > 0 && !allowedTypes.includes(req.file.mimetype)) {
      return res.status(400).json({
        success: false,
        message: `不支持的文件类型，支持的类型：${allowedTypes.join(', ')}`,
        error_code: 'INVALID_FILE_TYPE'
      });
    }

    // 检查文件大小
    if (req.file.size > maxSize) {
      return res.status(400).json({
        success: false,
        message: `文件大小不能超过 ${Math.round(maxSize / 1024 / 1024)}MB`,
        error_code: 'FILE_TOO_LARGE'
      });
    }

    next();
  };
};

/**
 * 批量操作验证规则
 */
export const validateBulkOperation = [
  body('ids')
    .isArray({ min: 1, max: 100 })
    .withMessage('ID数组长度必须在1-100之间'),
  
  body('ids.*')
    .isMongoId()
    .withMessage('ID格式不正确'),
  
  handleValidationErrors
];