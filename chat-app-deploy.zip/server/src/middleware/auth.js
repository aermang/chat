/**
 * 认证中间件
 * 提供JWT令牌验证、用户认证和权限控制功能
 */

import jwtUtils from '../utils/jwt.js';
import { User } from '../models/index.js';

/**
 * 验证访问令牌中间件
 * 验证请求头中的JWT令牌并将用户信息添加到req.user
 */
export const authenticateToken = async (req, res, next) => {
  try {
    // 从请求头获取令牌
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        success: false,
        message: '访问令牌缺失',
        error_code: 'TOKEN_MISSING'
      });
    }

    // 验证令牌
    const decoded = await jwtUtils.verifyAccessToken(token);
    
    // 检查用户是否存在
    const user = await User.findById(decoded.user_id).select('-password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: '用户不存在',
        error_code: 'USER_NOT_FOUND'
      });
    }

    // 检查用户账户状态
    if (user.status === 'disabled') {
      return res.status(403).json({
        success: false,
        message: '账户已被禁用',
        error_code: 'ACCOUNT_DISABLED'
      });
    }

    // 将用户信息添加到请求对象
    req.user = user;
    req.token = token;
    req.tokenPayload = decoded;

    next();
  } catch (error) {
    console.error('Token authentication error:', error);
    
    // 根据错误类型返回相应的状态码和消息
    if (error.message.includes('已过期')) {
      return res.status(401).json({
        success: false,
        message: '访问令牌已过期',
        error_code: 'TOKEN_EXPIRED'
      });
    } else if (error.message.includes('无效')) {
      return res.status(401).json({
        success: false,
        message: '访问令牌无效',
        error_code: 'TOKEN_INVALID'
      });
    } else {
      return res.status(401).json({
        success: false,
        message: '认证失败',
        error_code: 'AUTHENTICATION_FAILED'
      });
    }
  }
};

/**
 * 可选认证中间件
 * 如果提供了令牌则验证，否则继续执行（用于可选登录的接口）
 */
export const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      // 没有令牌，继续执行但不设置用户信息
      req.user = null;
      req.token = null;
      req.tokenPayload = null;
      return next();
    }

    // 有令牌，尝试验证
    try {
      const decoded = await jwtUtils.verifyAccessToken(token);
      const user = await User.findById(decoded.user_id).select('-password');
      
      if (user && user.status !== 'disabled') {
        req.user = user;
        req.token = token;
        req.tokenPayload = decoded;
      } else {
        req.user = null;
        req.token = null;
        req.tokenPayload = null;
      }
    } catch (error) {
      // 令牌验证失败，但不阻止请求继续
      req.user = null;
      req.token = null;
      req.tokenPayload = null;
    }

    next();
  } catch (error) {
    console.error('Optional auth error:', error);
    // 即使出错也继续执行
    req.user = null;
    req.token = null;
    req.tokenPayload = null;
    next();
  }
};

/**
 * 验证刷新令牌中间件
 * 专门用于刷新令牌的验证
 */
export const authenticateRefreshToken = async (req, res, next) => {
  try {
    const { refresh_token } = req.body;

    if (!refresh_token) {
      return res.status(401).json({
        success: false,
        message: '刷新令牌缺失',
        error_code: 'REFRESH_TOKEN_MISSING'
      });
    }

    // 验证刷新令牌
    const decoded = await jwtUtils.verifyRefreshToken(refresh_token);
    
    // 检查用户是否存在
    const user = await User.findById(decoded.user_id).select('-password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: '用户不存在',
        error_code: 'USER_NOT_FOUND'
      });
    }

    // 检查用户账户状态
    if (user.status === 'disabled') {
      return res.status(403).json({
        success: false,
        message: '账户已被禁用',
        error_code: 'ACCOUNT_DISABLED'
      });
    }

    // 将用户信息添加到请求对象
    req.user = user;
    req.refreshToken = refresh_token;
    req.refreshTokenPayload = decoded;

    next();
  } catch (error) {
    console.error('Refresh token authentication error:', error);
    
    if (error.message.includes('已过期')) {
      return res.status(401).json({
        success: false,
        message: '刷新令牌已过期，请重新登录',
        error_code: 'REFRESH_TOKEN_EXPIRED'
      });
    } else if (error.message.includes('无效')) {
      return res.status(401).json({
        success: false,
        message: '刷新令牌无效',
        error_code: 'REFRESH_TOKEN_INVALID'
      });
    } else {
      return res.status(401).json({
        success: false,
        message: '刷新令牌验证失败',
        error_code: 'REFRESH_TOKEN_VERIFICATION_FAILED'
      });
    }
  }
};

/**
 * 管理员权限验证中间件
 * 需要先通过authenticateToken中间件
 */
export const requireAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: '需要登录',
      error_code: 'AUTHENTICATION_REQUIRED'
    });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: '需要管理员权限',
      error_code: 'ADMIN_REQUIRED'
    });
  }

  next();
};

/**
 * 用户自己或管理员权限验证中间件
 * 允许用户访问自己的资源或管理员访问所有资源
 */
export const requireOwnerOrAdmin = (userIdParam = 'userId') => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: '需要登录',
        error_code: 'AUTHENTICATION_REQUIRED'
      });
    }

    const targetUserId = req.params[userIdParam] || req.body[userIdParam];
    const currentUserId = req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (currentUserId !== targetUserId && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: '权限不足',
        error_code: 'INSUFFICIENT_PERMISSIONS'
      });
    }

    next();
  };
};

/**
 * 速率限制中间件
 * 基于用户ID进行速率限制
 */
export const createUserRateLimit = (windowMs = 15 * 60 * 1000, max = 100) => {
  const requests = new Map();

  return (req, res, next) => {
    if (!req.user) {
      return next();
    }

    const userId = req.user._id.toString();
    const now = Date.now();
    const windowStart = now - windowMs;

    // 清理过期的请求记录
    if (requests.has(userId)) {
      const userRequests = requests.get(userId);
      const validRequests = userRequests.filter(timestamp => timestamp > windowStart);
      requests.set(userId, validRequests);
    }

    // 获取当前用户的请求记录
    const userRequests = requests.get(userId) || [];

    // 检查是否超过限制
    if (userRequests.length >= max) {
      return res.status(429).json({
        success: false,
        message: '请求过于频繁，请稍后再试',
        error_code: 'RATE_LIMIT_EXCEEDED',
        retry_after: Math.ceil(windowMs / 1000)
      });
    }

    // 记录当前请求
    userRequests.push(now);
    requests.set(userId, userRequests);

    // 设置响应头
    res.set({
      'X-RateLimit-Limit': max,
      'X-RateLimit-Remaining': Math.max(0, max - userRequests.length),
      'X-RateLimit-Reset': new Date(now + windowMs).toISOString()
    });

    next();
  };
};

/**
 * 验证邮箱验证令牌中间件
 */
export const authenticateEmailVerificationToken = async (req, res, next) => {
  try {
    const { token } = req.params;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: '验证令牌缺失',
        error_code: 'VERIFICATION_TOKEN_MISSING'
      });
    }

    // 验证邮箱验证令牌
    const decoded = await jwtUtils.verifyEmailVerificationToken(token);
    
    // 检查用户是否存在
    const user = await User.findById(decoded.user_id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在',
        error_code: 'USER_NOT_FOUND'
      });
    }

    // 将用户信息和令牌载荷添加到请求对象
    req.user = user;
    req.verificationToken = token;
    req.verificationTokenPayload = decoded;

    next();
  } catch (error) {
    console.error('Email verification token authentication error:', error);
    
    if (error.message.includes('已过期')) {
      return res.status(401).json({
        success: false,
        message: '验证令牌已过期',
        error_code: 'VERIFICATION_TOKEN_EXPIRED'
      });
    } else if (error.message.includes('无效')) {
      return res.status(401).json({
        success: false,
        message: '验证令牌无效',
        error_code: 'VERIFICATION_TOKEN_INVALID'
      });
    } else {
      return res.status(401).json({
        success: false,
        message: '令牌验证失败',
        error_code: 'VERIFICATION_TOKEN_VERIFICATION_FAILED'
      });
    }
  }
};

/**
 * 验证密码重置令牌中间件
 */
export const authenticatePasswordResetToken = async (req, res, next) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: '重置令牌缺失',
        error_code: 'RESET_TOKEN_MISSING'
      });
    }

    // 验证密码重置令牌
    const decoded = await jwtUtils.verifyPasswordResetToken(token);
    
    // 检查用户是否存在
    const user = await User.findById(decoded.user_id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在',
        error_code: 'USER_NOT_FOUND'
      });
    }

    // 将用户信息和令牌载荷添加到请求对象
    req.user = user;
    req.resetToken = token;
    req.resetTokenPayload = decoded;

    next();
  } catch (error) {
    console.error('Password reset token authentication error:', error);
    
    if (error.message.includes('已过期')) {
      return res.status(401).json({
        success: false,
        message: '重置令牌已过期',
        error_code: 'RESET_TOKEN_EXPIRED'
      });
    } else if (error.message.includes('无效')) {
      return res.status(401).json({
        success: false,
        message: '重置令牌无效',
        error_code: 'RESET_TOKEN_INVALID'
      });
    } else {
      return res.status(401).json({
        success: false,
        message: '令牌验证失败',
        error_code: 'RESET_TOKEN_VERIFICATION_FAILED'
      });
    }
  }
};

/**
 * WebSocket认证中间件
 * 用于Socket.io连接的认证
 */
export const authenticateSocket = async (socket, next) => {
  try {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];

    if (!token) {
      return next(new Error('认证令牌缺失'));
    }

    // 验证令牌
    const decoded = await jwtUtils.verifyAccessToken(token);
    
    // 检查用户是否存在
    const user = await User.findById(decoded.user_id).select('-password');
    if (!user) {
      return next(new Error('用户不存在'));
    }

    // 检查用户账户状态
    if (user.status === 'disabled') {
      return next(new Error('账户已被禁用'));
    }

    // 将用户信息添加到socket对象
    socket.user = user;
    socket.token = token;
    socket.tokenPayload = decoded;

    next();
  } catch (error) {
    console.error('Socket authentication error:', error);
    next(new Error('认证失败'));
  }
};