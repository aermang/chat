/**
 * 错误处理中间件
 * 统一处理应用程序中的错误
 */

import mongoose from 'mongoose';

/**
 * 自定义错误类
 */
export class AppError extends Error {
  constructor(message, statusCode = 500, errorCode = 'INTERNAL_ERROR') {
    super(message);
    this.statusCode = statusCode;
    this.errorCode = errorCode;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * 异步错误捕获包装器
 * 用于包装异步路由处理函数，自动捕获Promise rejection
 */
export const catchAsync = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

/**
 * 处理MongoDB Cast错误（无效的ObjectId）
 */
const handleCastErrorDB = (err) => {
  const message = `无效的${err.path}: ${err.value}`;
  return new AppError(message, 400, 'INVALID_ID');
};

/**
 * 处理MongoDB重复字段错误
 */
const handleDuplicateFieldsDB = (err) => {
  const field = Object.keys(err.keyValue)[0];
  const value = err.keyValue[field];
  const message = `${field}: ${value} 已存在`;
  return new AppError(message, 400, 'DUPLICATE_FIELD');
};

/**
 * 处理MongoDB验证错误
 */
const handleValidationErrorDB = (err) => {
  const errors = Object.values(err.errors).map(el => el.message);
  const message = `数据验证失败: ${errors.join('. ')}`;
  return new AppError(message, 400, 'VALIDATION_ERROR');
};

/**
 * 处理JWT错误
 */
const handleJWTError = () => {
  return new AppError('无效的令牌，请重新登录', 401, 'INVALID_TOKEN');
};

/**
 * 处理JWT过期错误
 */
const handleJWTExpiredError = () => {
  return new AppError('令牌已过期，请重新登录', 401, 'TOKEN_EXPIRED');
};

/**
 * 发送开发环境错误响应
 */
const sendErrorDev = (err, res) => {
  res.status(err.statusCode).json({
    success: false,
    error: err,
    message: err.message,
    error_code: err.errorCode,
    stack: err.stack
  });
};

/**
 * 发送生产环境错误响应
 */
const sendErrorProd = (err, res) => {
  // 操作性错误：发送给客户端
  if (err.isOperational) {
    res.status(err.statusCode).json({
      success: false,
      message: err.message,
      error_code: err.errorCode
    });
  } else {
    // 编程错误：不泄露错误详情
    console.error('ERROR 💥', err);
    
    res.status(500).json({
      success: false,
      message: '服务器内部错误',
      error_code: 'INTERNAL_ERROR'
    });
  }
};

/**
 * 全局错误处理中间件
 */
export const globalErrorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.errorCode = err.errorCode || 'INTERNAL_ERROR';

  if (process.env.NODE_ENV === 'development') {
    sendErrorDev(err, res);
  } else {
    let error = { ...err };
    error.message = err.message;

    // 处理不同类型的错误
    if (error.name === 'CastError') error = handleCastErrorDB(error);
    if (error.code === 11000) error = handleDuplicateFieldsDB(error);
    if (error.name === 'ValidationError') error = handleValidationErrorDB(error);
    if (error.name === 'JsonWebTokenError') error = handleJWTError();
    if (error.name === 'TokenExpiredError') error = handleJWTExpiredError();

    sendErrorProd(error, res);
  }
};

/**
 * 处理未找到路由的中间件
 */
export const notFoundHandler = (req, res, next) => {
  const err = new AppError(`找不到路由 ${req.originalUrl}`, 404, 'ROUTE_NOT_FOUND');
  next(err);
};

/**
 * 处理未捕获的Promise rejection
 */
process.on('unhandledRejection', (err, promise) => {
  console.log('UNHANDLED REJECTION! 💥 Shutting down...');
  console.log(err.name, err.message);
  process.exit(1);
});

/**
 * 处理未捕获的异常
 */
process.on('uncaughtException', (err) => {
  console.log('UNCAUGHT EXCEPTION! 💥 Shutting down...');
  console.log(err.name, err.message);
  process.exit(1);
});

/**
 * 处理SIGTERM信号
 */
process.on('SIGTERM', () => {
  console.log('👋 SIGTERM RECEIVED. Shutting down gracefully');
  process.exit(0);
});

/**
 * 处理SIGINT信号（Ctrl+C）
 */
process.on('SIGINT', () => {
  console.log('👋 SIGINT RECEIVED. Shutting down gracefully');
  process.exit(0);
});

/**
 * 数据库连接错误处理
 */
export const handleDatabaseErrors = () => {
  mongoose.connection.on('error', (err) => {
    console.error('MongoDB connection error:', err);
  });

  mongoose.connection.on('disconnected', () => {
    console.log('MongoDB disconnected');
  });

  mongoose.connection.on('reconnected', () => {
    console.log('MongoDB reconnected');
  });
};

/**
 * 创建特定类型的错误
 */
export const createError = {
  /**
   * 创建认证错误
   */
  auth: (message = '认证失败') => {
    return new AppError(message, 401, 'AUTHENTICATION_FAILED');
  },

  /**
   * 创建权限错误
   */
  permission: (message = '权限不足') => {
    return new AppError(message, 403, 'INSUFFICIENT_PERMISSIONS');
  },

  /**
   * 创建资源未找到错误
   */
  notFound: (resource = '资源') => {
    return new AppError(`${resource}不存在`, 404, 'RESOURCE_NOT_FOUND');
  },

  /**
   * 创建验证错误
   */
  validation: (message = '数据验证失败') => {
    return new AppError(message, 400, 'VALIDATION_ERROR');
  },

  /**
   * 创建冲突错误
   */
  conflict: (message = '资源冲突') => {
    return new AppError(message, 409, 'RESOURCE_CONFLICT');
  },

  /**
   * 创建速率限制错误
   */
  rateLimit: (message = '请求过于频繁') => {
    return new AppError(message, 429, 'RATE_LIMIT_EXCEEDED');
  },

  /**
   * 创建服务不可用错误
   */
  serviceUnavailable: (message = '服务暂时不可用') => {
    return new AppError(message, 503, 'SERVICE_UNAVAILABLE');
  }
};

/**
 * 错误日志记录中间件
 */
export const errorLogger = (err, req, res, next) => {
  // 记录错误信息
  const errorInfo = {
    timestamp: new Date().toISOString(),
    method: req.method,
    url: req.originalUrl,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    user: req.user ? req.user._id : 'anonymous',
    error: {
      name: err.name,
      message: err.message,
      statusCode: err.statusCode,
      errorCode: err.errorCode,
      stack: err.stack
    }
  };

  // 根据错误级别记录日志
  if (err.statusCode >= 500) {
    console.error('Server Error:', JSON.stringify(errorInfo, null, 2));
  } else if (err.statusCode >= 400) {
    console.warn('Client Error:', JSON.stringify(errorInfo, null, 2));
  }

  next(err);
};

/**
 * 健康检查错误处理
 */
export const healthCheckErrorHandler = (err, req, res, next) => {
  if (req.path === '/health') {
    return res.status(503).json({
      success: false,
      message: '服务健康检查失败',
      error_code: 'HEALTH_CHECK_FAILED',
      timestamp: new Date().toISOString()
    });
  }
  next(err);
};