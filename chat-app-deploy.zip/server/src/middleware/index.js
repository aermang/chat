/**
 * 中间件统一导出文件
 * 集中管理所有中间件
 */

// 导入认证中间件
import {
  authenticateToken,
  optionalAuth,
  authenticateRefreshToken,
  requireAdmin,
  requireOwnerOrAdmin,
  createUserRateLimit,
  authenticateEmailVerificationToken,
  authenticatePasswordResetToken,
  authenticateSocket
} from './auth.js';

// 导入验证中间件
import {
  handleValidationErrors,
  validateUserRegistration,
  validateUserLogin,
  validatePasswordChange,
  validateProfileUpdate,
  validateFriendRequest,
  validateFriendRequestAction,
  validateMessageSend,
  validateMomentCreate,
  validateCommentCreate,
  validatePagination,
  validateObjectId,
  validateSearch,
  validateEmail,
  validatePasswordReset,
  validateFileUpload,
  validateBulkOperation
} from './validation.js';

// 导入错误处理中间件
import {
  AppError,
  catchAsync,
  globalErrorHandler,
  notFoundHandler,
  handleDatabaseErrors,
  createError,
  errorLogger,
  healthCheckErrorHandler
} from './errorHandler.js';

// 重新导出认证中间件
export {
  authenticateToken,
  optionalAuth,
  authenticateRefreshToken,
  requireAdmin,
  requireOwnerOrAdmin,
  createUserRateLimit,
  authenticateEmailVerificationToken,
  authenticatePasswordResetToken,
  authenticateSocket
};

// 重新导出验证中间件
export {
  handleValidationErrors,
  validateUserRegistration,
  validateUserLogin,
  validatePasswordChange,
  validateProfileUpdate,
  validateFriendRequest,
  validateFriendRequestAction,
  validateMessageSend,
  validateMomentCreate,
  validateCommentCreate,
  validatePagination,
  validateObjectId,
  validateSearch,
  validateEmail,
  validatePasswordReset,
  validateFileUpload,
  validateBulkOperation
};

// 重新导出错误处理中间件
export {
  AppError,
  catchAsync,
  globalErrorHandler,
  notFoundHandler,
  handleDatabaseErrors,
  createError,
  errorLogger,
  healthCheckErrorHandler
};

/**
 * 默认导出常用中间件组合
 */
export default {
  // 认证相关
  auth: {
    authenticateToken,
    optionalAuth,
    authenticateRefreshToken,
    requireAdmin,
    requireOwnerOrAdmin,
    createUserRateLimit,
    authenticateEmailVerificationToken,
    authenticatePasswordResetToken,
    authenticateSocket
  },
  
  // 验证相关
  validation: {
    handleValidationErrors,
    validateUserRegistration,
    validateUserLogin,
    validatePasswordChange,
    validateProfileUpdate,
    validateFriendRequest,
    validateFriendRequestAction,
    validateMessageSend,
    validateMomentCreate,
    validateCommentCreate,
    validatePagination,
    validateObjectId,
    validateSearch,
    validateEmail,
    validatePasswordReset,
    validateFileUpload,
    validateBulkOperation
  },
  
  // 错误处理相关
  error: {
    AppError,
    catchAsync,
    globalErrorHandler,
    notFoundHandler,
    handleDatabaseErrors,
    createError,
    errorLogger,
    healthCheckErrorHandler
  }
};