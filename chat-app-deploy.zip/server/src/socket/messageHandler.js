/**
 * Socket.io 消息处理器
 * 处理实时消息相关事件
 */

import { Message, ChatSession, User } from '../models/index.js';
import { emitToUser, emitToSession } from './index.js';

/**
 * 消息事件处理器
 * @param {Object} io - Socket.io服务器实例
 * @param {Object} socket - Socket实例
 * @param {Map} onlineUsers - 在线用户映射
 */
export default function messageHandler(io, socket, onlineUsers) {
  const userId = socket.user._id.toString();

  /**
   * 发送消息事件
   */
  socket.on('send_message', async (data) => {
    try {
      const { session_id, content, message_type = 'text', reply_to } = data;

      // 验证必要参数
      if (!session_id || !content) {
        socket.emit('message_error', {
          error: '缺少必要参数',
          code: 'MISSING_PARAMS'
        });
        return;
      }

      // 验证会话是否存在且用户有权限
      const session = await ChatSession.findById(session_id);
      if (!session) {
        socket.emit('message_error', {
          error: '会话不存在',
          code: 'SESSION_NOT_FOUND'
        });
        return;
      }

      if (!session.participants.includes(userId)) {
        socket.emit('message_error', {
          error: '无权限访问此会话',
          code: 'ACCESS_DENIED'
        });
        return;
      }

      // 创建消息
      const messageData = {
        session_id,
        sender_id: userId,
        content,
        message_type,
        reply_to: reply_to || null
      };

      const message = await Message.create(messageData);
      await message.populate([
        {
          path: 'sender_id',
          select: 'username profile'
        },
        {
          path: 'reply_to',
          select: 'content sender_id message_type',
          populate: {
            path: 'sender_id',
            select: 'username'
          }
        }
      ]);

      // 更新会话最后消息信息
      await ChatSession.findByIdAndUpdate(session_id, {
        last_message_id: message._id,
        last_message_at: message.created_at,
        updated_at: new Date()
      });

      // 更新所有参与者的未读消息数（除了发送者）
      await ChatSession.updateOne(
        { _id: session_id },
        {
          $inc: {
            'participants_info.$[elem].unread_count': 1
          }
        },
        {
          arrayFilters: [{ 'elem.user_id': { $ne: userId } }]
        }
      );

      // 准备发送的消息数据
      const messageResponse = {
        _id: message._id,
        session_id: message.session_id,
        sender_id: message.sender_id,
        content: message.content,
        message_type: message.message_type,
        reply_to: message.reply_to,
        is_read: message.is_read,
        created_at: message.created_at,
        updated_at: message.updated_at
      };

      // 向会话中的所有用户发送新消息
      emitToSession(io, session_id, 'new_message', messageResponse);

      // 向离线用户发送推送通知（这里可以集成推送服务）
      const offlineParticipants = session.participants.filter(participantId => 
        participantId.toString() !== userId && !onlineUsers.has(participantId.toString())
      );

      if (offlineParticipants.length > 0) {
        // 这里可以集成推送通知服务
        console.log(`需要向 ${offlineParticipants.length} 个离线用户发送推送通知`);
      }

      // 确认消息发送成功
      socket.emit('message_sent', {
        message_id: message._id,
        temp_id: data.temp_id, // 客户端临时ID，用于匹配
        timestamp: message.created_at
      });

    } catch (error) {
      console.error('发送消息错误:', error);
      socket.emit('message_error', {
        error: '发送消息失败',
        code: 'SEND_FAILED',
        details: error.message
      });
    }
  });

  /**
   * 标记消息为已读事件
   */
  socket.on('mark_message_read', async (data) => {
    try {
      const { message_id, session_id } = data;

      if (message_id) {
        // 标记单条消息为已读
        await Message.findByIdAndUpdate(message_id, {
          is_read: true,
          read_at: new Date()
        });

        // 通知发送者消息已被读取
        const message = await Message.findById(message_id).populate('sender_id', 'username');
        if (message && message.sender_id._id.toString() !== userId) {
          emitToUser(io, message.sender_id._id.toString(), 'message_read', {
            message_id,
            reader_id: userId,
            read_at: new Date()
          });
        }
      } else if (session_id) {
        // 标记会话中所有未读消息为已读
        await Message.updateMany(
          {
            session_id,
            sender_id: { $ne: userId },
            is_read: false
          },
          {
            is_read: true,
            read_at: new Date()
          }
        );

        // 重置用户在该会话的未读计数
        await ChatSession.updateOne(
          { _id: session_id },
          {
            $set: {
              'participants_info.$[elem].unread_count': 0
            }
          },
          {
            arrayFilters: [{ 'elem.user_id': userId }]
          }
        );

        // 通知会话中的其他用户
        emitToSession(io, session_id, 'session_messages_read', {
          reader_id: userId,
          session_id,
          read_at: new Date()
        }, userId);
      }

      socket.emit('mark_read_success', { message_id, session_id });

    } catch (error) {
      console.error('标记消息已读错误:', error);
      socket.emit('mark_read_error', {
        error: '标记已读失败',
        code: 'MARK_READ_FAILED'
      });
    }
  });

  /**
   * 撤回消息事件
   */
  socket.on('recall_message', async (data) => {
    try {
      const { message_id } = data;

      if (!message_id) {
        socket.emit('recall_error', {
          error: '缺少消息ID',
          code: 'MISSING_MESSAGE_ID'
        });
        return;
      }

      // 查找消息
      const message = await Message.findById(message_id);
      if (!message) {
        socket.emit('recall_error', {
          error: '消息不存在',
          code: 'MESSAGE_NOT_FOUND'
        });
        return;
      }

      // 验证权限（只能撤回自己的消息）
      if (message.sender_id.toString() !== userId) {
        socket.emit('recall_error', {
          error: '无权限撤回此消息',
          code: 'ACCESS_DENIED'
        });
        return;
      }

      // 检查撤回时间限制（2分钟内）
      const now = new Date();
      const messageTime = new Date(message.created_at);
      const timeDiff = now - messageTime;
      const maxRecallTime = 2 * 60 * 1000; // 2分钟

      if (timeDiff > maxRecallTime) {
        socket.emit('recall_error', {
          error: '超过撤回时间限制',
          code: 'TIME_LIMIT_EXCEEDED'
        });
        return;
      }

      // 标记消息为已撤回
      await Message.findByIdAndUpdate(message_id, {
        is_recalled: true,
        recalled_at: new Date(),
        content: '[消息已撤回]'
      });

      // 通知会话中的所有用户
      emitToSession(io, message.session_id.toString(), 'message_recalled', {
        message_id,
        recalled_by: userId,
        recalled_at: new Date()
      });

      socket.emit('recall_success', { message_id });

    } catch (error) {
      console.error('撤回消息错误:', error);
      socket.emit('recall_error', {
        error: '撤回消息失败',
        code: 'RECALL_FAILED'
      });
    }
  });

  /**
   * 获取消息历史事件
   */
  socket.on('get_message_history', async (data) => {
    try {
      const { session_id, page = 1, limit = 20, before_message_id } = data;

      if (!session_id) {
        socket.emit('history_error', {
          error: '缺少会话ID',
          code: 'MISSING_SESSION_ID'
        });
        return;
      }

      // 验证用户是否有权限访问此会话
      const session = await ChatSession.findById(session_id);
      if (!session || !session.participants.includes(userId)) {
        socket.emit('history_error', {
          error: '无权限访问此会话',
          code: 'ACCESS_DENIED'
        });
        return;
      }

      // 构建查询条件
      const query = { session_id, is_deleted: false };
      
      if (before_message_id) {
        const beforeMessage = await Message.findById(before_message_id);
        if (beforeMessage) {
          query.created_at = { $lt: beforeMessage.created_at };
        }
      }

      // 查询消息
      const messages = await Message.find(query)
        .populate('sender_id', 'username profile')
        .populate({
          path: 'reply_to',
          select: 'content sender_id message_type',
          populate: {
            path: 'sender_id',
            select: 'username'
          }
        })
        .sort({ created_at: -1 })
        .limit(limit)
        .skip((page - 1) * limit);

      // 获取总数
      const total = await Message.countDocuments(query);

      socket.emit('message_history', {
        messages: messages.reverse(), // 按时间正序返回
        pagination: {
          page,
          limit,
          total,
          has_more: total > page * limit
        }
      });

    } catch (error) {
      console.error('获取消息历史错误:', error);
      socket.emit('history_error', {
        error: '获取消息历史失败',
        code: 'HISTORY_FAILED'
      });
    }
  });

  /**
   * 搜索消息事件
   */
  socket.on('search_messages', async (data) => {
    try {
      const { session_id, keyword, message_type, page = 1, limit = 20 } = data;

      if (!keyword) {
        socket.emit('search_error', {
          error: '缺少搜索关键词',
          code: 'MISSING_KEYWORD'
        });
        return;
      }

      // 构建查询条件
      const query = {
        is_deleted: false,
        content: { $regex: keyword, $options: 'i' }
      };

      if (session_id) {
        // 验证用户权限
        const session = await ChatSession.findById(session_id);
        if (!session || !session.participants.includes(userId)) {
          socket.emit('search_error', {
            error: '无权限访问此会话',
            code: 'ACCESS_DENIED'
          });
          return;
        }
        query.session_id = session_id;
      } else {
        // 搜索用户参与的所有会话
        const userSessions = await ChatSession.find({
          participants: userId
        }).select('_id');
        query.session_id = { $in: userSessions.map(s => s._id) };
      }

      if (message_type) {
        query.message_type = message_type;
      }

      // 执行搜索
      const messages = await Message.find(query)
        .populate('sender_id', 'username profile')
        .populate('session_id', 'session_name session_type')
        .sort({ created_at: -1 })
        .limit(limit)
        .skip((page - 1) * limit);

      const total = await Message.countDocuments(query);

      socket.emit('search_results', {
        messages,
        keyword,
        pagination: {
          page,
          limit,
          total,
          has_more: total > page * limit
        }
      });

    } catch (error) {
      console.error('搜索消息错误:', error);
      socket.emit('search_error', {
        error: '搜索消息失败',
        code: 'SEARCH_FAILED'
      });
    }
  });
}