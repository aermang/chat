/**
 * Socket.io 在线状态处理器
 * 处理用户在线状态相关事件
 */

import { User, Friendship } from '../models/index.js';
import { emitToUser, broadcastToAll } from './index.js';

/**
 * 在线状态事件处理器
 * @param {Object} io - Socket.io服务器实例
 * @param {Object} socket - Socket实例
 * @param {Map} onlineUsers - 在线用户映射
 */
export default function onlineStatusHandler(io, socket, onlineUsers) {
  const userId = socket.user._id.toString();

  /**
   * 更新用户状态事件
   */
  socket.on('update_status', async (data) => {
    try {
      const { status, status_message } = data;

      // 验证状态值
      const validStatuses = ['online', 'away', 'busy', 'invisible'];
      if (status && !validStatuses.includes(status)) {
        socket.emit('status_error', {
          error: '无效的状态值',
          code: 'INVALID_STATUS'
        });
        return;
      }

      // 更新数据库中的用户状态
      const updateData = {};
      if (status) {
        updateData.status = status;
      }
      if (status_message !== undefined) {
        updateData.status_message = status_message;
      }
      updateData.last_seen_at = new Date();

      const updatedUser = await User.findByIdAndUpdate(
        userId,
        updateData,
        { new: true, select: 'username status status_message last_seen_at profile' }
      );

      // 更新内存中的在线用户信息
      if (onlineUsers.has(userId)) {
        const userData = onlineUsers.get(userId);
        userData.userInfo.status = updatedUser.status;
        userData.userInfo.status_message = updatedUser.status_message;
        userData.lastSeen = new Date();
      }

      // 获取用户的好友列表
      const friendships = await Friendship.find({ user_id: userId })
        .select('friend_id');
      
      const friendIds = friendships.map(f => f.friend_id.toString());

      // 通知好友状态变化
      friendIds.forEach(friendId => {
        emitToUser(io, friendId, 'friend_status_changed', {
          user_id: userId,
          username: updatedUser.username,
          status: updatedUser.status,
          status_message: updatedUser.status_message,
          last_seen: updatedUser.last_seen_at,
          profile: updatedUser.profile
        });
      });

      socket.emit('status_updated', {
        status: updatedUser.status,
        status_message: updatedUser.status_message,
        updated_at: updatedUser.last_seen_at
      });

    } catch (error) {
      console.error('更新用户状态错误:', error);
      socket.emit('status_error', {
        error: '更新状态失败',
        code: 'UPDATE_STATUS_FAILED'
      });
    }
  });

  /**
   * 获取好友在线状态事件
   */
  socket.on('get_friends_status', async () => {
    try {
      // 获取用户的好友列表
      const friendships = await Friendship.find({ user_id: userId })
        .populate({
          path: 'friend_id',
          select: 'username profile status status_message is_online last_seen_at'
        });

      // 构建好友状态信息
      const friendsStatus = friendships.map(friendship => {
        const friend = friendship.friend_id;
        const isRealTimeOnline = onlineUsers.has(friend._id.toString());
        
        return {
          friend_id: friend._id,
          username: friend.username,
          profile: friend.profile,
          status: friend.status || 'online',
          status_message: friend.status_message || '',
          is_online: isRealTimeOnline,
          last_seen: isRealTimeOnline ? new Date() : friend.last_seen_at,
          remark: friendship.remark
        };
      });

      socket.emit('friends_status_list', {
        friends: friendsStatus,
        timestamp: new Date()
      });

    } catch (error) {
      console.error('获取好友状态错误:', error);
      socket.emit('friends_status_error', {
        error: '获取好友状态失败',
        code: 'GET_FRIENDS_STATUS_FAILED'
      });
    }
  });

  /**
   * 获取在线用户列表事件
   */
  socket.on('get_online_users', async (data) => {
    try {
      const { include_friends_only = false, page = 1, limit = 50 } = data;

      let onlineUsersList = Array.from(onlineUsers.values());

      if (include_friends_only) {
        // 只返回好友中的在线用户
        const friendships = await Friendship.find({ user_id: userId })
          .select('friend_id');
        
        const friendIds = new Set(friendships.map(f => f.friend_id.toString()));
        
        onlineUsersList = onlineUsersList.filter(userData => 
          friendIds.has(userData.userInfo._id.toString())
        );
      }

      // 分页处理
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedUsers = onlineUsersList.slice(startIndex, endIndex);

      const result = paginatedUsers.map(userData => ({
        user_id: userData.userInfo._id,
        username: userData.userInfo.username,
        profile: userData.userInfo.profile,
        status: userData.userInfo.status || 'online',
        status_message: userData.userInfo.status_message || '',
        last_seen: userData.lastSeen
      }));

      socket.emit('online_users_list', {
        users: result,
        pagination: {
          page,
          limit,
          total: onlineUsersList.length,
          has_more: endIndex < onlineUsersList.length
        },
        timestamp: new Date()
      });

    } catch (error) {
      console.error('获取在线用户列表错误:', error);
      socket.emit('online_users_error', {
        error: '获取在线用户列表失败',
        code: 'GET_ONLINE_USERS_FAILED'
      });
    }
  });

  /**
   * 检查用户是否在线事件
   */
  socket.on('check_user_online', async (data) => {
    try {
      const { user_ids } = data;

      if (!Array.isArray(user_ids)) {
        socket.emit('check_online_error', {
          error: '用户ID必须是数组',
          code: 'INVALID_USER_IDS'
        });
        return;
      }

      const onlineStatus = user_ids.map(userId => {
        const isOnline = onlineUsers.has(userId);
        const userData = onlineUsers.get(userId);
        
        return {
          user_id: userId,
          is_online: isOnline,
          last_seen: isOnline ? userData.lastSeen : null,
          status: isOnline ? userData.userInfo.status : null
        };
      });

      socket.emit('users_online_status', {
        users: onlineStatus,
        timestamp: new Date()
      });

    } catch (error) {
      console.error('检查用户在线状态错误:', error);
      socket.emit('check_online_error', {
        error: '检查用户在线状态失败',
        code: 'CHECK_ONLINE_FAILED'
      });
    }
  });

  /**
   * 设置勿扰模式事件
   */
  socket.on('toggle_do_not_disturb', async (data) => {
    try {
      const { enabled, until } = data;

      // 更新用户的勿扰设置
      const updateData = {
        'settings.do_not_disturb': enabled,
        last_seen_at: new Date()
      };

      if (enabled && until) {
        updateData['settings.do_not_disturb_until'] = new Date(until);
      } else {
        updateData['settings.do_not_disturb_until'] = null;
      }

      await User.findByIdAndUpdate(userId, updateData);

      // 更新内存中的用户信息
      if (onlineUsers.has(userId)) {
        const userData = onlineUsers.get(userId);
        userData.userInfo.settings = userData.userInfo.settings || {};
        userData.userInfo.settings.do_not_disturb = enabled;
        userData.userInfo.settings.do_not_disturb_until = until ? new Date(until) : null;
      }

      socket.emit('do_not_disturb_updated', {
        enabled,
        until: until ? new Date(until) : null,
        updated_at: new Date()
      });

    } catch (error) {
      console.error('设置勿扰模式错误:', error);
      socket.emit('do_not_disturb_error', {
        error: '设置勿扰模式失败',
        code: 'TOGGLE_DND_FAILED'
      });
    }
  });

  /**
   * 获取用户活跃统计事件
   */
  socket.on('get_activity_stats', async () => {
    try {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const thisWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      // 获取今日活跃用户数
      const todayActiveUsers = await User.countDocuments({
        last_seen_at: { $gte: today },
        is_deleted: false
      });

      // 获取本周活跃用户数
      const weekActiveUsers = await User.countDocuments({
        last_seen_at: { $gte: thisWeek },
        is_deleted: false
      });

      // 获取当前在线用户数
      const currentOnlineUsers = onlineUsers.size;

      // 获取用户总数
      const totalUsers = await User.countDocuments({ is_deleted: false });

      socket.emit('activity_stats', {
        current_online: currentOnlineUsers,
        today_active: todayActiveUsers,
        week_active: weekActiveUsers,
        total_users: totalUsers,
        timestamp: new Date()
      });

    } catch (error) {
      console.error('获取活跃统计错误:', error);
      socket.emit('activity_stats_error', {
        error: '获取活跃统计失败',
        code: 'GET_ACTIVITY_STATS_FAILED'
      });
    }
  });

  /**
   * 心跳检测事件
   */
  socket.on('heartbeat', () => {
    // 更新用户最后活跃时间
    if (onlineUsers.has(userId)) {
      onlineUsers.get(userId).lastSeen = new Date();
    }

    // 更新数据库中的最后活跃时间
    User.findByIdAndUpdate(userId, {
      last_seen_at: new Date()
    }).catch(console.error);

    // 响应心跳
    socket.emit('heartbeat_ack', {
      timestamp: new Date()
    });
  });
}

/**
 * 广播用户状态变化
 * @param {Object} io - Socket.io服务器实例
 * @param {String} userId - 用户ID
 * @param {String} status - 新状态
 * @param {Object} userInfo - 用户信息
 */
export function broadcastUserStatusChange(io, userId, status, userInfo) {
  // 获取用户的好友列表并通知状态变化
  Friendship.find({ user_id: userId })
    .select('friend_id')
    .then(friendships => {
      friendships.forEach(friendship => {
        emitToUser(io, friendship.friend_id.toString(), 'friend_status_changed', {
          user_id: userId,
          username: userInfo.username,
          status: status,
          profile: userInfo.profile,
          timestamp: new Date()
        });
      });
    })
    .catch(console.error);
}

/**
 * 清理离线用户
 * @param {Object} io - Socket.io服务器实例
 * @param {Map} onlineUsers - 在线用户映射
 * @param {Number} timeoutMs - 超时时间（毫秒）
 */
export function cleanupOfflineUsers(io, onlineUsers, timeoutMs = 5 * 60 * 1000) {
  const now = new Date();
  
  for (const [userId, userData] of onlineUsers.entries()) {
    if (now - userData.lastSeen > timeoutMs) {
      console.log(`清理超时用户: ${userData.userInfo.username}`);
      
      // 从在线用户列表移除
      onlineUsers.delete(userId);
      
      // 更新数据库状态
      User.findByIdAndUpdate(userId, {
        is_online: false,
        last_seen_at: userData.lastSeen
      }).catch(console.error);

      // 通知好友用户离线
      broadcastUserStatusChange(io, userId, 'offline', userData.userInfo);
    }
  }
}