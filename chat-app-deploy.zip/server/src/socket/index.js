/**
 * Socket.io 服务器配置
 * 处理实时通信功能
 */

import { Server } from 'socket.io';
import { authenticateSocket } from '../middleware/auth.js';
import { User } from '../models/index.js';
import messageHandler from './messageHandler.js';
import friendHandler from './friendHandler.js';
import notificationHandler from './notificationHandler.js';
import onlineStatusHandler from './onlineStatusHandler.js';

/**
 * 初始化Socket.io服务器
 * @param {Object} server - HTTP服务器实例
 * @returns {Object} Socket.io服务器实例
 */
export function initializeSocket(server) {
  const io = new Server(server, {
    cors: {
      origin: process.env.CLIENT_URL || "http://localhost:3000",
      methods: ["GET", "POST"],
      credentials: true
    },
    pingTimeout: 60000,
    pingInterval: 25000
  });

  // 存储在线用户
  const onlineUsers = new Map(); // userId -> { socketId, userInfo, lastSeen }
  const userSockets = new Map(); // socketId -> userId

  // Socket认证中间件
  io.use(authenticateSocket);

  // 连接处理
  io.on('connection', async (socket) => {
    const userId = socket.user._id.toString();
    const userInfo = socket.user;

    console.log(`用户 ${userInfo.username} 已连接，Socket ID: ${socket.id}`);

    // 添加到在线用户列表
    onlineUsers.set(userId, {
      socketId: socket.id,
      userInfo: userInfo,
      lastSeen: new Date()
    });
    userSockets.set(socket.id, userId);

    // 更新用户在线状态
    await User.findByIdAndUpdate(userId, {
      is_online: true,
      last_seen_at: new Date()
    });

    // 加入用户专属房间
    socket.join(`user_${userId}`);

    // 通知好友用户上线
    socket.broadcast.emit('user_online', {
      user_id: userId,
      username: userInfo.username,
      profile: userInfo.profile
    });

    // 注册事件处理器
    messageHandler(io, socket, onlineUsers);
    friendHandler(io, socket, onlineUsers);
    notificationHandler(io, socket, onlineUsers);
    onlineStatusHandler(io, socket, onlineUsers);

    // 发送在线用户列表
    socket.emit('online_users', Array.from(onlineUsers.values()).map(user => ({
      user_id: user.userInfo._id,
      username: user.userInfo.username,
      profile: user.userInfo.profile,
      last_seen: user.lastSeen
    })));

    // 心跳检测
    socket.on('ping', () => {
      socket.emit('pong');
      // 更新最后活跃时间
      if (onlineUsers.has(userId)) {
        onlineUsers.get(userId).lastSeen = new Date();
      }
    });

    // 加入聊天会话房间
    socket.on('join_session', (sessionId) => {
      if (sessionId) {
        socket.join(`session_${sessionId}`);
        console.log(`用户 ${userInfo.username} 加入会话房间: session_${sessionId}`);
      }
    });

    // 离开聊天会话房间
    socket.on('leave_session', (sessionId) => {
      if (sessionId) {
        socket.leave(`session_${sessionId}`);
        console.log(`用户 ${userInfo.username} 离开会话房间: session_${sessionId}`);
      }
    });

    // 正在输入状态
    socket.on('typing_start', (data) => {
      const { session_id } = data;
      if (session_id) {
        socket.to(`session_${session_id}`).emit('user_typing', {
          user_id: userId,
          username: userInfo.username,
          session_id
        });
      }
    });

    // 停止输入状态
    socket.on('typing_stop', (data) => {
      const { session_id } = data;
      if (session_id) {
        socket.to(`session_${session_id}`).emit('user_stop_typing', {
          user_id: userId,
          session_id
        });
      }
    });

    // 断开连接处理
    socket.on('disconnect', async (reason) => {
      console.log(`用户 ${userInfo.username} 断开连接，原因: ${reason}`);

      // 从在线用户列表移除
      onlineUsers.delete(userId);
      userSockets.delete(socket.id);

      // 更新用户离线状态
      await User.findByIdAndUpdate(userId, {
        is_online: false,
        last_seen_at: new Date()
      });

      // 通知好友用户离线
      socket.broadcast.emit('user_offline', {
        user_id: userId,
        username: userInfo.username,
        last_seen: new Date()
      });
    });

    // 错误处理
    socket.on('error', (error) => {
      console.error(`Socket错误 (用户: ${userInfo.username}):`, error);
    });
  });

  // 定期清理离线用户
  setInterval(() => {
    const now = new Date();
    const timeout = 5 * 60 * 1000; // 5分钟超时

    for (const [userId, userData] of onlineUsers.entries()) {
      if (now - userData.lastSeen > timeout) {
        console.log(`清理超时用户: ${userData.userInfo.username}`);
        onlineUsers.delete(userId);
        
        // 更新数据库状态
        User.findByIdAndUpdate(userId, {
          is_online: false,
          last_seen_at: userData.lastSeen
        }).catch(console.error);

        // 通知其他用户
        io.emit('user_offline', {
          user_id: userId,
          username: userData.userInfo.username,
          last_seen: userData.lastSeen
        });
      }
    }
  }, 60000); // 每分钟检查一次

  // 将在线用户信息附加到io实例
  io.onlineUsers = onlineUsers;
  io.userSockets = userSockets;

  return io;
}

/**
 * 获取用户的Socket实例
 * @param {Object} io - Socket.io服务器实例
 * @param {String} userId - 用户ID
 * @returns {Object|null} Socket实例
 */
export function getUserSocket(io, userId) {
  const userData = io.onlineUsers.get(userId);
  if (userData) {
    return io.sockets.sockets.get(userData.socketId);
  }
  return null;
}

/**
 * 向用户发送消息
 * @param {Object} io - Socket.io服务器实例
 * @param {String} userId - 用户ID
 * @param {String} event - 事件名称
 * @param {Object} data - 数据
 */
export function emitToUser(io, userId, event, data) {
  io.to(`user_${userId}`).emit(event, data);
}

/**
 * 向会话中的所有用户发送消息
 * @param {Object} io - Socket.io服务器实例
 * @param {String} sessionId - 会话ID
 * @param {String} event - 事件名称
 * @param {Object} data - 数据
 * @param {String} excludeUserId - 排除的用户ID
 */
export function emitToSession(io, sessionId, event, data, excludeUserId = null) {
  const room = `session_${sessionId}`;
  if (excludeUserId) {
    const userData = io.onlineUsers.get(excludeUserId);
    if (userData) {
      io.to(room).except(userData.socketId).emit(event, data);
    } else {
      io.to(room).emit(event, data);
    }
  } else {
    io.to(room).emit(event, data);
  }
}

/**
 * 广播消息给所有在线用户
 * @param {Object} io - Socket.io服务器实例
 * @param {String} event - 事件名称
 * @param {Object} data - 数据
 * @param {String} excludeUserId - 排除的用户ID
 */
export function broadcastToAll(io, event, data, excludeUserId = null) {
  if (excludeUserId) {
    const userData = io.onlineUsers.get(excludeUserId);
    if (userData) {
      io.except(userData.socketId).emit(event, data);
    } else {
      io.emit(event, data);
    }
  } else {
    io.emit(event, data);
  }
}

/**
 * 获取在线用户数量
 * @param {Object} io - Socket.io服务器实例
 * @returns {Number} 在线用户数量
 */
export function getOnlineUserCount(io) {
  return io.onlineUsers.size;
}

/**
 * 获取在线用户列表
 * @param {Object} io - Socket.io服务器实例
 * @returns {Array} 在线用户列表
 */
export function getOnlineUsers(io) {
  return Array.from(io.onlineUsers.values()).map(user => ({
    user_id: user.userInfo._id,
    username: user.userInfo.username,
    profile: user.userInfo.profile,
    last_seen: user.lastSeen
  }));
}

export default initializeSocket;