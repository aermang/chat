/**
 * Socket.io 好友处理器
 * 处理实时好友相关事件
 */

import { Friendship, FriendRequest, User, Notification } from '../models/index.js';
import { emitToUser } from './index.js';

/**
 * 好友事件处理器
 * @param {Object} io - Socket.io服务器实例
 * @param {Object} socket - Socket实例
 * @param {Map} onlineUsers - 在线用户映射
 */
export default function friendHandler(io, socket, onlineUsers) {
  const userId = socket.user._id.toString();

  /**
   * 发送好友申请事件
   */
  socket.on('send_friend_request', async (data) => {
    try {
      const { target_user_id, message } = data;

      if (!target_user_id) {
        socket.emit('friend_request_error', {
          error: '缺少目标用户ID',
          code: 'MISSING_TARGET_USER'
        });
        return;
      }

      // 检查目标用户是否存在
      const targetUser = await User.findById(target_user_id);
      if (!targetUser) {
        socket.emit('friend_request_error', {
          error: '目标用户不存在',
          code: 'USER_NOT_FOUND'
        });
        return;
      }

      // 检查是否已经是好友
      const existingFriendship = await Friendship.findOne({
        $or: [
          { user_id: userId, friend_id: target_user_id },
          { user_id: target_user_id, friend_id: userId }
        ]
      });

      if (existingFriendship) {
        socket.emit('friend_request_error', {
          error: '已经是好友关系',
          code: 'ALREADY_FRIENDS'
        });
        return;
      }

      // 检查是否已经发送过申请
      const existingRequest = await FriendRequest.findOne({
        requester_id: userId,
        target_id: target_user_id,
        status: 'pending'
      });

      if (existingRequest) {
        socket.emit('friend_request_error', {
          error: '已经发送过好友申请',
          code: 'REQUEST_ALREADY_SENT'
        });
        return;
      }

      // 创建好友申请
      const friendRequest = await FriendRequest.create({
        requester_id: userId,
        target_id: target_user_id,
        message: message || ''
      });

      await friendRequest.populate([
        { path: 'requester_id', select: 'username profile' },
        { path: 'target_id', select: 'username profile' }
      ]);

      // 创建通知
      await Notification.createFriendRequestNotification(
        target_user_id,
        userId,
        friendRequest._id
      );

      // 实时通知目标用户
      emitToUser(io, target_user_id, 'new_friend_request', {
        request_id: friendRequest._id,
        requester: friendRequest.requester_id,
        message: friendRequest.message,
        created_at: friendRequest.created_at
      });

      // 确认发送成功
      socket.emit('friend_request_sent', {
        request_id: friendRequest._id,
        target_user: friendRequest.target_id,
        status: 'sent'
      });

    } catch (error) {
      console.error('发送好友申请错误:', error);
      socket.emit('friend_request_error', {
        error: '发送好友申请失败',
        code: 'SEND_REQUEST_FAILED'
      });
    }
  });

  /**
   * 处理好友申请事件（接受/拒绝）
   */
  socket.on('handle_friend_request', async (data) => {
    try {
      const { request_id, action } = data; // action: 'accept' | 'reject'

      if (!request_id || !action) {
        socket.emit('handle_request_error', {
          error: '缺少必要参数',
          code: 'MISSING_PARAMS'
        });
        return;
      }

      // 查找好友申请
      const friendRequest = await FriendRequest.findById(request_id)
        .populate('requester_id', 'username profile')
        .populate('target_id', 'username profile');

      if (!friendRequest) {
        socket.emit('handle_request_error', {
          error: '好友申请不存在',
          code: 'REQUEST_NOT_FOUND'
        });
        return;
      }

      // 验证权限（只有目标用户可以处理申请）
      if (friendRequest.target_id._id.toString() !== userId) {
        socket.emit('handle_request_error', {
          error: '无权限处理此申请',
          code: 'ACCESS_DENIED'
        });
        return;
      }

      // 检查申请状态
      if (friendRequest.status !== 'pending') {
        socket.emit('handle_request_error', {
          error: '申请已被处理',
          code: 'REQUEST_ALREADY_HANDLED'
        });
        return;
      }

      if (action === 'accept') {
        // 接受好友申请
        await FriendRequest.findByIdAndUpdate(request_id, {
          status: 'accepted',
          handled_at: new Date()
        });

        // 创建双向好友关系
        await Friendship.createFriendship(
          friendRequest.requester_id._id,
          friendRequest.target_id._id
        );

        // 通知申请者
        emitToUser(io, friendRequest.requester_id._id.toString(), 'friend_request_accepted', {
          request_id,
          friend: friendRequest.target_id,
          accepted_at: new Date()
        });

        // 通知双方好友列表更新
        emitToUser(io, friendRequest.requester_id._id.toString(), 'friend_added', {
          friend: friendRequest.target_id
        });
        emitToUser(io, friendRequest.target_id._id.toString(), 'friend_added', {
          friend: friendRequest.requester_id
        });

        socket.emit('handle_request_success', {
          request_id,
          action: 'accepted',
          friend: friendRequest.requester_id
        });

      } else if (action === 'reject') {
        // 拒绝好友申请
        await FriendRequest.findByIdAndUpdate(request_id, {
          status: 'rejected',
          handled_at: new Date()
        });

        // 通知申请者（可选，避免打扰）
        // emitToUser(io, friendRequest.requester_id._id.toString(), 'friend_request_rejected', {
        //   request_id,
        //   rejected_at: new Date()
        // });

        socket.emit('handle_request_success', {
          request_id,
          action: 'rejected'
        });
      }

    } catch (error) {
      console.error('处理好友申请错误:', error);
      socket.emit('handle_request_error', {
        error: '处理好友申请失败',
        code: 'HANDLE_REQUEST_FAILED'
      });
    }
  });

  /**
   * 删除好友事件
   */
  socket.on('remove_friend', async (data) => {
    try {
      const { friend_id } = data;

      if (!friend_id) {
        socket.emit('remove_friend_error', {
          error: '缺少好友ID',
          code: 'MISSING_FRIEND_ID'
        });
        return;
      }

      // 查找好友关系
      const friendship = await Friendship.findOne({
        $or: [
          { user_id: userId, friend_id },
          { user_id: friend_id, friend_id: userId }
        ]
      });

      if (!friendship) {
        socket.emit('remove_friend_error', {
          error: '好友关系不存在',
          code: 'FRIENDSHIP_NOT_FOUND'
        });
        return;
      }

      // 删除双向好友关系
      await Friendship.deleteMany({
        $or: [
          { user_id: userId, friend_id },
          { user_id: friend_id, friend_id: userId }
        ]
      });

      // 获取被删除的好友信息
      const friendInfo = await User.findById(friend_id).select('username profile');

      // 通知对方好友被删除
      emitToUser(io, friend_id, 'friend_removed', {
        removed_by: userId,
        removed_at: new Date()
      });

      socket.emit('remove_friend_success', {
        friend_id,
        friend_info: friendInfo,
        removed_at: new Date()
      });

    } catch (error) {
      console.error('删除好友错误:', error);
      socket.emit('remove_friend_error', {
        error: '删除好友失败',
        code: 'REMOVE_FRIEND_FAILED'
      });
    }
  });

  /**
   * 更新好友备注事件
   */
  socket.on('update_friend_remark', async (data) => {
    try {
      const { friend_id, remark } = data;

      if (!friend_id) {
        socket.emit('update_remark_error', {
          error: '缺少好友ID',
          code: 'MISSING_FRIEND_ID'
        });
        return;
      }

      // 更新好友备注
      const friendship = await Friendship.findOneAndUpdate(
        { user_id: userId, friend_id },
        { remark: remark || '', updated_at: new Date() },
        { new: true }
      );

      if (!friendship) {
        socket.emit('update_remark_error', {
          error: '好友关系不存在',
          code: 'FRIENDSHIP_NOT_FOUND'
        });
        return;
      }

      socket.emit('update_remark_success', {
        friend_id,
        remark: friendship.remark,
        updated_at: friendship.updated_at
      });

    } catch (error) {
      console.error('更新好友备注错误:', error);
      socket.emit('update_remark_error', {
        error: '更新好友备注失败',
        code: 'UPDATE_REMARK_FAILED'
      });
    }
  });

  /**
   * 设置好友置顶事件
   */
  socket.on('toggle_friend_pin', async (data) => {
    try {
      const { friend_id, is_pinned } = data;

      if (!friend_id) {
        socket.emit('toggle_pin_error', {
          error: '缺少好友ID',
          code: 'MISSING_FRIEND_ID'
        });
        return;
      }

      // 更新好友置顶状态
      const friendship = await Friendship.findOneAndUpdate(
        { user_id: userId, friend_id },
        { is_pinned: Boolean(is_pinned), updated_at: new Date() },
        { new: true }
      );

      if (!friendship) {
        socket.emit('toggle_pin_error', {
          error: '好友关系不存在',
          code: 'FRIENDSHIP_NOT_FOUND'
        });
        return;
      }

      socket.emit('toggle_pin_success', {
        friend_id,
        is_pinned: friendship.is_pinned,
        updated_at: friendship.updated_at
      });

    } catch (error) {
      console.error('设置好友置顶错误:', error);
      socket.emit('toggle_pin_error', {
        error: '设置好友置顶失败',
        code: 'TOGGLE_PIN_FAILED'
      });
    }
  });

  /**
   * 获取好友在线状态事件
   */
  socket.on('get_friends_online_status', async () => {
    try {
      // 获取用户的所有好友
      const friendships = await Friendship.find({ user_id: userId })
        .populate('friend_id', 'username is_online last_seen_at');

      // 构建在线状态信息
      const friendsStatus = friendships.map(friendship => {
        const friend = friendship.friend_id;
        const isOnline = onlineUsers.has(friend._id.toString());
        
        return {
          friend_id: friend._id,
          username: friend.username,
          is_online: isOnline,
          last_seen: isOnline ? new Date() : friend.last_seen_at
        };
      });

      socket.emit('friends_online_status', {
        friends: friendsStatus,
        timestamp: new Date()
      });

    } catch (error) {
      console.error('获取好友在线状态错误:', error);
      socket.emit('friends_status_error', {
        error: '获取好友在线状态失败',
        code: 'GET_STATUS_FAILED'
      });
    }
  });

  /**
   * 搜索好友事件
   */
  socket.on('search_friends', async (data) => {
    try {
      const { keyword, page = 1, limit = 20 } = data;

      if (!keyword) {
        socket.emit('search_friends_error', {
          error: '缺少搜索关键词',
          code: 'MISSING_KEYWORD'
        });
        return;
      }

      // 获取用户的好友列表
      const friendships = await Friendship.find({ user_id: userId })
        .populate({
          path: 'friend_id',
          match: {
            $or: [
              { username: { $regex: keyword, $options: 'i' } },
              { 'profile.nickname': { $regex: keyword, $options: 'i' } }
            ]
          },
          select: 'username profile is_online last_seen_at'
        })
        .skip((page - 1) * limit)
        .limit(limit);

      // 过滤掉没有匹配的好友
      const matchedFriends = friendships
        .filter(friendship => friendship.friend_id)
        .map(friendship => ({
          friend_id: friendship.friend_id._id,
          username: friendship.friend_id.username,
          profile: friendship.friend_id.profile,
          remark: friendship.remark,
          is_pinned: friendship.is_pinned,
          is_online: onlineUsers.has(friendship.friend_id._id.toString()),
          last_seen: friendship.friend_id.last_seen_at,
          created_at: friendship.created_at
        }));

      socket.emit('search_friends_results', {
        friends: matchedFriends,
        keyword,
        pagination: {
          page,
          limit,
          total: matchedFriends.length
        }
      });

    } catch (error) {
      console.error('搜索好友错误:', error);
      socket.emit('search_friends_error', {
        error: '搜索好友失败',
        code: 'SEARCH_FRIENDS_FAILED'
      });
    }
  });
}