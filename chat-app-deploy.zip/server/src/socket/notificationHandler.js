/**
 * Socket.io 通知处理器
 * 处理实时通知相关事件
 */

import { Notification } from '../models/index.js';
import { emitToUser } from './index.js';

/**
 * 通知事件处理器
 * @param {Object} io - Socket.io服务器实例
 * @param {Object} socket - Socket实例
 * @param {Map} onlineUsers - 在线用户映射
 */
export default function notificationHandler(io, socket, onlineUsers) {
  const userId = socket.user._id.toString();

  /**
   * 获取通知列表事件
   */
  socket.on('get_notifications', async (data) => {
    try {
      const { 
        page = 1, 
        limit = 20, 
        type, 
        is_read, 
        priority 
      } = data;

      // 构建查询条件
      const query = {
        receiver_id: userId,
        is_deleted: false
      };

      if (type) {
        query.type = type;
      }

      if (typeof is_read === 'boolean') {
        query.is_read = is_read;
      }

      if (priority) {
        query.priority = priority;
      }

      // 查询通知
      const notifications = await Notification.find(query)
        .populate('sender_id', 'username profile')
        .sort({ created_at: -1 })
        .limit(limit)
        .skip((page - 1) * limit);

      // 获取总数
      const total = await Notification.countDocuments(query);

      // 获取未读数量
      const unreadCount = await Notification.countDocuments({
        receiver_id: userId,
        is_read: false,
        is_deleted: false
      });

      socket.emit('notifications_list', {
        notifications,
        pagination: {
          page,
          limit,
          total,
          has_more: total > page * limit
        },
        unread_count: unreadCount
      });

    } catch (error) {
      console.error('获取通知列表错误:', error);
      socket.emit('notifications_error', {
        error: '获取通知列表失败',
        code: 'GET_NOTIFICATIONS_FAILED'
      });
    }
  });

  /**
   * 标记通知为已读事件
   */
  socket.on('mark_notification_read', async (data) => {
    try {
      const { notification_id, mark_all = false } = data;

      if (mark_all) {
        // 标记所有通知为已读
        await Notification.updateMany(
          {
            receiver_id: userId,
            is_read: false,
            is_deleted: false
          },
          {
            is_read: true,
            read_at: new Date()
          }
        );

        socket.emit('mark_read_success', {
          mark_all: true,
          marked_count: await Notification.countDocuments({
            receiver_id: userId,
            is_read: true,
            is_deleted: false
          })
        });

      } else if (notification_id) {
        // 标记单个通知为已读
        const notification = await Notification.findOneAndUpdate(
          {
            _id: notification_id,
            receiver_id: userId
          },
          {
            is_read: true,
            read_at: new Date()
          },
          { new: true }
        );

        if (!notification) {
          socket.emit('mark_read_error', {
            error: '通知不存在或无权限',
            code: 'NOTIFICATION_NOT_FOUND'
          });
          return;
        }

        socket.emit('mark_read_success', {
          notification_id,
          read_at: notification.read_at
        });
      }

      // 发送更新后的未读数量
      const unreadCount = await Notification.countDocuments({
        receiver_id: userId,
        is_read: false,
        is_deleted: false
      });

      socket.emit('unread_count_updated', { unread_count: unreadCount });

    } catch (error) {
      console.error('标记通知已读错误:', error);
      socket.emit('mark_read_error', {
        error: '标记通知已读失败',
        code: 'MARK_READ_FAILED'
      });
    }
  });

  /**
   * 删除通知事件
   */
  socket.on('delete_notification', async (data) => {
    try {
      const { notification_id, delete_read = false } = data;

      if (delete_read) {
        // 删除所有已读通知
        const result = await Notification.updateMany(
          {
            receiver_id: userId,
            is_read: true,
            is_deleted: false
          },
          {
            is_deleted: true,
            deleted_at: new Date()
          }
        );

        socket.emit('delete_success', {
          delete_read: true,
          deleted_count: result.modifiedCount
        });

      } else if (notification_id) {
        // 删除单个通知
        const notification = await Notification.findOneAndUpdate(
          {
            _id: notification_id,
            receiver_id: userId
          },
          {
            is_deleted: true,
            deleted_at: new Date()
          },
          { new: true }
        );

        if (!notification) {
          socket.emit('delete_error', {
            error: '通知不存在或无权限',
            code: 'NOTIFICATION_NOT_FOUND'
          });
          return;
        }

        socket.emit('delete_success', {
          notification_id,
          deleted_at: notification.deleted_at
        });
      }

    } catch (error) {
      console.error('删除通知错误:', error);
      socket.emit('delete_error', {
        error: '删除通知失败',
        code: 'DELETE_FAILED'
      });
    }
  });

  /**
   * 获取未读通知数量事件
   */
  socket.on('get_unread_count', async () => {
    try {
      // 获取各类型未读通知数量
      const counts = await Notification.aggregate([
        {
          $match: {
            receiver_id: userId,
            is_read: false,
            is_deleted: false
          }
        },
        {
          $group: {
            _id: '$type',
            count: { $sum: 1 }
          }
        }
      ]);

      // 转换为对象格式
      const unreadCounts = {
        total: 0,
        friend_request: 0,
        new_message: 0,
        moment_like: 0,
        moment_comment: 0,
        system: 0
      };

      counts.forEach(item => {
        unreadCounts[item._id] = item.count;
        unreadCounts.total += item.count;
      });

      socket.emit('unread_counts', unreadCounts);

    } catch (error) {
      console.error('获取未读通知数量错误:', error);
      socket.emit('unread_count_error', {
        error: '获取未读通知数量失败',
        code: 'GET_UNREAD_COUNT_FAILED'
      });
    }
  });

  /**
   * 创建系统通知事件（管理员功能）
   */
  socket.on('create_system_notification', async (data) => {
    try {
      // 检查管理员权限
      if (socket.user.role !== 'admin') {
        socket.emit('create_notification_error', {
          error: '无权限创建系统通知',
          code: 'ACCESS_DENIED'
        });
        return;
      }

      const { 
        target_users, // 目标用户ID数组，为空则发送给所有用户
        title,
        content,
        priority = 'normal',
        link_url
      } = data;

      if (!title || !content) {
        socket.emit('create_notification_error', {
          error: '缺少标题或内容',
          code: 'MISSING_PARAMS'
        });
        return;
      }

      let targetUserIds = target_users;

      // 如果没有指定目标用户，则发送给所有用户
      if (!targetUserIds || targetUserIds.length === 0) {
        const allUsers = await User.find({ is_deleted: false }).select('_id');
        targetUserIds = allUsers.map(user => user._id.toString());
      }

      // 批量创建通知
      const notifications = targetUserIds.map(receiverId => ({
        receiver_id: receiverId,
        sender_id: userId,
        type: 'system',
        title,
        content,
        priority,
        link_url: link_url || null
      }));

      const createdNotifications = await Notification.insertMany(notifications);

      // 实时推送给在线用户
      targetUserIds.forEach(receiverId => {
        if (onlineUsers.has(receiverId)) {
          emitToUser(io, receiverId, 'new_notification', {
            type: 'system',
            title,
            content,
            priority,
            link_url,
            created_at: new Date()
          });
        }
      });

      socket.emit('create_notification_success', {
        created_count: createdNotifications.length,
        target_users: targetUserIds.length
      });

    } catch (error) {
      console.error('创建系统通知错误:', error);
      socket.emit('create_notification_error', {
        error: '创建系统通知失败',
        code: 'CREATE_NOTIFICATION_FAILED'
      });
    }
  });

  /**
   * 获取通知统计信息事件
   */
  socket.on('get_notification_stats', async () => {
    try {
      const stats = await Notification.aggregate([
        {
          $match: {
            receiver_id: userId,
            is_deleted: false
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            unread: {
              $sum: {
                $cond: [{ $eq: ['$is_read', false] }, 1, 0]
              }
            },
            today: {
              $sum: {
                $cond: [
                  {
                    $gte: [
                      '$created_at',
                      new Date(new Date().setHours(0, 0, 0, 0))
                    ]
                  },
                  1,
                  0
                ]
              }
            },
            this_week: {
              $sum: {
                $cond: [
                  {
                    $gte: [
                      '$created_at',
                      new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
                    ]
                  },
                  1,
                  0
                ]
              }
            }
          }
        }
      ]);

      const result = stats[0] || {
        total: 0,
        unread: 0,
        today: 0,
        this_week: 0
      };

      socket.emit('notification_stats', result);

    } catch (error) {
      console.error('获取通知统计错误:', error);
      socket.emit('notification_stats_error', {
        error: '获取通知统计失败',
        code: 'GET_STATS_FAILED'
      });
    }
  });

  /**
   * 设置通知偏好事件
   */
  socket.on('update_notification_settings', async (data) => {
    try {
      const { 
        enable_push = true,
        enable_email = false,
        enable_sound = true,
        quiet_hours_start,
        quiet_hours_end,
        notification_types = []
      } = data;

      // 这里可以将通知设置保存到用户配置中
      // 暂时通过Socket响应确认设置更新
      socket.emit('notification_settings_updated', {
        enable_push,
        enable_email,
        enable_sound,
        quiet_hours_start,
        quiet_hours_end,
        notification_types,
        updated_at: new Date()
      });

    } catch (error) {
      console.error('更新通知设置错误:', error);
      socket.emit('notification_settings_error', {
        error: '更新通知设置失败',
        code: 'UPDATE_SETTINGS_FAILED'
      });
    }
  });
}

/**
 * 向用户发送实时通知
 * @param {Object} io - Socket.io服务器实例
 * @param {String} userId - 用户ID
 * @param {Object} notificationData - 通知数据
 */
export function sendRealTimeNotification(io, userId, notificationData) {
  emitToUser(io, userId, 'new_notification', {
    ...notificationData,
    timestamp: new Date()
  });
}

/**
 * 批量发送实时通知
 * @param {Object} io - Socket.io服务器实例
 * @param {Array} userIds - 用户ID数组
 * @param {Object} notificationData - 通知数据
 */
export function broadcastNotification(io, userIds, notificationData) {
  userIds.forEach(userId => {
    sendRealTimeNotification(io, userId, notificationData);
  });
}