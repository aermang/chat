/**
 * 服务器启动文件
 * 初始化数据库连接、Socket.io和HTTP服务器
 */

import http from 'http';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import createApp from './app.js';
import { initializeSocket } from './socket/index.js';
import { initializeIndexes, cleanupExpiredData } from './models/index.js';
import { 
  handleDatabaseErrors
} from './middleware/errorHandler.js';

// 加载环境变量
dotenv.config();

// 处理未捕获的异常
process.on('uncaughtException', (err) => {
  console.error('未捕获的异常:', err);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  console.error('未处理的Promise拒绝:', err);
  process.exit(1);
});

/**
 * 连接MongoDB数据库
 */
async function connectDatabase() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/chat_app';
    
    console.log('正在连接MongoDB数据库...');
    
    await mongoose.connect(mongoUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      maxPoolSize: 10, // 连接池大小
      serverSelectionTimeoutMS: 5000, // 服务器选择超时
      socketTimeoutMS: 45000, // Socket超时
      bufferMaxEntries: 0, // 禁用缓冲
      bufferCommands: false // 禁用命令缓冲
    });

    console.log('✅ MongoDB数据库连接成功');

    // 初始化数据库索引
    await initializeIndexes();
    console.log('✅ 数据库索引初始化完成');

    // 设置数据库错误处理
    handleDatabaseErrors();

  } catch (error) {
    console.error('❌ MongoDB数据库连接失败:', error);
    process.exit(1);
  }
}

/**
 * 启动HTTP服务器和Socket.io
 */
async function startServer() {
  try {
    // 创建Express应用
    const app = createApp();
    
    // 创建HTTP服务器
    const server = http.createServer(app);
    
    // 初始化Socket.io
    const io = initializeSocket(server);
    console.log('✅ Socket.io服务器初始化完成');

    // 将io实例附加到app，供路由使用
    app.set('io', io);

    // 获取端口
    const PORT = process.env.PORT || 5000;
    
    // 启动服务器
    server.listen(PORT, () => {
      console.log(`🚀 服务器运行在端口 ${PORT}`);
      console.log(`📱 API地址: http://localhost:${PORT}/api`);
      console.log(`🔌 Socket.io地址: http://localhost:${PORT}`);
      console.log(`🏥 健康检查: http://localhost:${PORT}/health`);
      console.log(`🌍 环境: ${process.env.NODE_ENV || 'development'}`);
    });

    // 优雅关闭处理
    const gracefulShutdown = async (signal) => {
      console.log(`\n收到 ${signal} 信号，开始优雅关闭...`);
      
      // 停止接受新连接
      server.close(async () => {
        console.log('HTTP服务器已关闭');
        
        try {
          // 关闭Socket.io连接
          io.close(() => {
            console.log('Socket.io服务器已关闭');
          });
          
          // 关闭数据库连接
          await mongoose.connection.close();
          console.log('数据库连接已关闭');
          
          console.log('✅ 服务器优雅关闭完成');
          process.exit(0);
        } catch (error) {
          console.error('关闭过程中发生错误:', error);
          process.exit(1);
        }
      });

      // 强制关闭超时
      setTimeout(() => {
        console.error('强制关闭服务器');
        process.exit(1);
      }, 10000);
    };

    // 监听关闭信号
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return { app, server, io };

  } catch (error) {
    console.error('❌ 服务器启动失败:', error);
    process.exit(1);
  }
}

/**
 * 启动定时任务
 */
function startScheduledTasks() {
  // 每小时清理过期数据
  setInterval(async () => {
    try {
      console.log('开始清理过期数据...');
      await cleanupExpiredData();
      console.log('过期数据清理完成');
    } catch (error) {
      console.error('清理过期数据失败:', error);
    }
  }, 60 * 60 * 1000); // 1小时

  // 每天凌晨2点执行数据库维护
  const scheduleMaintenanceTask = () => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(2, 0, 0, 0);
    
    const msUntilMaintenance = tomorrow.getTime() - now.getTime();
    
    setTimeout(async () => {
      try {
        console.log('开始数据库维护任务...');
        
        // 执行数据库维护操作
        await cleanupExpiredData();
        
        // 可以添加更多维护任务，如：
        // - 数据库索引优化
        // - 日志文件清理
        // - 缓存清理等
        
        console.log('数据库维护任务完成');
        
        // 安排下一次维护
        scheduleMaintenanceTask();
        
      } catch (error) {
        console.error('数据库维护任务失败:', error);
      }
    }, msUntilMaintenance);
  };

  scheduleMaintenanceTask();
  console.log('✅ 定时任务已启动');
}

/**
 * 主启动函数
 */
async function main() {
  try {
    console.log('🚀 正在启动聊天应用服务器...');
    
    // 连接数据库
    await connectDatabase();
    
    // 启动服务器
    const { app, server, io } = await startServer();
    
    // 启动定时任务
    startScheduledTasks();
    
    console.log('✅ 服务器启动完成！');
    
    return { app, server, io };
    
  } catch (error) {
    console.error('❌ 服务器启动失败:', error);
    process.exit(1);
  }
}

// 如果直接运行此文件，则启动服务器
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(error => {
    console.error('启动失败:', error);
    process.exit(1);
  });
}

export default main;
export { connectDatabase, startServer };