/**
 * MongoDB数据库连接配置
 * 使用Mongoose ODM连接本地MongoDB实例
 */

import mongoose from 'mongoose';

/**
 * 连接MongoDB数据库
 * @returns {Promise<void>}
 */
export async function connectDatabase() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/chat_app';
    
    // Mongoose连接选项
    const options = {
      // 使用新的URL解析器
      useNewUrlParser: true,
      useUnifiedTopology: true,
      
      // 连接池配置
      maxPoolSize: 10, // 最大连接数
      serverSelectionTimeoutMS: 5000, // 服务器选择超时
      socketTimeoutMS: 45000, // Socket超时
      
      // 缓冲配置
      bufferMaxEntries: 0,
      bufferCommands: false,
    };

    // 连接数据库
    await mongoose.connect(mongoUri, options);
    
    console.log(`📦 MongoDB连接成功: ${mongoUri}`);
    
    // 监听连接事件
    mongoose.connection.on('error', (error) => {
      console.error('❌ MongoDB连接错误:', error);
    });
    
    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️ MongoDB连接断开');
    });
    
    mongoose.connection.on('reconnected', () => {
      console.log('🔄 MongoDB重新连接成功');
    });
    
  } catch (error) {
    console.error('❌ MongoDB连接失败:', error);
    throw error;
  }
}

/**
 * 关闭数据库连接
 * @returns {Promise<void>}
 */
export async function disconnectDatabase() {
  try {
    await mongoose.connection.close();
    console.log('📦 MongoDB连接已关闭');
  } catch (error) {
    console.error('❌ 关闭MongoDB连接时出错:', error);
    throw error;
  }
}

/**
 * 检查数据库连接状态
 * @returns {boolean}
 */
export function isDatabaseConnected() {
  return mongoose.connection.readyState === 1;
}

/**
 * 获取数据库连接状态描述
 * @returns {string}
 */
export function getDatabaseStatus() {
  const states = {
    0: '断开连接',
    1: '已连接',
    2: '正在连接',
    3: '正在断开连接'
  };
  
  return states[mongoose.connection.readyState] || '未知状态';
}