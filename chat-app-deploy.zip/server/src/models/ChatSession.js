/**
 * 聊天会话数据模型
 * 定义聊天会话的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 聊天会话Schema定义
 */
const chatSessionSchema = new Schema({
  // 会话ID（用于前端标识）
  chat_id: {
    type: String,
    required: [true, '聊天会话ID不能为空'],
    unique: true,
    index: true
  },
  
  // 参与者ID数组
  participants: [{
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }],
  
  // 会话类型
  chat_type: {
    type: String,
    enum: {
      values: ['private', 'group'],
      message: '会话类型必须是private或group'
    },
    default: 'private'
  },
  
  // 会话名称（群聊时使用）
  name: {
    type: String,
    maxlength: [50, '会话名称最多50个字符'],
    default: '',
    trim: true
  },
  
  // 会话头像（群聊时使用）
  avatar_url: {
    type: String,
    default: '',
    trim: true
  },
  
  // 会话描述
  description: {
    type: String,
    maxlength: [200, '会话描述最多200个字符'],
    default: '',
    trim: true
  },
  
  // 最后一条消息
  last_message: {
    content: { type: String, default: '' },
    sender_id: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    message_type: { type: String, default: 'text' },
    created_at: { type: Date, default: null }
  },
  
  // 最后消息时间
  last_message_time: {
    type: Date,
    default: Date.now
  },
  
  // 每个用户的未读数量
  unread_counts: {
    type: Map,
    of: Number,
    default: new Map()
  },
  
  // 会话设置
  settings: {
    // 是否置顶
    is_pinned: {
      type: Map,
      of: Boolean,
      default: new Map()
    },
    // 消息免打扰
    is_muted: {
      type: Map,
      of: Boolean,
      default: new Map()
    },
    // 会话背景
    background: {
      type: String,
      default: ''
    }
  },
  
  // 群聊管理员（群聊时使用）
  admins: [{
    type: Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // 群主（群聊时使用）
  owner: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // 是否活跃
  is_active: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
chatSessionSchema.index({ chat_id: 1 }, { unique: true });
chatSessionSchema.index({ participants: 1 });
chatSessionSchema.index({ last_message_time: -1 });
chatSessionSchema.index({ chat_type: 1, is_active: 1 });

/**
 * 静态方法：生成聊天会话ID
 * @param {string[]} participantIds - 参与者ID数组
 * @param {string} type - 会话类型
 * @returns {string} 会话ID
 */
chatSessionSchema.statics.generateChatId = function(participantIds, type = 'private') {
  if (type === 'private' && participantIds.length === 2) {
    // 私聊：按字典序排列用户ID
    const sortedIds = participantIds.sort();
    return `private_${sortedIds[0]}_${sortedIds[1]}`;
  } else if (type === 'group') {
    // 群聊：使用时间戳和随机数
    return `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  
  throw new Error('无效的会话类型或参与者数量');
};

/**
 * 静态方法：创建或获取私聊会话
 * @param {string} userId1 - 用户1的ID
 * @param {string} userId2 - 用户2的ID
 * @returns {Promise<ChatSession>} 聊天会话对象
 */
chatSessionSchema.statics.getOrCreatePrivateChat = async function(userId1, userId2) {
  const chatId = this.generateChatId([userId1, userId2], 'private');
  
  let session = await this.findOne({ chat_id: chatId });
  
  if (!session) {
    session = new this({
      chat_id: chatId,
      participants: [userId1, userId2],
      chat_type: 'private',
      unread_counts: new Map([
        [userId1, 0],
        [userId2, 0]
      ]),
      settings: {
        is_pinned: new Map([
          [userId1, false],
          [userId2, false]
        ]),
        is_muted: new Map([
          [userId1, false],
          [userId2, false]
        ])
      }
    });
    
    await session.save();
  }
  
  return session;
};

/**
 * 静态方法：创建群聊会话
 * @param {Object} groupData - 群聊数据
 * @returns {Promise<ChatSession>} 群聊会话对象
 */
chatSessionSchema.statics.createGroupChat = async function(groupData) {
  const {
    name,
    description = '',
    avatar_url = '',
    participants,
    owner
  } = groupData;
  
  if (!name || !participants || participants.length < 2) {
    throw new Error('群聊名称和参与者不能为空，且至少需要2个参与者');
  }
  
  const chatId = this.generateChatId(participants, 'group');
  
  // 初始化未读数量和设置
  const unreadCounts = new Map();
  const isPinned = new Map();
  const isMuted = new Map();
  
  participants.forEach(participantId => {
    unreadCounts.set(participantId, 0);
    isPinned.set(participantId, false);
    isMuted.set(participantId, false);
  });
  
  const session = new this({
    chat_id: chatId,
    participants,
    chat_type: 'group',
    name,
    description,
    avatar_url,
    owner,
    admins: [owner],
    unread_counts,
    settings: {
      is_pinned: isPinned,
      is_muted: isMuted
    }
  });
  
  return await session.save();
};

/**
 * 静态方法：获取用户的聊天会话列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<ChatSession[]>} 会话列表
 */
chatSessionSchema.statics.getUserChats = function(userId, options = {}) {
  const {
    chat_type = null,
    limit = 50,
    skip = 0
  } = options;
  
  // 构建查询条件
  const query = {
    participants: new mongoose.Types.ObjectId(userId),
    is_active: true
  };
  
  if (chat_type) {
    query.chat_type = chat_type;
  }
  
  return this.find(query)
    .populate('participants', 'username nickname avatar_url is_online last_seen')
    .populate('last_message.sender_id', 'username nickname')
    .sort({ last_message_time: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 实例方法：更新最后消息
 * @param {Object} messageData - 消息数据
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.updateLastMessage = async function(messageData) {
  const { content, sender_id, message_type, created_at } = messageData;
  
  this.last_message = {
    content,
    sender_id,
    message_type,
    created_at: created_at || new Date()
  };
  
  this.last_message_time = this.last_message.created_at;
  
  return await this.save();
};

/**
 * 实例方法：增加未读数量
 * @param {string} userId - 用户ID
 * @param {number} count - 增加的数量
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.incrementUnreadCount = async function(userId, count = 1) {
  const currentCount = this.unread_counts.get(userId) || 0;
  this.unread_counts.set(userId, currentCount + count);
  
  return await this.save();
};

/**
 * 实例方法：清零未读数量
 * @param {string} userId - 用户ID
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.clearUnreadCount = async function(userId) {
  this.unread_counts.set(userId, 0);
  return await this.save();
};

/**
 * 实例方法：切换置顶状态
 * @param {string} userId - 用户ID
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.togglePin = async function(userId) {
  const currentPinned = this.settings.is_pinned.get(userId) || false;
  this.settings.is_pinned.set(userId, !currentPinned);
  
  return await this.save();
};

/**
 * 实例方法：切换免打扰状态
 * @param {string} userId - 用户ID
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.toggleMute = async function(userId) {
  const currentMuted = this.settings.is_muted.get(userId) || false;
  this.settings.is_muted.set(userId, !currentMuted);
  
  return await this.save();
};

/**
 * 实例方法：添加参与者（群聊）
 * @param {string[]} userIds - 用户ID数组
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.addParticipants = async function(userIds) {
  if (this.chat_type !== 'group') {
    throw new Error('只有群聊可以添加参与者');
  }
  
  // 过滤已存在的参与者
  const newParticipants = userIds.filter(userId => 
    !this.participants.some(p => p.toString() === userId)
  );
  
  if (newParticipants.length === 0) {
    return this;
  }
  
  // 添加新参与者
  this.participants.push(...newParticipants);
  
  // 初始化新参与者的设置
  newParticipants.forEach(userId => {
    this.unread_counts.set(userId, 0);
    this.settings.is_pinned.set(userId, false);
    this.settings.is_muted.set(userId, false);
  });
  
  return await this.save();
};

/**
 * 实例方法：移除参与者（群聊）
 * @param {string[]} userIds - 用户ID数组
 * @returns {Promise<ChatSession>} 更新后的会话对象
 */
chatSessionSchema.methods.removeParticipants = async function(userIds) {
  if (this.chat_type !== 'group') {
    throw new Error('只有群聊可以移除参与者');
  }
  
  // 移除参与者
  this.participants = this.participants.filter(p => 
    !userIds.includes(p.toString())
  );
  
  // 清理相关设置
  userIds.forEach(userId => {
    this.unread_counts.delete(userId);
    this.settings.is_pinned.delete(userId);
    this.settings.is_muted.delete(userId);
  });
  
  // 如果群主被移除，转让群主权限
  if (userIds.includes(this.owner?.toString())) {
    this.owner = this.participants[0] || null;
  }
  
  // 移除管理员权限
  this.admins = this.admins.filter(adminId => 
    !userIds.includes(adminId.toString())
  );
  
  return await this.save();
};

// 创建并导出聊天会话模型
const ChatSession = mongoose.model('ChatSession', chatSessionSchema);

export default ChatSession;