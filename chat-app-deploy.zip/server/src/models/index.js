/**
 * 数据模型统一导出文件
 * 集中管理所有MongoDB数据模型
 */

import User from './User.js';
import Friendship from './Friendship.js';
import FriendRequest from './FriendRequest.js';
import Message from './Message.js';
import ChatSession from './ChatSession.js';
import Moment from './Moment.js';
import Like from './Like.js';
import Comment from './Comment.js';
import Notification from './Notification.js';

/**
 * 导出所有数据模型
 */
export {
  User,
  Friendship,
  FriendRequest,
  Message,
  ChatSession,
  Moment,
  Like,
  Comment,
  Notification
};

/**
 * 默认导出模型对象
 */
export default {
  User,
  Friendship,
  FriendRequest,
  Message,
  ChatSession,
  Moment,
  Like,
  Comment,
  Notification
};

/**
 * 初始化所有模型的索引
 * 在应用启动时调用此函数来确保所有索引都已创建
 */
export const initializeIndexes = async () => {
  try {
    console.log('开始创建数据库索引...');
    
    // 创建所有模型的索引
    await Promise.all([
      User.createIndexes(),
      Friendship.createIndexes(),
      FriendRequest.createIndexes(),
      Message.createIndexes(),
      ChatSession.createIndexes(),
      Moment.createIndexes(),
      Like.createIndexes(),
      Comment.createIndexes(),
      Notification.createIndexes()
    ]);
    
    console.log('数据库索引创建完成');
    return { success: true, message: '所有索引创建成功' };
  } catch (error) {
    console.error('创建数据库索引失败:', error);
    throw error;
  }
};

/**
 * 获取所有模型的统计信息
 * 用于监控和调试
 */
export const getModelsStats = async () => {
  try {
    const stats = {};
    
    // 获取每个模型的文档数量
    stats.users = await User.countDocuments();
    stats.friendships = await Friendship.countDocuments();
    stats.friend_requests = await FriendRequest.countDocuments();
    stats.messages = await Message.countDocuments();
    stats.chat_sessions = await ChatSession.countDocuments();
    stats.moments = await Moment.countDocuments();
    stats.likes = await Like.countDocuments();
    stats.comments = await Comment.countDocuments();
    stats.notifications = await Notification.countDocuments();
    
    // 计算总数
    stats.total = Object.values(stats).reduce((sum, count) => sum + count, 0);
    
    return stats;
  } catch (error) {
    console.error('获取模型统计信息失败:', error);
    throw error;
  }
};

/**
 * 清理所有模型的过期数据
 * 定期调用此函数来清理过期或无用的数据
 */
export const cleanupExpiredData = async () => {
  try {
    console.log('开始清理过期数据...');
    
    const results = {};
    
    // 清理过期的好友申请（30天前的已处理申请）
    results.friend_requests = await FriendRequest.cleanupExpiredRequests(30);
    
    // 清理过期的消息（根据需要，这里设置为90天）
    results.messages = await Message.cleanupExpiredMessages(90);
    
    // 清理过期的动态（根据需要，这里设置为365天）
    results.moments = await Moment.cleanupExpiredMoments(365);
    
    // 清理过期的已删除评论（30天）
    results.comments = await Comment.cleanupDeletedComments(30);
    
    // 清理已读通知（7天前的已读通知）
    // 注意：这里需要遍历所有用户，实际使用时可能需要优化
    const users = await User.find({}, '_id');
    let totalCleanedNotifications = 0;
    
    for (const user of users) {
      const result = await Notification.cleanupReadNotifications(user._id, 7);
      totalCleanedNotifications += result.modified_count;
    }
    
    results.notifications = {
      success: true,
      modified_count: totalCleanedNotifications,
      message: `已清理${totalCleanedNotifications}条已读通知`
    };
    
    console.log('过期数据清理完成:', results);
    return results;
  } catch (error) {
    console.error('清理过期数据失败:', error);
    throw error;
  }
};