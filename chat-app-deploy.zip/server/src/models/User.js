/**
 * 用户数据模型
 * 定义用户的数据结构和业务逻辑
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const { Schema } = mongoose;

/**
 * 用户Schema定义
 */
const userSchema = new Schema({
  // 基本信息
  username: {
    type: String,
    required: [true, '用户名不能为空'],
    unique: true,
    trim: true,
    minlength: [2, '用户名至少2个字符'],
    maxlength: [20, '用户名最多20个字符'],
    match: [/^[a-zA-Z0-9_\u4e00-\u9fa5]+$/, '用户名只能包含字母、数字、下划线和中文']
  },
  
  email: {
    type: String,
    required: [true, '邮箱不能为空'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, '请输入有效的邮箱地址']
  },
  
  password: {
    type: String,
    required: [true, '密码不能为空'],
    minlength: [6, '密码至少6个字符'],
    select: false // 默认查询时不返回密码字段
  },
  
  // 个人资料
  nickname: {
    type: String,
    trim: true,
    maxlength: [30, '昵称最多30个字符'],
    default: function() {
      return this.username;
    }
  },
  
  avatar_url: {
    type: String,
    default: '',
    trim: true
  },
  
  bio: {
    type: String,
    maxlength: [200, '个人简介最多200个字符'],
    default: '',
    trim: true
  },
  
  // 状态信息
  is_online: {
    type: Boolean,
    default: false
  },
  
  last_seen: {
    type: Date,
    default: Date.now
  },
  
  // 设置信息
  settings: {
    theme: {
      type: String,
      enum: ['light', 'dark', 'auto'],
      default: 'auto'
    },
    language: {
      type: String,
      enum: ['zh-CN', 'en-US'],
      default: 'zh-CN'
    },
    notifications: {
      message: { type: Boolean, default: true },
      friend_request: { type: Boolean, default: true },
      moment_like: { type: Boolean, default: true },
      moment_comment: { type: Boolean, default: true }
    }
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  },
  toJSON: {
    transform: function(doc, ret) {
      // 移除敏感信息
      delete ret.password;
      delete ret.__v;
      return ret;
    }
  }
});

/**
 * 索引定义
 */
userSchema.index({ username: 1 }, { unique: true });
userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ is_online: 1 });
userSchema.index({ created_at: -1 });

/**
 * 密码加密中间件
 * 在保存用户前自动加密密码
 */
userSchema.pre('save', async function(next) {
  // 如果密码没有修改，跳过加密
  if (!this.isModified('password')) {
    return next();
  }
  
  try {
    // 生成盐值并加密密码
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

/**
 * 实例方法：验证密码
 * @param {string} candidatePassword - 待验证的密码
 * @returns {Promise<boolean>} 密码是否正确
 */
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw new Error('密码验证失败');
  }
};

/**
 * 实例方法：更新在线状态
 * @param {boolean} isOnline - 是否在线
 * @returns {Promise<User>} 更新后的用户对象
 */
userSchema.methods.updateOnlineStatus = async function(isOnline) {
  this.is_online = isOnline;
  this.last_seen = new Date();
  return await this.save();
};

/**
 * 实例方法：获取公开信息
 * @returns {Object} 用户公开信息
 */
userSchema.methods.getPublicProfile = function() {
  return {
    _id: this._id,
    username: this.username,
    nickname: this.nickname,
    avatar_url: this.avatar_url,
    bio: this.bio,
    is_online: this.is_online,
    last_seen: this.last_seen
  };
};

/**
 * 静态方法：根据用户名或邮箱查找用户
 * @param {string} identifier - 用户名或邮箱
 * @returns {Promise<User|null>} 用户对象或null
 */
userSchema.statics.findByIdentifier = function(identifier) {
  return this.findOne({
    $or: [
      { username: identifier },
      { email: identifier }
    ]
  }).select('+password');
};

/**
 * 静态方法：搜索用户
 * @param {string} query - 搜索关键词
 * @param {number} limit - 结果数量限制
 * @returns {Promise<User[]>} 用户列表
 */
userSchema.statics.searchUsers = function(query, limit = 10) {
  const searchRegex = new RegExp(query, 'i');
  
  return this.find({
    $or: [
      { username: searchRegex },
      { nickname: searchRegex }
    ]
  })
  .select('username nickname avatar_url bio is_online')
  .limit(limit)
  .sort({ is_online: -1, created_at: -1 });
};

/**
 * 静态方法：获取在线用户数量
 * @returns {Promise<number>} 在线用户数量
 */
userSchema.statics.getOnlineCount = function() {
  return this.countDocuments({ is_online: true });
};

// 创建并导出用户模型
const User = mongoose.model('User', userSchema);

export default User;