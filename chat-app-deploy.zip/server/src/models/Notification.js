/**
 * 通知数据模型
 * 定义通知的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 通知Schema定义
 */
const notificationSchema = new Schema({
  // 接收通知的用户ID
  user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '用户ID不能为空']
  },
  
  // 发送通知的用户ID（可选，系统通知时为空）
  sender_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // 通知类型
  notification_type: {
    type: String,
    enum: {
      values: [
        'friend_request',      // 好友申请
        'friend_accepted',     // 好友申请被接受
        'friend_rejected',     // 好友申请被拒绝
        'new_message',         // 新消息
        'moment_like',         // 动态被点赞
        'moment_comment',      // 动态被评论
        'comment_reply',       // 评论被回复
        'comment_like',        // 评论被点赞
        'system',              // 系统通知
        'announcement'         // 公告通知
      ],
      message: '通知类型无效'
    },
    required: [true, '通知类型不能为空']
  },
  
  // 通知标题
  title: {
    type: String,
    required: [true, '通知标题不能为空'],
    maxlength: [100, '通知标题最多100个字符'],
    trim: true
  },
  
  // 通知内容
  content: {
    type: String,
    required: [true, '通知内容不能为空'],
    maxlength: [500, '通知内容最多500个字符'],
    trim: true
  },
  
  // 相关数据（JSON格式存储相关信息）
  related_data: {
    type: Schema.Types.Mixed,
    default: {}
  },
  
  // 跳转链接或路由
  action_url: {
    type: String,
    default: null
  },
  
  // 是否已读
  is_read: {
    type: Boolean,
    default: false
  },
  
  // 阅读时间
  read_at: {
    type: Date,
    default: null
  },
  
  // 通知优先级
  priority: {
    type: String,
    enum: {
      values: ['low', 'normal', 'high', 'urgent'],
      message: '优先级必须是low、normal、high或urgent'
    },
    default: 'normal'
  },
  
  // 是否推送到客户端
  push_sent: {
    type: Boolean,
    default: false
  },
  
  // 推送时间
  push_sent_at: {
    type: Date,
    default: null
  },
  
  // 过期时间
  expires_at: {
    type: Date,
    default: null
  },
  
  // 是否被删除
  is_deleted: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
notificationSchema.index({ user_id: 1, created_at: -1 });
notificationSchema.index({ user_id: 1, is_read: 1, created_at: -1 });
notificationSchema.index({ user_id: 1, notification_type: 1, created_at: -1 });
notificationSchema.index({ sender_id: 1, created_at: -1 });
notificationSchema.index({ expires_at: 1 }, { expireAfterSeconds: 0 });

/**
 * 虚拟字段：是否已过期
 */
notificationSchema.virtual('is_expired').get(function() {
  if (!this.expires_at) return false;
  return new Date() > this.expires_at;
});

/**
 * 实例方法：标记为已读
 * @returns {Promise<Notification>} 更新后的通知对象
 */
notificationSchema.methods.markAsRead = async function() {
  if (!this.is_read) {
    this.is_read = true;
    this.read_at = new Date();
    return await this.save();
  }
  return this;
};

/**
 * 实例方法：标记推送已发送
 * @returns {Promise<Notification>} 更新后的通知对象
 */
notificationSchema.methods.markPushSent = async function() {
  if (!this.push_sent) {
    this.push_sent = true;
    this.push_sent_at = new Date();
    return await this.save();
  }
  return this;
};

/**
 * 实例方法：软删除通知
 * @returns {Promise<Notification>} 更新后的通知对象
 */
notificationSchema.methods.softDelete = async function() {
  this.is_deleted = true;
  return await this.save();
};

/**
 * 静态方法：创建通知
 * @param {Object} notificationData - 通知数据
 * @returns {Promise<Notification>} 创建的通知对象
 */
notificationSchema.statics.createNotification = async function(notificationData) {
  const {
    user_id,
    sender_id = null,
    notification_type,
    title,
    content,
    related_data = {},
    action_url = null,
    priority = 'normal',
    expires_at = null
  } = notificationData;
  
  // 检查用户是否存在
  const User = mongoose.model('User');
  const user = await User.findById(user_id);
  if (!user) {
    throw new Error('接收用户不存在');
  }
  
  // 如果有发送者，检查发送者是否存在
  if (sender_id) {
    const sender = await User.findById(sender_id);
    if (!sender) {
      throw new Error('发送用户不存在');
    }
  }
  
  // 创建通知
  const notification = new this({
    user_id,
    sender_id,
    notification_type,
    title,
    content,
    related_data,
    action_url,
    priority,
    expires_at
  });
  
  return await notification.save();
};

/**
 * 静态方法：批量创建通知
 * @param {Array} notificationsData - 通知数据数组
 * @returns {Promise<Notification[]>} 创建的通知对象数组
 */
notificationSchema.statics.createBulkNotifications = async function(notificationsData) {
  const notifications = notificationsData.map(data => new this(data));
  return await this.insertMany(notifications);
};

/**
 * 静态方法：获取用户通知列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Object>} 通知列表和统计信息
 */
notificationSchema.statics.getUserNotifications = async function(userId, options = {}) {
  const {
    notification_type = null,
    is_read = null,
    limit = 20,
    skip = 0,
    include_deleted = false
  } = options;
  
  // 构建查询条件
  const query = { user_id: userId };
  
  if (notification_type) {
    query.notification_type = notification_type;
  }
  
  if (is_read !== null) {
    query.is_read = is_read;
  }
  
  if (!include_deleted) {
    query.is_deleted = false;
  }
  
  // 查询通知列表
  const notifications = await this.find(query)
    .populate('sender_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
  
  // 获取未读数量
  const unread_count = await this.countDocuments({
    user_id: userId,
    is_read: false,
    is_deleted: false
  });
  
  // 获取总数量
  const total_count = await this.countDocuments({
    user_id: userId,
    is_deleted: false
  });
  
  return {
    notifications,
    unread_count,
    total_count,
    has_more: skip + notifications.length < total_count
  };
};

/**
 * 静态方法：获取未读通知数量
 * @param {string} userId - 用户ID
 * @param {string} notification_type - 通知类型（可选）
 * @returns {Promise<number>} 未读通知数量
 */
notificationSchema.statics.getUnreadCount = function(userId, notification_type = null) {
  const query = {
    user_id: userId,
    is_read: false,
    is_deleted: false
  };
  
  if (notification_type) {
    query.notification_type = notification_type;
  }
  
  return this.countDocuments(query);
};

/**
 * 静态方法：标记所有通知为已读
 * @param {string} userId - 用户ID
 * @param {string} notification_type - 通知类型（可选）
 * @returns {Promise<Object>} 更新结果
 */
notificationSchema.statics.markAllAsRead = async function(userId, notification_type = null) {
  const query = {
    user_id: userId,
    is_read: false,
    is_deleted: false
  };
  
  if (notification_type) {
    query.notification_type = notification_type;
  }
  
  const result = await this.updateMany(
    query,
    {
      $set: {
        is_read: true,
        read_at: new Date()
      }
    }
  );
  
  return {
    success: true,
    modified_count: result.modifiedCount,
    message: `已标记${result.modifiedCount}条通知为已读`
  };
};

/**
 * 静态方法：批量删除通知
 * @param {string} userId - 用户ID
 * @param {Array} notificationIds - 通知ID数组
 * @returns {Promise<Object>} 删除结果
 */
notificationSchema.statics.bulkDelete = async function(userId, notificationIds) {
  const result = await this.updateMany(
    {
      _id: { $in: notificationIds },
      user_id: userId
    },
    {
      $set: { is_deleted: true }
    }
  );
  
  return {
    success: true,
    modified_count: result.modifiedCount,
    message: `已删除${result.modifiedCount}条通知`
  };
};

/**
 * 静态方法：清理已读通知
 * @param {string} userId - 用户ID
 * @param {number} daysOld - 保留天数，默认7天
 * @returns {Promise<Object>} 清理结果
 */
notificationSchema.statics.cleanupReadNotifications = async function(userId, daysOld = 7) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  const result = await this.updateMany(
    {
      user_id: userId,
      is_read: true,
      read_at: { $lt: cutoffDate }
    },
    {
      $set: { is_deleted: true }
    }
  );
  
  return {
    success: true,
    modified_count: result.modifiedCount,
    message: `已清理${result.modifiedCount}条已读通知`
  };
};

/**
 * 静态方法：获取待推送的通知
 * @param {Object} options - 查询选项
 * @returns {Promise<Notification[]>} 待推送通知列表
 */
notificationSchema.statics.getPendingPushNotifications = function(options = {}) {
  const { limit = 100 } = options;
  
  return this.find({
    push_sent: false,
    is_deleted: false,
    $or: [
      { expires_at: null },
      { expires_at: { $gt: new Date() } }
    ]
  })
  .populate('user_id', 'username push_settings')
  .populate('sender_id', 'username nickname avatar_url')
  .sort({ priority: -1, created_at: 1 })
  .limit(limit);
};

/**
 * 静态方法：创建好友申请通知
 * @param {string} receiverId - 接收者ID
 * @param {string} senderId - 发送者ID
 * @param {string} message - 申请消息
 * @returns {Promise<Notification>} 创建的通知对象
 */
notificationSchema.statics.createFriendRequestNotification = async function(receiverId, senderId, message) {
  const User = mongoose.model('User');
  const sender = await User.findById(senderId, 'username nickname');
  
  return await this.createNotification({
    user_id: receiverId,
    sender_id: senderId,
    notification_type: 'friend_request',
    title: '新的好友申请',
    content: `${sender.nickname || sender.username} 想要添加您为好友`,
    related_data: {
      sender_id: senderId,
      message: message
    },
    action_url: '/friends/requests',
    priority: 'normal'
  });
};

/**
 * 静态方法：创建消息通知
 * @param {string} receiverId - 接收者ID
 * @param {string} senderId - 发送者ID
 * @param {string} messageContent - 消息内容
 * @param {string} messageType - 消息类型
 * @returns {Promise<Notification>} 创建的通知对象
 */
notificationSchema.statics.createMessageNotification = async function(receiverId, senderId, messageContent, messageType) {
  const User = mongoose.model('User');
  const sender = await User.findById(senderId, 'username nickname');
  
  let content = `${sender.nickname || sender.username} 发来了一条消息`;
  if (messageType === 'text') {
    content = `${sender.nickname || sender.username}: ${messageContent.substring(0, 50)}${messageContent.length > 50 ? '...' : ''}`;
  } else if (messageType === 'image') {
    content = `${sender.nickname || sender.username} 发来了一张图片`;
  } else if (messageType === 'file') {
    content = `${sender.nickname || sender.username} 发来了一个文件`;
  }
  
  return await this.createNotification({
    user_id: receiverId,
    sender_id: senderId,
    notification_type: 'new_message',
    title: '新消息',
    content: content,
    related_data: {
      sender_id: senderId,
      message_type: messageType
    },
    action_url: `/chat/${senderId}`,
    priority: 'normal'
  });
};

/**
 * 静态方法：创建动态点赞通知
 * @param {string} momentOwnerId - 动态所有者ID
 * @param {string} likerId - 点赞者ID
 * @param {string} momentId - 动态ID
 * @returns {Promise<Notification>} 创建的通知对象
 */
notificationSchema.statics.createMomentLikeNotification = async function(momentOwnerId, likerId, momentId) {
  // 不给自己发通知
  if (momentOwnerId === likerId) return null;
  
  const User = mongoose.model('User');
  const liker = await User.findById(likerId, 'username nickname');
  
  return await this.createNotification({
    user_id: momentOwnerId,
    sender_id: likerId,
    notification_type: 'moment_like',
    title: '动态获得点赞',
    content: `${liker.nickname || liker.username} 赞了您的动态`,
    related_data: {
      moment_id: momentId,
      liker_id: likerId
    },
    action_url: `/moments/${momentId}`,
    priority: 'low'
  });
};

// 创建并导出通知模型
const Notification = mongoose.model('Notification', notificationSchema);

export default Notification;