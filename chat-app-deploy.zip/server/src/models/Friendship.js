/**
 * 好友关系数据模型
 * 定义用户之间的好友关系结构
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 好友关系Schema定义
 */
const friendshipSchema = new Schema({
  // 用户ID
  user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '用户ID不能为空']
  },
  
  // 好友ID
  friend_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '好友ID不能为空']
  },
  
  // 关系状态
  status: {
    type: String,
    enum: {
      values: ['accepted', 'blocked'],
      message: '好友关系状态必须是accepted或blocked'
    },
    default: 'accepted'
  },
  
  // 备注名称
  remark: {
    type: String,
    maxlength: [50, '备注名称最多50个字符'],
    default: '',
    trim: true
  },
  
  // 分组标签
  tags: [{
    type: String,
    maxlength: [20, '标签最多20个字符'],
    trim: true
  }],
  
  // 是否置顶
  is_pinned: {
    type: Boolean,
    default: false
  },
  
  // 消息免打扰
  is_muted: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
// 复合唯一索引，确保两个用户之间只有一条好友关系记录
friendshipSchema.index({ user_id: 1, friend_id: 1 }, { unique: true });
friendshipSchema.index({ user_id: 1, status: 1 });
friendshipSchema.index({ friend_id: 1, status: 1 });
friendshipSchema.index({ user_id: 1, is_pinned: -1, created_at: -1 });

/**
 * 验证中间件：防止用户添加自己为好友
 */
friendshipSchema.pre('save', function(next) {
  if (this.user_id.toString() === this.friend_id.toString()) {
    const error = new Error('不能添加自己为好友');
    return next(error);
  }
  next();
});

/**
 * 静态方法：检查两个用户是否为好友
 * @param {string} userId1 - 用户1的ID
 * @param {string} userId2 - 用户2的ID
 * @returns {Promise<boolean>} 是否为好友关系
 */
friendshipSchema.statics.areFriends = async function(userId1, userId2) {
  const friendship = await this.findOne({
    $or: [
      { user_id: userId1, friend_id: userId2, status: 'accepted' },
      { user_id: userId2, friend_id: userId1, status: 'accepted' }
    ]
  });
  
  return !!friendship;
};

/**
 * 静态方法：获取用户的好友列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<User[]>} 好友列表
 */
friendshipSchema.statics.getFriendsList = function(userId, options = {}) {
  const { 
    status = 'accepted', 
    limit = 50, 
    skip = 0,
    search = '',
    tags = []
  } = options;
  
  // 构建查询条件
  const matchConditions = {
    user_id: new mongoose.Types.ObjectId(userId),
    status: status
  };
  
  // 添加标签过滤
  if (tags.length > 0) {
    matchConditions.tags = { $in: tags };
  }
  
  // 构建聚合管道
  const pipeline = [
    { $match: matchConditions },
    {
      $lookup: {
        from: 'users',
        localField: 'friend_id',
        foreignField: '_id',
        as: 'friend'
      }
    },
    { $unwind: '$friend' },
    {
      $project: {
        _id: 1,
        friend_id: 1,
        remark: 1,
        tags: 1,
        is_pinned: 1,
        is_muted: 1,
        created_at: 1,
        'friend._id': 1,
        'friend.username': 1,
        'friend.nickname': 1,
        'friend.avatar_url': 1,
        'friend.bio': 1,
        'friend.is_online': 1,
        'friend.last_seen': 1
      }
    }
  ];
  
  // 添加搜索条件
  if (search) {
    const searchRegex = new RegExp(search, 'i');
    pipeline.push({
      $match: {
        $or: [
          { 'friend.username': searchRegex },
          { 'friend.nickname': searchRegex },
          { remark: searchRegex }
        ]
      }
    });
  }
  
  // 排序：置顶 > 在线状态 > 创建时间
  pipeline.push({
    $sort: {
      is_pinned: -1,
      'friend.is_online': -1,
      created_at: -1
    }
  });
  
  // 分页
  if (skip > 0) {
    pipeline.push({ $skip: skip });
  }
  pipeline.push({ $limit: limit });
  
  return this.aggregate(pipeline);
};

/**
 * 静态方法：创建双向好友关系
 * @param {string} userId1 - 用户1的ID
 * @param {string} userId2 - 用户2的ID
 * @returns {Promise<Object>} 创建结果
 */
friendshipSchema.statics.createFriendship = async function(userId1, userId2) {
  const session = await mongoose.startSession();
  
  try {
    await session.withTransaction(async () => {
      // 创建双向好友关系
      await this.create([
        { user_id: userId1, friend_id: userId2, status: 'accepted' },
        { user_id: userId2, friend_id: userId1, status: 'accepted' }
      ], { session });
    });
    
    return { success: true, message: '好友关系创建成功' };
  } catch (error) {
    if (error.code === 11000) {
      return { success: false, message: '好友关系已存在' };
    }
    throw error;
  } finally {
    await session.endSession();
  }
};

/**
 * 静态方法：删除好友关系
 * @param {string} userId1 - 用户1的ID
 * @param {string} userId2 - 用户2的ID
 * @returns {Promise<Object>} 删除结果
 */
friendshipSchema.statics.removeFriendship = async function(userId1, userId2) {
  const session = await mongoose.startSession();
  
  try {
    await session.withTransaction(async () => {
      // 删除双向好友关系
      await this.deleteMany({
        $or: [
          { user_id: userId1, friend_id: userId2 },
          { user_id: userId2, friend_id: userId1 }
        ]
      }, { session });
    });
    
    return { success: true, message: '好友关系删除成功' };
  } catch (error) {
    throw error;
  } finally {
    await session.endSession();
  }
};

/**
 * 静态方法：更新好友备注
 * @param {string} userId - 用户ID
 * @param {string} friendId - 好友ID
 * @param {string} remark - 备注名称
 * @returns {Promise<Friendship>} 更新后的好友关系
 */
friendshipSchema.statics.updateRemark = function(userId, friendId, remark) {
  return this.findOneAndUpdate(
    { user_id: userId, friend_id: friendId },
    { remark: remark },
    { new: true }
  );
};

/**
 * 静态方法：切换置顶状态
 * @param {string} userId - 用户ID
 * @param {string} friendId - 好友ID
 * @returns {Promise<Friendship>} 更新后的好友关系
 */
friendshipSchema.statics.togglePin = async function(userId, friendId) {
  const friendship = await this.findOne({ user_id: userId, friend_id: friendId });
  if (!friendship) {
    throw new Error('好友关系不存在');
  }
  
  friendship.is_pinned = !friendship.is_pinned;
  return await friendship.save();
};

// 创建并导出好友关系模型
const Friendship = mongoose.model('Friendship', friendshipSchema);

export default Friendship;