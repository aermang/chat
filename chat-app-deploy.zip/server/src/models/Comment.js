/**
 * 评论数据模型
 * 定义评论的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 评论Schema定义
 */
const commentSchema = new Schema({
  // 动态ID
  moment_id: {
    type: Schema.Types.ObjectId,
    ref: 'Moment',
    required: [true, '动态ID不能为空']
  },
  
  // 评论用户ID
  user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '用户ID不能为空']
  },
  
  // 评论内容
  content: {
    type: String,
    required: [true, '评论内容不能为空'],
    maxlength: [500, '评论内容最多500个字符'],
    trim: true
  },
  
  // 回复的评论ID（用于回复评论）
  reply_to: {
    type: Schema.Types.ObjectId,
    ref: 'Comment',
    default: null
  },
  
  // 被回复的用户ID
  reply_to_user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // 评论类型
  comment_type: {
    type: String,
    enum: {
      values: ['comment', 'reply'],
      message: '评论类型必须是comment或reply'
    },
    default: 'comment'
  },
  
  // 点赞数
  likes_count: {
    type: Number,
    default: 0,
    min: 0
  },
  
  // 回复数
  replies_count: {
    type: Number,
    default: 0,
    min: 0
  },
  
  // 是否被删除
  is_deleted: {
    type: Boolean,
    default: false
  },
  
  // 删除时间
  deleted_at: {
    type: Date,
    default: null
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
commentSchema.index({ moment_id: 1, created_at: -1 });
commentSchema.index({ user_id: 1, created_at: -1 });
commentSchema.index({ reply_to: 1, created_at: 1 });
commentSchema.index({ moment_id: 1, comment_type: 1, created_at: -1 });

/**
 * 实例方法：软删除评论
 * @returns {Promise<Comment>} 更新后的评论对象
 */
commentSchema.methods.softDelete = async function() {
  this.is_deleted = true;
  this.deleted_at = new Date();
  this.content = '[评论已删除]';
  
  return await this.save();
};

/**
 * 实例方法：增加点赞数
 * @returns {Promise<Comment>} 更新后的评论对象
 */
commentSchema.methods.incrementLikes = async function() {
  this.likes_count += 1;
  return await this.save();
};

/**
 * 实例方法：减少点赞数
 * @returns {Promise<Comment>} 更新后的评论对象
 */
commentSchema.methods.decrementLikes = async function() {
  this.likes_count = Math.max(0, this.likes_count - 1);
  return await this.save();
};

/**
 * 静态方法：创建评论
 * @param {Object} commentData - 评论数据
 * @returns {Promise<Comment>} 创建的评论对象
 */
commentSchema.statics.createComment = async function(commentData) {
  const {
    moment_id,
    user_id,
    content,
    reply_to = null,
    reply_to_user = null
  } = commentData;
  
  const session = await mongoose.startSession();
  
  try {
    return await session.withTransaction(async () => {
      // 检查动态是否存在且允许评论
      const Moment = mongoose.model('Moment');
      const moment = await Moment.findById(moment_id);
      
      if (!moment) {
        throw new Error('动态不存在');
      }
      
      if (!moment.allow_comment) {
        throw new Error('该动态不允许评论');
      }
      
      // 确定评论类型
      const comment_type = reply_to ? 'reply' : 'comment';
      
      // 创建评论
      const comment = new this({
        moment_id,
        user_id,
        content,
        reply_to,
        reply_to_user,
        comment_type
      });
      
      await comment.save({ session });
      
      // 更新动态评论数
      await Moment.findByIdAndUpdate(
        moment_id,
        { $inc: { 'stats.comments_count': 1 } },
        { session }
      );
      
      // 如果是回复，更新父评论的回复数
      if (reply_to) {
        await this.findByIdAndUpdate(
          reply_to,
          { $inc: { replies_count: 1 } },
          { session }
        );
      }
      
      return comment;
    });
  } catch (error) {
    throw error;
  } finally {
    await session.endSession();
  }
};

/**
 * 静态方法：删除评论
 * @param {string} commentId - 评论ID
 * @param {string} userId - 用户ID
 * @returns {Promise<Object>} 删除结果
 */
commentSchema.statics.deleteComment = async function(commentId, userId) {
  const session = await mongoose.startSession();
  
  try {
    return await session.withTransaction(async () => {
      const comment = await this.findById(commentId);
      
      if (!comment) {
        throw new Error('评论不存在');
      }
      
      if (comment.user_id.toString() !== userId) {
        throw new Error('只能删除自己的评论');
      }
      
      if (comment.is_deleted) {
        throw new Error('评论已被删除');
      }
      
      // 软删除评论
      await comment.softDelete();
      
      // 更新动态评论数
      const Moment = mongoose.model('Moment');
      await Moment.findByIdAndUpdate(
        comment.moment_id,
        { $inc: { 'stats.comments_count': -1 } },
        { session }
      );
      
      // 如果是回复，更新父评论的回复数
      if (comment.reply_to) {
        await this.findByIdAndUpdate(
          comment.reply_to,
          { $inc: { replies_count: -1 } },
          { session }
        );
      }
      
      return {
        success: true,
        message: '评论删除成功'
      };
    });
  } catch (error) {
    throw error;
  } finally {
    await session.endSession();
  }
};

/**
 * 静态方法：获取动态的评论列表
 * @param {string} momentId - 动态ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Comment[]>} 评论列表
 */
commentSchema.statics.getMomentComments = function(momentId, options = {}) {
  const {
    limit = 20,
    skip = 0,
    sort = 'created_at', // 'created_at' | 'likes_count'
    order = 1 // 1: 升序, -1: 降序
  } = options;
  
  const sortObj = {};
  sortObj[sort] = order;
  
  return this.find({
    moment_id: momentId,
    comment_type: 'comment',
    is_deleted: false
  })
  .populate('user_id', 'username nickname avatar_url')
  .populate('reply_to_user', 'username nickname')
  .sort(sortObj)
  .skip(skip)
  .limit(limit)
  .lean();
};

/**
 * 静态方法：获取评论的回复列表
 * @param {string} commentId - 评论ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Comment[]>} 回复列表
 */
commentSchema.statics.getCommentReplies = function(commentId, options = {}) {
  const {
    limit = 10,
    skip = 0
  } = options;
  
  return this.find({
    reply_to: commentId,
    comment_type: 'reply',
    is_deleted: false
  })
  .populate('user_id', 'username nickname avatar_url')
  .populate('reply_to_user', 'username nickname')
  .sort({ created_at: 1 })
  .skip(skip)
  .limit(limit)
  .lean();
};

/**
 * 静态方法：获取用户的评论列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Comment[]>} 评论列表
 */
commentSchema.statics.getUserComments = function(userId, options = {}) {
  const {
    limit = 20,
    skip = 0
  } = options;
  
  return this.find({
    user_id: userId,
    is_deleted: false
  })
  .populate('moment_id', 'content user_id')
  .populate('reply_to_user', 'username nickname')
  .sort({ created_at: -1 })
  .skip(skip)
  .limit(limit)
  .lean();
};

/**
 * 静态方法：搜索评论
 * @param {string} query - 搜索关键词
 * @param {Object} options - 搜索选项
 * @returns {Promise<Comment[]>} 搜索结果
 */
commentSchema.statics.searchComments = function(query, options = {}) {
  const {
    moment_id = null,
    user_id = null,
    limit = 20,
    skip = 0
  } = options;
  
  // 构建搜索条件
  const searchConditions = {
    content: new RegExp(query, 'i'),
    is_deleted: false
  };
  
  if (moment_id) {
    searchConditions.moment_id = moment_id;
  }
  
  if (user_id) {
    searchConditions.user_id = user_id;
  }
  
  return this.find(searchConditions)
    .populate('user_id', 'username nickname avatar_url')
    .populate('moment_id', 'content user_id')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：获取热门评论
 * @param {string} momentId - 动态ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Comment[]>} 热门评论列表
 */
commentSchema.statics.getHotComments = function(momentId, options = {}) {
  const { limit = 5 } = options;
  
  return this.find({
    moment_id: momentId,
    comment_type: 'comment',
    is_deleted: false,
    likes_count: { $gte: 1 }
  })
  .populate('user_id', 'username nickname avatar_url')
  .sort({ likes_count: -1, created_at: -1 })
  .limit(limit)
  .lean();
};

/**
 * 静态方法：清理过期的已删除评论
 * @param {number} daysOld - 保留天数，默认30天
 * @returns {Promise<Object>} 清理结果
 */
commentSchema.statics.cleanupDeletedComments = async function(daysOld = 30) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  const result = await this.deleteMany({
    is_deleted: true,
    deleted_at: { $lt: cutoffDate }
  });
  
  return {
    success: true,
    deleted_count: result.deletedCount,
    message: `已清理${result.deletedCount}条过期评论`
  };
};

// 创建并导出评论模型
const Comment = mongoose.model('Comment', commentSchema);

export default Comment;