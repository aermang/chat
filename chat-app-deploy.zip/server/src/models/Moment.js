/**
 * 朋友圈动态数据模型
 * 定义朋友圈动态的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 朋友圈动态Schema定义
 */
const momentSchema = new Schema({
  // 发布者
  user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '发布者ID不能为空']
  },
  
  // 动态内容
  content: {
    type: String,
    maxlength: [2000, '动态内容最多2000个字符'],
    default: '',
    trim: true
  },
  
  // 图片数组
  images: [{
    url: { type: String, required: true },
    thumbnail_url: { type: String, default: '' },
    width: { type: Number, default: 0 },
    height: { type: Number, default: 0 }
  }],
  
  // 位置信息
  location: {
    name: { type: String, default: '' },
    address: { type: String, default: '' },
    latitude: { type: Number, default: 0 },
    longitude: { type: Number, default: 0 }
  },
  
  // 可见性设置
  visibility: {
    type: String,
    enum: {
      values: ['public', 'friends', 'private', 'custom'],
      message: '可见性必须是public、friends、private或custom'
    },
    default: 'friends'
  },
  
  // 自定义可见用户（当visibility为custom时使用）
  visible_to: [{
    type: Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // 不可见用户
  hidden_from: [{
    type: Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // 统计信息
  stats: {
    likes_count: { type: Number, default: 0 },
    comments_count: { type: Number, default: 0 },
    views_count: { type: Number, default: 0 }
  },
  
  // 是否允许评论
  allow_comment: {
    type: Boolean,
    default: true
  },
  
  // 标签
  tags: [{
    type: String,
    maxlength: [20, '标签最多20个字符'],
    trim: true
  }],
  
  // 额外数据
  extra_data: {
    type: Schema.Types.Mixed,
    default: {}
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
momentSchema.index({ user_id: 1, created_at: -1 });
momentSchema.index({ created_at: -1 });
momentSchema.index({ visibility: 1, created_at: -1 });
momentSchema.index({ tags: 1 });
momentSchema.index({ 'location.name': 1 });

/**
 * 验证中间件：确保动态有内容或图片
 */
momentSchema.pre('save', function(next) {
  if (!this.content && (!this.images || this.images.length === 0)) {
    const error = new Error('动态必须包含文字内容或图片');
    return next(error);
  }
  next();
});

/**
 * 实例方法：增加点赞数
 * @returns {Promise<Moment>} 更新后的动态对象
 */
momentSchema.methods.incrementLikes = async function() {
  this.stats.likes_count += 1;
  return await this.save();
};

/**
 * 实例方法：减少点赞数
 * @returns {Promise<Moment>} 更新后的动态对象
 */
momentSchema.methods.decrementLikes = async function() {
  this.stats.likes_count = Math.max(0, this.stats.likes_count - 1);
  return await this.save();
};

/**
 * 实例方法：增加评论数
 * @returns {Promise<Moment>} 更新后的动态对象
 */
momentSchema.methods.incrementComments = async function() {
  this.stats.comments_count += 1;
  return await this.save();
};

/**
 * 实例方法：减少评论数
 * @returns {Promise<Moment>} 更新后的动态对象
 */
momentSchema.methods.decrementComments = async function() {
  this.stats.comments_count = Math.max(0, this.stats.comments_count - 1);
  return await this.save();
};

/**
 * 实例方法：增加浏览数
 * @returns {Promise<Moment>} 更新后的动态对象
 */
momentSchema.methods.incrementViews = async function() {
  this.stats.views_count += 1;
  return await this.save();
};

/**
 * 实例方法：检查用户是否可见此动态
 * @param {string} userId - 用户ID
 * @param {boolean} isFriend - 是否为好友
 * @returns {boolean} 是否可见
 */
momentSchema.methods.isVisibleTo = function(userId, isFriend = false) {
  // 发布者自己总是可见
  if (this.user_id.toString() === userId) {
    return true;
  }
  
  // 检查隐藏列表
  if (this.hidden_from.some(id => id.toString() === userId)) {
    return false;
  }
  
  switch (this.visibility) {
    case 'public':
      return true;
    case 'friends':
      return isFriend;
    case 'private':
      return false;
    case 'custom':
      return this.visible_to.some(id => id.toString() === userId);
    default:
      return false;
  }
};

/**
 * 静态方法：获取用户动态列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Moment[]>} 动态列表
 */
momentSchema.statics.getUserMoments = function(userId, options = {}) {
  const {
    limit = 20,
    skip = 0,
    before_date = null
  } = options;
  
  // 构建查询条件
  const query = { user_id: new mongoose.Types.ObjectId(userId) };
  
  if (before_date) {
    query.created_at = { $lt: new Date(before_date) };
  }
  
  return this.find(query)
    .populate('user_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：获取朋友圈时间线
 * @param {string} userId - 用户ID
 * @param {string[]} friendIds - 好友ID数组
 * @param {Object} options - 查询选项
 * @returns {Promise<Moment[]>} 动态列表
 */
momentSchema.statics.getTimeline = function(userId, friendIds = [], options = {}) {
  const {
    limit = 20,
    skip = 0,
    before_date = null
  } = options;
  
  // 构建查询条件：包括自己和好友的动态
  const userObjectIds = [
    new mongoose.Types.ObjectId(userId),
    ...friendIds.map(id => new mongoose.Types.ObjectId(id))
  ];
  
  const query = {
    user_id: { $in: userObjectIds },
    $or: [
      { visibility: 'public' },
      { visibility: 'friends', user_id: { $in: userObjectIds } },
      { visibility: 'custom', visible_to: new mongoose.Types.ObjectId(userId) }
    ],
    hidden_from: { $ne: new mongoose.Types.ObjectId(userId) }
  };
  
  if (before_date) {
    query.created_at = { $lt: new Date(before_date) };
  }
  
  return this.find(query)
    .populate('user_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：搜索动态
 * @param {string} userId - 用户ID
 * @param {string} query - 搜索关键词
 * @param {Object} options - 搜索选项
 * @returns {Promise<Moment[]>} 搜索结果
 */
momentSchema.statics.searchMoments = function(userId, query, options = {}) {
  const {
    limit = 20,
    skip = 0,
    tags = [],
    location = ''
  } = options;
  
  // 构建搜索条件
  const searchConditions = {
    $or: [
      { user_id: new mongoose.Types.ObjectId(userId) },
      { 
        visibility: { $in: ['public', 'friends'] },
        hidden_from: { $ne: new mongoose.Types.ObjectId(userId) }
      }
    ]
  };
  
  // 添加文本搜索
  if (query) {
    searchConditions.content = new RegExp(query, 'i');
  }
  
  // 添加标签过滤
  if (tags.length > 0) {
    searchConditions.tags = { $in: tags };
  }
  
  // 添加位置过滤
  if (location) {
    searchConditions['location.name'] = new RegExp(location, 'i');
  }
  
  return this.find(searchConditions)
    .populate('user_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：获取热门动态
 * @param {Object} options - 查询选项
 * @returns {Promise<Moment[]>} 热门动态列表
 */
momentSchema.statics.getTrendingMoments = function(options = {}) {
  const {
    limit = 20,
    days = 7 // 最近几天的动态
  } = options;
  
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return this.find({
    created_at: { $gte: cutoffDate },
    visibility: 'public'
  })
  .populate('user_id', 'username nickname avatar_url')
  .sort({ 
    'stats.likes_count': -1,
    'stats.comments_count': -1,
    created_at: -1
  })
  .limit(limit)
  .lean();
};

/**
 * 静态方法：获取用户动态统计
 * @param {string} userId - 用户ID
 * @returns {Promise<Object>} 统计信息
 */
momentSchema.statics.getUserStats = async function(userId) {
  const stats = await this.aggregate([
    { $match: { user_id: new mongoose.Types.ObjectId(userId) } },
    {
      $group: {
        _id: null,
        total_moments: { $sum: 1 },
        total_likes: { $sum: '$stats.likes_count' },
        total_comments: { $sum: '$stats.comments_count' },
        total_views: { $sum: '$stats.views_count' }
      }
    }
  ]);
  
  return stats[0] || {
    total_moments: 0,
    total_likes: 0,
    total_comments: 0,
    total_views: 0
  };
};

/**
 * 静态方法：清理过期动态
 * @param {number} daysOld - 保留天数，默认365天
 * @returns {Promise<Object>} 清理结果
 */
momentSchema.statics.cleanupOldMoments = async function(daysOld = 365) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  const result = await this.deleteMany({
    created_at: { $lt: cutoffDate },
    'stats.likes_count': 0,
    'stats.comments_count': 0
  });
  
  return {
    success: true,
    deleted_count: result.deletedCount,
    message: `已清理${result.deletedCount}条过期动态`
  };
};

// 创建并导出朋友圈动态模型
const Moment = mongoose.model('Moment', momentSchema);

export default Moment;