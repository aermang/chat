/**
 * 消息数据模型
 * 定义聊天消息的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 消息Schema定义
 */
const messageSchema = new Schema({
  // 发送者
  sender_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '发送者ID不能为空']
  },
  
  // 接收者（私聊时使用）
  receiver_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // 聊天会话ID
  chat_id: {
    type: String,
    required: [true, '聊天会话ID不能为空'],
    index: true
  },
  
  // 消息内容
  content: {
    type: String,
    required: [true, '消息内容不能为空'],
    maxlength: [5000, '消息内容最多5000个字符'],
    trim: true
  },
  
  // 消息类型
  message_type: {
    type: String,
    enum: {
      values: ['text', 'image', 'file', 'voice', 'video', 'location', 'system'],
      message: '消息类型必须是text、image、file、voice、video、location或system'
    },
    default: 'text'
  },
  
  // 文件信息（非文本消息时使用）
  file_info: {
    url: { type: String, default: '' },
    filename: { type: String, default: '' },
    size: { type: Number, default: 0 },
    mime_type: { type: String, default: '' },
    duration: { type: Number, default: 0 }, // 音频/视频时长（秒）
    thumbnail_url: { type: String, default: '' } // 缩略图URL
  },
  
  // 位置信息（位置消息时使用）
  location_info: {
    latitude: { type: Number, default: 0 },
    longitude: { type: Number, default: 0 },
    address: { type: String, default: '' },
    name: { type: String, default: '' }
  },
  
  // 回复信息
  reply_to: {
    message_id: {
      type: Schema.Types.ObjectId,
      ref: 'Message',
      default: null
    },
    content: { type: String, default: '' },
    sender_name: { type: String, default: '' }
  },
  
  // 消息状态
  status: {
    type: String,
    enum: ['sent', 'delivered', 'read'],
    default: 'sent'
  },
  
  // 是否已读
  is_read: {
    type: Boolean,
    default: false
  },
  
  // 已读时间
  read_at: {
    type: Date,
    default: null
  },
  
  // 是否已撤回
  is_recalled: {
    type: Boolean,
    default: false
  },
  
  // 撤回时间
  recalled_at: {
    type: Date,
    default: null
  },
  
  // 消息标签
  tags: [{
    type: String,
    maxlength: [20, '标签最多20个字符']
  }],
  
  // 额外数据
  extra_data: {
    type: Schema.Types.Mixed,
    default: {}
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
messageSchema.index({ chat_id: 1, created_at: -1 });
messageSchema.index({ sender_id: 1, created_at: -1 });
messageSchema.index({ receiver_id: 1, is_read: 1 });
messageSchema.index({ chat_id: 1, message_type: 1 });
messageSchema.index({ created_at: -1 });

/**
 * 虚拟字段：是否可撤回
 */
messageSchema.virtual('can_recall').get(function() {
  if (this.is_recalled) return false;
  
  const now = new Date();
  const messageTime = new Date(this.created_at);
  const diffMinutes = (now - messageTime) / (1000 * 60);
  
  // 2分钟内可撤回
  return diffMinutes <= 2;
});

/**
 * 实例方法：标记为已读
 * @returns {Promise<Message>} 更新后的消息对象
 */
messageSchema.methods.markAsRead = async function() {
  if (!this.is_read) {
    this.is_read = true;
    this.read_at = new Date();
    this.status = 'read';
    return await this.save();
  }
  return this;
};

/**
 * 实例方法：撤回消息
 * @returns {Promise<Message>} 更新后的消息对象
 */
messageSchema.methods.recall = async function() {
  if (this.is_recalled) {
    throw new Error('消息已经被撤回');
  }
  
  if (!this.can_recall) {
    throw new Error('消息发送超过2分钟，无法撤回');
  }
  
  this.is_recalled = true;
  this.recalled_at = new Date();
  this.content = '[消息已撤回]';
  
  return await this.save();
};

/**
 * 静态方法：获取聊天消息列表
 * @param {string} chatId - 聊天会话ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Object>} 消息列表和分页信息
 */
messageSchema.statics.getChatMessages = async function(chatId, options = {}) {
  const {
    page = 1,
    limit = 20,
    before_message_id = null,
    message_type = null,
    search = ''
  } = options;
  
  // 构建查询条件
  const query = { chat_id: chatId };
  
  if (message_type) {
    query.message_type = message_type;
  }
  
  if (search) {
    query.content = new RegExp(search, 'i');
  }
  
  if (before_message_id) {
    const beforeMessage = await this.findById(before_message_id);
    if (beforeMessage) {
      query.created_at = { $lt: beforeMessage.created_at };
    }
  }
  
  // 查询消息
  const messages = await this.find(query)
    .populate('sender_id', 'username nickname avatar_url')
    .populate('reply_to.message_id', 'content sender_id message_type')
    .sort({ created_at: -1 })
    .limit(limit)
    .lean();
  
  // 获取总数
  const total = await this.countDocuments({ chat_id: chatId });
  
  return {
    messages: messages.reverse(), // 按时间正序返回
    pagination: {
      page,
      limit,
      total,
      has_more: messages.length === limit
    }
  };
};

/**
 * 静态方法：创建消息
 * @param {Object} messageData - 消息数据
 * @returns {Promise<Message>} 创建的消息对象
 */
messageSchema.statics.createMessage = async function(messageData) {
  const {
    sender_id,
    receiver_id,
    chat_id,
    content,
    message_type = 'text',
    file_info = {},
    location_info = {},
    reply_to = null,
    extra_data = {}
  } = messageData;
  
  // 验证必要字段
  if (!sender_id || !chat_id || !content) {
    throw new Error('发送者ID、聊天会话ID和消息内容不能为空');
  }
  
  // 创建消息
  const message = new this({
    sender_id,
    receiver_id,
    chat_id,
    content,
    message_type,
    file_info,
    location_info,
    reply_to,
    extra_data,
    status: 'sent'
  });
  
  return await message.save();
};

/**
 * 静态方法：批量标记消息为已读
 * @param {string} chatId - 聊天会话ID
 * @param {string} userId - 用户ID
 * @param {string[]} messageIds - 消息ID数组（可选）
 * @returns {Promise<Object>} 更新结果
 */
messageSchema.statics.markMultipleAsRead = async function(chatId, userId, messageIds = []) {
  const query = {
    chat_id: chatId,
    receiver_id: userId,
    is_read: false
  };
  
  if (messageIds.length > 0) {
    query._id = { $in: messageIds };
  }
  
  const now = new Date();
  const result = await this.updateMany(query, {
    is_read: true,
    read_at: now,
    status: 'read',
    updated_at: now
  });
  
  return {
    success: true,
    modified_count: result.modifiedCount,
    message: `已标记${result.modifiedCount}条消息为已读`
  };
};

/**
 * 静态方法：获取未读消息数量
 * @param {string} userId - 用户ID
 * @param {string} chatId - 聊天会话ID（可选）
 * @returns {Promise<number>} 未读消息数量
 */
messageSchema.statics.getUnreadCount = function(userId, chatId = null) {
  const query = {
    receiver_id: userId,
    is_read: false
  };
  
  if (chatId) {
    query.chat_id = chatId;
  }
  
  return this.countDocuments(query);
};

/**
 * 静态方法：获取最近消息
 * @param {string} chatId - 聊天会话ID
 * @returns {Promise<Message|null>} 最近的消息
 */
messageSchema.statics.getLatestMessage = function(chatId) {
  return this.findOne({ chat_id: chatId })
    .populate('sender_id', 'username nickname')
    .sort({ created_at: -1 })
    .lean();
};

/**
 * 静态方法：搜索消息
 * @param {string} userId - 用户ID
 * @param {string} query - 搜索关键词
 * @param {Object} options - 搜索选项
 * @returns {Promise<Message[]>} 搜索结果
 */
messageSchema.statics.searchMessages = function(userId, query, options = {}) {
  const {
    chat_id = null,
    message_type = null,
    limit = 50,
    skip = 0
  } = options;
  
  // 构建搜索条件
  const searchConditions = {
    $or: [
      { sender_id: userId },
      { receiver_id: userId }
    ],
    content: new RegExp(query, 'i'),
    is_recalled: false
  };
  
  if (chat_id) {
    searchConditions.chat_id = chat_id;
  }
  
  if (message_type) {
    searchConditions.message_type = message_type;
  }
  
  return this.find(searchConditions)
    .populate('sender_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：清理过期消息
 * @param {number} daysOld - 保留天数，默认90天
 * @returns {Promise<Object>} 清理结果
 */
messageSchema.statics.cleanupOldMessages = async function(daysOld = 90) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  const result = await this.deleteMany({
    created_at: { $lt: cutoffDate },
    is_recalled: true
  });
  
  return {
    success: true,
    deleted_count: result.deletedCount,
    message: `已清理${result.deletedCount}条过期消息`
  };
};

// 创建并导出消息模型
const Message = mongoose.model('Message', messageSchema);

export default Message;