/**
 * 好友申请数据模型
 * 定义好友申请的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 好友申请Schema定义
 */
const friendRequestSchema = new Schema({
  // 申请发送者
  from_user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '申请发送者ID不能为空']
  },
  
  // 申请接收者
  to_user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '申请接收者ID不能为空']
  },
  
  // 申请消息
  message: {
    type: String,
    maxlength: [200, '申请消息最多200个字符'],
    default: '我是{username}，请添加我为好友',
    trim: true
  },
  
  // 申请状态
  status: {
    type: String,
    enum: {
      values: ['pending', 'accepted', 'rejected', 'ignored'],
      message: '申请状态必须是pending、accepted、rejected或ignored'
    },
    default: 'pending'
  },
  
  // 是否已读
  is_read: {
    type: Boolean,
    default: false
  },
  
  // 处理时间
  processed_at: {
    type: Date,
    default: null
  },
  
  // 拒绝原因（可选）
  reject_reason: {
    type: String,
    maxlength: [100, '拒绝原因最多100个字符'],
    default: '',
    trim: true
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
// 复合唯一索引，防止重复申请
friendRequestSchema.index({ from_user_id: 1, to_user_id: 1 }, { unique: true });
friendRequestSchema.index({ to_user_id: 1, status: 1 });
friendRequestSchema.index({ to_user_id: 1, is_read: 1 });
friendRequestSchema.index({ from_user_id: 1, status: 1 });
friendRequestSchema.index({ created_at: -1 });

/**
 * 验证中间件：防止用户向自己发送好友申请
 */
friendRequestSchema.pre('save', function(next) {
  if (this.from_user_id.toString() === this.to_user_id.toString()) {
    const error = new Error('不能向自己发送好友申请');
    return next(error);
  }
  next();
});

/**
 * 实例方法：处理好友申请
 * @param {string} action - 处理动作 ('accepted', 'rejected', 'ignored')
 * @param {string} reason - 拒绝原因（可选）
 * @returns {Promise<FriendRequest>} 更新后的申请对象
 */
friendRequestSchema.methods.process = async function(action, reason = '') {
  if (!['accepted', 'rejected', 'ignored'].includes(action)) {
    throw new Error('无效的处理动作');
  }
  
  this.status = action;
  this.processed_at = new Date();
  this.is_read = true;
  
  if (action === 'rejected' && reason) {
    this.reject_reason = reason;
  }
  
  return await this.save();
};

/**
 * 实例方法：标记为已读
 * @returns {Promise<FriendRequest>} 更新后的申请对象
 */
friendRequestSchema.methods.markAsRead = async function() {
  if (!this.is_read) {
    this.is_read = true;
    return await this.save();
  }
  return this;
};

/**
 * 静态方法：检查是否存在待处理的申请
 * @param {string} fromUserId - 申请发送者ID
 * @param {string} toUserId - 申请接收者ID
 * @returns {Promise<boolean>} 是否存在待处理申请
 */
friendRequestSchema.statics.hasPendingRequest = async function(fromUserId, toUserId) {
  const request = await this.findOne({
    $or: [
      { from_user_id: fromUserId, to_user_id: toUserId, status: 'pending' },
      { from_user_id: toUserId, to_user_id: fromUserId, status: 'pending' }
    ]
  });
  
  return !!request;
};

/**
 * 静态方法：获取用户的好友申请列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<FriendRequest[]>} 申请列表
 */
friendRequestSchema.statics.getUserRequests = function(userId, options = {}) {
  const {
    type = 'received', // 'received' | 'sent'
    status = 'all', // 'all' | 'pending' | 'accepted' | 'rejected' | 'ignored'
    limit = 20,
    skip = 0
  } = options;
  
  // 构建查询条件
  const matchConditions = {};
  
  if (type === 'received') {
    matchConditions.to_user_id = new mongoose.Types.ObjectId(userId);
  } else {
    matchConditions.from_user_id = new mongoose.Types.ObjectId(userId);
  }
  
  if (status !== 'all') {
    matchConditions.status = status;
  }
  
  // 构建聚合管道
  const pipeline = [
    { $match: matchConditions },
    {
      $lookup: {
        from: 'users',
        localField: type === 'received' ? 'from_user_id' : 'to_user_id',
        foreignField: '_id',
        as: 'user'
      }
    },
    { $unwind: '$user' },
    {
      $project: {
        _id: 1,
        from_user_id: 1,
        to_user_id: 1,
        message: 1,
        status: 1,
        is_read: 1,
        processed_at: 1,
        reject_reason: 1,
        created_at: 1,
        updated_at: 1,
        'user._id': 1,
        'user.username': 1,
        'user.nickname': 1,
        'user.avatar_url': 1,
        'user.bio': 1,
        'user.is_online': 1
      }
    },
    { $sort: { created_at: -1 } }
  ];
  
  // 分页
  if (skip > 0) {
    pipeline.push({ $skip: skip });
  }
  pipeline.push({ $limit: limit });
  
  return this.aggregate(pipeline);
};

/**
 * 静态方法：获取未读申请数量
 * @param {string} userId - 用户ID
 * @returns {Promise<number>} 未读申请数量
 */
friendRequestSchema.statics.getUnreadCount = function(userId) {
  return this.countDocuments({
    to_user_id: userId,
    is_read: false,
    status: 'pending'
  });
};

/**
 * 静态方法：创建好友申请
 * @param {string} fromUserId - 申请发送者ID
 * @param {string} toUserId - 申请接收者ID
 * @param {string} message - 申请消息
 * @returns {Promise<FriendRequest>} 创建的申请对象
 */
friendRequestSchema.statics.createRequest = async function(fromUserId, toUserId, message = '') {
  // 检查是否已存在待处理申请
  const existingRequest = await this.hasPendingRequest(fromUserId, toUserId);
  if (existingRequest) {
    throw new Error('已存在待处理的好友申请');
  }
  
  // 检查是否已经是好友
  const Friendship = mongoose.model('Friendship');
  const areFriends = await Friendship.areFriends(fromUserId, toUserId);
  if (areFriends) {
    throw new Error('你们已经是好友了');
  }
  
  // 创建申请
  const request = new this({
    from_user_id: fromUserId,
    to_user_id: toUserId,
    message: message || '我想添加您为好友'
  });
  
  return await request.save();
};

/**
 * 静态方法：批量标记为已读
 * @param {string} userId - 用户ID
 * @param {string[]} requestIds - 申请ID数组（可选）
 * @returns {Promise<Object>} 更新结果
 */
friendRequestSchema.statics.markMultipleAsRead = async function(userId, requestIds = []) {
  const query = { to_user_id: userId, is_read: false };
  
  if (requestIds.length > 0) {
    query._id = { $in: requestIds };
  }
  
  const result = await this.updateMany(query, { 
    is_read: true,
    updated_at: new Date()
  });
  
  return {
    success: true,
    modifiedCount: result.modifiedCount,
    message: `已标记${result.modifiedCount}条申请为已读`
  };
};

/**
 * 静态方法：清理过期的已处理申请
 * @param {number} daysOld - 保留天数，默认30天
 * @returns {Promise<Object>} 清理结果
 */
friendRequestSchema.statics.cleanupOldRequests = async function(daysOld = 30) {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  const result = await this.deleteMany({
    status: { $in: ['rejected', 'ignored'] },
    processed_at: { $lt: cutoffDate }
  });
  
  return {
    success: true,
    deletedCount: result.deletedCount,
    message: `已清理${result.deletedCount}条过期申请`
  };
};

// 创建并导出好友申请模型
const FriendRequest = mongoose.model('FriendRequest', friendRequestSchema);

export default FriendRequest;