/**
 * 点赞数据模型
 * 定义点赞的数据结构和业务逻辑
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

/**
 * 点赞Schema定义
 */
const likeSchema = new Schema({
  // 动态ID
  moment_id: {
    type: Schema.Types.ObjectId,
    ref: 'Moment',
    required: [true, '动态ID不能为空']
  },
  
  // 点赞用户ID
  user_id: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, '用户ID不能为空']
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

/**
 * 索引定义
 */
// 复合唯一索引，防止重复点赞
likeSchema.index({ moment_id: 1, user_id: 1 }, { unique: true });
likeSchema.index({ moment_id: 1, created_at: -1 });
likeSchema.index({ user_id: 1, created_at: -1 });

/**
 * 静态方法：切换点赞状态
 * @param {string} momentId - 动态ID
 * @param {string} userId - 用户ID
 * @returns {Promise<Object>} 操作结果
 */
likeSchema.statics.toggleLike = async function(momentId, userId) {
  const session = await mongoose.startSession();
  
  try {
    return await session.withTransaction(async () => {
      // 检查是否已点赞
      const existingLike = await this.findOne({ moment_id: momentId, user_id: userId });
      
      const Moment = mongoose.model('Moment');
      
      if (existingLike) {
        // 取消点赞
        await this.deleteOne({ _id: existingLike._id }, { session });
        await Moment.findByIdAndUpdate(
          momentId,
          { $inc: { 'stats.likes_count': -1 } },
          { session }
        );
        
        return {
          success: true,
          action: 'unliked',
          message: '取消点赞成功'
        };
      } else {
        // 添加点赞
        await this.create([{ moment_id: momentId, user_id: userId }], { session });
        await Moment.findByIdAndUpdate(
          momentId,
          { $inc: { 'stats.likes_count': 1 } },
          { session }
        );
        
        return {
          success: true,
          action: 'liked',
          message: '点赞成功'
        };
      }
    });
  } catch (error) {
    if (error.code === 11000) {
      return {
        success: false,
        message: '操作过于频繁，请稍后再试'
      };
    }
    throw error;
  } finally {
    await session.endSession();
  }
};

/**
 * 静态方法：获取动态的点赞列表
 * @param {string} momentId - 动态ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Like[]>} 点赞列表
 */
likeSchema.statics.getMomentLikes = function(momentId, options = {}) {
  const { limit = 50, skip = 0 } = options;
  
  return this.find({ moment_id: momentId })
    .populate('user_id', 'username nickname avatar_url')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

/**
 * 静态方法：检查用户是否点赞了动态
 * @param {string} momentId - 动态ID
 * @param {string} userId - 用户ID
 * @returns {Promise<boolean>} 是否已点赞
 */
likeSchema.statics.hasUserLiked = async function(momentId, userId) {
  const like = await this.findOne({ moment_id: momentId, user_id: userId });
  return !!like;
};

/**
 * 静态方法：获取用户点赞的动态列表
 * @param {string} userId - 用户ID
 * @param {Object} options - 查询选项
 * @returns {Promise<Moment[]>} 动态列表
 */
likeSchema.statics.getUserLikedMoments = function(userId, options = {}) {
  const { limit = 20, skip = 0 } = options;
  
  return this.find({ user_id: userId })
    .populate({
      path: 'moment_id',
      populate: {
        path: 'user_id',
        select: 'username nickname avatar_url'
      }
    })
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};

// 创建并导出点赞模型
const Like = mongoose.model('Like', likeSchema);

export default Like;