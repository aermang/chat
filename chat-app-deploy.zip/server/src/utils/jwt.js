/**
 * JWT工具类
 * 提供JWT令牌的生成、验证和刷新功能
 */

import jwt from 'jsonwebtoken';
import { promisify } from 'util';

// 将jwt方法转换为Promise版本
const signAsync = promisify(jwt.sign);
const verifyAsync = promisify(jwt.verify);

/**
 * JWT工具类
 */
class JWTUtils {
  constructor() {
    this.accessTokenSecret = process.env.JWT_SECRET || 'your-secret-key';
    this.refreshTokenSecret = process.env.JWT_REFRESH_SECRET || 'your-refresh-secret-key';
    this.accessTokenExpiry = process.env.JWT_EXPIRES_IN || '15m';
    this.refreshTokenExpiry = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
  }

  /**
   * 生成访问令牌
   * @param {Object} payload - 令牌载荷
   * @param {Object} options - 额外选项
   * @returns {Promise<string>} 访问令牌
   */
  async generateAccessToken(payload, options = {}) {
    try {
      const tokenPayload = {
        user_id: payload.user_id,
        username: payload.username,
        email: payload.email,
        type: 'access'
      };

      const tokenOptions = {
        expiresIn: options.expiresIn || this.accessTokenExpiry,
        issuer: 'chat-app',
        audience: 'chat-app-users',
        ...options
      };

      return await signAsync(tokenPayload, this.accessTokenSecret, tokenOptions);
    } catch (error) {
      throw new Error(`生成访问令牌失败: ${error.message}`);
    }
  }

  /**
   * 生成刷新令牌
   * @param {Object} payload - 令牌载荷
   * @param {Object} options - 额外选项
   * @returns {Promise<string>} 刷新令牌
   */
  async generateRefreshToken(payload, options = {}) {
    try {
      const tokenPayload = {
        user_id: payload.user_id,
        username: payload.username,
        type: 'refresh'
      };

      const tokenOptions = {
        expiresIn: options.expiresIn || this.refreshTokenExpiry,
        issuer: 'chat-app',
        audience: 'chat-app-users',
        ...options
      };

      return await signAsync(tokenPayload, this.refreshTokenSecret, tokenOptions);
    } catch (error) {
      throw new Error(`生成刷新令牌失败: ${error.message}`);
    }
  }

  /**
   * 生成令牌对（访问令牌和刷新令牌）
   * @param {Object} payload - 令牌载荷
   * @returns {Promise<Object>} 令牌对象
   */
  async generateTokenPair(payload) {
    try {
      const [accessToken, refreshToken] = await Promise.all([
        this.generateAccessToken(payload),
        this.generateRefreshToken(payload)
      ]);

      return {
        access_token: accessToken,
        refresh_token: refreshToken,
        token_type: 'Bearer',
        expires_in: this.parseExpiryToSeconds(this.accessTokenExpiry)
      };
    } catch (error) {
      throw new Error(`生成令牌对失败: ${error.message}`);
    }
  }

  /**
   * 验证访问令牌
   * @param {string} token - 访问令牌
   * @returns {Promise<Object>} 解码后的令牌载荷
   */
  async verifyAccessToken(token) {
    try {
      const decoded = await verifyAsync(token, this.accessTokenSecret, {
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });

      if (decoded.type !== 'access') {
        throw new Error('令牌类型错误');
      }

      return decoded;
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new Error('访问令牌已过期');
      } else if (error.name === 'JsonWebTokenError') {
        throw new Error('访问令牌无效');
      } else if (error.name === 'NotBeforeError') {
        throw new Error('访问令牌尚未生效');
      }
      throw new Error(`验证访问令牌失败: ${error.message}`);
    }
  }

  /**
   * 验证刷新令牌
   * @param {string} token - 刷新令牌
   * @returns {Promise<Object>} 解码后的令牌载荷
   */
  async verifyRefreshToken(token) {
    try {
      const decoded = await verifyAsync(token, this.refreshTokenSecret, {
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });

      if (decoded.type !== 'refresh') {
        throw new Error('令牌类型错误');
      }

      return decoded;
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new Error('刷新令牌已过期');
      } else if (error.name === 'JsonWebTokenError') {
        throw new Error('刷新令牌无效');
      } else if (error.name === 'NotBeforeError') {
        throw new Error('刷新令牌尚未生效');
      }
      throw new Error(`验证刷新令牌失败: ${error.message}`);
    }
  }

  /**
   * 从令牌中提取载荷（不验证签名）
   * @param {string} token - JWT令牌
   * @returns {Object} 令牌载荷
   */
  decodeToken(token) {
    try {
      return jwt.decode(token);
    } catch (error) {
      throw new Error(`解码令牌失败: ${error.message}`);
    }
  }

  /**
   * 检查令牌是否即将过期
   * @param {string} token - JWT令牌
   * @param {number} thresholdMinutes - 阈值分钟数，默认5分钟
   * @returns {boolean} 是否即将过期
   */
  isTokenExpiringSoon(token, thresholdMinutes = 5) {
    try {
      const decoded = this.decodeToken(token);
      if (!decoded || !decoded.exp) {
        return true;
      }

      const now = Math.floor(Date.now() / 1000);
      const threshold = thresholdMinutes * 60;
      
      return (decoded.exp - now) <= threshold;
    } catch (error) {
      return true;
    }
  }

  /**
   * 获取令牌剩余有效时间（秒）
   * @param {string} token - JWT令牌
   * @returns {number} 剩余秒数，-1表示已过期或无效
   */
  getTokenRemainingTime(token) {
    try {
      const decoded = this.decodeToken(token);
      if (!decoded || !decoded.exp) {
        return -1;
      }

      const now = Math.floor(Date.now() / 1000);
      const remaining = decoded.exp - now;
      
      return remaining > 0 ? remaining : -1;
    } catch (error) {
      return -1;
    }
  }

  /**
   * 将过期时间字符串转换为秒数
   * @param {string} expiry - 过期时间字符串（如 '15m', '1h', '7d'）
   * @returns {number} 秒数
   */
  parseExpiryToSeconds(expiry) {
    const units = {
      's': 1,
      'm': 60,
      'h': 3600,
      'd': 86400,
      'w': 604800
    };

    const match = expiry.match(/^(\d+)([smhdw])$/);
    if (!match) {
      throw new Error('无效的过期时间格式');
    }

    const [, value, unit] = match;
    return parseInt(value) * units[unit];
  }

  /**
   * 生成用于密码重置的临时令牌
   * @param {Object} payload - 令牌载荷
   * @param {string} expiresIn - 过期时间，默认1小时
   * @returns {Promise<string>} 临时令牌
   */
  async generatePasswordResetToken(payload, expiresIn = '1h') {
    try {
      const tokenPayload = {
        user_id: payload.user_id,
        email: payload.email,
        type: 'password_reset',
        timestamp: Date.now()
      };

      return await signAsync(tokenPayload, this.accessTokenSecret, {
        expiresIn,
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });
    } catch (error) {
      throw new Error(`生成密码重置令牌失败: ${error.message}`);
    }
  }

  /**
   * 验证密码重置令牌
   * @param {string} token - 密码重置令牌
   * @returns {Promise<Object>} 解码后的令牌载荷
   */
  async verifyPasswordResetToken(token) {
    try {
      const decoded = await verifyAsync(token, this.accessTokenSecret, {
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });

      if (decoded.type !== 'password_reset') {
        throw new Error('令牌类型错误');
      }

      return decoded;
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new Error('密码重置令牌已过期');
      } else if (error.name === 'JsonWebTokenError') {
        throw new Error('密码重置令牌无效');
      }
      throw new Error(`验证密码重置令牌失败: ${error.message}`);
    }
  }

  /**
   * 生成邮箱验证令牌
   * @param {Object} payload - 令牌载荷
   * @param {string} expiresIn - 过期时间，默认24小时
   * @returns {Promise<string>} 邮箱验证令牌
   */
  async generateEmailVerificationToken(payload, expiresIn = '24h') {
    try {
      const tokenPayload = {
        user_id: payload.user_id,
        email: payload.email,
        type: 'email_verification',
        timestamp: Date.now()
      };

      return await signAsync(tokenPayload, this.accessTokenSecret, {
        expiresIn,
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });
    } catch (error) {
      throw new Error(`生成邮箱验证令牌失败: ${error.message}`);
    }
  }

  /**
   * 验证邮箱验证令牌
   * @param {string} token - 邮箱验证令牌
   * @returns {Promise<Object>} 解码后的令牌载荷
   */
  async verifyEmailVerificationToken(token) {
    try {
      const decoded = await verifyAsync(token, this.accessTokenSecret, {
        issuer: 'chat-app',
        audience: 'chat-app-users'
      });

      if (decoded.type !== 'email_verification') {
        throw new Error('令牌类型错误');
      }

      return decoded;
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new Error('邮箱验证令牌已过期');
      } else if (error.name === 'JsonWebTokenError') {
        throw new Error('邮箱验证令牌无效');
      }
      throw new Error(`验证邮箱验证令牌失败: ${error.message}`);
    }
  }
}

// 创建JWT工具实例
const jwtUtils = new JWTUtils();

export default jwtUtils;