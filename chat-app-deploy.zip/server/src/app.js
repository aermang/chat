/**
 * Express应用程序主文件
 * 配置中间件、路由和错误处理
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'express-mongo-sanitize';
import xss from 'xss-clean';
import hpp from 'hpp';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';

// 导入路由
import routes from './routes/index.js';

// 导入中间件
import { 
  globalErrorHandler, 
  notFoundHandler,
  errorLogger 
} from './middleware/errorHandler.js';

// 获取当前文件目录
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * 创建Express应用实例
 * @returns {Object} Express应用实例
 */
function createApp() {
  const app = express();

  // 信任代理（用于部署在反向代理后面）
  app.set('trust proxy', 1);

  // 安全中间件
  app.use(helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "ws:", "wss:"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'none'"],
      },
    },
  }));

  // CORS配置
  app.use(cors({
    origin: function (origin, callback) {
      // 允许的源列表
      const allowedOrigins = [
        'http://localhost:3000',
        'http://localhost:5173',
        'http://127.0.0.1:3000',
        'http://127.0.0.1:5173'
      ];

      // 开发环境允许所有源
      if (process.env.NODE_ENV === 'development') {
        return callback(null, true);
      }

      // 生产环境检查源
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('不允许的CORS源'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
  }));

  // 压缩响应
  app.use(compression());

  // 请求日志
  if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
  } else {
    app.use(morgan('combined'));
  }

  // 解析请求体
  app.use(express.json({ 
    limit: '10mb',
    verify: (req, res, buf) => {
      req.rawBody = buf;
    }
  }));
  app.use(express.urlencoded({ 
    extended: true, 
    limit: '10mb' 
  }));

  // 数据清理和安全
  app.use(mongoSanitize()); // 防止NoSQL注入
  app.use(xss()); // 防止XSS攻击
  app.use(hpp()); // 防止HTTP参数污染

  // 全局速率限制
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15分钟
    max: process.env.NODE_ENV === 'development' ? 1000 : 100, // 开发环境更宽松
    message: {
      error: '请求过于频繁，请稍后再试',
      code: 'RATE_LIMIT_EXCEEDED'
    },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      // 跳过健康检查和静态文件
      return req.path === '/health' || req.path.startsWith('/uploads/');
    }
  });
  app.use(limiter);

  // 静态文件服务
  app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

  // API路由
  app.use('/api', routes);

  // 健康检查端点
  app.get('/health', (req, res) => {
    res.status(200).json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.npm_package_version || '1.0.0'
    });
  });

  // 根路径
  app.get('/', (req, res) => {
    res.json({
      message: '聊天应用API服务器',
      version: '1.0.0',
      status: 'running',
      docs: '/api/docs'
    });
  });

  // 错误日志中间件
  app.use(errorLogger);

  // 404处理
  app.use(notFoundHandler);

  // 全局错误处理
  app.use(globalErrorHandler);

  return app;
}

export default createApp;