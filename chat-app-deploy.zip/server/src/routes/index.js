/**
 * 主路由文件
 * 整合所有API路由
 */

import express from 'express';
import authRoutes from './auth.js';
import userRoutes from './users.js';
import friendRoutes from './friends.js';
import messageRoutes from './messages.js';
import sessionRoutes from './sessions.js';
import momentRoutes from './moments.js';
import notificationRoutes from './notifications.js';

const router = express.Router();

// API版本信息
router.get('/', (req, res) => {
  res.json({
    success: true,
    message: '聊天应用 API 服务',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    endpoints: {
      auth: '/api/auth',
      users: '/api/users',
      friends: '/api/friends',
      messages: '/api/messages',
      sessions: '/api/sessions',
      moments: '/api/moments',
      notifications: '/api/notifications'
    }
  });
});

// 健康检查
router.get('/health', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    version: process.version
  });
});

// 注册各模块路由
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/friends', friendRoutes);
router.use('/messages', messageRoutes);
router.use('/sessions', sessionRoutes);
router.use('/moments', momentRoutes);
router.use('/notifications', notificationRoutes);

export default router;