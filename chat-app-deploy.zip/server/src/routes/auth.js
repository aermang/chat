/**
 * 认证路由
 * 处理用户注册、登录、令牌刷新等认证相关操作
 */

import express from 'express';
import bcrypt from 'bcryptjs';
import jwtUtils from '../utils/jwt.js';
import { User } from '../models/index.js';
import {
  validateUserRegistration,
  validateUserLogin,
  validateEmail,
  validatePasswordReset,
  authenticateRefreshToken,
  authenticatePasswordResetToken,
  authenticateEmailVerificationToken,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

/**
 * 用户注册
 * POST /api/auth/register
 */
router.post('/register', validateUserRegistration, catchAsync(async (req, res) => {
  const { username, email, password, nickname } = req.body;

  // 检查用户名是否已存在
  const existingUser = await User.findByIdentifier(username);
  if (existingUser) {
    throw createError.conflict('用户名已存在');
  }

  // 检查邮箱是否已存在
  const existingEmail = await User.findByIdentifier(email);
  if (existingEmail) {
    throw createError.conflict('邮箱已被注册');
  }

  // 创建新用户
  const userData = {
    username,
    email,
    password,
    nickname: nickname || username,
    profile: {
      nickname: nickname || username
    }
  };

  const user = new User(userData);
  await user.save();

  // 生成令牌对
  const tokenPayload = {
    user_id: user._id,
    username: user.username,
    email: user.email
  };

  const tokens = await jwtUtils.generateTokenPair(tokenPayload);

  // 更新用户在线状态
  await user.updateOnlineStatus(true);

  // 返回用户信息和令牌
  res.status(201).json({
    success: true,
    message: '注册成功',
    data: {
      user: user.getPublicInfo(),
      tokens
    }
  });
}));

/**
 * 用户登录
 * POST /api/auth/login
 */
router.post('/login', validateUserLogin, catchAsync(async (req, res) => {
  const { identifier, password } = req.body;

  // 查找用户（通过用户名或邮箱）
  const user = await User.findByIdentifier(identifier);
  if (!user) {
    throw createError.auth('用户名或密码错误');
  }

  // 验证密码
  const isPasswordValid = await user.comparePassword(password);
  if (!isPasswordValid) {
    throw createError.auth('用户名或密码错误');
  }

  // 检查账户状态
  if (user.status === 'disabled') {
    throw createError.auth('账户已被禁用');
  }

  // 生成令牌对
  const tokenPayload = {
    user_id: user._id,
    username: user.username,
    email: user.email
  };

  const tokens = await jwtUtils.generateTokenPair(tokenPayload);

  // 更新用户在线状态和最后登录时间
  await user.updateOnlineStatus(true);
  user.last_login_at = new Date();
  await user.save();

  // 返回用户信息和令牌
  res.json({
    success: true,
    message: '登录成功',
    data: {
      user: user.getPublicInfo(),
      tokens
    }
  });
}));

/**
 * 刷新令牌
 * POST /api/auth/refresh
 */
router.post('/refresh', authenticateRefreshToken, catchAsync(async (req, res) => {
  const user = req.user;

  // 生成新的令牌对
  const tokenPayload = {
    user_id: user._id,
    username: user.username,
    email: user.email
  };

  const tokens = await jwtUtils.generateTokenPair(tokenPayload);

  res.json({
    success: true,
    message: '令牌刷新成功',
    data: {
      tokens
    }
  });
}));

/**
 * 用户登出
 * POST /api/auth/logout
 */
router.post('/logout', catchAsync(async (req, res) => {
  // 从请求头获取令牌
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (token) {
    try {
      // 验证令牌并获取用户信息
      const decoded = await jwtUtils.verifyAccessToken(token);
      const user = await User.findById(decoded.user_id);
      
      if (user) {
        // 更新用户离线状态
        await user.updateOnlineStatus(false);
      }
    } catch (error) {
      // 令牌无效或过期，忽略错误
      console.log('Logout with invalid token:', error.message);
    }
  }

  res.json({
    success: true,
    message: '登出成功'
  });
}));

/**
 * 发送密码重置邮件
 * POST /api/auth/forgot-password
 */
router.post('/forgot-password', validateEmail, catchAsync(async (req, res) => {
  const { email } = req.body;

  // 查找用户
  const user = await User.findByIdentifier(email);
  if (!user) {
    // 为了安全，即使用户不存在也返回成功消息
    return res.json({
      success: true,
      message: '如果该邮箱已注册，您将收到密码重置邮件'
    });
  }

  // 生成密码重置令牌
  const resetToken = await jwtUtils.generatePasswordResetToken({
    user_id: user._id,
    email: user.email
  });

  // TODO: 发送邮件（这里暂时返回令牌，实际应用中应该发送邮件）
  // 在实际应用中，应该将令牌通过邮件发送给用户
  console.log('Password reset token for', email, ':', resetToken);

  res.json({
    success: true,
    message: '如果该邮箱已注册，您将收到密码重置邮件',
    // 开发环境下返回令牌，生产环境应该移除
    ...(process.env.NODE_ENV === 'development' && { reset_token: resetToken })
  });
}));

/**
 * 重置密码
 * POST /api/auth/reset-password
 */
router.post('/reset-password', validatePasswordReset, authenticatePasswordResetToken, catchAsync(async (req, res) => {
  const { new_password } = req.body;
  const user = req.user;

  // 更新密码
  user.password = new_password;
  await user.save();

  res.json({
    success: true,
    message: '密码重置成功，请使用新密码登录'
  });
}));

/**
 * 发送邮箱验证邮件
 * POST /api/auth/send-verification
 */
router.post('/send-verification', validateEmail, catchAsync(async (req, res) => {
  const { email } = req.body;

  // 查找用户
  const user = await User.findByIdentifier(email);
  if (!user) {
    throw createError.notFound('用户');
  }

  // 检查邮箱是否已验证
  if (user.email_verified) {
    return res.json({
      success: true,
      message: '邮箱已验证'
    });
  }

  // 生成邮箱验证令牌
  const verificationToken = await jwtUtils.generateEmailVerificationToken({
    user_id: user._id,
    email: user.email
  });

  // TODO: 发送验证邮件（这里暂时返回令牌，实际应用中应该发送邮件）
  console.log('Email verification token for', email, ':', verificationToken);

  res.json({
    success: true,
    message: '验证邮件已发送',
    // 开发环境下返回令牌，生产环境应该移除
    ...(process.env.NODE_ENV === 'development' && { verification_token: verificationToken })
  });
}));

/**
 * 验证邮箱
 * GET /api/auth/verify-email/:token
 */
router.get('/verify-email/:token', authenticateEmailVerificationToken, catchAsync(async (req, res) => {
  const user = req.user;

  // 更新邮箱验证状态
  user.email_verified = true;
  user.email_verified_at = new Date();
  await user.save();

  res.json({
    success: true,
    message: '邮箱验证成功'
  });
}));

/**
 * 检查用户名是否可用
 * GET /api/auth/check-username/:username
 */
router.get('/check-username/:username', catchAsync(async (req, res) => {
  const { username } = req.params;

  // 验证用户名格式
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
    return res.json({
      success: true,
      available: false,
      message: '用户名格式不正确'
    });
  }

  // 检查用户名是否已存在
  const existingUser = await User.findByIdentifier(username);
  const available = !existingUser;

  res.json({
    success: true,
    available,
    message: available ? '用户名可用' : '用户名已存在'
  });
}));

/**
 * 检查邮箱是否可用
 * GET /api/auth/check-email/:email
 */
router.get('/check-email/:email', catchAsync(async (req, res) => {
  const { email } = req.params;

  // 验证邮箱格式
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.json({
      success: true,
      available: false,
      message: '邮箱格式不正确'
    });
  }

  // 检查邮箱是否已存在
  const existingUser = await User.findByIdentifier(email);
  const available = !existingUser;

  res.json({
    success: true,
    available,
    message: available ? '邮箱可用' : '邮箱已被注册'
  });
}));

/**
 * 获取当前用户信息（需要认证）
 * GET /api/auth/me
 */
router.get('/me', catchAsync(async (req, res) => {
  // 从请求头获取令牌
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    throw createError.auth('访问令牌缺失');
  }

  // 验证令牌
  const decoded = await jwtUtils.verifyAccessToken(token);
  
  // 获取用户信息
  const user = await User.findById(decoded.user_id).select('-password');
  if (!user) {
    throw createError.notFound('用户');
  }

  res.json({
    success: true,
    data: {
      user: user.getPublicInfo()
    }
  });
}));

export default router;