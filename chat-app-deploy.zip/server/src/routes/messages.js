/**
 * 消息路由
 * 处理消息发送、接收、查询等操作
 */

import express from 'express';
import multer from 'multer';
import { Message, ChatSession, User, Friendship } from '../models/index.js';
import {
  authenticateToken,
  validateMessageSend,
  validatePagination,
  validateObjectId,
  validateFileUpload,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

// 配置文件上传
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  }
});

/**
 * 发送消息
 * POST /api/messages
 */
router.post('/', 
  authenticateToken, 
  validateMessageSend, 
  catchAsync(async (req, res) => {
    const senderId = req.user._id;
    const { 
      receiver_id, 
      session_id, 
      content, 
      type = 'text',
      file_info,
      location_info,
      reply_to
    } = req.body;

    let receiverId = receiver_id;
    let sessionId = session_id;

    // 如果没有提供session_id，根据receiver_id创建或获取会话
    if (!sessionId && receiverId) {
      // 检查接收者是否存在
      const receiver = await User.findById(receiverId);
      if (!receiver) {
        throw createError.notFound('接收者不存在');
      }

      // 检查是否为好友（私聊需要好友关系）
      const isFriend = await Friendship.isFriend(senderId, receiverId);
      if (!isFriend) {
        throw createError.forbidden('只能向好友发送消息');
      }

      // 创建或获取私聊会话
      const session = await ChatSession.createOrGetPrivateSession(senderId, receiverId);
      sessionId = session._id;
    }

    // 如果提供了session_id，验证用户是否为会话参与者
    if (sessionId) {
      const session = await ChatSession.findById(sessionId);
      if (!session) {
        throw createError.notFound('聊天会话不存在');
      }

      // 检查用户是否为会话参与者
      const isParticipant = session.participants.some(p => p.toString() === senderId.toString());
      if (!isParticipant) {
        throw createError.forbidden('您不是此会话的参与者');
      }

      // 对于私聊，设置接收者ID
      if (session.type === 'private') {
        receiverId = session.participants.find(p => p.toString() !== senderId.toString());
      }
    }

    // 验证回复消息
    if (reply_to) {
      const replyMessage = await Message.findById(reply_to);
      if (!replyMessage) {
        throw createError.notFound('回复的消息不存在');
      }
      if (replyMessage.session_id.toString() !== sessionId.toString()) {
        throw createError.validation('回复消息必须在同一会话中');
      }
    }

    // 创建消息
    const messageData = {
      sender_id: senderId,
      receiver_id: receiverId,
      session_id: sessionId,
      content,
      type,
      file_info,
      location_info,
      reply_to
    };

    const message = await Message.createMessage(messageData);

    // 填充发送者信息
    await message.populate('sender_id', 'username profile');
    if (message.reply_to) {
      await message.populate('reply_to', 'sender_id content type created_at');
      await message.populate('reply_to.sender_id', 'username profile');
    }

    res.status(201).json({
      success: true,
      message: '消息发送成功',
      data: {
        message: message
      }
    });
  })
);

/**
 * 获取聊天消息列表
 * GET /api/messages/session/:sessionId
 */
router.get('/session/:sessionId',
  authenticateToken,
  validateObjectId('sessionId'),
  validatePagination,
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const { page = 1, limit = 50, before_id } = req.query;
    const userId = req.user._id;

    // 验证会话存在且用户有权限
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 获取消息列表
    const options = {
      limit: parseInt(limit),
      page: parseInt(page),
      before_id
    };

    const result = await Message.getChatMessages(sessionId, options);

    res.json({
      success: true,
      data: {
        messages: result.messages,
        pagination: result.pagination
      }
    });
  })
);

/**
 * 获取与特定用户的聊天记录
 * GET /api/messages/user/:userId
 */
router.get('/user/:userId',
  authenticateToken,
  validateObjectId('userId'),
  validatePagination,
  catchAsync(async (req, res) => {
    const currentUserId = req.user._id;
    const { userId } = req.params;
    const { page = 1, limit = 50, before_id } = req.query;

    // 检查是否为好友
    const isFriend = await Friendship.isFriend(currentUserId, userId);
    if (!isFriend) {
      throw createError.forbidden('只能查看好友的聊天记录');
    }

    // 获取或创建私聊会话
    const session = await ChatSession.createOrGetPrivateSession(currentUserId, userId);

    // 获取消息列表
    const options = {
      limit: parseInt(limit),
      page: parseInt(page),
      before_id
    };

    const result = await Message.getChatMessages(session._id, options);

    res.json({
      success: true,
      data: {
        session_id: session._id,
        messages: result.messages,
        pagination: result.pagination
      }
    });
  })
);

/**
 * 标记消息为已读
 * PUT /api/messages/:messageId/read
 */
router.put('/:messageId/read',
  authenticateToken,
  validateObjectId('messageId'),
  catchAsync(async (req, res) => {
    const { messageId } = req.params;
    const userId = req.user._id;

    // 查找消息
    const message = await Message.findById(messageId);
    if (!message) {
      throw createError.notFound('消息不存在');
    }

    // 检查权限（只有接收者可以标记为已读）
    if (message.receiver_id && message.receiver_id.toString() !== userId.toString()) {
      throw createError.forbidden('只能标记发给自己的消息为已读');
    }

    // 标记为已读
    await message.markAsRead();

    res.json({
      success: true,
      message: '消息已标记为已读'
    });
  })
);

/**
 * 批量标记消息为已读
 * PUT /api/messages/session/:sessionId/read
 */
router.put('/session/:sessionId/read',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;
    const { message_ids } = req.body;

    // 验证会话权限
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 批量标记为已读
    let result;
    if (message_ids && Array.isArray(message_ids)) {
      // 标记指定消息为已读
      result = await Message.markMultipleAsRead(sessionId, userId, message_ids);
    } else {
      // 标记会话中所有未读消息为已读
      result = await Message.markMultipleAsRead(sessionId, userId);
    }

    res.json({
      success: true,
      message: `已标记 ${result.modifiedCount} 条消息为已读`
    });
  })
);

/**
 * 撤回消息
 * PUT /api/messages/:messageId/recall
 */
router.put('/:messageId/recall',
  authenticateToken,
  validateObjectId('messageId'),
  catchAsync(async (req, res) => {
    const { messageId } = req.params;
    const userId = req.user._id;

    // 查找消息
    const message = await Message.findById(messageId);
    if (!message) {
      throw createError.notFound('消息不存在');
    }

    // 检查权限（只有发送者可以撤回）
    if (message.sender_id.toString() !== userId.toString()) {
      throw createError.forbidden('只能撤回自己发送的消息');
    }

    // 检查是否可以撤回
    if (!message.can_recall) {
      throw createError.forbidden('消息发送超过2分钟，无法撤回');
    }

    // 撤回消息
    await message.recall();

    res.json({
      success: true,
      message: '消息已撤回'
    });
  })
);

/**
 * 获取未读消息数量
 * GET /api/messages/unread-count
 */
router.get('/unread-count', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  const unreadCount = await Message.getUnreadCount(userId);

  res.json({
    success: true,
    data: {
      unread_count: unreadCount
    }
  });
}));

/**
 * 获取会话的未读消息数量
 * GET /api/messages/session/:sessionId/unread-count
 */
router.get('/session/:sessionId/unread-count',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;

    // 验证会话权限
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 获取未读消息数量
    const unreadCount = await Message.countDocuments({
      session_id: sessionId,
      receiver_id: userId,
      is_read: false,
      is_recalled: false
    });

    res.json({
      success: true,
      data: {
        unread_count: unreadCount
      }
    });
  })
);

/**
 * 搜索消息
 * GET /api/messages/search
 */
router.get('/search', authenticateToken, catchAsync(async (req, res) => {
  const { q: query, session_id, type, page = 1, limit = 20 } = req.query;
  const userId = req.user._id;

  if (!query || query.trim().length === 0) {
    return res.json({
      success: true,
      data: { messages: [], pagination: { total: 0 } }
    });
  }

  // 构建搜索选项
  const options = {
    query: query.trim(),
    session_id,
    type,
    user_id: userId,
    page: parseInt(page),
    limit: parseInt(limit)
  };

  const result = await Message.searchMessages(options);

  res.json({
    success: true,
    data: {
      messages: result.messages,
      pagination: result.pagination
    }
  });
}));

/**
 * 上传文件消息
 * POST /api/messages/upload
 */
router.post('/upload',
  authenticateToken,
  upload.single('file'),
  validateFileUpload(['image/*', 'audio/*', 'video/*', 'application/*'], 10 * 1024 * 1024),
  catchAsync(async (req, res) => {
    const file = req.file;
    const { receiver_id, session_id } = req.body;

    if (!file) {
      throw createError.validation('请选择要上传的文件');
    }

    // TODO: 实际应用中应该将文件上传到云存储服务
    // 这里暂时返回一个模拟的URL
    const fileUrl = `https://example.com/files/${Date.now()}_${file.originalname}`;

    // 确定消息类型
    let messageType = 'file';
    if (file.mimetype.startsWith('image/')) {
      messageType = 'image';
    } else if (file.mimetype.startsWith('audio/')) {
      messageType = 'voice';
    } else if (file.mimetype.startsWith('video/')) {
      messageType = 'video';
    }

    // 构建文件信息
    const fileInfo = {
      name: file.originalname,
      size: file.size,
      type: file.mimetype,
      url: fileUrl
    };

    // 发送文件消息
    const messageData = {
      receiver_id,
      session_id,
      content: file.originalname,
      type: messageType,
      file_info: fileInfo
    };

    // 这里重用发送消息的逻辑
    req.body = messageData;
    
    // 调用发送消息的处理逻辑
    const senderId = req.user._id;
    let receiverId = receiver_id;
    let sessionId = session_id;

    // 如果没有提供session_id，根据receiver_id创建或获取会话
    if (!sessionId && receiverId) {
      const receiver = await User.findById(receiverId);
      if (!receiver) {
        throw createError.notFound('接收者不存在');
      }

      const isFriend = await Friendship.isFriend(senderId, receiverId);
      if (!isFriend) {
        throw createError.forbidden('只能向好友发送消息');
      }

      const session = await ChatSession.createOrGetPrivateSession(senderId, receiverId);
      sessionId = session._id;
    }

    // 创建消息
    const message = await Message.createMessage({
      sender_id: senderId,
      receiver_id: receiverId,
      session_id: sessionId,
      content: file.originalname,
      type: messageType,
      file_info: fileInfo
    });

    await message.populate('sender_id', 'username profile');

    res.status(201).json({
      success: true,
      message: '文件上传成功',
      data: {
        message: message,
        file_url: fileUrl
      }
    });
  })
);

/**
 * 获取最近消息
 * GET /api/messages/recent
 */
router.get('/recent', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;
  const { limit = 10 } = req.query;

  const recentMessages = await Message.getRecentMessages(userId, parseInt(limit));

  res.json({
    success: true,
    data: {
      messages: recentMessages
    }
  });
}));

/**
 * 删除消息（软删除）
 * DELETE /api/messages/:messageId
 */
router.delete('/:messageId',
  authenticateToken,
  validateObjectId('messageId'),
  catchAsync(async (req, res) => {
    const { messageId } = req.params;
    const userId = req.user._id;

    // 查找消息
    const message = await Message.findById(messageId);
    if (!message) {
      throw createError.notFound('消息不存在');
    }

    // 检查权限（发送者和接收者都可以删除）
    const canDelete = message.sender_id.toString() === userId.toString() ||
                     (message.receiver_id && message.receiver_id.toString() === userId.toString());

    if (!canDelete) {
      throw createError.forbidden('无权删除此消息');
    }

    // 软删除消息
    message.status = 'deleted';
    await message.save();

    res.json({
      success: true,
      message: '消息已删除'
    });
  })
);

/**
 * 获取消息详情
 * GET /api/messages/:messageId
 */
router.get('/:messageId',
  authenticateToken,
  validateObjectId('messageId'),
  catchAsync(async (req, res) => {
    const { messageId } = req.params;
    const userId = req.user._id;

    // 查找消息
    const message = await Message.findById(messageId)
      .populate('sender_id', 'username profile')
      .populate('receiver_id', 'username profile')
      .populate('reply_to', 'sender_id content type created_at')
      .populate('reply_to.sender_id', 'username profile');

    if (!message) {
      throw createError.notFound('消息不存在');
    }

    // 检查权限
    const canView = message.sender_id._id.toString() === userId.toString() ||
                   (message.receiver_id && message.receiver_id._id.toString() === userId.toString());

    if (!canView) {
      throw createError.forbidden('无权查看此消息');
    }

    res.json({
      success: true,
      data: {
        message: message
      }
    });
  })
);

export default router;