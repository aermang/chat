/**
 * 聊天会话路由
 * 处理聊天会话管理、群聊创建等操作
 */

import express from 'express';
import { ChatSession, User, Friendship, Message } from '../models/index.js';
import {
  authenticateToken,
  validatePagination,
  validateObjectId,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

/**
 * 获取用户的聊天会话列表
 * GET /api/sessions
 */
router.get('/', authenticateToken, validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20, type } = req.query;
  const userId = req.user._id;

  const options = {
    page: parseInt(page),
    limit: parseInt(limit),
    type
  };

  const result = await ChatSession.getUserSessions(userId, options);

  res.json({
    success: true,
    data: {
      sessions: result.sessions,
      pagination: result.pagination
    }
  });
}));

/**
 * 获取或创建私聊会话
 * POST /api/sessions/private
 */
router.post('/private', 
  authenticateToken, 
  validateObjectId('user_id', 'body'),
  catchAsync(async (req, res) => {
    const currentUserId = req.user._id;
    const { user_id } = req.body;

    if (currentUserId.toString() === user_id) {
      throw createError.validation('不能与自己创建私聊会话');
    }

    // 检查目标用户是否存在
    const targetUser = await User.findById(user_id);
    if (!targetUser) {
      throw createError.notFound('用户不存在');
    }

    // 检查是否为好友
    const isFriend = await Friendship.isFriend(currentUserId, user_id);
    if (!isFriend) {
      throw createError.forbidden('只能与好友创建私聊会话');
    }

    // 创建或获取私聊会话
    const session = await ChatSession.createOrGetPrivateSession(currentUserId, user_id);

    // 填充参与者信息
    await session.populate('participants', 'username profile is_online last_seen_at');

    res.json({
      success: true,
      data: {
        session: session
      }
    });
  })
);

/**
 * 创建群聊会话
 * POST /api/sessions/group
 */
router.post('/group', authenticateToken, catchAsync(async (req, res) => {
  const creatorId = req.user._id;
  const { name, description, participant_ids = [] } = req.body;

  if (!name || name.trim().length === 0) {
    throw createError.validation('群聊名称不能为空');
  }

  if (name.length > 50) {
    throw createError.validation('群聊名称不能超过50个字符');
  }

  if (participant_ids.length === 0) {
    throw createError.validation('至少需要添加一个群成员');
  }

  if (participant_ids.length > 200) {
    throw createError.validation('群成员数量不能超过200人');
  }

  // 验证所有参与者都存在且为好友
  const participants = await User.find({
    _id: { $in: participant_ids },
    status: 'active'
  });

  if (participants.length !== participant_ids.length) {
    throw createError.validation('部分用户不存在或已被禁用');
  }

  // 检查是否都是好友
  for (const participantId of participant_ids) {
    const isFriend = await Friendship.isFriend(creatorId, participantId);
    if (!isFriend) {
      const user = participants.find(p => p._id.toString() === participantId);
      throw createError.forbidden(`${user.username} 不是您的好友`);
    }
  }

  // 创建群聊会话
  const sessionData = {
    name: name.trim(),
    description: description ? description.trim() : '',
    participant_ids: [...participant_ids, creatorId], // 包含创建者
    creator_id: creatorId
  };

  const session = await ChatSession.createGroupSession(sessionData);

  // 填充参与者信息
  await session.populate('participants', 'username profile is_online last_seen_at');
  await session.populate('creator_id', 'username profile');

  res.status(201).json({
    success: true,
    message: '群聊创建成功',
    data: {
      session: session
    }
  });
}));

/**
 * 获取会话详情
 * GET /api/sessions/:sessionId
 */
router.get('/:sessionId',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;

    // 查找会话
    const session = await ChatSession.findById(sessionId)
      .populate('participants', 'username profile is_online last_seen_at')
      .populate('creator_id', 'username profile')
      .populate('admins', 'username profile');

    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p._id.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    res.json({
      success: true,
      data: {
        session: session
      }
    });
  })
);

/**
 * 更新会话信息
 * PUT /api/sessions/:sessionId
 */
router.put('/:sessionId',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;
    const { name, description, avatar_url } = req.body;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查权限（只有群主和管理员可以修改群聊信息）
    if (session.type === 'group') {
      const isCreator = session.creator_id && session.creator_id.toString() === userId.toString();
      const isAdmin = session.admins && session.admins.some(admin => admin.toString() === userId.toString());
      
      if (!isCreator && !isAdmin) {
        throw createError.forbidden('只有群主和管理员可以修改群聊信息');
      }
    } else {
      throw createError.forbidden('私聊会话信息不能修改');
    }

    // 更新会话信息
    const updates = {};
    if (name !== undefined) {
      if (!name || name.trim().length === 0) {
        throw createError.validation('群聊名称不能为空');
      }
      if (name.length > 50) {
        throw createError.validation('群聊名称不能超过50个字符');
      }
      updates.name = name.trim();
    }

    if (description !== undefined) {
      if (description && description.length > 200) {
        throw createError.validation('群聊描述不能超过200个字符');
      }
      updates.description = description ? description.trim() : '';
    }

    if (avatar_url !== undefined) {
      updates.avatar_url = avatar_url;
    }

    // 执行更新
    const updatedSession = await ChatSession.findByIdAndUpdate(
      sessionId,
      { $set: updates },
      { new: true, runValidators: true }
    ).populate('participants', 'username profile is_online last_seen_at')
     .populate('creator_id', 'username profile')
     .populate('admins', 'username profile');

    res.json({
      success: true,
      message: '会话信息更新成功',
      data: {
        session: updatedSession
      }
    });
  })
);

/**
 * 添加会话参与者
 * POST /api/sessions/:sessionId/participants
 */
router.post('/:sessionId/participants',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;
    const { user_ids } = req.body;

    if (!Array.isArray(user_ids) || user_ids.length === 0) {
      throw createError.validation('用户ID列表不能为空');
    }

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 只有群聊可以添加参与者
    if (session.type !== 'group') {
      throw createError.forbidden('只有群聊可以添加参与者');
    }

    // 检查权限（只有群主和管理员可以添加成员）
    const isCreator = session.creator_id && session.creator_id.toString() === userId.toString();
    const isAdmin = session.admins && session.admins.some(admin => admin.toString() === userId.toString());
    
    if (!isCreator && !isAdmin) {
      throw createError.forbidden('只有群主和管理员可以添加群成员');
    }

    // 验证要添加的用户
    const usersToAdd = await User.find({
      _id: { $in: user_ids },
      status: 'active'
    });

    if (usersToAdd.length !== user_ids.length) {
      throw createError.validation('部分用户不存在或已被禁用');
    }

    // 检查群成员数量限制
    const newMemberCount = session.participants.length + user_ids.length;
    if (newMemberCount > 200) {
      throw createError.validation('群成员数量不能超过200人');
    }

    // 添加参与者
    const result = await session.addParticipants(user_ids);

    res.json({
      success: true,
      message: `成功添加 ${result.addedCount} 个群成员`,
      data: {
        added_count: result.addedCount,
        already_exists: result.alreadyExists
      }
    });
  })
);

/**
 * 移除会话参与者
 * DELETE /api/sessions/:sessionId/participants/:userId
 */
router.delete('/:sessionId/participants/:userId',
  authenticateToken,
  validateObjectId('sessionId'),
  validateObjectId('userId'),
  catchAsync(async (req, res) => {
    const { sessionId, userId: targetUserId } = req.params;
    const currentUserId = req.user._id;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 只有群聊可以移除参与者
    if (session.type !== 'group') {
      throw createError.forbidden('只有群聊可以移除参与者');
    }

    // 检查权限
    const isCreator = session.creator_id && session.creator_id.toString() === currentUserId.toString();
    const isAdmin = session.admins && session.admins.some(admin => admin.toString() === currentUserId.toString());
    const isSelf = currentUserId.toString() === targetUserId;

    // 群主和管理员可以移除其他成员，普通成员只能退出群聊
    if (!isCreator && !isAdmin && !isSelf) {
      throw createError.forbidden('只有群主和管理员可以移除群成员');
    }

    // 群主不能被移除（除非是自己退出）
    if (session.creator_id && session.creator_id.toString() === targetUserId && !isSelf) {
      throw createError.forbidden('不能移除群主');
    }

    // 移除参与者
    await session.removeParticipant(targetUserId);

    const message = isSelf ? '已退出群聊' : '群成员已被移除';

    res.json({
      success: true,
      message: message
    });
  })
);

/**
 * 设置会话置顶状态
 * PUT /api/sessions/:sessionId/pin
 */
router.put('/:sessionId/pin',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;
    const { is_pinned } = req.body;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 更新置顶状态
    await session.updateUserSettings(userId, { is_pinned: Boolean(is_pinned) });

    res.json({
      success: true,
      message: is_pinned ? '会话已置顶' : '会话已取消置顶'
    });
  })
);

/**
 * 设置会话免打扰状态
 * PUT /api/sessions/:sessionId/mute
 */
router.put('/:sessionId/mute',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;
    const { is_muted } = req.body;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 更新免打扰状态
    await session.updateUserSettings(userId, { is_muted: Boolean(is_muted) });

    res.json({
      success: true,
      message: is_muted ? '已开启免打扰' : '已关闭免打扰'
    });
  })
);

/**
 * 清空会话消息
 * DELETE /api/sessions/:sessionId/messages
 */
router.delete('/:sessionId/messages',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 软删除会话中的所有消息（只对当前用户生效）
    const result = await Message.updateMany(
      { 
        session_id: sessionId,
        $or: [
          { sender_id: userId },
          { receiver_id: userId }
        ]
      },
      { 
        $set: { 
          status: 'deleted',
          [`deleted_by.${userId}`]: new Date()
        }
      }
    );

    // 重置会话的未读数量
    await session.resetUnreadCount(userId);

    res.json({
      success: true,
      message: '聊天记录已清空',
      data: {
        deleted_count: result.modifiedCount
      }
    });
  })
);

/**
 * 删除会话
 * DELETE /api/sessions/:sessionId
 */
router.delete('/:sessionId',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    if (session.type === 'private') {
      // 私聊：只是从用户的会话列表中隐藏
      session.participants = session.participants.filter(p => p.toString() !== userId.toString());
      if (session.participants.length === 0) {
        // 如果没有参与者了，标记为非活跃
        session.is_active = false;
      }
      await session.save();
    } else {
      // 群聊：检查是否为群主
      const isCreator = session.creator_id && session.creator_id.toString() === userId.toString();
      
      if (isCreator) {
        // 群主解散群聊
        session.is_active = false;
        await session.save();
      } else {
        // 普通成员退出群聊
        await session.removeParticipant(userId);
      }
    }

    const message = session.type === 'group' && session.creator_id && session.creator_id.toString() === userId.toString()
      ? '群聊已解散'
      : '已退出会话';

    res.json({
      success: true,
      message: message
    });
  })
);

/**
 * 获取会话统计信息
 * GET /api/sessions/:sessionId/stats
 */
router.get('/:sessionId/stats',
  authenticateToken,
  validateObjectId('sessionId'),
  catchAsync(async (req, res) => {
    const { sessionId } = req.params;
    const userId = req.user._id;

    // 查找会话
    const session = await ChatSession.findById(sessionId);
    if (!session) {
      throw createError.notFound('聊天会话不存在');
    }

    // 检查用户是否为参与者
    const isParticipant = session.participants.some(p => p.toString() === userId.toString());
    if (!isParticipant) {
      throw createError.forbidden('您不是此会话的参与者');
    }

    // 获取统计信息
    const stats = {
      participant_count: session.participants.length,
      message_count: await Message.countDocuments({ 
        session_id: sessionId, 
        status: { $ne: 'deleted' } 
      }),
      unread_count: await Message.countDocuments({
        session_id: sessionId,
        receiver_id: userId,
        is_read: false,
        is_recalled: false,
        status: { $ne: 'deleted' }
      }),
      created_at: session.created_at,
      last_message_at: session.last_message_at
    };

    res.json({
      success: true,
      data: {
        stats: stats
      }
    });
  })
);

export default router;