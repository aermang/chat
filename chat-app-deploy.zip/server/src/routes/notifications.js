/**
 * 通知路由
 * 处理系统通知、消息通知等操作
 */

import express from 'express';
import { Notification } from '../models/index.js';
import {
  authenticateToken,
  validatePagination,
  validateObjectId,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

/**
 * 获取用户通知列表
 * GET /api/notifications
 */
router.get('/', authenticateToken, validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20, type, is_read } = req.query;
  const userId = req.user._id;

  const options = {
    page: parseInt(page),
    limit: parseInt(limit),
    type,
    is_read: is_read !== undefined ? is_read === 'true' : undefined
  };

  const result = await Notification.getUserNotifications(userId, options);

  res.json({
    success: true,
    data: {
      notifications: result.notifications,
      pagination: result.pagination
    }
  });
}));

/**
 * 获取未读通知数量
 * GET /api/notifications/unread-count
 */
router.get('/unread-count', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  const unreadCount = await Notification.getUnreadCount(userId);

  res.json({
    success: true,
    data: {
      unread_count: unreadCount
    }
  });
}));

/**
 * 获取各类型未读通知数量
 * GET /api/notifications/unread-count-by-type
 */
router.get('/unread-count-by-type', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  // 获取各类型未读通知数量
  const counts = await Notification.aggregate([
    {
      $match: {
        receiver_id: userId,
        is_read: false,
        is_deleted: false,
        $or: [
          { expires_at: null },
          { expires_at: { $gt: new Date() } }
        ]
      }
    },
    {
      $group: {
        _id: '$type',
        count: { $sum: 1 }
      }
    }
  ]);

  // 格式化结果
  const countsByType = {};
  counts.forEach(item => {
    countsByType[item._id] = item.count;
  });

  // 确保所有类型都有值
  const allTypes = ['friend_request', 'message', 'moment_like', 'moment_comment', 'system'];
  allTypes.forEach(type => {
    if (!countsByType[type]) {
      countsByType[type] = 0;
    }
  });

  res.json({
    success: true,
    data: {
      counts_by_type: countsByType,
      total_unread: Object.values(countsByType).reduce((sum, count) => sum + count, 0)
    }
  });
}));

/**
 * 标记通知为已读
 * PUT /api/notifications/:notificationId/read
 */
router.put('/:notificationId/read',
  authenticateToken,
  validateObjectId('notificationId'),
  catchAsync(async (req, res) => {
    const { notificationId } = req.params;
    const userId = req.user._id;

    // 查找通知
    const notification = await Notification.findById(notificationId);
    if (!notification) {
      throw createError.notFound('通知不存在');
    }

    // 检查权限
    if (notification.receiver_id.toString() !== userId.toString()) {
      throw createError.forbidden('无权操作此通知');
    }

    // 标记为已读
    await notification.markAsRead();

    res.json({
      success: true,
      message: '通知已标记为已读'
    });
  })
);

/**
 * 批量标记通知为已读
 * PUT /api/notifications/mark-read
 */
router.put('/mark-read', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;
  const { notification_ids, type } = req.body;

  let query = { receiver_id: userId, is_read: false };

  if (notification_ids && Array.isArray(notification_ids)) {
    // 标记指定通知为已读
    query._id = { $in: notification_ids };
  } else if (type) {
    // 标记指定类型的所有通知为已读
    query.type = type;
  }
  // 如果都没有提供，则标记所有未读通知为已读

  const result = await Notification.markAllAsRead(userId, query);

  res.json({
    success: true,
    message: `已标记 ${result.modifiedCount} 个通知为已读`
  });
}));

/**
 * 删除通知
 * DELETE /api/notifications/:notificationId
 */
router.delete('/:notificationId',
  authenticateToken,
  validateObjectId('notificationId'),
  catchAsync(async (req, res) => {
    const { notificationId } = req.params;
    const userId = req.user._id;

    // 查找通知
    const notification = await Notification.findById(notificationId);
    if (!notification) {
      throw createError.notFound('通知不存在');
    }

    // 检查权限
    if (notification.receiver_id.toString() !== userId.toString()) {
      throw createError.forbidden('无权删除此通知');
    }

    // 软删除通知
    await notification.softDelete();

    res.json({
      success: true,
      message: '通知已删除'
    });
  })
);

/**
 * 批量删除通知
 * DELETE /api/notifications
 */
router.delete('/', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;
  const { notification_ids, type, is_read } = req.body;

  let query = { receiver_id: userId };

  if (notification_ids && Array.isArray(notification_ids)) {
    // 删除指定通知
    query._id = { $in: notification_ids };
  } else {
    // 根据条件批量删除
    if (type) {
      query.type = type;
    }
    if (is_read !== undefined) {
      query.is_read = is_read;
    }
  }

  const result = await Notification.batchDelete(userId, query);

  res.json({
    success: true,
    message: `已删除 ${result.modifiedCount} 个通知`
  });
}));

/**
 * 清空已读通知
 * DELETE /api/notifications/read
 */
router.delete('/read', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  const result = await Notification.clearReadNotifications(userId);

  res.json({
    success: true,
    message: `已清空 ${result.deletedCount} 个已读通知`
  });
}));

/**
 * 获取通知详情
 * GET /api/notifications/:notificationId
 */
router.get('/:notificationId',
  authenticateToken,
  validateObjectId('notificationId'),
  catchAsync(async (req, res) => {
    const { notificationId } = req.params;
    const userId = req.user._id;

    // 查找通知
    const notification = await Notification.findById(notificationId)
      .populate('sender_id', 'username profile')
      .populate('receiver_id', 'username profile');

    if (!notification) {
      throw createError.notFound('通知不存在');
    }

    // 检查权限
    if (notification.receiver_id._id.toString() !== userId.toString()) {
      throw createError.forbidden('无权查看此通知');
    }

    // 如果未读，自动标记为已读
    if (!notification.is_read) {
      await notification.markAsRead();
    }

    res.json({
      success: true,
      data: {
        notification: notification
      }
    });
  })
);

/**
 * 创建系统通知（管理员功能）
 * POST /api/notifications/system
 */
router.post('/system', authenticateToken, catchAsync(async (req, res) => {
  const senderId = req.user._id;
  const { 
    receiver_ids, 
    title, 
    content, 
    action_url, 
    priority = 'normal',
    expires_at 
  } = req.body;

  // 简单的权限检查（实际应用中应该有更严格的管理员权限验证）
  // 这里假设只有特定用户可以发送系统通知
  // TODO: 实现管理员权限验证

  if (!Array.isArray(receiver_ids) || receiver_ids.length === 0) {
    throw createError.validation('接收者列表不能为空');
  }

  if (!title || title.trim().length === 0) {
    throw createError.validation('通知标题不能为空');
  }

  if (!content || content.trim().length === 0) {
    throw createError.validation('通知内容不能为空');
  }

  // 批量创建通知
  const notifications = receiver_ids.map(receiverId => ({
    receiver_id: receiverId,
    sender_id: senderId,
    type: 'system',
    title: title.trim(),
    content: content.trim(),
    action_url,
    priority,
    expires_at: expires_at ? new Date(expires_at) : null
  }));

  const result = await Notification.batchCreate(notifications);

  res.status(201).json({
    success: true,
    message: `成功创建 ${result.length} 个系统通知`,
    data: {
      created_count: result.length
    }
  });
}));

/**
 * 获取通知统计信息
 * GET /api/notifications/stats
 */
router.get('/stats', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  // 获取各种统计信息
  const [
    totalCount,
    unreadCount,
    todayCount,
    weekCount
  ] = await Promise.all([
    // 总通知数
    Notification.countDocuments({
      receiver_id: userId,
      is_deleted: false
    }),
    // 未读通知数
    Notification.countDocuments({
      receiver_id: userId,
      is_read: false,
      is_deleted: false,
      $or: [
        { expires_at: null },
        { expires_at: { $gt: new Date() } }
      ]
    }),
    // 今日通知数
    Notification.countDocuments({
      receiver_id: userId,
      is_deleted: false,
      created_at: {
        $gte: new Date(new Date().setHours(0, 0, 0, 0))
      }
    }),
    // 本周通知数
    Notification.countDocuments({
      receiver_id: userId,
      is_deleted: false,
      created_at: {
        $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      }
    })
  ]);

  res.json({
    success: true,
    data: {
      stats: {
        total_count: totalCount,
        unread_count: unreadCount,
        today_count: todayCount,
        week_count: weekCount,
        read_rate: totalCount > 0 ? ((totalCount - unreadCount) / totalCount * 100).toFixed(1) : 0
      }
    }
  });
}));

/**
 * 更新通知推送状态（内部API）
 * PUT /api/notifications/:notificationId/push-status
 */
router.put('/:notificationId/push-status',
  authenticateToken,
  validateObjectId('notificationId'),
  catchAsync(async (req, res) => {
    const { notificationId } = req.params;
    const { push_status, push_error } = req.body;

    // 查找通知
    const notification = await Notification.findById(notificationId);
    if (!notification) {
      throw createError.notFound('通知不存在');
    }

    // 更新推送状态
    await notification.markPushSent(push_status, push_error);

    res.json({
      success: true,
      message: '推送状态更新成功'
    });
  })
);

/**
 * 获取待推送通知列表（内部API）
 * GET /api/notifications/pending-push
 */
router.get('/pending-push', catchAsync(async (req, res) => {
  const { limit = 100 } = req.query;

  const notifications = await Notification.getPendingPushNotifications(parseInt(limit));

  res.json({
    success: true,
    data: {
      notifications: notifications,
      count: notifications.length
    }
  });
}));

export default router;