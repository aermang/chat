/**
 * 好友路由
 * 处理好友关系管理、好友申请等操作
 */

import express from 'express';
import { User, Friendship, FriendRequest, Notification } from '../models/index.js';
import {
  authenticateToken,
  validateFriendRequest,
  validatePagination,
  validateObjectId,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

/**
 * 获取好友列表
 * GET /api/friends
 */
router.get('/', authenticateToken, validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20, group, search } = req.query;
  const userId = req.user._id;
  const skip = (page - 1) * limit;

  // 构建查询条件
  const query = { user_id: userId };
  if (group) {
    query.group_tag = group;
  }

  // 获取好友关系
  let friendships = await Friendship.find(query)
    .populate('friend_id', 'username profile email is_online last_seen_at')
    .sort({ is_pinned: -1, created_at: -1 })
    .skip(skip)
    .limit(parseInt(limit));

  // 如果有搜索条件，过滤结果
  if (search) {
    friendships = friendships.filter(friendship => {
      const friend = friendship.friend_id;
      const nickname = friendship.remark_name || friend.profile.nickname || friend.username;
      return nickname.toLowerCase().includes(search.toLowerCase()) ||
             friend.username.toLowerCase().includes(search.toLowerCase());
    });
  }

  // 获取总数
  const total = await Friendship.countDocuments(query);

  // 格式化返回数据
  const friends = friendships.map(friendship => ({
    friendship_id: friendship._id,
    user: friendship.friend_id.getPublicInfo(),
    remark_name: friendship.remark_name,
    group_tag: friendship.group_tag,
    is_pinned: friendship.is_pinned,
    is_muted: friendship.is_muted,
    created_at: friendship.created_at
  }));

  res.json({
    success: true,
    data: {
      friends,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: total,
        total_pages: Math.ceil(total / limit),
        has_more: skip + friendships.length < total
      }
    }
  });
}));

/**
 * 搜索好友
 * GET /api/friends/search
 */
router.get('/search', authenticateToken, catchAsync(async (req, res) => {
  const { q: query, limit = 10 } = req.query;
  const userId = req.user._id;

  if (!query || query.trim().length === 0) {
    return res.json({
      success: true,
      data: { friends: [] }
    });
  }

  // 获取好友列表
  const friendships = await Friendship.find({ user_id: userId })
    .populate('friend_id', 'username profile email is_online last_seen_at')
    .limit(parseInt(limit));

  // 搜索匹配的好友
  const matchedFriends = friendships.filter(friendship => {
    const friend = friendship.friend_id;
    const nickname = friendship.remark_name || friend.profile.nickname || friend.username;
    return nickname.toLowerCase().includes(query.toLowerCase()) ||
           friend.username.toLowerCase().includes(query.toLowerCase());
  }).map(friendship => ({
    friendship_id: friendship._id,
    user: friendship.friend_id.getPublicInfo(),
    remark_name: friendship.remark_name,
    group_tag: friendship.group_tag,
    is_pinned: friendship.is_pinned,
    is_muted: friendship.is_muted
  }));

  res.json({
    success: true,
    data: {
      friends: matchedFriends
    }
  });
}));

/**
 * 检查好友关系
 * GET /api/friends/check/:userId
 */
router.get('/check/:userId', 
  authenticateToken, 
  validateObjectId('userId'), 
  catchAsync(async (req, res) => {
    const currentUserId = req.user._id;
    const { userId } = req.params;

    if (currentUserId.toString() === userId) {
      throw createError.validation('不能检查与自己的好友关系');
    }

    // 检查是否为好友
    const isFriend = await Friendship.isFriend(currentUserId, userId);

    res.json({
      success: true,
      data: {
        is_friend: isFriend
      }
    });
  })
);

/**
 * 发送好友申请
 * POST /api/friends/request
 */
router.post('/request', 
  authenticateToken, 
  validateFriendRequest, 
  catchAsync(async (req, res) => {
    const senderId = req.user._id;
    const { receiver_id, message } = req.body;

    // 检查接收者是否存在
    const receiver = await User.findById(receiver_id);
    if (!receiver) {
      throw createError.notFound('用户');
    }

    // 检查是否已经是好友
    const isFriend = await Friendship.isFriend(senderId, receiver_id);
    if (isFriend) {
      throw createError.conflict('已经是好友关系');
    }

    // 检查是否已有待处理的申请
    const existingRequest = await FriendRequest.hasPendingRequest(senderId, receiver_id);
    if (existingRequest) {
      throw createError.conflict('已有待处理的好友申请');
    }

    // 创建好友申请
    const friendRequest = await FriendRequest.createRequest(senderId, receiver_id, message);

    // 创建通知
    await Notification.createFriendRequestNotification(receiver_id, senderId, friendRequest._id);

    res.status(201).json({
      success: true,
      message: '好友申请已发送',
      data: {
        request: friendRequest
      }
    });
  })
);

/**
 * 获取好友申请列表
 * GET /api/friends/requests
 */
router.get('/requests', authenticateToken, validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20, type = 'received' } = req.query;
  const userId = req.user._id;
  const skip = (page - 1) * limit;

  // 构建查询条件
  const query = type === 'sent' 
    ? { sender_id: userId }
    : { receiver_id: userId };

  // 获取好友申请
  const requests = await FriendRequest.find(query)
    .populate('sender_id', 'username profile')
    .populate('receiver_id', 'username profile')
    .sort({ created_at: -1 })
    .skip(skip)
    .limit(parseInt(limit));

  // 获取总数
  const total = await FriendRequest.countDocuments(query);

  // 格式化返回数据
  const formattedRequests = requests.map(request => ({
    request_id: request._id,
    sender: request.sender_id.getPublicInfo(),
    receiver: request.receiver_id.getPublicInfo(),
    message: request.message,
    status: request.status,
    is_read: request.is_read,
    created_at: request.created_at,
    processed_at: request.processed_at,
    reject_reason: request.reject_reason
  }));

  res.json({
    success: true,
    data: {
      requests: formattedRequests,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: total,
        total_pages: Math.ceil(total / limit),
        has_more: skip + requests.length < total
      }
    }
  });
}));

/**
 * 处理好友申请
 * PUT /api/friends/requests/:requestId
 */
router.put('/requests/:requestId',
  authenticateToken,
  validateObjectId('requestId'),
  catchAsync(async (req, res) => {
    const { requestId } = req.params;
    const { action, reject_reason } = req.body;
    const userId = req.user._id;

    if (!['accept', 'reject'].includes(action)) {
      throw createError.validation('操作类型必须是 accept 或 reject');
    }

    // 查找好友申请
    const friendRequest = await FriendRequest.findById(requestId)
      .populate('sender_id', 'username profile')
      .populate('receiver_id', 'username profile');

    if (!friendRequest) {
      throw createError.notFound('好友申请');
    }

    // 检查权限（只有接收者可以处理申请）
    if (friendRequest.receiver_id._id.toString() !== userId.toString()) {
      throw createError.forbidden('无权处理此好友申请');
    }

    // 检查申请状态
    if (friendRequest.status !== 'pending') {
      throw createError.conflict('该申请已被处理');
    }

    // 处理好友申请
    const result = await friendRequest.process(action, reject_reason);

    // 如果接受申请，创建好友关系
    if (action === 'accept') {
      await Friendship.createFriendship(
        friendRequest.sender_id._id,
        friendRequest.receiver_id._id
      );
    }

    res.json({
      success: true,
      message: action === 'accept' ? '已接受好友申请' : '已拒绝好友申请',
      data: {
        request: result
      }
    });
  })
);

/**
 * 标记好友申请为已读
 * PUT /api/friends/requests/:requestId/read
 */
router.put('/requests/:requestId/read',
  authenticateToken,
  validateObjectId('requestId'),
  catchAsync(async (req, res) => {
    const { requestId } = req.params;
    const userId = req.user._id;

    // 查找好友申请
    const friendRequest = await FriendRequest.findById(requestId);
    if (!friendRequest) {
      throw createError.notFound('好友申请');
    }

    // 检查权限
    if (friendRequest.receiver_id.toString() !== userId.toString()) {
      throw createError.forbidden('无权操作此好友申请');
    }

    // 标记为已读
    await friendRequest.markAsRead();

    res.json({
      success: true,
      message: '已标记为已读'
    });
  })
);

/**
 * 获取未读好友申请数量
 * GET /api/friends/requests/unread-count
 */
router.get('/requests/unread-count', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  const unreadCount = await FriendRequest.getUnreadCount(userId);

  res.json({
    success: true,
    data: {
      unread_count: unreadCount
    }
  });
}));

/**
 * 删除好友
 * DELETE /api/friends/:friendId
 */
router.delete('/:friendId',
  authenticateToken,
  validateObjectId('friendId'),
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { friendId } = req.params;

    // 检查是否为好友
    const isFriend = await Friendship.isFriend(userId, friendId);
    if (!isFriend) {
      throw createError.notFound('好友关系不存在');
    }

    // 删除好友关系
    await Friendship.removeFriendship(userId, friendId);

    res.json({
      success: true,
      message: '已删除好友'
    });
  })
);

/**
 * 更新好友备注
 * PUT /api/friends/:friendId/remark
 */
router.put('/:friendId/remark',
  authenticateToken,
  validateObjectId('friendId'),
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { friendId } = req.params;
    const { remark_name } = req.body;

    if (remark_name && remark_name.length > 20) {
      throw createError.validation('备注名称不能超过20个字符');
    }

    // 查找好友关系
    const friendship = await Friendship.findOne({
      user_id: userId,
      friend_id: friendId
    });

    if (!friendship) {
      throw createError.notFound('好友关系不存在');
    }

    // 更新备注
    await friendship.updateRemark(remark_name);

    res.json({
      success: true,
      message: '备注更新成功',
      data: {
        remark_name: friendship.remark_name
      }
    });
  })
);

/**
 * 切换好友置顶状态
 * PUT /api/friends/:friendId/pin
 */
router.put('/:friendId/pin',
  authenticateToken,
  validateObjectId('friendId'),
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { friendId } = req.params;

    // 查找好友关系
    const friendship = await Friendship.findOne({
      user_id: userId,
      friend_id: friendId
    });

    if (!friendship) {
      throw createError.notFound('好友关系不存在');
    }

    // 切换置顶状态
    await friendship.togglePin();

    res.json({
      success: true,
      message: friendship.is_pinned ? '已置顶' : '已取消置顶',
      data: {
        is_pinned: friendship.is_pinned
      }
    });
  })
);

/**
 * 切换好友免打扰状态
 * PUT /api/friends/:friendId/mute
 */
router.put('/:friendId/mute',
  authenticateToken,
  validateObjectId('friendId'),
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { friendId } = req.params;

    // 查找好友关系
    const friendship = await Friendship.findOne({
      user_id: userId,
      friend_id: friendId
    });

    if (!friendship) {
      throw createError.notFound('好友关系不存在');
    }

    // 切换免打扰状态
    friendship.is_muted = !friendship.is_muted;
    await friendship.save();

    res.json({
      success: true,
      message: friendship.is_muted ? '已开启免打扰' : '已关闭免打扰',
      data: {
        is_muted: friendship.is_muted
      }
    });
  })
);

/**
 * 设置好友分组
 * PUT /api/friends/:friendId/group
 */
router.put('/:friendId/group',
  authenticateToken,
  validateObjectId('friendId'),
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { friendId } = req.params;
    const { group_tag } = req.body;

    if (group_tag && group_tag.length > 10) {
      throw createError.validation('分组标签不能超过10个字符');
    }

    // 查找好友关系
    const friendship = await Friendship.findOne({
      user_id: userId,
      friend_id: friendId
    });

    if (!friendship) {
      throw createError.notFound('好友关系不存在');
    }

    // 更新分组
    friendship.group_tag = group_tag || '';
    await friendship.save();

    res.json({
      success: true,
      message: '分组设置成功',
      data: {
        group_tag: friendship.group_tag
      }
    });
  })
);

/**
 * 获取好友分组列表
 * GET /api/friends/groups
 */
router.get('/groups', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;

  // 获取所有分组
  const groups = await Friendship.aggregate([
    { $match: { user_id: userId, group_tag: { $ne: '' } } },
    { $group: { _id: '$group_tag', count: { $sum: 1 } } },
    { $sort: { _id: 1 } }
  ]);

  const formattedGroups = groups.map(group => ({
    name: group._id,
    count: group.count
  }));

  res.json({
    success: true,
    data: {
      groups: formattedGroups
    }
  });
}));

/**
 * 批量标记好友申请为已读
 * PUT /api/friends/requests/mark-read
 */
router.put('/requests/mark-read', authenticateToken, catchAsync(async (req, res) => {
  const userId = req.user._id;
  const { request_ids } = req.body;

  if (!Array.isArray(request_ids) || request_ids.length === 0) {
    throw createError.validation('请求ID列表不能为空');
  }

  // 批量标记为已读
  const result = await FriendRequest.markMultipleAsRead(userId, request_ids);

  res.json({
    success: true,
    message: `已标记 ${result.modifiedCount} 个申请为已读`
  });
}));

export default router;