/**
 * 朋友圈路由
 * 处理朋友圈动态发布、查看、点赞、评论等操作
 */

import express from 'express';
import multer from 'multer';
import { Moment, Like, Comment, User, Friendship } from '../models/index.js';
import {
  authenticateToken,
  optionalAuth,
  validateMomentCreate,
  validateCommentCreate,
  validatePagination,
  validateObjectId,
  validateFileUpload,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

// 配置文件上传
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB per file
  }
});

/**
 * 发布朋友圈动态
 * POST /api/moments
 */
router.post('/', 
  authenticateToken, 
  validateMomentCreate, 
  catchAsync(async (req, res) => {
    const userId = req.user._id;
    const { content, images, location, visibility = 'friends', allow_comment = true, tags } = req.body;

    // 创建动态
    const momentData = {
      user_id: userId,
      content: content ? content.trim() : '',
      images: images || [],
      location,
      visibility,
      allow_comment,
      tags: tags || []
    };

    const moment = await Moment.create(momentData);

    // 填充用户信息
    await moment.populate('user_id', 'username profile');

    res.status(201).json({
      success: true,
      message: '动态发布成功',
      data: {
        moment: moment
      }
    });
  })
);

/**
 * 上传朋友圈图片
 * POST /api/moments/upload-images
 */
router.post('/upload-images',
  authenticateToken,
  upload.array('images', 9), // 最多9张图片
  validateFileUpload(['image/jpeg', 'image/png', 'image/gif'], 5 * 1024 * 1024),
  catchAsync(async (req, res) => {
    const files = req.files;

    if (!files || files.length === 0) {
      throw createError.validation('请选择要上传的图片');
    }

    if (files.length > 9) {
      throw createError.validation('最多只能上传9张图片');
    }

    // TODO: 实际应用中应该将文件上传到云存储服务
    // 这里暂时返回模拟的URL
    const imageUrls = files.map((file, index) => ({
      url: `https://example.com/moments/${Date.now()}_${index}.${file.mimetype.split('/')[1]}`,
      width: 800, // 模拟图片尺寸
      height: 600
    }));

    res.json({
      success: true,
      message: '图片上传成功',
      data: {
        images: imageUrls
      }
    });
  })
);

/**
 * 获取朋友圈时间线
 * GET /api/moments/timeline
 */
router.get('/timeline', authenticateToken, validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const userId = req.user._id;

  const options = {
    page: parseInt(page),
    limit: parseInt(limit)
  };

  const result = await Moment.getTimeline(userId, options);

  res.json({
    success: true,
    data: {
      moments: result.moments,
      pagination: result.pagination
    }
  });
}));

/**
 * 获取用户的朋友圈动态
 * GET /api/moments/user/:userId
 */
router.get('/user/:userId',
  optionalAuth,
  validateObjectId('userId'),
  validatePagination,
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const currentUserId = req.user?._id;

    // 检查用户是否存在
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户不存在');
    }

    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      viewer_id: currentUserId
    };

    const result = await Moment.getUserMoments(userId, options);

    res.json({
      success: true,
      data: {
        user: user.getPublicInfo(),
        moments: result.moments,
        pagination: result.pagination
      }
    });
  })
);

/**
 * 获取动态详情
 * GET /api/moments/:momentId
 */
router.get('/:momentId',
  optionalAuth,
  validateObjectId('momentId'),
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const currentUserId = req.user?._id;

    // 查找动态
    const moment = await Moment.findById(momentId)
      .populate('user_id', 'username profile');

    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查可见性
    const canView = await moment.checkVisibility(currentUserId);
    if (!canView) {
      throw createError.forbidden('无权查看此动态');
    }

    // 增加浏览数
    if (currentUserId && currentUserId.toString() !== moment.user_id._id.toString()) {
      await moment.incrementViewCount();
    }

    // 获取点赞和评论信息
    const [isLiked, likes, comments] = await Promise.all([
      currentUserId ? Like.exists({ moment_id: momentId, user_id: currentUserId }) : false,
      Like.find({ moment_id: momentId })
        .populate('user_id', 'username profile')
        .sort({ created_at: -1 })
        .limit(10),
      Comment.find({ moment_id: momentId, is_deleted: false })
        .populate('user_id', 'username profile')
        .populate('reply_to_user', 'username profile')
        .sort({ created_at: 1 })
        .limit(20)
    ]);

    res.json({
      success: true,
      data: {
        moment: {
          ...moment.toObject(),
          is_liked: Boolean(isLiked),
          recent_likes: likes,
          recent_comments: comments
        }
      }
    });
  })
);

/**
 * 点赞/取消点赞动态
 * POST /api/moments/:momentId/like
 */
router.post('/:momentId/like',
  authenticateToken,
  validateObjectId('momentId'),
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const userId = req.user._id;

    // 检查动态是否存在
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查可见性
    const canView = await moment.checkVisibility(userId);
    if (!canView) {
      throw createError.forbidden('无权操作此动态');
    }

    // 切换点赞状态
    const result = await Like.toggleLike(momentId, userId);

    res.json({
      success: true,
      message: result.isLiked ? '点赞成功' : '取消点赞成功',
      data: {
        is_liked: result.isLiked,
        like_count: result.likeCount
      }
    });
  })
);

/**
 * 获取动态点赞列表
 * GET /api/moments/:momentId/likes
 */
router.get('/:momentId/likes',
  optionalAuth,
  validateObjectId('momentId'),
  validatePagination,
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const currentUserId = req.user?._id;
    const skip = (page - 1) * limit;

    // 检查动态是否存在
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查可见性
    const canView = await moment.checkVisibility(currentUserId);
    if (!canView) {
      throw createError.forbidden('无权查看此动态');
    }

    // 获取点赞列表
    const likes = await Like.getMomentLikes(momentId, {
      limit: parseInt(limit),
      skip: skip
    });

    // 获取总数
    const total = await Like.countDocuments({ moment_id: momentId });

    res.json({
      success: true,
      data: {
        likes: likes,
        pagination: {
          current_page: parseInt(page),
          per_page: parseInt(limit),
          total: total,
          total_pages: Math.ceil(total / limit),
          has_more: skip + likes.length < total
        }
      }
    });
  })
);

/**
 * 评论动态
 * POST /api/moments/:momentId/comments
 */
router.post('/:momentId/comments',
  authenticateToken,
  validateObjectId('momentId'),
  validateCommentCreate,
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const userId = req.user._id;
    const { content, reply_to_comment, reply_to_user } = req.body;

    // 检查动态是否存在
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查可见性
    const canView = await moment.checkVisibility(userId);
    if (!canView) {
      throw createError.forbidden('无权评论此动态');
    }

    // 检查是否允许评论
    if (!moment.allow_comment) {
      throw createError.forbidden('此动态不允许评论');
    }

    // 验证回复信息
    if (reply_to_comment) {
      const parentComment = await Comment.findById(reply_to_comment);
      if (!parentComment || parentComment.moment_id.toString() !== momentId) {
        throw createError.validation('回复的评论不存在或不属于此动态');
      }
    }

    if (reply_to_user) {
      const replyUser = await User.findById(reply_to_user);
      if (!replyUser) {
        throw createError.validation('回复的用户不存在');
      }
    }

    // 创建评论
    const commentData = {
      moment_id: momentId,
      user_id: userId,
      content: content.trim(),
      reply_to_comment,
      reply_to_user,
      type: reply_to_comment ? 'reply' : 'comment'
    };

    const comment = await Comment.createComment(commentData);

    // 填充用户信息
    await comment.populate('user_id', 'username profile');
    if (comment.reply_to_user) {
      await comment.populate('reply_to_user', 'username profile');
    }

    res.status(201).json({
      success: true,
      message: '评论成功',
      data: {
        comment: comment
      }
    });
  })
);

/**
 * 获取动态评论列表
 * GET /api/moments/:momentId/comments
 */
router.get('/:momentId/comments',
  optionalAuth,
  validateObjectId('momentId'),
  validatePagination,
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const currentUserId = req.user?._id;

    // 检查动态是否存在
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查可见性
    const canView = await moment.checkVisibility(currentUserId);
    if (!canView) {
      throw createError.forbidden('无权查看此动态');
    }

    const options = {
      page: parseInt(page),
      limit: parseInt(limit)
    };

    const result = await Comment.getMomentComments(momentId, options);

    res.json({
      success: true,
      data: {
        comments: result.comments,
        pagination: result.pagination
      }
    });
  })
);

/**
 * 删除评论
 * DELETE /api/moments/comments/:commentId
 */
router.delete('/comments/:commentId',
  authenticateToken,
  validateObjectId('commentId'),
  catchAsync(async (req, res) => {
    const { commentId } = req.params;
    const userId = req.user._id;

    // 查找评论
    const comment = await Comment.findById(commentId);
    if (!comment) {
      throw createError.notFound('评论不存在');
    }

    // 检查权限（只有评论作者和动态作者可以删除）
    const moment = await Moment.findById(comment.moment_id);
    const canDelete = comment.user_id.toString() === userId.toString() ||
                     (moment && moment.user_id.toString() === userId.toString());

    if (!canDelete) {
      throw createError.forbidden('无权删除此评论');
    }

    // 删除评论
    await comment.deleteComment();

    res.json({
      success: true,
      message: '评论已删除'
    });
  })
);

/**
 * 删除动态
 * DELETE /api/moments/:momentId
 */
router.delete('/:momentId',
  authenticateToken,
  validateObjectId('momentId'),
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const userId = req.user._id;

    // 查找动态
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查权限（只有作者可以删除）
    if (moment.user_id.toString() !== userId.toString()) {
      throw createError.forbidden('只能删除自己的动态');
    }

    // 软删除动态
    moment.is_deleted = true;
    await moment.save();

    res.json({
      success: true,
      message: '动态已删除'
    });
  })
);

/**
 * 搜索动态
 * GET /api/moments/search
 */
router.get('/search', authenticateToken, catchAsync(async (req, res) => {
  const { q: query, page = 1, limit = 20 } = req.query;
  const userId = req.user._id;

  if (!query || query.trim().length === 0) {
    return res.json({
      success: true,
      data: { moments: [], pagination: { total: 0 } }
    });
  }

  const options = {
    query: query.trim(),
    user_id: userId,
    page: parseInt(page),
    limit: parseInt(limit)
  };

  const result = await Moment.searchMoments(options);

  res.json({
    success: true,
    data: {
      moments: result.moments,
      pagination: result.pagination
    }
  });
}));

/**
 * 获取热门动态
 * GET /api/moments/trending
 */
router.get('/trending', validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20, days = 7 } = req.query;

  const options = {
    page: parseInt(page),
    limit: parseInt(limit),
    days: parseInt(days)
  };

  const result = await Moment.getTrendingMoments(options);

  res.json({
    success: true,
    data: {
      moments: result.moments,
      pagination: result.pagination
    }
  });
}));

/**
 * 获取用户动态统计
 * GET /api/moments/user/:userId/stats
 */
router.get('/user/:userId/stats',
  optionalAuth,
  validateObjectId('userId'),
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const currentUserId = req.user?._id;

    // 检查用户是否存在
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户不存在');
    }

    // 获取统计信息
    const stats = await Moment.getUserStats(userId, currentUserId);

    res.json({
      success: true,
      data: {
        stats: stats
      }
    });
  })
);

/**
 * 更新动态
 * PUT /api/moments/:momentId
 */
router.put('/:momentId',
  authenticateToken,
  validateObjectId('momentId'),
  catchAsync(async (req, res) => {
    const { momentId } = req.params;
    const userId = req.user._id;
    const { content, visibility, allow_comment, tags } = req.body;

    // 查找动态
    const moment = await Moment.findById(momentId);
    if (!moment) {
      throw createError.notFound('动态不存在');
    }

    // 检查权限（只有作者可以编辑）
    if (moment.user_id.toString() !== userId.toString()) {
      throw createError.forbidden('只能编辑自己的动态');
    }

    // 更新动态
    const updates = {};
    if (content !== undefined) {
      if (!content && (!moment.images || moment.images.length === 0)) {
        throw createError.validation('动态内容和图片不能同时为空');
      }
      updates.content = content ? content.trim() : '';
    }

    if (visibility !== undefined) {
      if (!['public', 'friends', 'private'].includes(visibility)) {
        throw createError.validation('可见性设置无效');
      }
      updates.visibility = visibility;
    }

    if (allow_comment !== undefined) {
      updates.allow_comment = Boolean(allow_comment);
    }

    if (tags !== undefined) {
      if (Array.isArray(tags) && tags.length <= 10) {
        updates.tags = tags.filter(tag => tag && tag.trim().length > 0).slice(0, 10);
      }
    }

    // 执行更新
    const updatedMoment = await Moment.findByIdAndUpdate(
      momentId,
      { $set: updates },
      { new: true, runValidators: true }
    ).populate('user_id', 'username profile');

    res.json({
      success: true,
      message: '动态更新成功',
      data: {
        moment: updatedMoment
      }
    });
  })
);

export default router;