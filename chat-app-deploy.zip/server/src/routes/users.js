/**
 * 用户路由
 * 处理用户信息管理、搜索、设置等操作
 */

import express from 'express';
import multer from 'multer';
import { User } from '../models/index.js';
import {
  authenticateToken,
  optionalAuth,
  requireOwnerOrAdmin,
  validateProfileUpdate,
  validatePasswordChange,
  validatePagination,
  validateSearch,
  validateFileUpload,
  catchAsync,
  createError
} from '../middleware/index.js';

const router = express.Router();

// 配置文件上传
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB
  }
});

/**
 * 获取用户信息
 * GET /api/users/:userId
 */
router.get('/:userId', optionalAuth, catchAsync(async (req, res) => {
  const { userId } = req.params;
  const currentUser = req.user;

  // 查找用户
  const user = await User.findById(userId).select('-password');
  if (!user) {
    throw createError.notFound('用户');
  }

  // 获取用户公开信息
  let userInfo = user.getPublicInfo();

  // 如果是当前用户，返回完整信息
  if (currentUser && currentUser._id.toString() === userId) {
    userInfo = {
      ...userInfo,
      email: user.email,
      email_verified: user.email_verified,
      settings: user.settings,
      created_at: user.created_at,
      updated_at: user.updated_at
    };
  }

  res.json({
    success: true,
    data: {
      user: userInfo
    }
  });
}));

/**
 * 更新用户资料
 * PUT /api/users/:userId/profile
 */
router.put('/:userId/profile', 
  authenticateToken, 
  requireOwnerOrAdmin('userId'),
  validateProfileUpdate, 
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const updateData = req.body;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // 更新用户资料
    const allowedFields = ['nickname', 'bio', 'avatar_url', 'settings'];
    const updates = {};

    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        if (field === 'settings') {
          // 合并设置对象
          updates[field] = { ...user.settings, ...updateData[field] };
        } else if (field === 'nickname' || field === 'bio' || field === 'avatar_url') {
          // 更新profile字段
          updates[`profile.${field}`] = updateData[field];
        } else {
          updates[field] = updateData[field];
        }
      }
    });

    // 执行更新
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { $set: updates },
      { new: true, runValidators: true }
    ).select('-password');

    res.json({
      success: true,
      message: '资料更新成功',
      data: {
        user: updatedUser.getPublicInfo()
      }
    });
  })
);

/**
 * 修改密码
 * PUT /api/users/:userId/password
 */
router.put('/:userId/password',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  validatePasswordChange,
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const { current_password, new_password } = req.body;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // 验证当前密码
    const isCurrentPasswordValid = await user.comparePassword(current_password);
    if (!isCurrentPasswordValid) {
      throw createError.auth('当前密码错误');
    }

    // 更新密码
    user.password = new_password;
    await user.save();

    res.json({
      success: true,
      message: '密码修改成功'
    });
  })
);

/**
 * 上传头像
 * POST /api/users/:userId/avatar
 */
router.post('/:userId/avatar',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  upload.single('avatar'),
  validateFileUpload(['image/jpeg', 'image/png', 'image/gif'], 2 * 1024 * 1024),
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const file = req.file;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // TODO: 实际应用中应该将文件上传到云存储服务
    // 这里暂时返回一个模拟的URL
    const avatarUrl = `https://example.com/avatars/${userId}_${Date.now()}.${file.mimetype.split('/')[1]}`;

    // 更新用户头像
    user.profile.avatar_url = avatarUrl;
    await user.save();

    res.json({
      success: true,
      message: '头像上传成功',
      data: {
        avatar_url: avatarUrl
      }
    });
  })
);

/**
 * 搜索用户
 * GET /api/users/search
 */
router.get('/search', validateSearch, validatePagination, catchAsync(async (req, res) => {
  const { q: query, page = 1, limit = 20 } = req.query;
  const skip = (page - 1) * limit;

  // 搜索用户
  const users = await User.searchUsers(query, {
    limit: parseInt(limit),
    skip: skip
  });

  // 获取总数
  const total = await User.countDocuments({
    $or: [
      { username: new RegExp(query, 'i') },
      { 'profile.nickname': new RegExp(query, 'i') },
      { email: new RegExp(query, 'i') }
    ],
    status: 'active'
  });

  res.json({
    success: true,
    data: {
      users: users.map(user => user.getPublicInfo()),
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: total,
        total_pages: Math.ceil(total / limit),
        has_more: skip + users.length < total
      }
    }
  });
}));

/**
 * 获取在线用户列表
 * GET /api/users/online
 */
router.get('/online', validatePagination, catchAsync(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const skip = (page - 1) * limit;

  // 获取在线用户
  const users = await User.find({
    is_online: true,
    status: 'active'
  })
  .select('-password')
  .sort({ last_seen_at: -1 })
  .skip(skip)
  .limit(parseInt(limit));

  // 获取在线用户总数
  const onlineCount = await User.getOnlineUsersCount();

  res.json({
    success: true,
    data: {
      users: users.map(user => user.getPublicInfo()),
      online_count: onlineCount,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: onlineCount,
        total_pages: Math.ceil(onlineCount / limit),
        has_more: skip + users.length < onlineCount
      }
    }
  });
}));

/**
 * 获取用户统计信息
 * GET /api/users/:userId/stats
 */
router.get('/:userId/stats', optionalAuth, catchAsync(async (req, res) => {
  const { userId } = req.params;
  const currentUser = req.user;

  // 查找用户
  const user = await User.findById(userId);
  if (!user) {
    throw createError.notFound('用户');
  }

  // 基础统计信息
  const stats = {
    join_date: user.created_at,
    last_seen: user.last_seen_at,
    is_online: user.is_online
  };

  // 如果是当前用户或好友，显示更多统计信息
  if (currentUser && (currentUser._id.toString() === userId)) {
    // TODO: 添加更多统计信息，如好友数量、动态数量等
    // 这些需要在实现相关功能后添加
    stats.friends_count = 0; // 占位符
    stats.moments_count = 0; // 占位符
    stats.messages_count = 0; // 占位符
  }

  res.json({
    success: true,
    data: {
      stats
    }
  });
}));

/**
 * 更新用户在线状态
 * PUT /api/users/:userId/online-status
 */
router.put('/:userId/online-status',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const { is_online } = req.body;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // 更新在线状态
    await user.updateOnlineStatus(is_online);

    res.json({
      success: true,
      message: '在线状态更新成功',
      data: {
        is_online: user.is_online,
        last_seen_at: user.last_seen_at
      }
    });
  })
);

/**
 * 获取用户设置
 * GET /api/users/:userId/settings
 */
router.get('/:userId/settings',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  catchAsync(async (req, res) => {
    const { userId } = req.params;

    // 查找用户
    const user = await User.findById(userId).select('settings');
    if (!user) {
      throw createError.notFound('用户');
    }

    res.json({
      success: true,
      data: {
        settings: user.settings
      }
    });
  })
);

/**
 * 更新用户设置
 * PUT /api/users/:userId/settings
 */
router.put('/:userId/settings',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  catchAsync(async (req, res) => {
    const { userId } = req.params;
    const newSettings = req.body;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // 验证设置字段
    const allowedSettings = ['theme', 'language', 'notifications'];
    const validSettings = {};

    Object.keys(newSettings).forEach(key => {
      if (allowedSettings.includes(key)) {
        validSettings[key] = newSettings[key];
      }
    });

    // 更新设置
    user.settings = { ...user.settings, ...validSettings };
    await user.save();

    res.json({
      success: true,
      message: '设置更新成功',
      data: {
        settings: user.settings
      }
    });
  })
);

/**
 * 删除用户账户（软删除）
 * DELETE /api/users/:userId
 */
router.delete('/:userId',
  authenticateToken,
  requireOwnerOrAdmin('userId'),
  catchAsync(async (req, res) => {
    const { userId } = req.params;

    // 查找用户
    const user = await User.findById(userId);
    if (!user) {
      throw createError.notFound('用户');
    }

    // 软删除用户（更改状态为disabled）
    user.status = 'disabled';
    user.is_online = false;
    await user.save();

    res.json({
      success: true,
      message: '账户已删除'
    });
  })
);

/**
 * 批量获取用户信息
 * POST /api/users/batch
 */
router.post('/batch', catchAsync(async (req, res) => {
  const { user_ids } = req.body;

  if (!Array.isArray(user_ids) || user_ids.length === 0) {
    throw createError.validation('用户ID列表不能为空');
  }

  if (user_ids.length > 100) {
    throw createError.validation('一次最多查询100个用户');
  }

  // 查找用户
  const users = await User.find({
    _id: { $in: user_ids },
    status: 'active'
  }).select('-password');

  res.json({
    success: true,
    data: {
      users: users.map(user => user.getPublicInfo())
    }
  });
}));

export default router;