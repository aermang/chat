# 聊天应用后端服务器

基于 Node.js + Express + MongoDB + Socket.io 构建的实时聊天应用后端服务。

## 功能特性

- 🔐 **用户认证**: JWT Token 认证系统
- 💬 **实时通信**: Socket.io 实现的 WebSocket 通信
- 👥 **好友系统**: 好友申请、管理、分组功能
- 📱 **消息系统**: 私聊、群聊、消息撤回、已读状态
- 🌟 **朋友圈**: 动态发布、点赞、评论功能
- 🔔 **通知系统**: 实时通知推送
- 📁 **文件上传**: 支持图片、视频等文件上传
- 🛡️ **安全防护**: 数据验证、XSS防护、速率限制
- 📊 **数据统计**: 用户活跃度、消息统计等

## 技术栈

- **运行环境**: Node.js 18+
- **Web框架**: Express.js
- **数据库**: MongoDB + Mongoose
- **实时通信**: Socket.io
- **认证**: JWT (JSON Web Tokens)
- **密码加密**: bcryptjs
- **文件上传**: Multer
- **数据验证**: express-validator
- **安全中间件**: helmet, cors, xss-clean 等

## 项目结构

```
server/
├── src/
│   ├── models/          # 数据模型
│   │   ├── User.js      # 用户模型
│   │   ├── Message.js   # 消息模型
│   │   ├── Friendship.js # 好友关系模型
│   │   └── ...
│   ├── routes/          # API路由
│   │   ├── auth.js      # 认证路由
│   │   ├── users.js     # 用户路由
│   │   ├── messages.js  # 消息路由
│   │   └── ...
│   ├── middleware/      # 中间件
│   │   ├── auth.js      # 认证中间件
│   │   ├── validation.js # 数据验证中间件
│   │   └── errorHandler.js # 错误处理中间件
│   ├── socket/          # Socket.io处理器
│   │   ├── index.js     # Socket.io主配置
│   │   ├── messageHandler.js # 消息处理器
│   │   └── ...
│   ├── utils/           # 工具函数
│   │   ├── jwt.js       # JWT工具
│   │   └── ...
│   ├── app.js           # Express应用配置
│   └── server.js        # 服务器启动文件
├── scripts/             # 脚本文件
│   └── seedDatabase.js  # 数据库种子数据
├── uploads/             # 文件上传目录
├── logs/                # 日志文件目录
├── .env                 # 环境变量配置
├── .env.example         # 环境变量示例
├── package.json         # 项目依赖配置
└── README.md           # 项目说明文档
```

## 快速开始

### 1. 环境要求

- Node.js 18.0.0 或更高版本
- MongoDB 4.4 或更高版本
- npm 8.0.0 或更高版本

### 2. 安装依赖

```bash
cd server
npm install
```

### 3. 环境配置

复制环境变量示例文件并配置：

```bash
cp .env.example .env
```

编辑 `.env` 文件，配置以下关键参数：

```env
# 数据库连接
MONGODB_URI=mongodb://localhost:27017/chat_app

# JWT密钥（生产环境请使用强密钥）
JWT_SECRET=your-super-secret-jwt-key
JWT_REFRESH_SECRET=your-super-secret-refresh-key

# 服务器端口
PORT=5000

# 客户端URL（用于CORS）
CLIENT_URL=http://localhost:3000
```

### 4. 启动MongoDB

确保MongoDB服务正在运行：

```bash
# Windows
net start MongoDB

# macOS (使用Homebrew)
brew services start mongodb-community

# Linux (使用systemd)
sudo systemctl start mongod
```

### 5. 初始化数据库

运行种子数据脚本创建测试数据：

```bash
npm run db:seed
```

### 6. 启动服务器

开发模式（自动重启）：
```bash
npm run dev
```

生产模式：
```bash
npm start
```

服务器启动后，你将看到以下信息：
```
🚀 服务器运行在端口 5000
📱 API地址: http://localhost:5000/api
🔌 Socket.io地址: http://localhost:5000
🏥 健康检查: http://localhost:5000/health
```

## API 文档

### 认证相关

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/auth/register` | 用户注册 |
| POST | `/api/auth/login` | 用户登录 |
| POST | `/api/auth/refresh` | 刷新Token |
| POST | `/api/auth/logout` | 用户登出 |
| POST | `/api/auth/forgot-password` | 忘记密码 |
| POST | `/api/auth/reset-password` | 重置密码 |

### 用户相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/users/profile` | 获取用户资料 |
| PUT | `/api/users/profile` | 更新用户资料 |
| POST | `/api/users/avatar` | 上传头像 |
| GET | `/api/users/search` | 搜索用户 |

### 好友相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/friends` | 获取好友列表 |
| POST | `/api/friends/request` | 发送好友申请 |
| PUT | `/api/friends/request/:id` | 处理好友申请 |
| DELETE | `/api/friends/:id` | 删除好友 |

### 消息相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/messages/:sessionId` | 获取聊天记录 |
| POST | `/api/messages` | 发送消息 |
| PUT | `/api/messages/:id/read` | 标记消息已读 |
| DELETE | `/api/messages/:id` | 撤回消息 |

### 朋友圈相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/moments` | 获取朋友圈动态 |
| POST | `/api/moments` | 发布动态 |
| POST | `/api/moments/:id/like` | 点赞动态 |
| POST | `/api/moments/:id/comment` | 评论动态 |

## Socket.io 事件

### 连接事件

- `connection` - 用户连接
- `disconnect` - 用户断开连接
- `ping` / `pong` - 心跳检测

### 消息事件

- `send_message` - 发送消息
- `new_message` - 接收新消息
- `message_read` - 消息已读
- `typing_start` / `typing_stop` - 输入状态

### 好友事件

- `send_friend_request` - 发送好友申请
- `friend_request_accepted` - 好友申请被接受
- `friend_online` / `friend_offline` - 好友上线/离线

### 通知事件

- `new_notification` - 新通知
- `notification_read` - 通知已读

## 测试

运行测试：
```bash
npm test
```

运行测试并生成覆盖率报告：
```bash
npm run test:coverage
```

监听模式运行测试：
```bash
npm run test:watch
```

## 代码质量

检查代码规范：
```bash
npm run lint
```

自动修复代码规范问题：
```bash
npm run lint:fix
```

格式化代码：
```bash
npm run format
```

运行所有检查：
```bash
npm run check
```

## 部署

### 生产环境配置

1. 设置环境变量：
```env
NODE_ENV=production
MONGODB_URI=mongodb://your-production-db/chat_app
JWT_SECRET=your-production-jwt-secret
```

2. 安装生产依赖：
```bash
npm ci --only=production
```

3. 启动服务：
```bash
npm start
```

### Docker 部署

创建 `Dockerfile`：
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

构建和运行：
```bash
docker build -t chat-app-server .
docker run -p 5000:5000 chat-app-server
```

## 监控和日志

- 应用日志存储在 `logs/` 目录
- 健康检查端点: `GET /health`
- 错误监控和性能指标可通过中间件集成

## 安全注意事项

- 生产环境必须使用强JWT密钥
- 启用HTTPS
- 配置防火墙规则
- 定期更新依赖包
- 监控异常访问

## 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 支持

如果你遇到问题或有建议，请：

1. 查看 [Issues](https://github.com/your-repo/issues) 页面
2. 创建新的 Issue
3. 联系开发团队

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 基础聊天功能
- 用户认证系统
- 好友管理
- 朋友圈功能