/**
 * 数据库种子数据脚本
 * 用于初始化测试数据
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { User, Friendship, ChatSession, Message, Moment, Like, Comment } from '../src/models/index.js';

// 加载环境变量
dotenv.config();

/**
 * 连接数据库
 */
async function connectDatabase() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/chat_app';
    await mongoose.connect(mongoUri);
    console.log('✅ 数据库连接成功');
  } catch (error) {
    console.error('❌ 数据库连接失败:', error);
    process.exit(1);
  }
}

/**
 * 清理现有数据
 */
async function clearDatabase() {
  try {
    await User.deleteMany({});
    await Friendship.deleteMany({});
    await ChatSession.deleteMany({});
    await Message.deleteMany({});
    await Moment.deleteMany({});
    await Like.deleteMany({});
    await Comment.deleteMany({});
    console.log('✅ 数据库清理完成');
  } catch (error) {
    console.error('❌ 数据库清理失败:', error);
    throw error;
  }
}

/**
 * 创建测试用户
 */
async function createUsers() {
  try {
    const users = [
      {
        username: 'admin',
        email: 'admin@chatapp.com',
        password: await bcrypt.hash('admin123', 12),
        role: 'admin',
        profile: {
          nickname: '管理员',
          avatar: '',
          bio: '系统管理员账户',
          gender: 'other',
          birthday: new Date('1990-01-01'),
          location: '系统'
        },
        is_verified: true,
        is_online: false
      },
      {
        username: 'alice',
        email: 'alice@example.com',
        password: await bcrypt.hash('password123', 12),
        profile: {
          nickname: 'Alice',
          avatar: '',
          bio: '喜欢编程和音乐',
          gender: 'female',
          birthday: new Date('1995-03-15'),
          location: '北京'
        },
        is_verified: true,
        is_online: false
      },
      {
        username: 'bob',
        email: 'bob@example.com',
        password: await bcrypt.hash('password123', 12),
        profile: {
          nickname: 'Bob',
          avatar: '',
          bio: '热爱运动和旅行',
          gender: 'male',
          birthday: new Date('1992-07-20'),
          location: '上海'
        },
        is_verified: true,
        is_online: false
      },
      {
        username: 'charlie',
        email: 'charlie@example.com',
        password: await bcrypt.hash('password123', 12),
        profile: {
          nickname: 'Charlie',
          avatar: '',
          bio: '设计师，喜欢创意和艺术',
          gender: 'male',
          birthday: new Date('1988-11-10'),
          location: '深圳'
        },
        is_verified: true,
        is_online: false
      },
      {
        username: 'diana',
        email: 'diana@example.com',
        password: await bcrypt.hash('password123', 12),
        profile: {
          nickname: 'Diana',
          avatar: '',
          bio: '摄影爱好者',
          gender: 'female',
          birthday: new Date('1993-05-25'),
          location: '广州'
        },
        is_verified: true,
        is_online: false
      }
    ];

    const createdUsers = await User.insertMany(users);
    console.log(`✅ 创建了 ${createdUsers.length} 个测试用户`);
    return createdUsers;
  } catch (error) {
    console.error('❌ 创建用户失败:', error);
    throw error;
  }
}

/**
 * 创建好友关系
 */
async function createFriendships(users) {
  try {
    const friendships = [];
    
    // Alice和Bob是好友
    friendships.push(
      { user_id: users[1]._id, friend_id: users[2]._id, remark: 'Bob同学' },
      { user_id: users[2]._id, friend_id: users[1]._id, remark: 'Alice' }
    );
    
    // Alice和Charlie是好友
    friendships.push(
      { user_id: users[1]._id, friend_id: users[3]._id, remark: 'Charlie设计师' },
      { user_id: users[3]._id, friend_id: users[1]._id, remark: 'Alice程序员' }
    );
    
    // Bob和Diana是好友
    friendships.push(
      { user_id: users[2]._id, friend_id: users[4]._id, remark: 'Diana摄影师' },
      { user_id: users[4]._id, friend_id: users[2]._id, remark: 'Bob运动达人' }
    );

    await Friendship.insertMany(friendships);
    console.log(`✅ 创建了 ${friendships.length} 个好友关系`);
  } catch (error) {
    console.error('❌ 创建好友关系失败:', error);
    throw error;
  }
}

/**
 * 创建聊天会话
 */
async function createChatSessions(users) {
  try {
    const sessions = [
      {
        session_type: 'private',
        participants: [users[1]._id, users[2]._id], // Alice和Bob
        session_name: '',
        created_by: users[1]._id,
        participants_info: [
          { user_id: users[1]._id, joined_at: new Date(), unread_count: 0 },
          { user_id: users[2]._id, joined_at: new Date(), unread_count: 0 }
        ]
      },
      {
        session_type: 'group',
        participants: [users[1]._id, users[2]._id, users[3]._id], // Alice、Bob、Charlie
        session_name: '技术交流群',
        description: '讨论技术问题的群聊',
        created_by: users[1]._id,
        participants_info: [
          { user_id: users[1]._id, joined_at: new Date(), unread_count: 0 },
          { user_id: users[2]._id, joined_at: new Date(), unread_count: 0 },
          { user_id: users[3]._id, joined_at: new Date(), unread_count: 0 }
        ]
      }
    ];

    const createdSessions = await ChatSession.insertMany(sessions);
    console.log(`✅ 创建了 ${createdSessions.length} 个聊天会话`);
    return createdSessions;
  } catch (error) {
    console.error('❌ 创建聊天会话失败:', error);
    throw error;
  }
}

/**
 * 创建测试消息
 */
async function createMessages(users, sessions) {
  try {
    const messages = [
      {
        session_id: sessions[0]._id,
        sender_id: users[1]._id, // Alice
        content: '嗨，Bob！最近怎么样？',
        message_type: 'text'
      },
      {
        session_id: sessions[0]._id,
        sender_id: users[2]._id, // Bob
        content: '很好！刚完成了一个新项目，你呢？',
        message_type: 'text'
      },
      {
        session_id: sessions[1]._id,
        sender_id: users[1]._id, // Alice
        content: '欢迎大家加入技术交流群！',
        message_type: 'text'
      },
      {
        session_id: sessions[1]._id,
        sender_id: users[3]._id, // Charlie
        content: '谢谢邀请！很高兴能和大家一起交流',
        message_type: 'text'
      }
    ];

    await Message.insertMany(messages);
    
    // 更新会话的最后消息信息
    for (const session of sessions) {
      const lastMessage = messages.filter(m => m.session_id.equals(session._id)).pop();
      if (lastMessage) {
        await ChatSession.findByIdAndUpdate(session._id, {
          last_message_at: new Date(),
          updated_at: new Date()
        });
      }
    }

    console.log(`✅ 创建了 ${messages.length} 条测试消息`);
  } catch (error) {
    console.error('❌ 创建消息失败:', error);
    throw error;
  }
}

/**
 * 创建朋友圈动态
 */
async function createMoments(users) {
  try {
    const moments = [
      {
        user_id: users[1]._id, // Alice
        content: '今天学习了新的编程技术，感觉很有收获！ #编程 #学习',
        images: [],
        visibility: 'public'
      },
      {
        user_id: users[2]._id, // Bob
        content: '周末去爬山了，风景真美！',
        images: [],
        visibility: 'friends'
      },
      {
        user_id: users[3]._id, // Charlie
        content: '刚完成了一个新的设计作品，大家觉得怎么样？',
        images: [],
        visibility: 'public'
      }
    ];

    const createdMoments = await Moment.insertMany(moments);
    console.log(`✅ 创建了 ${createdMoments.length} 条朋友圈动态`);
    return createdMoments;
  } catch (error) {
    console.error('❌ 创建朋友圈动态失败:', error);
    throw error;
  }
}

/**
 * 创建点赞和评论
 */
async function createLikesAndComments(users, moments) {
  try {
    // 创建点赞
    const likes = [
      {
        user_id: users[2]._id, // Bob
        target_type: 'moment',
        target_id: moments[0]._id // Alice的动态
      },
      {
        user_id: users[3]._id, // Charlie
        target_type: 'moment',
        target_id: moments[0]._id // Alice的动态
      }
    ];

    await Like.insertMany(likes);

    // 创建评论
    const comments = [
      {
        user_id: users[2]._id, // Bob
        target_type: 'moment',
        target_id: moments[0]._id, // Alice的动态
        content: '学习新技术确实很有成就感！'
      },
      {
        user_id: users[1]._id, // Alice
        target_type: 'moment',
        target_id: moments[1]._id, // Bob的动态
        content: '哇，风景真的很美！下次一起去吧'
      }
    ];

    await Comment.insertMany(comments);

    // 更新动态的点赞和评论数
    for (const moment of moments) {
      const likeCount = await Like.countDocuments({
        target_type: 'moment',
        target_id: moment._id
      });
      const commentCount = await Comment.countDocuments({
        target_type: 'moment',
        target_id: moment._id
      });

      await Moment.findByIdAndUpdate(moment._id, {
        like_count: likeCount,
        comment_count: commentCount
      });
    }

    console.log(`✅ 创建了 ${likes.length} 个点赞和 ${comments.length} 条评论`);
  } catch (error) {
    console.error('❌ 创建点赞和评论失败:', error);
    throw error;
  }
}

/**
 * 主函数
 */
async function main() {
  try {
    console.log('🚀 开始初始化数据库种子数据...');
    
    await connectDatabase();
    await clearDatabase();
    
    const users = await createUsers();
    await createFriendships(users);
    
    const sessions = await createChatSessions(users);
    await createMessages(users, sessions);
    
    const moments = await createMoments(users);
    await createLikesAndComments(users, moments);
    
    console.log('✅ 数据库种子数据初始化完成！');
    console.log('\n测试账户信息:');
    console.log('管理员: admin / admin123');
    console.log('用户1: alice / password123');
    console.log('用户2: bob / password123');
    console.log('用户3: charlie / password123');
    console.log('用户4: diana / password123');
    
  } catch (error) {
    console.error('❌ 初始化失败:', error);
  } finally {
    await mongoose.connection.close();
    console.log('数据库连接已关闭');
    process.exit(0);
  }
}

// 运行脚本
main();