# 微信风格即时通讯App - 技术架构文档

## 1. 架构设计

```mermaid
graph TD
    A[用户浏览器] --> B[React前端应用]
    B --> C[IndexedDB本地存储]
    B --> D[WebSocket客户端]
    D --> E[WebSocket服务器]
    E --> F[Supabase数据库]
    E --> G[文件存储服务]

    subgraph "前端层"
        B
        C
    end

    subgraph "后端层（后期升级）"
        E
    end

    subgraph "数据层"
        F
        G
    end
```

## 2. 技术描述

* 前端：React\@18 + TypeScript\@5 + Vite\@5 + Tailwind CSS\@3 + Zustand\@4

* 本地存储：IndexedDB + Dexie.js\@3

* 后端（后期）：Node.js\@20 + Express\@4 + Socket.io\@4

* 数据库（后期）：本地MongoDB数据库

* 测试：Playwright\@1.40 + Vitest\@1.0

## 3. 路由定义

| 路由             | 用途            |
| -------------- | ------------- |
| /              | 首页，检查登录状态并重定向 |
| /login         | 登录页面，用户身份验证   |
| /register      | 注册页面，新用户注册    |
| /main          | 主界面，包含四个标签页   |
| /main/messages | 消息页面，显示聊天列表   |
| /main/contacts | 通讯录页面，显示好友列表  |
| /main/discover | 发现页面，朋友圈入口    |
| /main/profile  | 个人中心页面        |
| /chat/:userId  | 聊天对话页面        |
| /add-friend    | 添加好友页面        |
| /moments       | 朋友圈页面         |
| /settings      | 设置页面          |

## 4. API定义（后期联网版本）

### 4.1 核心API

用户认证相关

```
POST /api/auth/login
```

请求参数：

| 参数名      | 参数类型   | 是否必需 | 描述   |
| -------- | ------ | ---- | ---- |
| email    | string | true | 用户邮箱 |
| password | string | true | 用户密码 |

响应参数：

| 参数名     | 参数类型    | 描述      |
| ------- | ------- | ------- |
| success | boolean | 登录是否成功  |
| token   | string  | JWT认证令牌 |
| user    | object  | 用户信息对象  |

示例：

```json
{
  "email": "user@example.com",
  "password": "123456"
}
```

消息发送相关

```
POST /api/messages/send
```

请求参数：

| 参数名        | 参数类型   | 是否必需 | 描述                     |
| ---------- | ------ | ---- | ---------------------- |
| receiverId | string | true | 接收者ID                  |
| content    | string | true | 消息内容                   |
| type       | string | true | 消息类型（text/image/voice） |

好友管理相关

```
POST /api/friends/add
GET /api/friends/list
DELETE /api/friends/:friendId
```

## 5. 服务器架构图（后期联网版本）

```mermaid
graph TD
    A[客户端/前端] --> B[控制器层]
    B --> C[服务层]
    C --> D[数据访问层]
    D --> E[(Supabase数据库)]
    
    F[WebSocket服务] --> C
    G[文件上传服务] --> H[对象存储]

    subgraph 服务器
        B
        C
        D
        F
        G
    end
```

## 6. 数据模型

### 6.1 数据模型定义

```mermaid
erDiagram
    USERS ||--o{ MESSAGES : sends
    USERS ||--o{ FRIENDSHIPS : has
    USERS ||--o{ MOMENTS : posts
    MOMENTS ||--o{ LIKES : receives
    MOMENTS ||--o{ COMMENTS : has

    USERS {
        uuid id PK
        string email
        string password_hash
        string nickname
        string avatar_url
        timestamp created_at
        timestamp updated_at
        boolean is_online
    }
    
    MESSAGES {
        uuid id PK
        uuid sender_id FK
        uuid receiver_id FK
        string content
        string message_type
        timestamp created_at
        boolean is_read
    }
    
    FRIENDSHIPS {
        uuid id PK
        uuid user_id FK
        uuid friend_id FK
        string status
        timestamp created_at
    }
    
    MOMENTS {
        uuid id PK
        uuid user_id FK
        string content
        string images
        timestamp created_at
        integer likes_count
        integer comments_count
    }
    
    LIKES {
        uuid id PK
        uuid moment_id FK
        uuid user_id FK
        timestamp created_at
    }
    
    COMMENTS {
        uuid id PK
        uuid moment_id FK
        uuid user_id FK
        string content
        timestamp created_at
    }
```

### 6.2 数据定义语言

用户表 (users)

```sql
-- 创建用户表
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    nickname VARCHAR(100) NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_online BOOLEAN DEFAULT false
);

-- 创建索引
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_nickname ON users(nickname);

-- 权限设置
GRANT SELECT ON users TO anon;
GRANT ALL PRIVILEGES ON users TO authenticated;
```

消息表 (messages)

```sql
-- 创建消息表
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID REFERENCES users(id) ON DELETE CASCADE,
    receiver_id UUID REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    message_type VARCHAR(20) DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'voice')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_read BOOLEAN DEFAULT false
);

-- 创建索引
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_receiver ON messages(receiver_id);
CREATE INDEX idx_messages_created_at ON messages(created_at DESC);

-- 权限设置
GRANT SELECT ON messages TO anon;
GRANT ALL PRIVILEGES ON messages TO authenticated;
```

好友关系表 (friendships)

```sql
-- 创建好友关系表
CREATE TABLE friendships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    friend_id UUID REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'blocked')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, friend_id)
);

-- 创建索引
CREATE INDEX idx_friendships_user ON friendships(user_id);
CREATE INDEX idx_friendships_friend ON friendships(friend_id);

-- 权限设置
GRANT SELECT ON friendships TO anon;
GRANT ALL PRIVILEGES ON friendships TO authenticated;
```

朋友圈动态表 (moments)

```sql
-- 创建朋友圈动态表
CREATE TABLE moments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    content TEXT,
    images TEXT[], -- 存储图片URL数组
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0
);

-- 创建索引
CREATE INDEX idx_moments_user ON moments(user_id);
CREATE INDEX idx_moments_created_at ON moments(created_at DESC);

-- 权限设置
GRANT SELECT ON moments TO anon;
GRANT ALL PRIVILEGES ON moments TO authenticated;
```

点赞表 (likes)

```sql
-- 创建点赞表
CREATE TABLE likes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    moment_id UUID REFERENCES moments(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(moment_id, user_id)
);

-- 权限设置
GRANT SELECT ON likes TO anon;
GRANT ALL PRIVILEGES ON likes TO authenticated;
```

评论表 (comments)

```sql
-- 创建评论表
CREATE TABLE comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    moment_id UUID REFERENCES moments(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX idx_comments_moment ON comments(moment_id);
CREATE INDEX idx_comments_created_at ON comments(created_at DESC);

-- 权限设置
GRANT SELECT ON comments TO anon;
GRANT ALL PRIVILEGES ON comments TO authenticated;
```

初始化数据

```sql
-- 插入测试用户
INSERT INTO users (email, password_hash, nickname, avatar_url) VALUES
('demo1@example.com', '$2b$10$hash1', '张三', '/avatars/avatar1.jpg'),
('demo2@example.com', '$2b$10$hash2', '李四', '/avatars/avatar2.jpg'),
('demo3@example.com', '$2b$10$hash3', '王五', '/avatars/avatar3.jpg');

-- 插入测试好友关系
INSERT INTO friendships (user_id, friend_id, status) VALUES
((SELECT id FROM users WHERE email = 'demo1@example.com'), (SELECT id FROM users WHERE email = 'demo2@example.com'), 'accepted'),
((SELECT id FROM users WHERE email = 'demo2@example.com'), (SELECT id FROM users WHERE email = 'demo1@example.com'), 'accepted');

-- 插入测试消息
INSERT INTO messages (sender_id, receiver_id, content, message_type) VALUES
((SELECT id FROM users WHERE email = 'demo1@example.com'), (SELECT id FROM users WHERE email = 'demo2@example.com'), '你好！', 'text'),
((SELECT id FROM users WHERE email = 'demo2@example.com'), (SELECT id FROM users WHERE email = 'demo1@example.com'), '你好，很高兴认识你！', 'text');
```

