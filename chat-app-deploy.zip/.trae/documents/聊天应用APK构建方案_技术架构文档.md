# 聊天应用APK构建方案 - 技术架构文档

## 1. 架构设计

```mermaid
graph TD
    A[Android APK应用] --> B[Capacitor Runtime]
    B --> C[React Frontend]
    C --> D[HTTP/WebSocket Client]
    D --> E[Node.js Backend Server]
    E --> F[MongoDB Database]
    E --> G[Socket.io Server]
    
    subgraph "移动端层"
        A
        B
        H[原生Android插件]
        I[推送服务]
    end
    
    subgraph "前端层"
        C
        J[React Router]
        K[Zustand Store]
        L[Tailwind CSS]
    end
    
    subgraph "后端层"
        E
        G
        M[JWT认证]
        N[文件上传服务]
    end
    
    subgraph "数据层"
        F
        O[Redis缓存]
    end
    
    subgraph "外部服务"
        P[Firebase推送]
        Q[文件存储服务]
    end
    
    B --> H
    A --> I
    I --> P
    E --> O
    N --> Q
```

## 2. 技术描述

- **移动端框架**: Capacitor@5 + Android SDK
- **前端**: React@18 + TypeScript + Vite + Tailwind CSS
- **后端**: Node.js + Express + Socket.io
- **数据库**: MongoDB + Redis
- **构建工具**: Vite + Capacitor CLI + Android Studio
- **推送服务**: Firebase Cloud Messaging (FCM)

## 3. 路由定义

| 路由 | 用途 |
|------|------|
| /login | 登录页面，用户认证和注册 |
| /chat-list | 聊天列表页面，显示所有会话 |
| /chat/:id | 聊天详情页面，具体会话界面 |
| /contacts | 联系人页面，好友列表管理 |
| /moments | 朋友圈页面，社交动态展示 |
| /profile | 个人中心页面，用户信息和设置 |
| /add-friend | 添加好友页面，用户搜索和申请 |
| /settings | 设置页面，应用配置选项 |
| /friend-requests | 好友申请页面，处理好友请求 |

## 4. API定义

### 4.1 核心API

**用户认证相关**
```
POST /api/auth/login
```

请求参数:
| 参数名 | 参数类型 | 是否必需 | 描述 |
|--------|----------|----------|------|
| email | string | true | 用户邮箱 |
| password | string | true | 用户密码 |

响应参数:
| 参数名 | 参数类型 | 描述 |
|--------|----------|------|
| success | boolean | 登录是否成功 |
| token | string | JWT认证令牌 |
| user | object | 用户信息对象 |

**消息发送相关**
```
POST /api/messages/send
```

请求参数:
| 参数名 | 参数类型 | 是否必需 | 描述 |
|--------|----------|----------|------|
| receiverId | string | true | 接收者用户ID |
| content | string | true | 消息内容 |
| type | string | true | 消息类型(text/image/file) |

**文件上传相关**
```
POST /api/upload/file
```

请求参数:
| 参数名 | 参数类型 | 是否必需 | 描述 |
|--------|----------|----------|------|
| file | File | true | 上传的文件对象 |
| type | string | true | 文件类型(image/video/document) |

## 5. Capacitor插件配置

### 5.1 核心插件列表

```json
{
  "@capacitor/core": "^5.0.0",
  "@capacitor/cli": "^5.0.0",
  "@capacitor/android": "^5.0.0",
  "@capacitor/app": "^5.0.0",
  "@capacitor/haptics": "^5.0.0",
  "@capacitor/keyboard": "^5.0.0",
  "@capacitor/status-bar": "^5.0.0",
  "@capacitor/splash-screen": "^5.0.0",
  "@capacitor/camera": "^5.0.0",
  "@capacitor/filesystem": "^5.0.0",
  "@capacitor/push-notifications": "^5.0.0",
  "@capacitor/local-notifications": "^5.0.0",
  "@capacitor/network": "^5.0.0",
  "@capacitor/device": "^5.0.0"
}
```

### 5.2 Capacitor配置文件

```typescript
// capacitor.config.ts
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.chatapp.mobile',
  appName: '聊天应用',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#07C160",
      showSpinner: false
    },
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"]
    },
    Camera: {
      permissions: ["camera", "photos"]
    }
  }
};

export default config;
```

## 6. 数据模型

### 6.1 数据模型定义

```mermaid
erDiagram
    USER ||--o{ MESSAGE : sends
    USER ||--o{ FRIENDSHIP : has
    USER ||--o{ MOMENT : posts
    MESSAGE ||--o{ FILE_ATTACHMENT : contains
    MOMENT ||--o{ LIKE : receives
    MOMENT ||--o{ COMMENT : receives

    USER {
        string id PK
        string email
        string username
        string avatar
        string phone
        datetime createdAt
        datetime lastActive
    }
    
    MESSAGE {
        string id PK
        string senderId FK
        string receiverId FK
        string content
        string type
        boolean isRead
        datetime createdAt
    }
    
    FRIENDSHIP {
        string id PK
        string userId1 FK
        string userId2 FK
        string status
        datetime createdAt
    }
    
    MOMENT {
        string id PK
        string userId FK
        string content
        array images
        datetime createdAt
    }
```

### 6.2 数据定义语言

**用户表 (users)**
```sql
-- 创建用户表
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    avatar VARCHAR(500),
    phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_active TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_phone ON users(phone);
```

**消息表 (messages)**
```sql
-- 创建消息表
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES users(id),
    receiver_id UUID NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    message_type VARCHAR(20) DEFAULT 'text',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_receiver ON messages(receiver_id);
CREATE INDEX idx_messages_created_at ON messages(created_at DESC);
```

**好友关系表 (friendships)**
```sql
-- 创建好友关系表
CREATE TABLE friendships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id1 UUID NOT NULL REFERENCES users(id),
    user_id2 UUID NOT NULL REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id1, user_id2)
);

-- 创建索引
CREATE INDEX idx_friendships_user1 ON friendships(user_id1);
CREATE INDEX idx_friendships_user2 ON friendships(user_id2);
CREATE INDEX idx_friendships_status ON friendships(status);
```

## 7. 构建和部署流程

### 7.1 开发环境配置
1. 安装Android Studio和Android SDK
2. 配置Java开发环境 (JDK 11+)
3. 安装Capacitor CLI工具
4. 配置签名证书

### 7.2 构建步骤
```bash
# 1. 安装依赖
npm install

# 2. 添加Capacitor平台
npx cap add android

# 3. 构建Web应用
npm run build

# 4. 同步到Android项目
npx cap sync android

# 5. 打开Android Studio
npx cap open android

# 6. 在Android Studio中构建APK
```

### 7.3 发布配置
- 配置应用签名证书
- 设置版本号和构建号
- 配置ProGuard代码混淆
- 生成发布版APK文件