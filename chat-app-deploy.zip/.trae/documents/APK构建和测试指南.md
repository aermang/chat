# 聊天应用APK构建和测试指南

## 项目概述

本项目是一个基于React + Capacitor的跨平台聊天应用，支持Web和移动端（Android/iOS）。

## 环境要求

### 开发环境
- Node.js 18+
- npm 或 pnpm
- Android Studio (用于Android开发)
- Xcode (用于iOS开发，仅macOS)

### 系统要求
- Windows 10/11 或 macOS 10.15+
- 至少8GB RAM
- 20GB可用磁盘空间

## 项目结构

```
chat/
├── src/                    # 前端源代码
│   ├── components/         # React组件
│   ├── pages/             # 页面组件
│   ├── services/          # 服务层
│   ├── hooks/             # 自定义Hooks
│   └── styles/            # 样式文件
├── server/                # 后端服务器
│   ├── src/               # 服务器源代码
│   └── .env               # 环境变量配置
├── android/               # Android项目
├── ios/                   # iOS项目
├── dist/                  # 构建输出
└── capacitor.config.ts    # Capacitor配置
```

## 功能特性

### 核心功能
- 用户注册和登录
- 实时聊天消息
- 好友管理
- 群组聊天
- 文件和图片分享
- 消息通知

### 移动端特性
- 相机拍照
- 相册选择
- 文件选择
- 本地通知
- 触觉反馈
- 网络状态检测
- 设备信息获取

## 构建步骤

### 1. 环境准备

#### 安装依赖
```bash
# 安装项目依赖
npm install

# 安装Capacitor CLI（如果未安装）
npm install -g @capacitor/cli
```

#### 配置环境变量
在`server/.env`文件中配置以下变量：
```env
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb://localhost:27017/chatapp
JWT_SECRET=your-jwt-secret-key
JWT_REFRESH_SECRET=your-refresh-secret-key
```

### 2. 前端构建

```bash
# 构建前端应用
npm run build

# 同步到移动端项目
npx cap sync
```

### 3. Android APK构建

#### 方法一：使用Android Studio（推荐）
1. 打开Android Studio
2. 选择"Open an existing Android Studio project"
3. 选择项目中的`android`文件夹
4. 等待项目同步完成
5. 点击菜单栏 Build → Build Bundle(s) / APK(s) → Build APK(s)
6. 构建完成后，APK文件位于：`android/app/build/outputs/apk/debug/app-debug.apk`

#### 方法二：命令行构建
```bash
# 进入android目录
cd android

# 使用Gradle构建（需要安装Gradle）
./gradlew assembleDebug

# 或使用Android Studio的Gradle
# 在Android Studio中打开Terminal，运行：
gradlew assembleDebug
```

### 4. 发布版本构建

#### 生成签名密钥
```bash
# 生成发布密钥
keytool -genkey -v -keystore release-key.keystore -alias release -keyalg RSA -keysize 2048 -validity 10000
```

#### 配置签名
在`android/app/build.gradle`中添加签名配置：
```gradle
android {
    signingConfigs {
        release {
            storeFile file('path/to/release-key.keystore')
            storePassword 'your-store-password'
            keyAlias 'release'
            keyPassword 'your-key-password'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

#### 构建发布版本
```bash
cd android
./gradlew assembleRelease
```

## 测试指南

### 1. Web端测试

```bash
# 启动开发服务器
npm run dev

# 访问 http://localhost:5173
```

### 2. 移动端测试

#### 在模拟器中测试
1. 在Android Studio中启动Android模拟器
2. 运行应用：
   ```bash
   npx cap run android
   ```

#### 在真机上测试
1. 启用开发者选项和USB调试
2. 连接设备到电脑
3. 运行应用：
   ```bash
   npx cap run android --target=device
   ```

#### 安装APK测试
1. 将构建的APK文件传输到Android设备
2. 在设备上启用"未知来源"安装
3. 点击APK文件进行安装

### 3. 功能测试

#### 原生功能测试
应用内置了原生功能测试页面，可以测试：
- 相机拍照功能
- 相册选择功能
- 文件选择功能
- 本地通知功能
- 触觉反馈功能
- 网络状态检测
- 设备信息获取

访问路径：应用内导航到"原生功能测试"页面

#### 聊天功能测试
1. 注册新用户账号
2. 登录应用
3. 添加好友
4. 发送文本消息
5. 发送图片和文件
6. 测试群组聊天
7. 测试消息通知

## 常见问题

### 构建问题

#### Q: 构建时出现"ENOTEMPTY"错误
A: 清理构建缓存：
```bash
# 清理前端构建缓存
rm -rf dist
rm -rf .vite_cache

# 清理Android构建缓存
cd android
./gradlew clean
```

#### Q: Android Studio无法识别项目
A: 确保：
1. Android Studio版本为最新稳定版
2. 已安装Android SDK和构建工具
3. 项目中的`android`文件夹完整

#### Q: 依赖安装失败
A: 尝试：
```bash
# 清理npm缓存
npm cache clean --force

# 删除node_modules重新安装
rm -rf node_modules
npm install
```

### 运行问题

#### Q: 应用启动后立即崩溃
A: 检查：
1. 设备Android版本是否满足最低要求（API 22+）
2. 应用权限是否正确配置
3. 查看Android Studio的Logcat输出错误信息

#### Q: 网络请求失败
A: 确保：
1. 后端服务器正在运行
2. 网络配置正确
3. Android网络安全配置允许HTTP请求（开发环境）

### 权限问题

#### Q: 相机或文件访问被拒绝
A: 检查：
1. `android/app/src/main/AndroidManifest.xml`中的权限声明
2. 应用运行时权限请求
3. 设备系统权限设置

## 性能优化

### 1. 构建优化
- 启用代码分割
- 压缩图片资源
- 移除未使用的依赖

### 2. 运行时优化
- 实现懒加载
- 优化图片加载
- 缓存网络请求

### 3. 移动端优化
- 减少包体积
- 优化启动时间
- 降低内存使用

## 部署指南

### 1. Google Play Store发布
1. 创建Google Play开发者账号
2. 准备应用图标、截图和描述
3. 上传签名的APK或AAB文件
4. 配置应用信息和定价
5. 提交审核

### 2. 内部分发
1. 使用Firebase App Distribution
2. 或通过企业内部应用商店
3. 直接分发APK文件

## 维护和更新

### 1. 版本管理
- 遵循语义化版本控制
- 维护更新日志
- 定期更新依赖

### 2. 监控和分析
- 集成崩溃报告工具
- 监控应用性能
- 收集用户反馈

### 3. 安全更新
- 定期更新安全补丁
- 检查依赖漏洞
- 更新加密算法

## 联系支持

如遇到问题，请：
1. 查看本文档的常见问题部分
2. 检查项目的GitHub Issues
3. 联系开发团队获取支持

---

*最后更新：2024年12月*