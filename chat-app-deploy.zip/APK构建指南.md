# 聊天应用 APK 构建指南

## 项目概述

本项目已成功配置为使用 Capacitor 5.x 框架将 React + TypeScript + Vite Web 应用转换为 Android APK。

## 已完成的配置

### 1. Capacitor 框架集成 ✅
- 已安装 Capacitor 5.x 核心包和 CLI
- 已配置 `capacitor.config.ts` 文件
- 已添加 Android 平台支持

### 2. 原生插件配置 ✅
已安装并配置以下 Capacitor 插件：
- `@capacitor/camera` - 相机功能
- `@capacitor/filesystem` - 文件系统访问
- `@capacitor/local-notifications` - 本地通知
- `@capacitor/push-notifications` - 推送通知
- `@capacitor/device` - 设备信息
- `@capacitor/network` - 网络状态
- `@capacitor/haptics` - 触觉反馈
- `@capacitor/keyboard` - 键盘控制
- `@capacitor/splash-screen` - 启动屏幕
- `@capacitor/status-bar` - 状态栏控制
- `@capacitor/app` - 应用生命周期

### 3. Android 权限配置 ✅
在 `android/app/src/main/AndroidManifest.xml` 中已配置：
- 网络访问权限
- 相机权限
- 文件读写权限
- 录音权限
- 网络状态访问权限
- 震动权限
- 推送通知权限

### 4. 移动端 UI 优化 ✅
- 创建了 `MobileToolbar` 组件，支持移动端特有功能
- 实现了 `useMobile` Hook 用于移动端检测和适配
- 集成了 `fileService` 和 `notificationService` 原生功能服务
- 优化了移动端响应式设计

### 5. 原生功能集成 ✅
- **相机功能**：支持拍照和从相册选择图片
- **文件访问**：支持文件选择和保存
- **推送通知**：支持本地通知和推送通知
- **触觉反馈**：支持设备震动反馈

## APK 构建步骤

### 前提条件
1. **Android Studio** - 需要安装 Android Studio 和 Android SDK
2. **Java Development Kit (JDK)** - 建议使用 JDK 11 或更高版本
3. **Android SDK** - 通过 Android Studio 安装

### 构建步骤

#### 1. 构建 Web 资源
```bash
npm run build
```

#### 2. 同步到 Android 项目
```bash
npx cap sync android
```

#### 3. 打开 Android Studio
```bash
npx cap open android
```

#### 4. 在 Android Studio 中构建 APK
1. 等待 Android Studio 完全加载项目
2. 点击菜单 `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
3. 等待构建完成
4. APK 文件将生成在 `android/app/build/outputs/apk/debug/` 目录中

### 替代构建方法（命令行）
如果已安装 Android SDK 和配置了环境变量：
```bash
cd android
./gradlew assembleDebug
```

## 项目结构

```
chat/
├── src/                          # React 前端源码
│   ├── components/
│   │   └── MobileToolbar.tsx     # 移动端工具栏组件
│   ├── hooks/
│   │   └── useMobile.ts          # 移动端适配 Hook
│   ├── services/
│   │   ├── fileService.ts        # 文件操作服务
│   │   └── notificationService.ts # 通知服务
│   └── pages/
│       └── Chat.tsx              # 聊天页面（已优化移动端）
├── android/                      # Android 项目
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml # Android 权限配置
│   │   │   ├── assets/public/      # Web 资源文件
│   │   │   └── res/values/
│   │   │       └── strings.xml     # 应用名称配置
│   │   └── build.gradle           # 应用构建配置
│   └── build.gradle               # 项目构建配置
├── capacitor.config.ts            # Capacitor 配置
└── package.json                   # 项目依赖
```

## 应用信息

- **应用名称**: 聊天应用
- **包名**: com.chatapp.app
- **版本**: 1.0 (versionCode: 1)
- **最小 Android 版本**: API 24 (Android 7.0)
- **目标 Android 版本**: API 34 (Android 14)

## 功能特性

### Web 功能（保持完整）
- 用户注册和登录
- 实时聊天功能
- 文件和图片分享
- 响应式设计

### 移动端增强功能
- 原生相机集成
- 文件系统访问
- 推送通知支持
- 触觉反馈
- 移动端优化的 UI 组件
- 键盘自适应
- 状态栏控制

## 测试状态

### 已测试功能 ✅
- Web 版本功能完整性
- 移动端 UI 适配
- Capacitor 插件集成
- 原生功能服务
- TypeScript 类型检查通过
- 构建流程验证

### 需要设备测试的功能
- 实际 APK 安装和运行
- 相机功能实际操作
- 推送通知接收
- 文件访问权限
- 网络连接和后端通信

## 注意事项

1. **开发环境**: 当前在 Web 环境下，某些原生功能可能受限
2. **权限请求**: 首次使用相机、文件等功能时，应用会请求相应权限
3. **网络配置**: 应用配置了 `usesCleartextTraffic="true"` 以支持 HTTP 连接
4. **后端兼容**: 保持与现有 MongoDB 后端的完全兼容性

## 下一步建议

1. 在实际 Android 设备上测试 APK
2. 配置生产环境的签名密钥
3. 优化 APK 大小和性能
4. 添加应用图标和启动画面
5. 配置 Google Play 发布准备

## 故障排除

### 常见问题
1. **权限被拒绝**: 检查 AndroidManifest.xml 中的权限配置
2. **构建失败**: 确保 Android SDK 和构建工具版本正确
3. **插件错误**: 运行 `npx cap sync` 重新同步插件
4. **网络问题**: 检查网络权限和后端服务器配置

### 日志查看
- Android Studio: View → Tool Windows → Logcat
- Chrome DevTools: 在 Web 版本中调试
- Capacitor 日志: 使用 `npx cap run android --livereload` 进行实时调试

---

**构建完成时间**: 2024年11月2日  
**Capacitor 版本**: 5.x  
**Android Gradle Plugin**: 8.2.1  
**目标 SDK**: 34