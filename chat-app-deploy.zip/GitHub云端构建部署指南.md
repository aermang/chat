# GitHub Actions云端构建部署指南

## 🚀 快速开始

### 📋 前置条件
- GitHub账户
- 项目代码已准备就绪
- 基本的Git操作知识

### 🎯 部署步骤

#### 1. 创建GitHub仓库
```bash
# 方法1: 通过GitHub网站创建
1. 访问 https://github.com
2. 点击 "New repository"
3. 输入仓库名称（如：chat-app）
4. 选择 "Public" 或 "Private"
5. 点击 "Create repository"

# 方法2: 使用GitHub CLI（如果已安装）
gh repo create chat-app --public
```

#### 2. 初始化本地Git仓库
```bash
# 在项目根目录执行
cd d:\聊天工具开发\chat

# 初始化Git仓库
git init

# 添加远程仓库（替换为你的GitHub用户名）
git remote add origin https://github.com/YOUR_USERNAME/chat-app.git

# 检查远程仓库配置
git remote -v
```

#### 3. 提交并推送代码
```bash
# 添加所有文件到暂存区
git add .

# 创建初始提交
git commit -m "初始提交：聊天应用项目"

# 推送到GitHub
git push -u origin main
```

#### 4. 触发自动构建
推送代码后，GitHub Actions会自动开始构建：
- 访问你的GitHub仓库
- 点击 "Actions" 标签页
- 查看 "构建Android APK" 工作流状态

## 🔧 配置详解

### 📁 工作流文件结构
```
.github/
└── workflows/
    └── build-apk.yml    # 主要构建配置文件
```

### ⚙️ 构建环境配置
- **操作系统**: Ubuntu Latest
- **Node.js版本**: 22.14.0（与本地环境一致）
- **Java版本**: 17（推荐用于Android构建）
- **Android SDK**: API Level 33
- **构建工具**: Gradle 7.6+

### 🎛️ 环境变量
```yaml
env:
  NODE_VERSION: '22.14.0'
  JAVA_VERSION: '17'
  GRADLE_OPTS: '-Dorg.gradle.daemon=false -Dorg.gradle.parallel=true'
```

## 📦 构建产物

### 🎯 自动生成的文件
1. **Debug APK**: `app-debug.apk`
   - 用于开发和测试
   - 每次推送都会生成
   - 保留30天

2. **Release APK**: `app-release-unsigned.apk`
   - 仅在推送到main分支时生成
   - 用于生产发布
   - 保留90天

3. **构建日志**: 
   - 详细的构建过程日志
   - 错误诊断信息
   - 保留7天

### 📥 下载APK文件

#### 方法1: 从Actions页面下载
1. 访问GitHub仓库的Actions页面
2. 点击最新的构建任务
3. 在"Artifacts"部分下载APK文件

#### 方法2: 从Releases页面下载
1. 访问GitHub仓库的Releases页面
2. 下载最新版本的APK文件
3. 包含详细的版本信息和更新日志

## 🛠️ 故障排除

### ❌ 常见问题及解决方案

#### 1. 构建超时
**问题**: 构建时间超过30分钟
**解决方案**:
```yaml
# 在build-apk.yml中调整超时时间
jobs:
  build:
    timeout-minutes: 45  # 增加到45分钟
```

#### 2. 依赖下载失败
**问题**: npm或Gradle依赖下载失败
**解决方案**:
- GitHub Actions环境网络稳定，通常不会出现本地SSL问题
- 如果出现问题，检查package.json和build.gradle配置

#### 3. Capacitor同步失败
**问题**: `npx cap sync android` 失败
**解决方案**:
- 工作流已包含清理步骤
- 自动删除可能冲突的目录

#### 4. APK文件未生成
**问题**: 构建成功但找不到APK文件
**解决方案**:
```bash
# 检查APK文件路径
find android -name "*.apk" -type f
```

### 🔍 调试技巧

#### 1. 查看详细日志
```yaml
# 在构建步骤中添加详细输出
- name: 构建Android APK (Debug)
  run: |
    cd android
    ./gradlew assembleDebug --no-daemon --stacktrace --info --debug
```

#### 2. 验证环境
工作流包含环境验证步骤：
```yaml
- name: 验证环境
  run: |
    echo "Node.js版本: $(node --version)"
    echo "Java版本: $(java -version)"
    echo "项目文件:"
    ls -la
```

#### 3. 上传构建日志
```yaml
- name: 上传构建日志
  if: always()  # 即使构建失败也上传日志
  uses: actions/upload-artifact@v4
  with:
    name: build-logs-${{ github.run_number }}
    path: |
      android/build/reports/
      android/app/build/reports/
```

## 🚀 高级配置

### 🔐 签名配置（可选）
如果需要发布到Google Play Store，需要配置APK签名：

1. **生成签名密钥**:
```bash
keytool -genkey -v -keystore my-release-key.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

2. **配置GitHub Secrets**:
   - `KEYSTORE_FILE`: Base64编码的keystore文件
   - `KEYSTORE_PASSWORD`: keystore密码
   - `KEY_ALIAS`: 密钥别名
   - `KEY_PASSWORD`: 密钥密码

3. **更新工作流**:
```yaml
- name: 签名APK
  run: |
    echo "${{ secrets.KEYSTORE_FILE }}" | base64 -d > my-release-key.keystore
    cd android
    ./gradlew assembleRelease \
      -Pandroid.injected.signing.store.file=../my-release-key.keystore \
      -Pandroid.injected.signing.store.password=${{ secrets.KEYSTORE_PASSWORD }} \
      -Pandroid.injected.signing.key.alias=${{ secrets.KEY_ALIAS }} \
      -Pandroid.injected.signing.key.password=${{ secrets.KEY_PASSWORD }}
```

### 📊 构建通知
配置构建状态通知：

```yaml
- name: 发送构建通知
  if: always()
  uses: 8398a7/action-slack@v3
  with:
    status: ${{ job.status }}
    text: APK构建${{ job.status == 'success' && '成功' || '失败' }}
  env:
    SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK }}
```

## 📈 性能优化

### ⚡ 缓存策略
工作流已配置多层缓存：
1. **Gradle缓存**: 加速Android构建
2. **Node.js缓存**: 加速依赖安装
3. **npm缓存**: 减少网络请求

### 🔄 并行构建
```yaml
strategy:
  matrix:
    build-type: [debug, release]
```

### 📱 多架构支持
```yaml
- name: 构建多架构APK
  run: |
    cd android
    ./gradlew assembleDebug -Pandroid.injected.build.abi=arm64-v8a,armeabi-v7a
```

## 📋 检查清单

### ✅ 部署前检查
- [ ] GitHub仓库已创建
- [ ] 本地Git仓库已初始化
- [ ] 远程仓库已配置
- [ ] .github/workflows/build-apk.yml文件存在
- [ ] package.json和capacitor.config.ts配置正确

### ✅ 构建后验证
- [ ] Actions页面显示构建成功
- [ ] APK文件已生成并可下载
- [ ] APK文件可以正常安装
- [ ] 应用功能正常运行

## 🆘 获取帮助

### 📞 支持渠道
1. **GitHub Issues**: 在仓库中创建Issue
2. **GitHub Discussions**: 社区讨论
3. **官方文档**: 
   - [GitHub Actions文档](https://docs.github.com/en/actions)
   - [Capacitor文档](https://capacitorjs.com/docs)
   - [Android开发文档](https://developer.android.com)

### 🔗 有用链接
- [GitHub Actions市场](https://github.com/marketplace?type=actions)
- [Android构建最佳实践](https://developer.android.com/studio/build/optimize-your-build)
- [Capacitor Android配置](https://capacitorjs.com/docs/android/configuration)

---

## 🎉 总结

GitHub Actions云端构建方案的优势：
- ✅ **稳定可靠**: 云端环境避免本地SSL问题
- ✅ **自动化**: 推送代码即自动构建
- ✅ **多版本**: 同时生成Debug和Release版本
- ✅ **易于分享**: 通过GitHub直接分发APK
- ✅ **版本管理**: 自动创建Release和版本标签
- ✅ **日志完整**: 详细的构建日志便于调试

**推荐使用此方案作为主要的APK构建和分发方式！**