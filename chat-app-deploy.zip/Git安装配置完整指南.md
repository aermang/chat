# 🚀 Git 安装配置完整指南

## 🔄 最新更新

**检测状态**：已确认 Git 未安装，已创建完整的安装解决方案
**更新时间**：刚刚完成环境检测和脚本创建
**可用工具**：
- ✅ `install-git.bat` - 一键安装脚本
- ✅ `install-git.ps1` - PowerShell 安装脚本  
- ✅ 完整的手动安装指导

## 📊 当前状态

**检测结果**：
- ❌ Git 未安装
- ✅ Node.js v22.14.0 已安装
- ✅ 项目文件完整
- ✅ GitHub Actions 配置已优化

**目标**：安装并配置 Git，为 GitHub Actions 云端 APK 构建做准备

## 🚀 方案一：自动安装（推荐）

### 使用自动安装脚本

1. **运行安装脚本**
   ```bash
   # 双击运行
   install-git.bat
   
   # 或在 PowerShell 中运行
   .\install-git.ps1
   ```

2. **脚本功能**
   - ✅ 自动检测 Git 安装状态
   - ✅ 多种安装方式（Chocolatey/手动下载）
   - ✅ 自动配置 Git 用户信息
   - ✅ 可选安装 GitHub CLI
   - ✅ 环境变量自动刷新

### 安装选项说明

**选项1：自动安装（推荐）**
- 使用 Chocolatey 包管理器
- 完全自动化，无需手动操作
- 自动处理环境变量

**选项2：手动下载安装**
- 自动下载最新版 Git 安装程序
- 启动图形界面安装向导
- 建议使用默认设置

**选项3：官网手动下载**
- 打开 Git 官网下载页面
- 适合网络环境特殊的情况

## 🔧 方案二：手动安装

### 1. 下载 Git

访问官网：https://git-scm.com/download/win

**推荐版本**：Git for Windows 2.43.0 或更新版本

### 2. 安装 Git

1. **运行安装程序**
   - 双击下载的 `.exe` 文件
   - 选择"以管理员身份运行"

2. **安装设置（推荐配置）**
   - **安装路径**：使用默认路径
   - **组件选择**：
     - ✅ Git Bash Here
     - ✅ Git GUI Here
     - ✅ Git LFS (Large File Support)
     - ✅ Associate .git* configuration files
   - **默认编辑器**：选择您熟悉的编辑器
   - **PATH 环境**：选择 "Git from the command line and also from 3rd-party software"
   - **HTTPS 传输**：选择 "Use the OpenSSL library"
   - **行尾转换**：选择 "Checkout Windows-style, commit Unix-style line endings"
   - **终端模拟器**：选择 "Use MinTTY"
   - **默认分支名**：选择 "Override the default branch name for new repositories" 并设为 "main"

### 3. 验证安装

安装完成后，打开新的命令提示符或 PowerShell：

```bash
git --version
```

应该显示类似：`git version 2.43.0.windows.1`

## ⚙️ Git 基本配置

### 1. 设置用户信息

```bash
# 设置用户名（替换为您的 GitHub 用户名）
git config --global user.name "您的GitHub用户名"

# 设置邮箱（替换为您的 GitHub 邮箱）
git config --global user.email "您的GitHub邮箱"
```

### 2. 设置默认分支

```bash
git config --global init.defaultBranch main
```

### 3. 设置行尾处理

```bash
git config --global core.autocrlf true
git config --global core.safecrlf false
```

### 4. 验证配置

```bash
git config --global --list
```

## 🔐 GitHub 认证配置

### 方案1：使用 GitHub CLI（推荐）

1. **安装 GitHub CLI**
   ```bash
   # 使用 Chocolatey（如果已安装）
   choco install gh
   
   # 或访问：https://cli.github.com/
   ```

2. **登录 GitHub**
   ```bash
   gh auth login
   ```

### 方案2：使用 Personal Access Token

1. **创建 Token**
   - 访问：https://github.com/settings/tokens
   - 点击 "Generate new token (classic)"
   - 选择权限：`repo`, `workflow`, `write:packages`

2. **配置认证**
   - 首次推送时输入用户名和 Token（而非密码）

### 方案3：使用 SSH 密钥

1. **生成 SSH 密钥**
   ```bash
   ssh-keygen -t ed25519 -C "您的GitHub邮箱"
   ```

2. **添加到 GitHub**
   - 复制公钥内容：`cat ~/.ssh/id_ed25519.pub`
   - 访问：https://github.com/settings/keys
   - 添加新的 SSH 密钥

## 🎯 完成安装后的下一步

### 1. 验证环境

运行以下命令确认一切正常：

```bash
# 检查 Git
git --version

# 检查配置
git config --global user.name
git config --global user.email

# 检查 GitHub CLI（如果安装了）
gh --version
```

### 2. 初始化项目

```bash
# 在项目目录中
cd d:\聊天工具开发\chat

# 初始化 Git 仓库
git init
git branch -M main

# 添加文件
git add .
git commit -m "🚀 初始化项目 - 准备 GitHub Actions APK 构建"
```

### 3. 运行自动部署

安装完成后，您可以：

```bash
# 运行自动部署脚本
.\deploy-to-github.bat
```

## 🔍 故障排除

### 问题1：Git 命令不被识别

**解决方案**：
1. 重启命令提示符/PowerShell
2. 检查环境变量 PATH 是否包含 Git 路径
3. 重新安装 Git 并确保选择了正确的 PATH 选项

### 问题2：权限被拒绝

**解决方案**：
1. 以管理员身份运行命令提示符
2. 检查 Git 安装目录的权限
3. 配置 GitHub 认证（Token 或 SSH）

### 问题3：网络连接问题

**解决方案**：
1. 检查防火墙设置
2. 配置代理（如果需要）
3. 使用 SSH 而非 HTTPS

### 问题4：中文乱码

**解决方案**：
```bash
git config --global core.quotepath false
git config --global gui.encoding utf-8
git config --global i18n.commit.encoding utf-8
git config --global i18n.logoutputencoding utf-8
```

## 📋 安装检查清单

安装完成后，请确认以下项目：

- [ ] ✅ Git 命令可以正常运行
- [ ] ✅ 用户名和邮箱已配置
- [ ] ✅ 默认分支设置为 main
- [ ] ✅ GitHub 认证已配置
- [ ] ✅ 可以访问 GitHub 仓库
- [ ] ✅ 项目已初始化为 Git 仓库

## 🎉 完成！

Git 安装和配置完成后，您就可以：

1. **运行自动部署**：`.\deploy-to-github.bat`
2. **手动部署**：按照 `manual-deploy-guide.md` 操作
3. **享受 GitHub Actions 自动 APK 构建**

---

💡 **提示**：如果遇到任何问题，请参考故障排除部分或重新运行安装脚本。