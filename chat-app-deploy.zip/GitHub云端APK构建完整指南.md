# 🚀 GitHub云端APK构建完整指南

> **一键解决本地APK构建问题，使用GitHub Actions云端构建服务**

## 📋 目录

- [🎯 方案概述](#-方案概述)
- [⚡ 快速开始](#-快速开始)
- [📝 详细步骤](#-详细步骤)
- [📦 APK下载](#-apk下载)
- [🔧 故障排除](#-故障排除)
- [❓ 常见问题](#-常见问题)

## 🎯 方案概述

### 为什么选择GitHub Actions？

- ✅ **完全免费**: 公开仓库免费使用GitHub Actions
- ✅ **环境稳定**: 预配置的Ubuntu环境，无SSL证书问题
- ✅ **自动化**: 推送代码即自动构建APK
- ✅ **多版本**: 同时生成Debug和Release版本
- ✅ **易分享**: 自动创建Release，便于分发

### 构建流程

```mermaid
graph LR
    A[推送代码] --> B[触发GitHub Actions]
    B --> C[安装环境]
    C --> D[构建Web应用]
    D --> E[同步Android项目]
    E --> F[编译APK]
    F --> G[上传文件]
    G --> H[创建Release]
```

## ⚡ 快速开始

### 方式一：一键部署脚本（推荐）

1. **运行部署脚本**
   ```bash
   # 双击运行
   deploy-to-github.bat
   ```

2. **等待构建完成**
   - 构建时间：10-15分钟
   - 自动创建Release
   - 自动上传APK文件

### 方式二：手动操作

1. **创建GitHub仓库**
2. **推送代码**
3. **等待自动构建**

## 📝 详细步骤

### 步骤1: 环境准备

#### 必需软件
- [Git](https://git-scm.com/download/win) - 版本控制
- [Node.js](https://nodejs.org/) - 项目依赖

#### 可选软件
- [GitHub CLI](https://cli.github.com/) - 命令行工具（推荐）
- [GitHub Desktop](https://desktop.github.com/) - 图形界面工具

### 步骤2: 创建GitHub仓库

#### 方式A: 网页创建
1. 访问 [https://github.com/new](https://github.com/new)
2. 填写仓库信息：
   - **仓库名**: `chat-app` 或 `instant-messaging-app`
   - **可见性**: 选择 `Public`（免费使用Actions）
   - **不要勾选**: README、.gitignore、License
3. 点击 `Create repository`

#### 方式B: GitHub CLI创建
```bash
gh repo create chat-app --public --description "基于Web技术的即时通讯应用"
```

### 步骤3: 推送代码

#### 初始化Git仓库
```bash
# 初始化仓库
git init
git branch -M main

# 配置用户信息（如果未配置）
git config --global user.name "您的用户名"
git config --global user.email "您的邮箱"

# 添加文件
git add .
git commit -m "🚀 初始提交: 聊天应用项目"

# 连接远程仓库
git remote add origin https://github.com/您的用户名/仓库名.git

# 推送代码
git push -u origin main
```

### 步骤4: 监控构建

#### 查看构建状态
1. 访问仓库的 `Actions` 标签页
2. 查看 `🚀 构建Android APK` 工作流
3. 等待构建完成（绿色✅表示成功）

#### 使用监控脚本
```bash
# 运行监控脚本
monitor-build.bat
```

## 📦 APK下载

### 方式一: 从Artifacts下载

1. **进入Actions页面**
   ```
   https://github.com/您的用户名/仓库名/actions
   ```

2. **选择最新的成功构建**
   - 点击绿色✅的构建记录

3. **下载APK文件**
   - 滚动到页面底部的 `Artifacts` 部分
   - 下载 `聊天应用-Debug-vXXX` 或 `聊天应用-Release-vXXX`

### 方式二: 从Release下载（推荐）

1. **访问Release页面**
   ```
   https://github.com/您的用户名/仓库名/releases
   ```

2. **下载最新版本**
   - 点击最新的Release
   - 在 `Assets` 部分下载APK文件

### APK文件说明

| 文件名 | 类型 | 用途 | 推荐 |
|--------|------|------|------|
| `app-debug.apk` | 调试版 | 开发测试 | 🧪 开发者 |
| `app-release-unsigned.apk` | 发布版 | 生产使用 | ⭐ 推荐 |

## 🔧 故障排除

### 常见构建错误

#### 1. 构建失败 - 依赖问题
**症状**: `npm install` 失败
**解决方案**:
```bash
# 清理缓存
npm cache clean --force
# 删除node_modules重新安装
rm -rf node_modules
npm install
```

#### 2. 构建失败 - Gradle错误
**症状**: Android构建失败
**解决方案**:
- 检查 `android/gradle/wrapper/gradle-wrapper.properties`
- 确保Gradle版本兼容

#### 3. 推送失败 - 身份验证
**症状**: `git push` 需要身份验证
**解决方案**:
- 使用GitHub Desktop
- 配置SSH密钥
- 使用Personal Access Token

### 构建日志分析

#### 查看详细日志
1. 进入失败的构建页面
2. 点击失败的步骤
3. 查看详细错误信息

#### 常见错误模式
```bash
# 网络问题
Error: connect ETIMEDOUT

# 权限问题  
Error: Permission denied

# 依赖问题
Error: Module not found
```

## ❓ 常见问题

### Q: 构建需要多长时间？
**A**: 通常10-15分钟，首次构建可能需要更长时间。

### Q: 为什么选择公开仓库？
**A**: 私有仓库的GitHub Actions有使用限制，公开仓库完全免费。

### Q: APK文件安全吗？
**A**: 是的，构建过程完全透明，可以查看所有构建日志。

### Q: 可以自定义构建配置吗？
**A**: 可以，修改 `.github/workflows/build-apk.yml` 文件。

### Q: 如何更新应用？
**A**: 推送新代码到main分支，会自动触发新的构建。

### Q: 构建失败怎么办？
**A**: 查看构建日志，根据错误信息进行修复，或参考故障排除部分。

## 🎯 高级配置

### 自定义构建类型

在GitHub仓库页面，进入 `Actions` → `🚀 构建Android APK` → `Run workflow`，可以选择：
- `debug`: 仅构建调试版
- `release`: 仅构建发布版  
- `both`: 构建两个版本

### 自动发布配置

修改 `.github/workflows/build-apk.yml` 中的发布条件：
```yaml
# 仅在main分支创建Release
if: github.ref == 'refs/heads/main' && success()

# 在所有分支创建Release
if: success()
```

### 构建通知

可以配置Slack、邮件等通知方式，在构建完成时自动通知。

## 📞 技术支持

如果遇到问题：

1. **查看文档**: 首先查看本指南的故障排除部分
2. **检查日志**: 查看GitHub Actions的详细构建日志
3. **搜索问题**: 在GitHub Issues中搜索类似问题
4. **提交Issue**: 在项目仓库中创建新的Issue

---

## 🎉 总结

GitHub Actions云端构建方案完美解决了本地环境问题：

- ✅ **无需本地Android SDK**
- ✅ **无需处理SSL证书问题**  
- ✅ **无需安装Android Studio**
- ✅ **自动化构建和发布**
- ✅ **免费且稳定**

只需要几个简单步骤，就能获得专业级的APK构建服务！

**🚀 立即开始使用GitHub云端构建，告别本地环境烦恼！**