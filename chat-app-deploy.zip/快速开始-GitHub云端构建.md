# ⚡ 快速开始 - GitHub云端APK构建

> **3分钟完成设置，10分钟获得APK文件**

## 🎯 一键部署（推荐）

### 步骤1: 运行部署脚本
```bash
# 双击运行以下文件
deploy-to-github.bat
```

### 步骤2: 按提示操作
1. 脚本会自动检查环境
2. 按提示输入GitHub信息
3. 等待代码推送完成

### 步骤3: 等待构建
- ⏱️ 构建时间：10-15分钟
- 🔗 访问：`https://github.com/您的用户名/仓库名/actions`
- 📦 下载：构建完成后自动创建Release

## 🔧 手动操作

### 如果自动脚本失败，可以手动操作：

#### 1. 创建GitHub仓库
- 访问：https://github.com/new
- 仓库名：`chat-app`
- 设置为：`Public`
- 不勾选任何初始化选项

#### 2. 推送代码
```bash
git init
git add .
git commit -m "初始提交"
git branch -M main
git remote add origin https://github.com/您的用户名/chat-app.git
git push -u origin main
```

#### 3. 监控构建
```bash
# 运行监控脚本
monitor-build.bat
```

## 📱 下载APK

### 方式1: Release页面（推荐）
```
https://github.com/您的用户名/仓库名/releases
```

### 方式2: Actions页面
```
https://github.com/您的用户名/仓库名/actions
```
点击最新构建 → 滚动到底部 → 下载Artifacts

## 🆘 遇到问题？

### 常见解决方案：
1. **Git未安装**: 下载 https://git-scm.com/download/win
2. **推送失败**: 使用GitHub Desktop或配置SSH
3. **构建失败**: 查看Actions页面的错误日志

### 获取帮助：
- 📖 详细指南：`GitHub云端APK构建完整指南.md`
- 🔍 故障排除：查看完整指南的故障排除部分

---

**🎉 就是这么简单！推送代码，等待构建，下载APK！**