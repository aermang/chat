# Git 安装验证脚本 (更新版)
# 等待用户手动安装Git后进行验证和配置

Write-Host "Git Installation Verification Script" -ForegroundColor Green
Write-Host "====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Git官网已打开，请按照以下步骤操作：" -ForegroundColor Yellow
Write-Host "1. 从打开的网页下载Git安装程序" -ForegroundColor White
Write-Host "2. 运行安装程序，使用默认设置安装" -ForegroundColor White
Write-Host "3. 安装完成后，按任意键继续..." -ForegroundColor White
Write-Host ""

# 等待用户按键
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

Write-Host ""
Write-Host "正在验证Git安装..." -ForegroundColor Yellow

# 检查Git是否已安装
function Test-GitInstalled {
    try {
        $gitVersion = git --version 2>$null
        if ($gitVersion) {
            Write-Host "✅ Git安装成功: $gitVersion" -ForegroundColor Green
            return $true
        }
    } catch {
        Write-Host "❌ Git未安装或未正确配置" -ForegroundColor Red
        return $false
    }
    return $false
}

# 配置Git用户信息
function Set-GitConfig {
    Write-Host ""
    Write-Host "配置Git用户信息..." -ForegroundColor Yellow
    
    # 检查现有配置
    $existingName = git config --global user.name 2>$null
    $existingEmail = git config --global user.email 2>$null
    
    if ($existingName -and $existingEmail) {
        Write-Host "Git用户信息已配置:" -ForegroundColor Green
        Write-Host "   用户名: $existingName" -ForegroundColor Cyan
        Write-Host "   邮箱: $existingEmail" -ForegroundColor Cyan
        
        $reconfigure = Read-Host "是否重新配置？(y/N)"
        if ($reconfigure -ne 'y' -and $reconfigure -ne 'Y') {
            return $true
        }
    }
    
    # 获取用户输入
    do {
        $userName = Read-Host "请输入您的GitHub用户名"
    } while ([string]::IsNullOrWhiteSpace($userName))
    
    do {
        $userEmail = Read-Host "请输入您的GitHub邮箱"
    } while ([string]::IsNullOrWhiteSpace($userEmail))
    
    try {
        git config --global user.name "$userName"
        git config --global user.email "$userEmail"
        git config --global init.defaultBranch main
        git config --global core.autocrlf true
        
        Write-Host ""
        Write-Host "✅ Git配置完成:" -ForegroundColor Green
        Write-Host "   用户名: $userName" -ForegroundColor Cyan
        Write-Host "   邮箱: $userEmail" -ForegroundColor Cyan
        Write-Host "   默认分支: main" -ForegroundColor Cyan
        return $true
    } catch {
        Write-Host "❌ Git配置失败: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 主验证流程
$maxRetries = 3
$retryCount = 0

while ($retryCount -lt $maxRetries) {
    if (Test-GitInstalled) {
        Write-Host ""
        Write-Host "🎉 Git安装验证成功！" -ForegroundColor Green
        
        if (Set-GitConfig) {
            Write-Host ""
            Write-Host "🎊 Git安装和配置完成！" -ForegroundColor Green
            Write-Host ""
            Write-Host "下一步操作：" -ForegroundColor Cyan
            Write-Host "1. 运行 quick-deploy.ps1 进行自动部署" -ForegroundColor Yellow
            Write-Host "2. 或者运行 deploy-to-github.bat 创建GitHub仓库" -ForegroundColor Yellow
            Write-Host "3. 查看 manual-deploy-guide.md 了解手动部署步骤" -ForegroundColor Yellow
            break
        }
    } else {
        $retryCount++
        if ($retryCount -lt $maxRetries) {
            Write-Host ""
            Write-Host "Git未检测到，可能需要：" -ForegroundColor Yellow
            Write-Host "1. 重新启动PowerShell/命令提示符" -ForegroundColor White
            Write-Host "2. 确保Git已正确安装" -ForegroundColor White
            Write-Host "3. 检查系统环境变量" -ForegroundColor White
            Write-Host ""
            Write-Host "按任意键重试 ($retryCount/$maxRetries)..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        } else {
            Write-Host ""
            Write-Host "❌ Git安装验证失败" -ForegroundColor Red
            Write-Host "请确保：" -ForegroundColor Yellow
            Write-Host "1. Git已正确安装" -ForegroundColor White
            Write-Host "2. 重新启动PowerShell" -ForegroundColor White
            Write-Host "3. 或者联系技术支持" -ForegroundColor White
        }
    }
}

Write-Host ""
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")