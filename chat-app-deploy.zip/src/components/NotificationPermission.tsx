/**
 * 特药管理系统 - 通知权限管理组件
 * 处理浏览器通知权限的请求和管理
 */

import React, { useState, useEffect } from 'react';
import { Bell, BellOff, AlertCircle, Check, X } from 'lucide-react';
import { useTouchFeedback } from '../hooks';

/**
 * 通知权限状态
 */
type NotificationPermissionStatus = 'default' | 'granted' | 'denied';

/**
 * 组件属性接口
 */
interface NotificationPermissionProps {
  onPermissionChange?: (permission: NotificationPermissionStatus) => void;
  showInline?: boolean;
  className?: string;
}

/**
 * 通知权限管理组件
 */
const NotificationPermission: React.FC<NotificationPermissionProps> = ({
  onPermissionChange,
  showInline = false,
  className = ''
}) => {
  const { handleTouchStart, handleTouchEnd, touchStyles } = useTouchFeedback();
  const [permission, setPermission] = useState<NotificationPermissionStatus>('default');
  const [isRequesting, setIsRequesting] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  /**
   * 检查通知权限状态
   */
  const checkPermission = (): NotificationPermissionStatus => {
    if (!('Notification' in window)) {
      return 'denied';
    }
    return Notification.permission as NotificationPermissionStatus;
  };

  /**
   * 初始化权限状态
   */
  useEffect(() => {
    const currentPermission = checkPermission();
    setPermission(currentPermission);
    setShowPrompt(currentPermission === 'default');
    
    if (onPermissionChange) {
      onPermissionChange(currentPermission);
    }
  }, [onPermissionChange]);

  /**
   * 请求通知权限
   */
  const requestPermission = async () => {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return;
    }

    if (permission === 'granted') {
      return;
    }

    setIsRequesting(true);

    try {
      const result = await Notification.requestPermission();
      setPermission(result as NotificationPermissionStatus);
      setShowPrompt(false);
      
      if (onPermissionChange) {
        onPermissionChange(result as NotificationPermissionStatus);
      }

      // 发送测试通知
      if (result === 'granted') {
        new Notification('用药提醒已启用', {
          body: '您将收到及时的用药提醒通知',
          icon: '/favicon.ico',
          tag: 'permission-granted'
        });
      }
    } catch (error) {
      console.error('Failed to request notification permission:', error);
    } finally {
      setIsRequesting(false);
    }
  };

  /**
   * 关闭权限提示
   */
  const dismissPrompt = () => {
    setShowPrompt(false);
  };

  /**
   * 获取权限状态图标
   */
  const getPermissionIcon = () => {
    switch (permission) {
      case 'granted':
        return <Bell className="w-5 h-5 text-green-500" />;
      case 'denied':
        return <BellOff className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    }
  };

  /**
   * 获取权限状态文本
   */
  const getPermissionText = () => {
    switch (permission) {
      case 'granted':
        return '通知已启用';
      case 'denied':
        return '通知已禁用';
      default:
        return '需要通知权限';
    }
  };

  /**
   * 获取权限状态描述
   */
  const getPermissionDescription = () => {
    switch (permission) {
      case 'granted':
        return '您将收到及时的用药提醒通知';
      case 'denied':
        return '无法发送用药提醒通知，请在浏览器设置中手动启用';
      default:
        return '启用通知后，您将收到及时的用药提醒';
    }
  };

  // 如果不显示内联且权限已授予，则不渲染
  if (!showInline && permission === 'granted') {
    return null;
  }

  // 如果不显示提示且权限不是默认状态，则不渲染
  if (!showPrompt && permission !== 'default' && !showInline) {
    return null;
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 ${className}`}>
      <div className="p-4">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 mt-1">
            {getPermissionIcon()}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                {getPermissionText()}
              </h3>
              
              {!showInline && permission === 'default' && (
                <button
                  onClick={dismissPrompt}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors ${touchStyles}`}
                  title="关闭"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {getPermissionDescription()}
            </p>
            
            {permission === 'default' && (
              <div className="mt-3 flex space-x-2">
                <button
                  onClick={requestPermission}
                  disabled={isRequesting}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md
                    text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500
                    disabled:opacity-50 disabled:cursor-not-allowed transition-colors
                    ${touchStyles}
                  `}
                >
                  {isRequesting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      请求中...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      启用通知
                    </>
                  )}
                </button>
                
                {!showInline && (
                  <button
                    onClick={dismissPrompt}
                    onTouchStart={handleTouchStart}
                    onTouchEnd={handleTouchEnd}
                    className={`
                      inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm leading-4 font-medium rounded-md
                      text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600
                      focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors
                      ${touchStyles}
                    `}
                  >
                    稍后再说
                  </button>
                )}
              </div>
            )}
            
            {permission === 'denied' && (
              <div className="mt-3">
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  要启用通知，请点击浏览器地址栏左侧的锁图标，然后选择"允许"通知权限。
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationPermission;