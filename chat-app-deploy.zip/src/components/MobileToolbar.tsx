/**
 * 移动端工具栏组件
 * 提供相机、文件选择等移动端特有功能
 */

import React from 'react';
import { Camera, Image, FileText, Mic, MapPin, X } from 'lucide-react';
import { CapacitorService } from '../services/capacitorService';
import { fileService, FileInfo, ImageInfo } from '../services/fileService';
import { toast } from 'sonner';

interface MobileToolbarProps {
  onFileSelect?: (file: File) => void;
  onImageSelect?: (imageUrl: string) => void;
  onClose?: () => void;
  className?: string;
}

/**
 * 移动端工具栏组件
 */
const MobileToolbar: React.FC<MobileToolbarProps> = ({
  onFileSelect,
  onImageSelect,
  onClose,
  className = ''
}) => {
  /**
   * 处理拍照功能
   */
  const handleCamera = async () => {
    try {
      const imageInfo: ImageInfo = await fileService.capturePhoto();
      const imageUrl = `data:${imageInfo.type};base64,${imageInfo.data}`;
      onImageSelect?.(imageUrl);
      onClose?.();
      toast.success('拍照成功');
    } catch (error) {
      console.error('拍照失败:', error);
      toast.error('拍照失败，请检查相机权限');
    }
  };

  /**
   * 处理从相册选择图片
   */
  const handleGallery = async () => {
    try {
      const imageInfo: ImageInfo = await fileService.selectFromGallery();
      const imageUrl = `data:${imageInfo.type};base64,${imageInfo.data}`;
      onImageSelect?.(imageUrl);
      onClose?.();
      toast.success('选择图片成功');
    } catch (error) {
      console.error('选择图片失败:', error);
      toast.error('选择图片失败，请检查存储权限');
    }
  };

  /**
   * 处理文件选择
   */
  const handleFileSelectClick = async () => {
    try {
      const fileInfo: FileInfo = await fileService.selectFile();
      // 创建File对象用于兼容
      const file = new File([fileInfo.data], fileInfo.name, { type: fileInfo.type });
      onFileSelect?.(file);
      onClose?.();
      toast.success('文件选择成功');
    } catch (error) {
      console.error('文件选择失败:', error);
      toast.error('文件选择失败');
    }
  };

  /**
   * 语音录制功能（占位符）
   */
  const handleVoiceRecord = () => {
    toast.info('语音录制功能开发中...');
  };

  /**
   * 位置分享功能（占位符）
   */
  const handleLocationShare = () => {
    toast.info('位置分享功能开发中...');
  };

  // 如果不是移动端环境，不显示工具栏
  if (!CapacitorService.isNative() && window.innerWidth > 768) {
    return null;
  }

  return (
    <div className={`bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 ${className}`}>
      {/* 工具栏头部 */}
      <div className="flex items-center justify-between p-2 border-b border-gray-200 dark:border-gray-700">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">选择功能</span>
        <button
          onClick={onClose}
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          title="关闭"
        >
          <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
        </button>
      </div>
      
      {/* 功能按钮区域 */}
      <div className="flex items-center justify-around p-2">
      {/* 拍照按钮 */}
      <button
        onClick={handleCamera}
        className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="拍照"
      >
        <Camera className="w-6 h-6 text-blue-600 dark:text-blue-400" />
        <span className="text-xs text-gray-600 dark:text-gray-400 mt-1">拍照</span>
      </button>

      {/* 相册按钮 */}
      <button
        onClick={handleGallery}
        className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="相册"
      >
        <Image className="w-6 h-6 text-green-600 dark:text-green-400" />
        <span className="text-xs text-gray-600 dark:text-gray-400 mt-1">相册</span>
      </button>

      {/* 文件按钮 */}
      <button
        onClick={handleFileSelectClick}
        className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="文件"
      >
        <FileText className="w-6 h-6 text-purple-600 dark:text-purple-400" />
        <span className="text-xs text-gray-600 dark:text-gray-400 mt-1">文件</span>
      </button>

      {/* 语音按钮 */}
      <button
        onClick={handleVoiceRecord}
        className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="语音"
      >
        <Mic className="w-6 h-6 text-red-600 dark:text-red-400" />
        <span className="text-xs text-gray-600 dark:text-gray-400 mt-1">语音</span>
      </button>

      {/* 位置按钮 */}
      <button
        onClick={handleLocationShare}
        className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="位置"
      >
        <MapPin className="w-6 h-6 text-orange-600 dark:text-orange-400" />
        <span className="text-xs text-gray-600 dark:text-gray-400 mt-1">位置</span>
      </button>
      </div>
    </div>
  );
};

export default MobileToolbar;