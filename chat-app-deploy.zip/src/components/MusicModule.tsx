/**
 * 音乐模块组件
 * 展示音乐列表、歌单管理、流派筛选等功能
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Play, 
  Heart, 
  Filter,
  Plus,
  Music,
  Clock,
  User,
  List,
  Trash2,
  Edit
} from 'lucide-react';
import { useMediaStore } from '../store/mediaStore';
import { Track, Playlist } from '../types';

interface MusicModuleProps {
  className?: string;
}

/**
 * 音乐模块组件
 * @param className - 自定义样式类名
 */
const MusicModule: React.FC<MusicModuleProps> = ({ className = '' }) => {
  const navigate = useNavigate();
  const {
    tracks,
    playlists,
    isLoading,
    error,
    loadTracks,
    loadTracksByGenre,
    playContent,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    createPlaylist,
    addToPlaylist,
    removeFromPlaylist,
    deletePlaylist,
    searchContent,
    searchResults,
    clearSearchResults,
  } = useMediaStore();

  const [selectedGenre, setSelectedGenre] = useState<string>('popular');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'tracks' | 'playlists'>('tracks');
  const [showCreatePlaylist, setShowCreatePlaylist] = useState<boolean>(false);
  const [newPlaylistName, setNewPlaylistName] = useState<string>('');
  const [newPlaylistDescription, setNewPlaylistDescription] = useState<string>('');
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);

  // 音乐流派选项
  const genres = [
    { id: 'popular', name: '热门音乐', icon: '🔥' },
    { id: 'pop', name: '流行音乐', icon: '🎵' },
    { id: 'rock', name: '摇滚音乐', icon: '🎸' },
    { id: 'jazz', name: '爵士音乐', icon: '🎺' },
    { id: 'classical', name: '古典音乐', icon: '🎼' },
    { id: 'electronic', name: '电子音乐', icon: '🎛️' },
    { id: 'hip-hop', name: '嘻哈音乐', icon: '🎤' },
    { id: 'country', name: '乡村音乐', icon: '🤠' },
  ];

  /**
   * 组件初始化时加载音乐数据
   */
  useEffect(() => {
    if (selectedGenre === 'popular') {
      loadTracks();
    } else {
      loadTracksByGenre(selectedGenre);
    }
  }, [selectedGenre]);

  /**
   * 处理流派切换
   * @param genreId - 流派ID
   */
  const handleGenreChange = (genreId: string) => {
    setSelectedGenre(genreId);
    clearSearchResults();
  };

  /**
   * 处理播放音乐
   * @param track - 音乐对象
   */
  const handlePlayTrack = (track: Track) => {
    // 跳转到专业播放器页面，确保在移动端有完整的播放体验
    playContent(track, 'track');
    navigate(`/app/video/play/${track.id}`);
  };

  /**
   * 处理收藏切换
   * @param track - 音乐对象
   */
  const handleToggleFavorite = async (track: Track) => {
    if (isFavorite(track.id, 'track')) {
      await removeFromFavorites(track.id, 'track');
    } else {
      await addToFavorites(track.id, 'track');
    }
  };

  /**
   * 处理创建歌单
   */
  const handleCreatePlaylist = async () => {
    if (newPlaylistName.trim()) {
      await createPlaylist(newPlaylistName, newPlaylistDescription);
      setNewPlaylistName('');
      setNewPlaylistDescription('');
      setShowCreatePlaylist(false);
    }
  };

  /**
   * 处理添加到歌单
   * @param playlistId - 歌单ID
   * @param trackId - 音乐ID
   */
  const handleAddToPlaylist = async (playlistId: string, trackId: string) => {
    await addToPlaylist(playlistId, trackId);
  };

  /**
   * 处理从歌单移除
   * @param playlistId - 歌单ID
   * @param trackId - 音乐ID
   */
  const handleRemoveFromPlaylist = async (playlistId: string, trackId: string) => {
    await removeFromPlaylist(playlistId, trackId);
  };

  /**
   * 处理删除歌单
   * @param playlistId - 歌单ID
   */
  const handleDeletePlaylist = async (playlistId: string) => {
    if (confirm('确定要删除这个歌单吗？')) {
      await deletePlaylist(playlistId);
      if (selectedPlaylist?.id === playlistId) {
        setSelectedPlaylist(null);
      }
    }
  };

  /**
   * 格式化时长显示
   * @param seconds - 秒数
   * @returns 格式化的时长字符串
   */
  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  /**
   * 渲染音乐卡片
   * @param track - 音乐对象
   * @param showPlaylistActions - 是否显示歌单操作
   */
  const renderTrackCard = (track: Track, showPlaylistActions = false) => (
    <div
      key={track.id}
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow card-touch"
    >
      <div className="relative">
        <img
          src={track.albumCover}
          alt={track.title}
          className="w-full h-48 object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center group">
          <button
            onClick={() => handlePlayTrack(track)}
            className="bg-blue-600 text-white rounded-full p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform hover:scale-110 shadow-lg touch-feedback button-touch"
            title={`播放 ${track.title}`}
          >
            <Play className="w-6 h-6 fill-current" />
          </button>
        </div>
        <button
          onClick={() => handleToggleFavorite(track)}
          className={`absolute top-2 right-2 p-2 rounded-full transition-colors touch-feedback button-touch ${
            isFavorite(track.id, 'track')
              ? 'bg-red-500 text-white'
              : 'bg-white bg-opacity-80 text-gray-600 hover:bg-red-500 hover:text-white'
          }`}
        >
          <Heart className="w-4 h-4" />
        </button>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1">
          {track.title}
        </h3>
        
        <div className="flex items-center space-x-1 text-sm text-gray-600 mb-2">
          <User className="w-4 h-4" />
          <span>{track.artist}</span>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
          <span>{track.album}</span>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{formatDuration(track.duration)}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {track.genres.slice(0, 2).map((genre) => (
            <span
              key={genre}
              className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
            >
              {genre}
            </span>
          ))}
        </div>

        {/* 歌单操作按钮 */}
        {showPlaylistActions && selectedPlaylist && (
          <div className="flex space-x-2">
            <button
              onClick={() => handleAddToPlaylist(selectedPlaylist.id, track.id)}
              className="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-blue-700 transition-colors"
            >
              添加到歌单
            </button>
            {selectedPlaylist.tracks.some(t => t.id === track.id) && (
              <button
                onClick={() => handleRemoveFromPlaylist(selectedPlaylist.id, track.id)}
                className="bg-red-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );

  /**
   * 渲染歌单卡片
   * @param playlist - 歌单对象
   */
  const renderPlaylistCard = (playlist: Playlist) => (
    <div
      key={playlist.id}
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
      onClick={() => setSelectedPlaylist(playlist)}
    >
      <div className="relative">
        <div className="w-full h-48 bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center">
          <List className="w-16 h-16 text-white" />
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleDeletePlaylist(playlist.id);
          }}
          className="absolute top-2 right-2 p-2 bg-white bg-opacity-80 text-gray-600 rounded-full hover:bg-red-500 hover:text-white transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">
          {playlist.name}
        </h3>
        
        {playlist.description && (
          <p className="text-sm text-gray-600 mb-2 line-clamp-2">
            {playlist.description}
          </p>
        )}
        
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>{playlist.tracks.length} 首歌曲</span>
          <span>{new Date(playlist.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );

  // 获取要显示的音乐列表
  const displayTracks = searchResults?.tracks || tracks;

  return (
    <div className={`space-y-6 overflow-y-auto ${className}`} style={{ maxHeight: 'calc(100vh - 200px)' }}>
      {/* 标签切换 */}
      <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
        <button
          onClick={() => setActiveTab('tracks')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'tracks'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Music className="w-4 h-4 inline-block mr-2" />
          音乐库
        </button>
        <button
          onClick={() => setActiveTab('playlists')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'playlists'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <List className="w-4 h-4 inline-block mr-2" />
          我的歌单
        </button>
      </div>

      {/* 控制栏 */}
      <div className="flex items-center justify-end space-x-4">
        {activeTab === 'tracks' && (
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-gray-100 text-gray-600 p-2 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Filter className="w-5 h-5" />
          </button>
        )}
        {activeTab === 'playlists' && (
          <button
            onClick={() => setShowCreatePlaylist(true)}
            className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* 流派筛选 */}
      {showFilters && activeTab === 'tracks' && (
        <div className="bg-white rounded-lg p-4 shadow-sm border">
          <h4 className="font-medium text-gray-900 mb-3">音乐流派</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {genres.map((genre) => (
              <button
                key={genre.id}
                onClick={() => handleGenreChange(genre.id)}
                className={`flex items-center space-x-2 p-3 rounded-lg text-left transition-colors ${
                  selectedGenre === genre.id
                    ? 'bg-blue-100 text-blue-700 border-2 border-blue-300'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <span className="text-lg">{genre.icon}</span>
                <span className="text-sm font-medium">{genre.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 创建歌单弹窗 */}
      {showCreatePlaylist && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">创建新歌单</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  歌单名称
                </label>
                <input
                  type="text"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="输入歌单名称"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  歌单描述（可选）
                </label>
                <textarea
                  value={newPlaylistDescription}
                  onChange={(e) => setNewPlaylistDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="输入歌单描述"
                  rows={3}
                />
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowCreatePlaylist(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleCreatePlaylist}
                disabled={!newPlaylistName.trim()}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                创建
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 错误提示 */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* 加载状态 */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2 text-gray-600">加载中...</span>
        </div>
      )}

      {/* 内容区域 */}
      {!isLoading && (
        <>
          {/* 音乐库标签 */}
          {activeTab === 'tracks' && (
            <>
              {displayTracks.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {searchResults ? `搜索结果 (${displayTracks.length})` : 
                       genres.find(g => g.id === selectedGenre)?.name || '音乐列表'}
                    </h3>
                    {searchResults && (
                      <button
                        onClick={() => {
                          clearSearchResults();
                        }}
                        className="text-blue-600 hover:text-blue-700 text-sm"
                      >
                        清除搜索
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {displayTracks.map((track) => renderTrackCard(track, !!selectedPlaylist))}
                  </div>
                </div>
              )}

              {displayTracks.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Music className="w-16 h-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {searchResults ? '未找到相关音乐' : '暂无音乐'}
                  </h3>
                  <p className="text-gray-600">
                    {searchResults ? '尝试使用其他关键词搜索' : '请稍后再试'}
                  </p>
                </div>
              )}
            </>
          )}

          {/* 歌单标签 */}
          {activeTab === 'playlists' && (
            <>
              {selectedPlaylist ? (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <button
                        onClick={() => setSelectedPlaylist(null)}
                        className="text-blue-600 hover:text-blue-700 text-sm mb-2"
                      >
                        ← 返回歌单列表
                      </button>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {selectedPlaylist.name}
                      </h3>
                      {selectedPlaylist.description && (
                        <p className="text-gray-600 text-sm">
                          {selectedPlaylist.description}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  {selectedPlaylist.tracks.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 lg:gap-6">
                      {selectedPlaylist.tracks.map((track) => renderTrackCard(track, true))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="text-gray-400 mb-4">
                        <List className="w-16 h-16 mx-auto" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        歌单为空
                      </h3>
                      <p className="text-gray-600">
                        从音乐库中添加歌曲到这个歌单
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {playlists.length > 0 ? (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        我的歌单 ({playlists.length})
                      </h3>
                      
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 lg:gap-6">
                        {playlists.map(renderPlaylistCard)}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="text-gray-400 mb-4">
                        <List className="w-16 h-16 mx-auto" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        还没有歌单
                      </h3>
                      <p className="text-gray-600 mb-4">
                        创建你的第一个歌单来收藏喜欢的音乐
                      </p>
                      <button
                        onClick={() => setShowCreatePlaylist(true)}
                        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        创建歌单
                      </button>
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default MusicModule;