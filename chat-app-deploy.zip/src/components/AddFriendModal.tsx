import React, { useState } from 'react';
import { X, Search, UserPlus, Mail, User as UserIcon } from 'lucide-react';
import { useAppStore } from '../store';
import { User } from '../types';

interface AddFriendModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * 添加好友模态框组件
 * 支持通过邮箱或用户名搜索用户并发送好友申请
 */
export const AddFriendModal: React.FC<AddFriendModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { searchUsers, sendFriendRequest, friends } = useAppStore();
  
  const [searchType, setSearchType] = useState<'email' | 'username'>('username');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [requestMessage, setRequestMessage] = useState('');

  /**
   * 处理搜索
   */
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setSearchResults([]);
    
    try {
      // 搜索用户，只传递查询字符串
      const users = await searchUsers(searchQuery.trim());
      
      // 过滤掉已经是好友的用户
      const filteredUsers = users.filter(user => 
        !friends.some(friend => friend.id === user.id)
      );
      
      setSearchResults(filteredUsers);
    } catch (error) {
      console.error('搜索用户失败:', error);
    } finally {
      setIsSearching(false);
    }
  };

  /**
   * 发送好友申请
   * @param userId - 目标用户ID
   */
  const handleSendFriendRequest = async (userId: string) => {
    try {
      const success = await sendFriendRequest(userId, requestMessage);
      if (success) {
        // 清空申请消息
        setRequestMessage('');
        // 从搜索结果中移除已发送申请的用户
        setSearchResults(prev => prev.filter(user => user.id !== userId));
      }
    } catch (error) {
      console.error('发送好友申请失败:', error);
    }
  };

  /**
   * 处理键盘事件
   */
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  /**
   * 重置状态
   */
  const resetState = () => {
    setSearchQuery('');
    setSearchResults([]);
    setRequestMessage('');
    setIsSearching(false);
  };

  /**
   * 关闭模态框
   */
  const handleClose = () => {
    resetState();
    onClose();
  };

  /**
   * 获取用户头像颜色
   * @param username - 用户名
   * @returns 头像背景色
   */
  const getAvatarColor = (username: string): string => {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
      '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
    ];
    const index = username.charCodeAt(0) % colors.length;
    return colors[index];
  };

  /**
   * 获取用户名首字母
   * @param username - 用户名
   * @returns 首字母
   */
  const getInitials = (username: string): string => {
    return username.charAt(0).toUpperCase();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-md max-h-[80vh] flex flex-col">
        {/* 头部 */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">添加好友</h2>
          <button
            onClick={handleClose}
            className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* 搜索区域 */}
        <div className="p-4 space-y-4">
          {/* 搜索类型选择 - 仅支持用户名搜索 */}
          <div className="flex space-x-2">
            <button
              onClick={() => setSearchType('username')}
              className="flex items-center px-3 py-2 rounded-lg transition-colors bg-blue-500 text-white"
            >
              <UserIcon className="w-4 h-4 mr-2" />
              用户名搜索
            </button>
          </div>

          {/* 搜索输入框 */}
          <div className="flex space-x-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="请输入用户名"
              className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
            />
            <button
              onClick={handleSearch}
              disabled={isSearching || !searchQuery.trim()}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>

          {/* 申请消息输入框 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              申请消息（可选）
            </label>
            <textarea
              value={requestMessage}
              onChange={(e) => setRequestMessage(e.target.value)}
              placeholder="请输入申请消息..."
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              rows={3}
              maxLength={200}
            />
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              {requestMessage.length}/200
            </div>
          </div>
        </div>

        {/* 搜索结果 */}
        <div className="flex-1 overflow-y-auto">
          {isSearching ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          ) : searchResults.length === 0 && searchQuery ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <UserIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>未找到相关用户</p>
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {searchResults.map((user) => (
                <div key={user.id} className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  {/* 头像 */}
                  <div className="flex-shrink-0">
                    {user.avatar ? (
                      <img
                        src={user.avatar}
                        alt={user.username}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                        style={{ backgroundColor: getAvatarColor(user.username) }}
                      >
                        {getInitials(user.username)}
                      </div>
                    )}
                  </div>

                  {/* 用户信息 */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-gray-900 dark:text-white truncate">
                      {user.username}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                      {user.email}
                    </p>
                    {user.bio && (
                      <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 line-clamp-2">
                        {user.bio}
                      </p>
                    )}
                  </div>

                  {/* 添加按钮 */}
                  <button
                    onClick={() => handleSendFriendRequest(user.id)}
                    className="flex items-center px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    <UserPlus className="w-4 h-4 mr-1" />
                    添加
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddFriendModal;