import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Heart, 
  Share2, 
  Download, 
  Eye, 
  ThumbsUp, 
  Star,
  Clock,
  Calendar,
  User,
  Tag,
  Monitor,
  Volume2,
  Languages,
  Subtitles,
  MoreHorizontal,
  Bookmark,
  Flag
} from 'lucide-react';
import { useMediaStore } from '../store/mediaStore';
import { useIsMobile } from '../hooks/useIsMobile';
import { 
  EnhancedMovie, 
  VideoRecommendation, 
  VideoQuality,
  Subtitle,
  AudioTrack
} from '../types';

interface VideoDetailsProps {
  /** 电影详情数据 */
  movie: EnhancedMovie;
  /** 推荐视频列表 */
  recommendations?: VideoRecommendation[];
  /** 用户是否已收藏 */
  isFavorited?: boolean;
  /** 用户评分 */
  userRating?: number;
  /** 点击播放回调 */
  onPlay?: (video: EnhancedMovie) => void;
  /** 点击推荐视频回调 */
  onRecommendationClick?: (video: EnhancedMovie) => void;
  /** 收藏切换回调 */
  onToggleFavorite?: (videoId: string) => void;
  /** 评分回调 */
  onRate?: (videoId: string, rating: number) => void;
}

/**
 * 视频详情组件
 * 显示视频的详细信息、播放控制、相关推荐等
 */
const VideoDetails: React.FC<VideoDetailsProps> = ({
  movie,
  recommendations = [],
  isFavorited = false,
  userRating,
  onPlay,
  onRecommendationClick,
  onToggleFavorite,
  onRate
}) => {
  const { playContent } = useMediaStore();
  const isMobile = useIsMobile();
  
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [selectedQuality, setSelectedQuality] = useState<string>(
    movie.videoQualities.find(q => q.isDefault)?.resolution || movie.videoQualities[0]?.resolution || '1080p'
  );
  const [showTechnicalInfo, setShowTechnicalInfo] = useState(false);
  const [currentRating, setCurrentRating] = useState(userRating || 0);
  const [hoverRating, setHoverRating] = useState(0);

  /**
   * 格式化文件大小
   */
  const formatFileSize = (sizeInMB: number): string => {
    if (sizeInMB >= 1024) {
      return `${(sizeInMB / 1024).toFixed(1)} GB`;
    }
    return `${sizeInMB.toFixed(0)} MB`;
  };

  /**
   * 格式化数字显示
   */
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  /**
   * 格式化时长
   */
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  /**
   * 处理播放按钮点击
   */
  const handlePlay = () => {
    if (onPlay) {
      onPlay(movie);
    } else {
      playContent(movie, 'movie');
    }
  };

  /**
   * 处理收藏切换
   */
  const handleToggleFavorite = () => {
    if (onToggleFavorite) {
      onToggleFavorite(movie.id);
    }
  };

  /**
   * 处理评分
   */
  const handleRate = (rating: number) => {
    setCurrentRating(rating);
    if (onRate) {
      onRate(movie.id, rating);
    }
  };

  /**
   * 处理推荐视频点击
   */
  const handleRecommendationClick = (recommendedVideo: EnhancedMovie) => {
    if (onRecommendationClick) {
      onRecommendationClick(recommendedVideo);
    }
  };

  /**
   * 获取质量选项的详细信息
   */
  const getQualityInfo = (quality: VideoQuality) => {
    return `${quality.resolution} • ${quality.bitrate}kbps${quality.fileSize ? ` • ${formatFileSize(quality.fileSize)}` : ''}`;
  };

  return (
    <div className="max-w-7xl mx-auto p-4 space-y-6">
      {/* 视频标题和基本信息 */}
      <div className="space-y-4">
        <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">
          {movie.title}
        </h1>
        
        {/* 视频统计信息 */}
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-300">
          <div className="flex items-center space-x-1">
            <Eye className="w-4 h-4" />
            <span>{formatNumber(movie.viewCount)} 次观看</span>
          </div>
          <div className="flex items-center space-x-1">
            <Calendar className="w-4 h-4" />
            <span>{new Date(movie.releaseDate).toLocaleDateString('zh-CN')}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{formatDuration(movie.duration)}</span>
          </div>
          {movie.uploader && (
            <div className="flex items-center space-x-1">
              <User className="w-4 h-4" />
              <span>{movie.uploader.name}</span>
            </div>
          )}
        </div>

        {/* 评分显示 */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <Star className="w-5 h-5 text-yellow-400 fill-current" />
            <span className="text-lg font-semibold text-white">
              {movie.averageRating.toFixed(1)}
            </span>
            <span className="text-sm text-gray-400">
              ({formatNumber(movie.ratingCount)} 评分)
            </span>
          </div>
          
          {/* 用户评分 */}
          <div className="flex items-center space-x-1">
            <span className="text-sm text-gray-400">您的评分:</span>
            <div className="flex space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => handleRate(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="transition-colors"
                >
                  <Star 
                    className={`w-4 h-4 ${
                      star <= (hoverRating || currentRating)
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-500'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handlePlay}
          className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
        >
          <Play className="w-5 h-5" />
          <span>播放</span>
        </button>
        
        <button
          onClick={handleToggleFavorite}
          className={`
            flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-colors
            ${isFavorited 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
            }
          `}
        >
          <Heart className={`w-5 h-5 ${isFavorited ? 'fill-current' : ''}`} />
          <span>{isFavorited ? '已收藏' : '收藏'}</span>
        </button>
        
        <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-gray-300 px-4 py-3 rounded-lg font-medium transition-colors">
           <ThumbsUp className="w-5 h-5" />
           <span>{formatNumber(movie.likeCount)}</span>
         </button>
        
        <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-gray-300 px-4 py-3 rounded-lg font-medium transition-colors">
          <Share2 className="w-5 h-5" />
          <span>分享</span>
        </button>
        
        <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-gray-300 px-4 py-3 rounded-lg font-medium transition-colors">
          <Download className="w-5 h-5" />
          <span>下载</span>
        </button>
        
        <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-gray-300 px-4 py-3 rounded-lg font-medium transition-colors">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* 视频描述 */}
      <div className="bg-gray-800 rounded-lg p-6 space-y-4">
        <h3 className="text-lg font-semibold text-white">视频简介</h3>
        
        <div className="text-gray-300 leading-relaxed">
           <p className={showFullDescription ? '' : 'line-clamp-3'}>
             {movie.description}
           </p>
           {movie.description.length > 200 && (
             <button
               onClick={() => setShowFullDescription(!showFullDescription)}
               className="text-green-400 hover:text-green-300 mt-2 text-sm font-medium"
             >
               {showFullDescription ? '收起' : '展开'}
             </button>
           )}
         </div>

         {/* 标签 */}
         {movie.genres && (
           <div className="flex flex-wrap gap-2">
             <Tag className="w-4 h-4 text-gray-400" />
             {movie.genres.map((genre, index) => (
               <span key={index} className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm">
                 {genre}
               </span>
             ))}
           </div>
         )}
      </div>

      {/* 技术信息 */}
      <div className="bg-gray-800 rounded-lg p-6 space-y-4">
        <button
          onClick={() => setShowTechnicalInfo(!showTechnicalInfo)}
          className="flex items-center justify-between w-full text-left"
        >
          <h3 className="text-lg font-semibold text-white">技术信息</h3>
          <span className="text-gray-400">
            {showTechnicalInfo ? '收起' : '展开'}
          </span>
        </button>
        
        {showTechnicalInfo && (
          <div className="space-y-4">
            {/* 视频质量选项 */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Monitor className="w-4 h-4 mr-2" />
                可用质量
              </h4>
              <div className="space-y-2">
                 {movie.videoQualities.map((quality) => (
                  <div
                    key={quality.resolution}
                    className={`
                      p-3 rounded-lg border cursor-pointer transition-colors
                      ${selectedQuality === quality.resolution
                        ? 'border-green-500 bg-green-500/10'
                        : 'border-gray-600 hover:border-gray-500'
                      }
                    `}
                    onClick={() => setSelectedQuality(quality.resolution)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-white">
                        {quality.resolution}
                      </span>
                      <span className="text-sm text-gray-400">
                        {quality.bitrate}kbps
                      </span>
                    </div>
                    {quality.fileSize && (
                      <div className="text-sm text-gray-400 mt-1">
                        文件大小: {formatFileSize(quality.fileSize)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 字幕信息 */}
             {movie.subtitles.length > 0 && (
               <div>
                 <h4 className="text-sm font-medium text-gray-300 mb-2 flex items-center">
                   <Subtitles className="w-4 h-4 mr-2" />
                   可用字幕
                 </h4>
                 <div className="flex flex-wrap gap-2">
                   {movie.subtitles.map((subtitle) => (
                    <span
                      key={subtitle.id}
                      className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm"
                    >
                      {subtitle.label}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* 音轨信息 */}
             {movie.audioTracks.length > 1 && (
               <div>
                 <h4 className="text-sm font-medium text-gray-300 mb-2 flex items-center">
                   <Languages className="w-4 h-4 mr-2" />
                   音轨选项
                 </h4>
                 <div className="flex flex-wrap gap-2">
                   {movie.audioTracks.map((track) => (
                    <span
                      key={track.id}
                      className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm"
                    >
                      {track.label}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 相关推荐 */}
      {recommendations.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-white">相关推荐</h3>
          
          <div className={`
            grid gap-4
            ${isMobile ? 'grid-cols-1' : 'grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'}
          `}>
            {recommendations.map((recommendation) => (
              <div
                key={recommendation.id}
                className="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-750 transition-colors cursor-pointer group"
                onClick={() => handleRecommendationClick(recommendation.video)}
              >
                <div className="relative aspect-video">
                  <img
                    src={recommendation.video.posterUrl}
                    alt={recommendation.video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/75 text-white text-xs px-2 py-1 rounded">
                    {formatDuration(recommendation.video.duration)}
                  </div>
                </div>
                
                <div className="p-4 space-y-2">
                  <h4 className="font-medium text-white line-clamp-2 group-hover:text-green-400 transition-colors">
                    {recommendation.video.title}
                  </h4>
                  
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Eye className="w-3 h-3" />
                      <span>{formatNumber(recommendation.video.viewCount)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-yellow-400 fill-current" />
                      <span>{recommendation.video.averageRating.toFixed(1)}</span>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    推荐原因: {recommendation.reason}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoDetails;