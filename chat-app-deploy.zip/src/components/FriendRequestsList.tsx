import React, { useEffect, useState } from 'react';
import { X, Check, UserX, Clock } from 'lucide-react';
import { useAppStore } from '../store';
import { FriendRequest, User } from '../types';

interface FriendRequestsListProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * 好友申请列表组件
 * 显示待处理的好友申请，支持接受、拒绝和忽略操作
 */
export const FriendRequestsList: React.FC<FriendRequestsListProps> = ({
  isOpen,
  onClose,
}) => {
  const { 
    friendRequests, 
    loadFriendRequests, 
    handleFriendRequest,
    markFriendRequestAsRead,
    users
  } = useAppStore();
  
  const [isLoading, setIsLoading] = useState(false);

  // 加载好友申请
  useEffect(() => {
    if (isOpen) {
      loadFriendRequests();
    }
  }, [isOpen, loadFriendRequests]);

  /**
   * 处理好友申请操作
   * @param requestId - 申请ID
   * @param action - 操作类型（接受/拒绝/忽略）
   */
  const handleAction = async (requestId: string, action: 'accept' | 'reject' | 'ignore') => {
    setIsLoading(true);
    try {
      await handleFriendRequest(requestId, action);
      // 标记为已读
      await markFriendRequestAsRead(requestId);
    } catch (error) {
      console.error('处理好友申请失败:', error);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * 格式化时间显示
   * @param date - 日期对象
   * @returns 格式化后的时间字符串
   */
  const formatTime = (date: Date): string => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    return date.toLocaleDateString();
  };

  /**
   * 获取用户头像颜色
   * @param username - 用户名
   * @returns 头像背景色
   */
  const getAvatarColor = (username: string): string => {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
      '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
    ];
    const index = username.charCodeAt(0) % colors.length;
    return colors[index];
  };

  /**
   * 获取用户名首字母
   * @param username - 用户名
   * @returns 首字母
   */
  const getInitials = (username: string): string => {
    return username.charAt(0).toUpperCase();
  };

  /**
   * 根据用户ID获取用户信息
   * @param userId - 用户ID
   * @returns 用户信息或null
   */
  const getUserById = (userId: string): User | null => {
    return users.find(user => user.id === userId) || null;
  };

  if (!isOpen) return null;

  // 过滤待处理的申请
  const pendingRequests = friendRequests.filter(request => request.status === 'pending');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md mx-4 max-h-[80vh] flex flex-col">
        {/* 头部 */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">新的朋友</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 内容区域 */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          ) : pendingRequests.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-500">
              <UserX className="w-12 h-12 mb-4 opacity-50" />
              <p>暂无好友申请</p>
            </div>
          ) : (
            <div className="p-4 space-y-4">
              {pendingRequests.map((request) => {
                const fromUser = getUserById(request.from_user_id);
                if (!fromUser) return null;

                return (
                  <div key={request.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    {/* 头像 */}
                    <div className="relative">
                      {fromUser.avatar ? (
                        <img
                          src={fromUser.avatar}
                          alt={fromUser.username}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div
                          className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                          style={{ backgroundColor: getAvatarColor(fromUser.username) }}
                        >
                          {getInitials(fromUser.username)}
                        </div>
                      )}
                      {!request.is_read && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
                      )}
                    </div>

                    {/* 用户信息 */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium text-gray-900 truncate">
                          {fromUser.username}
                        </h3>
                        <span className="text-xs text-gray-500 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatTime(new Date(request.created_at))}
                        </span>
                      </div>
                      {request.message && (
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                          {request.message}
                        </p>
                      )}
                    </div>

                    {/* 操作按钮 */}
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleAction(request.id, 'accept')}
                        disabled={isLoading}
                        className="p-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors disabled:opacity-50"
                        title="接受"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleAction(request.id, 'reject')}
                        disabled={isLoading}
                        className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors disabled:opacity-50"
                        title="拒绝"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FriendRequestsList;