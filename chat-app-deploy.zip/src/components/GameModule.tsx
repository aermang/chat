/**
 * 游戏模块组件
 * 展示HTML5游戏列表、分类筛选、游戏得分管理等功能
 */

import React, { useEffect, useState } from 'react';
import { 
  Play, 
  Heart, 
  Filter,
  Trophy,
  Clock,
  Star,
  Gamepad2,
  ExternalLink,
  Award
} from 'lucide-react';
import { useMediaStore } from '../store/mediaStore';
import { Game } from '../types';

interface GameModuleProps {
  className?: string;
}

/**
 * 游戏模块组件
 * @param className - 自定义样式类名
 */
const GameModule: React.FC<GameModuleProps> = ({ className = '' }) => {
  const {
    games,
    gameScores,
    isLoading,
    error,
    loadGames,
    loadGamesByCategory,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    saveGameScore,
    getHighScore,
    searchContent,
    searchResults,
    clearSearchResults,
  } = useMediaStore();

  const [selectedCategory, setSelectedCategory] = useState<string>('popular');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'games' | 'scores'>('games');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [showGameModal, setShowGameModal] = useState<boolean>(false);

  // 游戏分类选项
  const categories = [
    { id: 'popular', name: '热门游戏', icon: '🔥' },
    { id: 'puzzle', name: '益智游戏', icon: '🧩' },
    { id: 'action', name: '动作游戏', icon: '⚡' },
    { id: 'adventure', name: '冒险游戏', icon: '🗺️' },
    { id: 'strategy', name: '策略游戏', icon: '♟️' },
    { id: 'arcade', name: '街机游戏', icon: '🕹️' },
    { id: 'sports', name: '体育游戏', icon: '⚽' },
    { id: 'racing', name: '竞速游戏', icon: '🏎️' },
  ];

  /**
   * 组件初始化时加载游戏数据
   */
  useEffect(() => {
    if (selectedCategory === 'popular') {
      loadGames();
    } else {
      loadGamesByCategory(selectedCategory);
    }
  }, [selectedCategory]);

  /**
   * 处理分类切换
   * @param categoryId - 分类ID
   */
  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId);
    clearSearchResults();
  };

  /**
   * 处理游戏启动
   * @param game - 游戏对象
   */
  const handlePlayGame = (game: Game) => {
    setSelectedGame(game);
    setShowGameModal(true);
  };

  /**
   * 处理收藏切换
   * @param game - 游戏对象
   */
  const handleToggleFavorite = async (game: Game) => {
    if (isFavorite(game.id, 'game')) {
      await removeFromFavorites(game.id, 'game');
    } else {
      await addToFavorites(game.id, 'game');
    }
  };

  /**
   * 处理游戏结束，保存得分
   * @param gameId - 游戏ID
   * @param score - 得分
   * @param playTime - 游戏时长
   */
  const handleGameEnd = async (gameId: string, score: number, playTime: number) => {
    await saveGameScore(gameId, score, playTime);
  };

  /**
   * 格式化游戏时长
   * @param minutes - 分钟数
   * @returns 格式化的时长字符串
   */
  const formatPlayTime = (minutes: number): string => {
    if (minutes < 60) {
      return `${minutes}分钟`;
    }
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}小时${mins > 0 ? `${mins}分钟` : ''}`;
  };

  /**
   * 格式化评分显示
   * @param rating - 评分
   * @returns 格式化的评分字符串
   */
  const formatRating = (rating: number): string => {
    return rating.toFixed(1);
  };

  /**
   * 渲染游戏卡片
   * @param game - 游戏对象
   */
  const renderGameCard = (game: Game) => {
    const highScore = getHighScore(game.id);
    
    return (
      <div
        key={game.id}
        className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow card-touch"
      >
        <div className="relative">
          <img
            src={game.thumbnailUrl}
            alt={game.title}
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center group">
            <button
              onClick={() => handlePlayGame(game)}
              className="bg-green-600 text-white rounded-full p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform hover:scale-110 shadow-lg touch-feedback button-touch"
              title={`开始游戏 ${game.title}`}
            >
              <Play className="w-6 h-6 fill-current" />
            </button>
          </div>
          <button
            onClick={() => handleToggleFavorite(game)}
            className={`absolute top-2 right-2 p-2 rounded-full transition-colors touch-feedback button-touch ${
              isFavorite(game.id, 'game')
                ? 'bg-red-500 text-white'
                : 'bg-white bg-opacity-80 text-gray-600 hover:bg-red-500 hover:text-white'
            }`}
          >
            <Heart className="w-4 h-4" />
          </button>
          {highScore > 0 && (
            <div className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              <Trophy className="w-3 h-3 inline-block mr-1" />
              {highScore}
            </div>
          )}
        </div>
        
        <div className="p-4">
          <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
            {game.title}
          </h3>
          
          <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>{formatRating(game.rating)}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{game.playCount} 次游戏</span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-1 mb-3">
            {game.categories.slice(0, 2).map((category) => (
              <span
                key={category}
                className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
              >
                {category}
              </span>
            ))}
          </div>
          
          <p className="text-sm text-gray-600 line-clamp-2">
            {game.description}
          </p>
          
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
            <span className="text-xs text-gray-500">
              {game.developer}
            </span>
            <button
              onClick={() => handlePlayGame(game)}
              className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-green-700 transition-colors flex items-center space-x-1"
            >
              <Gamepad2 className="w-4 h-4" />
              <span>开始游戏</span>
            </button>
          </div>
        </div>
      </div>
    );
  };

  /**
   * 渲染游戏得分记录
   */
  const renderScoreCard = (score: any) => {
    const game = games.find(g => g.id === score.gameId);
    if (!game) return null;

    return (
      <div
        key={score.id}
        className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center space-x-4">
          <img
            src={game.thumbnailUrl}
            alt={game.title}
            className="w-16 h-16 rounded-lg object-cover"
          />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1">
              {game.title}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span className="font-medium">{score.score}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-4 h-4" />
                <span>{formatPlayTime(score.playTime)}</span>
              </div>
              <span>{new Date(score.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-green-600">
              {score.score}
            </div>
            <div className="text-xs text-gray-500">
              最高分: {getHighScore(game.id)}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // 获取要显示的游戏列表
  const displayGames = searchResults?.games || games;

  return (
    <div className={`space-y-6 overflow-y-auto ${className}`} style={{ maxHeight: 'calc(100vh - 200px)' }}>
      {/* 标签切换 */}
      <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
        <button
          onClick={() => setActiveTab('games')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'games'
              ? 'bg-white text-green-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Gamepad2 className="w-4 h-4 inline-block mr-2" />
          游戏库
        </button>
        <button
          onClick={() => setActiveTab('scores')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'scores'
              ? 'bg-white text-green-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Trophy className="w-4 h-4 inline-block mr-2" />
          游戏记录
        </button>
      </div>

      {/* 筛选控制栏 */}
      <div className="flex items-center justify-end">
        {activeTab === 'games' && (
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-gray-100 text-gray-600 p-2 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Filter className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* 分类筛选 */}
      {showFilters && activeTab === 'games' && (
        <div className="bg-white rounded-lg p-4 shadow-sm border">
          <h4 className="font-medium text-gray-900 mb-3">游戏分类</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleCategoryChange(category.id)}
                className={`flex items-center space-x-2 p-3 rounded-lg text-left transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-green-100 text-green-700 border-2 border-green-300'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <span className="text-lg">{category.icon}</span>
                <span className="text-sm font-medium">{category.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 游戏弹窗 */}
      {showGameModal && selectedGame && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold text-gray-900">
                {selectedGame.title}
              </h3>
              <button
                onClick={() => setShowGameModal(false)}
                className="text-gray-400 hover:text-gray-600 text-xl"
              >
                ×
              </button>
            </div>
            
            <div className="p-4">
              <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
                <iframe
                  src={selectedGame.gameUrl}
                  className="w-full h-full rounded-lg"
                  frameBorder="0"
                  allowFullScreen
                  title={selectedGame.title}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span>{formatRating(selectedGame.rating)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Trophy className="w-4 h-4 text-yellow-500" />
                    <span>最高分: {getHighScore(selectedGame.id)}</span>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleToggleFavorite(selectedGame)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      isFavorite(selectedGame.id, 'game')
                        ? 'bg-red-500 text-white hover:bg-red-600'
                        : 'bg-gray-100 text-gray-600 hover:bg-red-500 hover:text-white'
                    }`}
                  >
                    <Heart className="w-4 h-4 inline-block mr-1" />
                    {isFavorite(selectedGame.id, 'game') ? '已收藏' : '收藏'}
                  </button>
                  
                  <a
                    href={selectedGame.gameUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4 inline-block mr-1" />
                    全屏游戏
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 错误提示 */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* 加载状态 */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <span className="ml-2 text-gray-600">加载中...</span>
        </div>
      )}

      {/* 内容区域 */}
      {!isLoading && (
        <>
          {/* 游戏库标签 */}
          {activeTab === 'games' && (
            <>
              {displayGames.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {searchResults ? `搜索结果 (${displayGames.length})` : 
                       categories.find(c => c.id === selectedCategory)?.name || '游戏列表'}
                    </h3>
                    {searchResults && (
                      <button
                        onClick={() => {
                          clearSearchResults();
                        }}
                        className="text-green-600 hover:text-green-700 text-sm"
                      >
                        清除搜索
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 lg:gap-6">
                    {displayGames.map(renderGameCard)}
                  </div>
                </div>
              )}

              {displayGames.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Gamepad2 className="w-16 h-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {searchResults ? '未找到相关游戏' : '暂无游戏'}
                  </h3>
                  <p className="text-gray-600">
                    {searchResults ? '尝试使用其他关键词搜索' : '请稍后再试'}
                  </p>
                </div>
              )}
            </>
          )}

          {/* 游戏记录标签 */}
          {activeTab === 'scores' && (
            <>
              {gameScores.length > 0 ? (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    游戏记录 ({gameScores.length})
                  </h3>
                  
                  <div className="space-y-4">
                    {gameScores
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map(renderScoreCard)}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Award className="w-16 h-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    还没有游戏记录
                  </h3>
                  <p className="text-gray-600 mb-4">
                    开始游戏来创建你的第一个记录
                  </p>
                  <button
                    onClick={() => setActiveTab('games')}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    浏览游戏
                  </button>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default GameModule;