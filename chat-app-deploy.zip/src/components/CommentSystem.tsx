import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, 
  ThumbsUp, 
  ThumbsDown, 
  Reply, 
  MoreHorizontal,
  Send,
  Star,
  Heart,
  Flag,
  Edit3,
  Trash2,
  User,
  Clock,
  Pin,
  Award,
  Smile,
  Image,
  AtSign
} from 'lucide-react';
import { useIsMobile } from '../hooks/useIsMobile';
import { 
  VideoComment, 
  VideoRating,
  CommentSystemState,
  CommentActions
} from '../types';

interface CommentSystemProps {
  /** 视频ID */
  videoId: string;
  /** 评论列表 */
  comments: VideoComment[];
  /** 评论总数 */
  totalComments: number;
  /** 当前用户ID */
  currentUserId?: string;
  /** 是否允许评论 */
  allowComments?: boolean;
  /** 是否允许评分 */
  allowRating?: boolean;
  /** 当前用户评分 */
  userRating?: VideoRating;
  /** 评论排序方式 */
  sortBy?: 'newest' | 'oldest' | 'likes' | 'replies';
  /** 发布评论回调 */
  onSubmitComment?: (content: string, parentId?: string) => Promise<void>;
  /** 点赞评论回调 */
  onLikeComment?: (commentId: string) => Promise<void>;
  /** 踩评论回调 */
  onDislikeComment?: (commentId: string) => Promise<void>;
  /** 回复评论回调 */
  onReplyComment?: (commentId: string, content: string) => Promise<void>;
  /** 删除评论回调 */
  onDeleteComment?: (commentId: string) => Promise<void>;
  /** 举报评论回调 */
  onReportComment?: (commentId: string, reason: string) => Promise<void>;
  /** 提交评分回调 */
  onSubmitRating?: (rating: number, comment?: string) => Promise<void>;
  /** 加载更多评论回调 */
  onLoadMore?: () => Promise<void>;
}

/**
 * 评论系统组件
 * 提供完整的评论功能，包括发布、回复、点赞、评分等
 */
const CommentSystem: React.FC<CommentSystemProps> = ({
  videoId,
  comments,
  totalComments,
  currentUserId,
  allowComments = true,
  allowRating = true,
  userRating,
  sortBy = 'newest',
  onSubmitComment,
  onLikeComment,
  onDislikeComment,
  onReplyComment,
  onDeleteComment,
  onReportComment,
  onSubmitRating,
  onLoadMore
}) => {
  const isMobile = useIsMobile();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [ratingValue, setRatingValue] = useState(userRating?.rating || 0);
  const [ratingComment, setRatingComment] = useState(userRating?.review || '');
  const [hoverRating, setHoverRating] = useState(0);
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  /**
   * 格式化时间显示
   */
  const formatTimeAgo = (date: Date): string => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return '刚刚';
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)}分钟前`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)}小时前`;
    } else if (diffInSeconds < 2592000) {
      return `${Math.floor(diffInSeconds / 86400)}天前`;
    } else {
      return date.toLocaleDateString('zh-CN');
    }
  };

  /**
   * 格式化数字显示
   */
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  /**
   * 处理评论提交
   */
  const handleSubmitComment = async () => {
    if (!newComment.trim() || !onSubmitComment || isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      await onSubmitComment(newComment.trim());
      setNewComment('');
    } catch (error) {
      console.error('提交评论失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * 处理回复提交
   */
  const handleSubmitReply = async (parentId: string) => {
    if (!replyContent.trim() || !onReplyComment || isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      await onReplyComment(parentId, replyContent.trim());
      setReplyContent('');
      setReplyingTo(null);
    } catch (error) {
      console.error('提交回复失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * 处理评分提交
   */
  const handleSubmitRating = async () => {
    if (!onSubmitRating || ratingValue === 0) return;
    
    try {
      await onSubmitRating(ratingValue, ratingComment.trim() || undefined);
      setShowRatingModal(false);
    } catch (error) {
      console.error('提交评分失败:', error);
    }
  };

  /**
   * 切换评论展开状态
   */
  const toggleCommentExpanded = (commentId: string) => {
    const newExpanded = new Set(expandedComments);
    if (newExpanded.has(commentId)) {
      newExpanded.delete(commentId);
    } else {
      newExpanded.add(commentId);
    }
    setExpandedComments(newExpanded);
  };

  /**
   * 处理点赞
   */
  const handleLike = async (commentId: string) => {
    if (onLikeComment) {
      await onLikeComment(commentId);
    }
  };

  /**
   * 处理踩
   */
  const handleDislike = async (commentId: string) => {
    if (onDislikeComment) {
      await onDislikeComment(commentId);
    }
  };

  /**
   * 渲染评论项
   */
  const renderComment = (comment: VideoComment, isReply: boolean = false) => {
    const isExpanded = expandedComments.has(comment.id);
    const canDelete = currentUserId === comment.userId;
    const hasLiked = comment.isLiked || false;
    const hasDisliked = false; // 暂时设为false，因为接口中没有dislike相关字段

    return (
      <div
        key={comment.id}
        className={`
          ${isReply ? 'ml-8 border-l-2 border-gray-700 pl-4' : ''}
          space-y-3
        `}
      >
        <div className="flex space-x-3">
          {/* 用户头像 */}
          <div className="flex-shrink-0">
            {comment.userAvatar ? (
              <img
                src={comment.userAvatar}
                alt={comment.userName}
                className="w-8 h-8 rounded-full object-cover"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                <User className="w-4 h-4 text-gray-300" />
              </div>
            )}
          </div>

          {/* 评论内容 */}
          <div className="flex-1 space-y-2">
            {/* 用户信息和时间 */}
            <div className="flex items-center space-x-2">
              <span className="font-medium text-white">
                {comment.userName}
              </span>
              <span className="text-sm text-gray-400">
                {formatTimeAgo(comment.createdAt)}
              </span>
            </div>

            {/* 评论文本 */}
            <div className="text-gray-200 leading-relaxed">
              <p className={isExpanded || comment.content.length <= 200 ? '' : 'line-clamp-3'}>
                {comment.content}
              </p>
              {comment.content.length > 200 && (
                <button
                  onClick={() => toggleCommentExpanded(comment.id)}
                  className="text-green-400 hover:text-green-300 text-sm mt-1"
                >
                  {isExpanded ? '收起' : '展开'}
                </button>
              )}
            </div>

            {/* 评论操作 */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => handleLike(comment.id)}
                className={`
                  flex items-center space-x-1 text-sm transition-colors
                  ${hasLiked 
                    ? 'text-green-400' 
                    : 'text-gray-400 hover:text-green-400'
                  }
                `}
              >
                <ThumbsUp className={`w-4 h-4 ${hasLiked ? 'fill-current' : ''}`} />
                <span>{formatNumber(comment.likeCount)}</span>
              </button>

              <button
                onClick={() => handleDislike(comment.id)}
                className={`
                  flex items-center space-x-1 text-sm transition-colors
                  ${hasDisliked 
                    ? 'text-red-400' 
                    : 'text-gray-400 hover:text-red-400'
                  }
                `}
              >
                <ThumbsDown className={`w-4 h-4 ${hasDisliked ? 'fill-current' : ''}`} />
                <span>0</span>
              </button>

              {allowComments && (
                <button
                  onClick={() => setReplyingTo(comment.id)}
                  className="flex items-center space-x-1 text-sm text-gray-400 hover:text-green-400 transition-colors"
                >
                  <Reply className="w-4 h-4" />
                  <span>回复</span>
                </button>
              )}

              {/* 更多操作 */}
              <div className="relative">
                <button className="text-gray-400 hover:text-white transition-colors">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 回复输入框 */}
            {replyingTo === comment.id && (
              <div className="space-y-3 mt-4">
                <textarea
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  placeholder={`回复 @${comment.userName}...`}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-green-500 resize-none"
                  rows={3}
                />
                <div className="flex items-center justify-end space-x-3">
                  <button
                    onClick={() => {
                      setReplyingTo(null);
                      setReplyContent('');
                    }}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    取消
                  </button>
                  <button
                    onClick={() => handleSubmitReply(comment.id)}
                    disabled={!replyContent.trim() || isSubmitting}
                    className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    <span>回复</span>
                  </button>
                </div>
              </div>
            )}

            {/* 子回复 */}
            {comment.replies && comment.replies.length > 0 && (
              <div className="space-y-4 mt-4">
                {comment.replies.map((reply) => renderComment(reply, true))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* 评论统计和排序 */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-white flex items-center space-x-2">
          <MessageCircle className="w-5 h-5" />
          <span>{formatNumber(totalComments)} 条评论</span>
        </h3>
        
        <div className="flex items-center space-x-4">
          {allowRating && (
            <button
              onClick={() => setShowRatingModal(true)}
              className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Star className="w-4 h-4" />
              <span>评分</span>
            </button>
          )}
          
          <select
            value={sortBy}
            className="bg-gray-700 border border-gray-600 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-green-500"
          >
            <option value="newest">最新</option>
            <option value="oldest">最早</option>
            <option value="likes">最多赞</option>
            <option value="replies">最多回复</option>
          </select>
        </div>
      </div>

      {/* 发表评论 */}
      {allowComments && currentUserId && (
        <div className="bg-gray-800 rounded-lg p-6 space-y-4">
          <h4 className="text-lg font-medium text-white">发表评论</h4>
          
          <div className="space-y-3">
            <textarea
              ref={textareaRef}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="写下你的想法..."
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-green-500 resize-none"
              rows={4}
            />
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <button className="text-gray-400 hover:text-white transition-colors">
                  <Smile className="w-5 h-5" />
                </button>
                <button className="text-gray-400 hover:text-white transition-colors">
                  <Image className="w-5 h-5" />
                </button>
                <button className="text-gray-400 hover:text-white transition-colors">
                  <AtSign className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <span className="text-sm text-gray-400">
                  {newComment.length}/1000
                </span>
                <button
                  onClick={handleSubmitComment}
                  disabled={!newComment.trim() || isSubmitting}
                  className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>发布</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 评论列表 */}
      <div className="space-y-6">
        {comments.map((comment) => renderComment(comment))}
      </div>

      {/* 加载更多 */}
      {comments.length < totalComments && onLoadMore && (
        <div className="text-center">
          <button
            onClick={onLoadMore}
            className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors"
          >
            加载更多评论
          </button>
        </div>
      )}

      {/* 评分模态框 */}
      {showRatingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-white">为视频评分</h3>
              <button
                onClick={() => setShowRatingModal(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                ×
              </button>
            </div>
            
            {/* 星级评分 */}
            <div className="text-center space-y-4">
              <div className="flex justify-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRatingValue(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="transition-colors"
                  >
                    <Star 
                      className={`w-8 h-8 ${
                        star <= (hoverRating || ratingValue)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-500'
                      }`}
                    />
                  </button>
                ))}
              </div>
              
              <div className="text-lg font-medium text-white">
                {ratingValue > 0 && (
                  <span>
                    {ratingValue === 1 && '很差'}
                    {ratingValue === 2 && '较差'}
                    {ratingValue === 3 && '一般'}
                    {ratingValue === 4 && '不错'}
                    {ratingValue === 5 && '很棒'}
                  </span>
                )}
              </div>
            </div>
            
            {/* 评分评论 */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-300">
                评价 (可选)
              </label>
              <textarea
                value={ratingComment}
                onChange={(e) => setRatingComment(e.target.value)}
                placeholder="分享你的观看体验..."
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-green-500 resize-none"
                rows={3}
              />
            </div>
            
            {/* 操作按钮 */}
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setShowRatingModal(false)}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleSubmitRating}
                disabled={ratingValue === 0}
                className="bg-green-500 hover:bg-green-600 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
              >
                提交评分
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommentSystem;