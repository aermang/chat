/**
 * 影视模块组件
 * 展示电影列表、分类筛选、搜索等功能
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Play, 
  Heart, 
  Filter,
  Star,
  Clock,
  Calendar,
  Grid3X3,
  List,
  SlidersHorizontal,
  Eye,
  Download,
  Share2,
  Info,
  ChevronDown,
  X,
  Bookmark,
  TrendingUp,
  Award,
  Users,
  Zap
} from 'lucide-react';
import { useMediaStore } from '../store/mediaStore';
import { useIsMobile } from '../hooks/useIsMobile';
import { EnhancedMovie } from '../types';

interface MovieModuleProps {
  className?: string;
  /** 点击视频详情回调 */
  onVideoDetails?: (movie: EnhancedMovie) => void;
  /** 点击播放回调 */
  onPlay?: (movie: EnhancedMovie) => void;
}

type ViewMode = 'grid' | 'list';
type SortBy = 'newest' | 'oldest' | 'rating' | 'views' | 'duration' | 'title';

/**
 * 影视模块组件
 * @param className - 自定义样式类名
 * @param onVideoDetails - 点击视频详情回调
 * @param onPlay - 点击播放回调
 */
const MovieModule: React.FC<MovieModuleProps> = ({ 
  className = '',
  onVideoDetails,
  onPlay
}) => {
  const navigate = useNavigate();
  const {
    movies,
    isLoading,
    error,
    loadMovies,
    loadMoviesByCategory,
    playContent,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    searchContent,
    searchResults,
    clearSearchResults,
  } = useMediaStore();

  const isMobile = useIsMobile();
  
  const [selectedCategory, setSelectedCategory] = useState<string>('popular');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortBy>('newest');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState<boolean>(false);
  
  // 高级筛选状态
  const [filters, setFilters] = useState({
    minRating: 0,
    maxRating: 10,
    minDuration: 0,
    maxDuration: 300,
    genres: [] as string[],
    years: [] as number[],
    quality: [] as string[]
  });

  // 电影分类选项
  const categories = [
    { id: 'popular', name: '热门推荐', icon: '🔥', color: 'bg-red-500' },
    { id: 'trending', name: '趋势榜单', icon: '📈', color: 'bg-green-500' },
    { id: 'new', name: '最新上映', icon: '✨', color: 'bg-blue-500' },
    { id: 'action', name: '动作片', icon: '💥', color: 'bg-orange-500' },
    { id: 'comedy', name: '喜剧片', icon: '😄', color: 'bg-yellow-500' },
    { id: 'drama', name: '剧情片', icon: '🎭', color: 'bg-purple-500' },
    { id: 'horror', name: '恐怖片', icon: '👻', color: 'bg-gray-700' },
    { id: 'romance', name: '爱情片', icon: '💕', color: 'bg-pink-500' },
    { id: 'sci-fi', name: '科幻片', icon: '🚀', color: 'bg-indigo-500' },
    { id: 'documentary', name: '纪录片', icon: '📹', color: 'bg-teal-500' },
  ];

  // 排序选项
  const sortOptions = [
    { value: 'newest', label: '最新发布', icon: Clock },
    { value: 'oldest', label: '最早发布', icon: Calendar },
    { value: 'rating', label: '评分最高', icon: Star },
    { value: 'views', label: '观看最多', icon: Eye },
    { value: 'duration', label: '时长排序', icon: Clock },
    { value: 'title', label: '标题排序', icon: List }
  ];

  // 可用类型
  const availableGenres = [
    '动作', '喜剧', '剧情', '恐怖', '爱情', '科幻', '悬疑', '犯罪',
    '战争', '历史', '传记', '音乐', '家庭', '冒险', '奇幻', '动画'
  ];

  // 可用年份
  const availableYears = Array.from({ length: 30 }, (_, i) => new Date().getFullYear() - i);

  // 可用质量
  const availableQualities = ['4K', '1080p', '720p', '480p'];

  /**
   * 组件初始化时加载电影数据
   */
  useEffect(() => {
    if (selectedCategory === 'popular') {
      loadMovies();
    } else {
      loadMoviesByCategory(selectedCategory);
    }
  }, [selectedCategory]);

  /**
   * 处理分类切换
   * @param categoryId - 分类ID
   */
  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId);
    clearSearchResults();
  };

  /**
   * 处理播放电影
   * @param movie - 电影对象
   */
  const handlePlayMovie = (movie: EnhancedMovie) => {
    if (onPlay) {
      onPlay(movie);
    } else {
      // 跳转到专业播放器页面，确保在移动端有完整的播放体验
      playContent(movie, 'movie');
      navigate(`/app/video/play/${movie.id}`);
    }
  };

  /**
   * 处理视频详情
   * @param movie - 电影对象
   */
  const handleVideoDetails = (movie: EnhancedMovie) => {
    if (onVideoDetails) {
      onVideoDetails(movie);
    }
  };

  /**
   * 处理收藏切换
   * @param movie - 电影对象
   */
  const handleToggleFavorite = async (movie: EnhancedMovie) => {
    if (isFavorite(movie.id, 'movie')) {
      await removeFromFavorites(movie.id, 'movie');
    } else {
      await addToFavorites(movie.id, 'movie');
    }
  };

  /**
   * 格式化时长显示
   * @param seconds - 秒数
   * @returns 格式化的时长字符串
   */
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  /**
   * 格式化数字显示
   */
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  /**
   * 应用筛选和排序
   */
  const getFilteredAndSortedMovies = (): EnhancedMovie[] => {
    let movieList = searchResults?.movies || movies;
    
    // 应用筛选
    movieList = movieList.filter(movie => {
      if (movie.averageRating < filters.minRating || movie.averageRating > filters.maxRating) {
        return false;
      }
      
      const durationMinutes = movie.duration / 60;
      if (durationMinutes < filters.minDuration || durationMinutes > filters.maxDuration) {
        return false;
      }
      
      if (filters.genres.length > 0 && !filters.genres.some(genre => movie.genres.includes(genre))) {
        return false;
      }
      
      const movieYear = new Date(movie.releaseDate).getFullYear();
      if (filters.years.length > 0 && !filters.years.includes(movieYear)) {
        return false;
      }
      
      return true;
    });
    
    // 应用排序
    movieList.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime();
        case 'oldest':
          return new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime();
        case 'rating':
          return b.averageRating - a.averageRating;
        case 'views':
          return b.viewCount - a.viewCount;
        case 'duration':
          return b.duration - a.duration;
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });
    
    return movieList;
  };

  /**
   * 渲染网格视图电影卡片
   * @param movie - 电影对象
   */
  const renderGridMovieCard = (movie: EnhancedMovie) => (
    <div
      key={movie.id}
      className="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-750 transition-all duration-300 group cursor-pointer"
    >
      <div className="relative aspect-[2/3]">
        <img
          src={movie.posterUrl}
          alt={movie.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        
        {/* 悬浮操作层 */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all duration-300 flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handlePlayMovie(movie);
              }}
              className="bg-green-500 hover:bg-green-600 text-white rounded-full p-3 transition-colors"
              title="播放"
            >
              <Play className="w-5 h-5 fill-current" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleVideoDetails(movie);
              }}
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3 transition-colors"
              title="详情"
            >
              <Info className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {/* 质量标签 */}
        {movie.videoQualities.length > 0 && (
          <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
            {movie.videoQualities[0].resolution}
          </div>
        )}
        
        {/* 收藏按钮 */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleToggleFavorite(movie);
          }}
          className={`
            absolute top-2 right-2 p-2 rounded-full transition-colors
            ${isFavorite(movie.id, 'movie')
              ? 'bg-red-500 text-white'
              : 'bg-black/50 text-white hover:bg-red-500'
            }
          `}
        >
          <Heart className={`w-4 h-4 ${isFavorite(movie.id, 'movie') ? 'fill-current' : ''}`} />
        </button>
        
        {/* 时长 */}
        <div className="absolute bottom-2 right-2 bg-black/75 text-white text-xs px-2 py-1 rounded">
          {formatDuration(movie.duration)}
        </div>
      </div>
      
      <div className="p-4 space-y-2">
        <h3 className="font-semibold text-white line-clamp-2 group-hover:text-green-400 transition-colors">
          {movie.title}
        </h3>
        
        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center space-x-1">
            <Star className="w-3 h-3 text-yellow-400 fill-current" />
            <span>{movie.averageRating.toFixed(1)}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Eye className="w-3 h-3" />
            <span>{formatNumber(movie.viewCount)}</span>
          </div>
        </div>
        
        <div className="text-xs text-gray-500">
          {new Date(movie.releaseDate).getFullYear()} • {movie.genres.join(', ')}
        </div>
      </div>
    </div>
  );

  /**
   * 渲染列表视图电影卡片
   * @param movie - 电影对象
   */
  const renderListMovieCard = (movie: EnhancedMovie) => (
    <div
      key={movie.id}
      className="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-750 transition-colors group cursor-pointer"
      onClick={() => handleVideoDetails(movie)}
    >
      <div className="flex space-x-4 p-4">
        <div className="relative flex-shrink-0 w-32 aspect-[2/3]">
          <img
            src={movie.posterUrl}
            alt={movie.title}
            className="w-full h-full object-cover rounded-lg"
            loading="lazy"
          />
          
          {/* 质量标签 */}
          {movie.videoQualities.length > 0 && (
            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
              {movie.videoQualities[0].resolution}
            </div>
          )}
          
          {/* 时长 */}
          <div className="absolute bottom-2 right-2 bg-black/75 text-white text-xs px-2 py-1 rounded">
            {formatDuration(movie.duration)}
          </div>
        </div>
        
        <div className="flex-1 space-y-3">
          <div>
            <h3 className="text-lg font-semibold text-white group-hover:text-green-400 transition-colors line-clamp-2">
              {movie.title}
            </h3>
            <p className="text-gray-400 text-sm mt-1 line-clamp-3">
              {movie.description}
            </p>
          </div>
          
          <div className="flex items-center space-x-6 text-sm text-gray-400">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span>{movie.averageRating.toFixed(1)}</span>
              <span>({formatNumber(movie.ratingCount)})</span>
            </div>
            <div className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span>{formatNumber(movie.viewCount)}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Calendar className="w-4 h-4" />
              <span>{new Date(movie.releaseDate).getFullYear()}</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {movie.genres.map((genre, index) => (
                <span key={index} className="bg-gray-700 text-gray-300 px-2 py-1 rounded-full text-xs">
                  {genre}
                </span>
              ))}
              {movie.uploader && (
                <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded-full text-xs">
                  {movie.uploader.name}
                </span>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleFavorite(movie);
                }}
                className={`
                  p-2 rounded-full transition-colors
                  ${isFavorite(movie.id, 'movie')
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-red-500 hover:text-white'
                  }
                `}
              >
                <Heart className={`w-4 h-4 ${isFavorite(movie.id, 'movie') ? 'fill-current' : ''}`} />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handlePlayMovie(movie);
                }}
                className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>播放</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // 获取要显示的电影列表
  const displayMovies = getFilteredAndSortedMovies();

  return (
    <div className={`bg-gray-900 min-h-screen ${className}`}>
      <div className="max-w-7xl mx-auto p-4 space-y-6">
        {/* 控制栏 */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          {/* 控制按钮 */}
          <div className="flex items-center space-x-3">
            {/* 视图切换 */}
            <div className="flex bg-gray-800 rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`
                  p-2 rounded-md transition-colors
                  ${viewMode === 'grid' 
                    ? 'bg-green-500 text-white' 
                    : 'text-gray-400 hover:text-white'
                  }
                `}
              >
                <Grid3X3 className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`
                  p-2 rounded-md transition-colors
                  ${viewMode === 'list' 
                    ? 'bg-green-500 text-white' 
                    : 'text-gray-400 hover:text-white'
                  }
                `}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
            
            {/* 排序 */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortBy)}
              className="bg-gray-800 border border-gray-700 text-white px-4 py-2 rounded-lg focus:outline-none focus:border-green-500"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            
            {/* 筛选按钮 */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`
                p-2 rounded-lg transition-colors
                ${showFilters 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-800 text-gray-400 hover:text-white'
                }
              `}
            >
              <Filter className="w-5 h-5" />
            </button>
            
            {/* 高级筛选按钮 */}
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`
                p-2 rounded-lg transition-colors
                ${showAdvancedFilters 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-800 text-gray-400 hover:text-white'
                }
              `}
            >
              <SlidersHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 分类筛选 */}
        {showFilters && (
          <div className="bg-gray-800 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-white">电影分类</h4>
              <button
                onClick={() => setShowFilters(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className={`
              grid gap-3
              ${isMobile ? 'grid-cols-2' : 'grid-cols-3 lg:grid-cols-5'}
            `}>
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleCategoryChange(category.id)}
                  className={`
                    flex items-center space-x-3 p-4 rounded-lg text-left transition-all duration-200
                    ${selectedCategory === category.id
                      ? 'bg-green-500 text-white shadow-lg scale-105'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600 hover:scale-102'
                    }
                  `}
                >
                  <div className={`
                    w-10 h-10 rounded-lg flex items-center justify-center text-lg
                    ${selectedCategory === category.id ? 'bg-white/20' : category.color}
                  `}>
                    {category.icon}
                  </div>
                  <div>
                    <div className="font-medium">{category.name}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 高级筛选 */}
        {showAdvancedFilters && (
          <div className="bg-gray-800 rounded-lg p-6 space-y-6">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-white">高级筛选</h4>
              <button
                onClick={() => setShowAdvancedFilters(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 评分范围 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-300">
                  评分范围: {filters.minRating} - {filters.maxRating}
                </label>
                <div className="flex items-center space-x-4">
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="0.1"
                    value={filters.minRating}
                    onChange={(e) => setFilters(prev => ({ ...prev, minRating: parseFloat(e.target.value) }))}
                    className="flex-1"
                  />
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="0.1"
                    value={filters.maxRating}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxRating: parseFloat(e.target.value) }))}
                    className="flex-1"
                  />
                </div>
              </div>
              
              {/* 时长范围 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-300">
                  时长范围: {filters.minDuration}min - {filters.maxDuration}min
                </label>
                <div className="flex items-center space-x-4">
                  <input
                    type="range"
                    min="0"
                    max="300"
                    step="5"
                    value={filters.minDuration}
                    onChange={(e) => setFilters(prev => ({ ...prev, minDuration: parseInt(e.target.value) }))}
                    className="flex-1"
                  />
                  <input
                    type="range"
                    min="0"
                    max="300"
                    step="5"
                    value={filters.maxDuration}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxDuration: parseInt(e.target.value) }))}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
            
            {/* 重置筛选 */}
            <div className="flex justify-end">
              <button
                onClick={() => setFilters({
                  minRating: 0,
                  maxRating: 10,
                  minDuration: 0,
                  maxDuration: 300,
                  genres: [],
                  years: [],
                  quality: []
                })}
                className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
              >
                重置筛选
              </button>
            </div>
          </div>
        )}

        {/* 错误提示 */}
        {error && (
          <div className="bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        {/* 加载状态 */}
        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
            <span className="ml-4 text-gray-300 text-lg">加载中...</span>
          </div>
        )}

        {/* 电影列表 */}
        {!isLoading && displayMovies.length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-white">
                {searchResults ? `搜索结果 (${displayMovies.length})` : 
                 categories.find(c => c.id === selectedCategory)?.name || '电影列表'}
              </h3>
              {searchResults && (
                <button
                  onClick={() => {
                    clearSearchResults();
                  }}
                  className="text-green-400 hover:text-green-300 text-sm font-medium"
                >
                  清除搜索
                </button>
              )}
            </div>
            
            {viewMode === 'grid' ? (
              <div className={`
                grid gap-4
                ${isMobile 
                  ? 'grid-cols-2' 
                  : 'grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6'
                }
              `}>
                {displayMovies.map(renderGridMovieCard)}
              </div>
            ) : (
              <div className="space-y-4">
                {displayMovies.map(renderListMovieCard)}
              </div>
            )}
          </div>
        )}

        {/* 空状态 */}
        {!isLoading && displayMovies.length === 0 && (
          <div className="text-center py-20">
            <div className="text-gray-500 mb-6">
              <Play className="w-20 h-20 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">
              {searchResults ? '未找到相关电影' : '暂无电影'}
            </h3>
            <p className="text-gray-400 mb-6">
              {searchResults ? '尝试使用其他关键词搜索' : '请稍后再试'}
            </p>
            {searchResults && (
              <button
                onClick={() => {
                  clearSearchResults();
                }}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition-colors"
              >
                浏览所有电影
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MovieModule;