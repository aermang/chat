/**
 * 通知徽章组件
 * 用于显示未读消息数量的红色徽章
 */

import React from 'react';

interface NotificationBadgeProps {
  /** 未读数量 */
  count: number;
  /** 最大显示数量，超过显示99+ */
  maxCount?: number;
  /** 是否显示为小圆点（不显示数字） */
  dot?: boolean;
  /** 自定义样式类名 */
  className?: string;
  /** 徽章位置 */
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
  /** 子元素 */
  children?: React.ReactNode;
}

/**
 * 通知徽章组件
 */
export const NotificationBadge: React.FC<NotificationBadgeProps> = ({
  count,
  maxCount = 99,
  dot = false,
  className = '',
  position = 'top-right',
  children
}) => {
  // 如果没有未读消息且不是强制显示圆点模式，不显示徽章
  if (count <= 0 && !dot) {
    return <>{children}</>;
  }

  // 计算显示的数字
  const displayCount = count > maxCount ? `${maxCount}+` : count.toString();

  // 位置样式映射
  const positionClasses = {
    'top-right': '-top-1 -right-1',
    'top-left': '-top-1 -left-1',
    'bottom-right': '-bottom-1 -right-1',
    'bottom-left': '-bottom-1 -left-1'
  };

  return (
    <div className="relative inline-block">
      {children}
      {(count > 0 || dot) && (
        <div
          className={`
            absolute ${positionClasses[position]}
            bg-red-500 text-white text-xs font-bold
            flex items-center justify-center
            ${dot ? 'w-2 h-2' : 'min-w-[18px] h-[18px] px-1'}
            rounded-full
            border-2 border-white
            ${className}
          `}
        >
          {!dot && displayCount}
        </div>
      )}
    </div>
  );
};

export default NotificationBadge;