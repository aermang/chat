/**
 * 飞鸽风格即时通讯App - 路由保护组件
 * 用于保护需要认证的路由，未认证用户将被重定向到登录页面
 */

import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAppStore } from '../store';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * 路由保护组件
 * 检查用户认证状态，未认证则重定向到登录页面
 */
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated, currentUser } = useAppStore();
  
  // 如果未认证或没有当前用户，重定向到登录页面
  if (!isAuthenticated || !currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  // 已认证，渲染子组件
  return <>{children}</>;
};

export default ProtectedRoute;