/**
 * 飞鸽风格即时通讯App - 媒体播放器组件
 * 支持视频和音频播放，提供完整的播放控制功能
 * 优化版本：增强桌面端窗口控制和移动端兼容性
 */

import React, { useRef, useEffect, useState } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  SkipBack, 
  SkipForward,
  Maximize,
  Minimize,
  RotateCcw,
  X,
  Minimize2,
  Square,
  PictureInPicture,
  Settings
} from 'lucide-react';
import { useMediaStore } from '../store/mediaStore';
import { useIsMobile } from '../hooks/useIsMobile';
import { Movie, Track, EnhancedMovie, PlaybackRate } from '../types';

interface MediaPlayerProps {
  className?: string;
}

/**
 * 媒体播放器组件
 * @param className - 自定义样式类名
 */
const MediaPlayer: React.FC<MediaPlayerProps> = ({ className = '' }) => {
  const {
    currentPlaying,
    pauseContent,
    resumeContent,
    stopContent,
    setProgress,
    setVolume,
    playerState,
  } = useMediaStore();

  const isMobile = useIsMobile();
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [controlsTimeout, setControlsTimeout] = useState<NodeJS.Timeout | null>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isPiPMode, setIsPiPMode] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSettings, setShowSettings] = useState(false);
  
  // 移动端触摸手势状态
  const [touchStart, setTouchStart] = useState<{ x: number; y: number; time: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  /**
   * 获取当前媒体元素
   */
  const getCurrentMediaElement = () => {
    return currentPlaying.type === 'movie' ? videoRef.current : audioRef.current;
  };

  /**
   * 格式化时间显示
   * @param seconds - 秒数
   * @returns 格式化的时间字符串
   */
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  /**
   * 处理播放/暂停 - 增强移动端兼容性
   */
  const handlePlayPause = async () => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) {
      console.error('媒体元素不存在');
      return;
    }

    try {
      if (currentPlaying.isPlaying) {
        await mediaElement.pause();
        pauseContent();
      } else {
        // 确保媒体元素已加载
        if (mediaElement.readyState < 2) {
          console.log('等待媒体加载...');
          await new Promise((resolve) => {
            const handleCanPlay = () => {
              mediaElement.removeEventListener('canplay', handleCanPlay);
              resolve(void 0);
            };
            mediaElement.addEventListener('canplay', handleCanPlay);
            
            // 如果5秒内没有加载完成，也继续尝试播放
            setTimeout(() => {
              mediaElement.removeEventListener('canplay', handleCanPlay);
              resolve(void 0);
            }, 5000);
          });
        }
        
        await mediaElement.play();
        resumeContent();
        console.log('开始播放:', mediaElement.src);
      }
    } catch (error) {
      console.error('播放/暂停失败:', error);
      // 如果是因为用户交互问题，显示提示
      if (error.name === 'NotAllowedError') {
        console.warn('需要用户交互才能播放媒体');
      }
    }
  };

  /**
   * 处理进度条变化
   * @param e - 事件对象
   */
  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    const progress = parseFloat(e.target.value);
    const currentTime = (progress / 100) * mediaElement.duration;
    mediaElement.currentTime = currentTime;
    setProgress(progress / 100);
  };

  /**
   * 处理音量变化
   * @param e - 事件对象
   */
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const volume = parseFloat(e.target.value) / 100;
    const mediaElement = getCurrentMediaElement();
    if (mediaElement) {
      mediaElement.volume = volume;
    }
    setVolume(volume);
  };

  /**
   * 切换静音状态
   */
  const toggleMute = () => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    if (mediaElement.volume > 0) {
      mediaElement.volume = 0;
      setVolume(0);
    } else {
      mediaElement.volume = 0.5;
      setVolume(0.5);
    }
  };

  /**
   * 快进10秒
   */
  const skipForward = () => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    mediaElement.currentTime = Math.min(
      mediaElement.currentTime + 10,
      mediaElement.duration
    );
  };

  /**
   * 快退10秒
   */
  const skipBackward = () => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    mediaElement.currentTime = Math.max(mediaElement.currentTime - 10, 0);
  };

  /**
   * 切换全屏模式
   */
  const toggleFullscreen = () => {
    if (!videoRef.current) return;

    if (!isFullscreen) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  /**
   * 显示控制栏
   */
  const showControlsTemporarily = () => {
    setShowControls(true);
    
    if (controlsTimeout) {
      clearTimeout(controlsTimeout);
    }
    
    const timeout = setTimeout(() => {
      if (currentPlaying.isPlaying && isFullscreen) {
        setShowControls(false);
      }
    }, 3000);
    
    setControlsTimeout(timeout);
  };

  /**
   * 重置播放
   */
  const resetPlayback = () => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    mediaElement.currentTime = 0;
    setProgress(0);
  };

  /**
   * 处理画中画模式切换
   */
  const handlePictureInPicture = async () => {
    if (!videoRef.current || currentPlaying.type !== 'movie') return;

    try {
      if (!isPiPMode) {
        if (videoRef.current.requestPictureInPicture) {
          await videoRef.current.requestPictureInPicture();
          setIsPiPMode(true);
        }
      } else {
        if (document.exitPictureInPicture) {
          await document.exitPictureInPicture();
          setIsPiPMode(false);
        }
      }
    } catch (error) {
      console.error('画中画切换失败:', error);
    }
  };

  /**
   * 处理播放器最小化
   */
  const handleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  /**
   * 处理播放器关闭
   */
  const handleClose = () => {
    stopContent();
  };

  /**
   * 处理播放速度调节
   */
  const handlePlaybackRateChange = (rate: number) => {
    const mediaElement = getCurrentMediaElement();
    if (mediaElement) {
      mediaElement.playbackRate = rate;
      setPlaybackRate(rate);
      setShowSettings(false);
    }
  };

  /**
   * 键盘快捷键处理
   */
  const handleKeyDown = (e: KeyboardEvent) => {
    if (!currentPlaying.content) return;

    switch (e.code) {
      case 'Space':
        e.preventDefault();
        handlePlayPause();
        break;
      case 'ArrowLeft':
        e.preventDefault();
        skipBackward();
        break;
      case 'ArrowRight':
        e.preventDefault();
        skipForward();
        break;
      case 'ArrowUp':
        e.preventDefault();
        {
          const newVolume = Math.min(1, playerState.volume + 0.1);
          const mediaElement = getCurrentMediaElement();
          if (mediaElement) {
            mediaElement.volume = newVolume;
            setVolume(newVolume);
          }
        }
        break;
      case 'ArrowDown':
        e.preventDefault();
        {
          const newVolume = Math.max(0, playerState.volume - 0.1);
          const mediaElement = getCurrentMediaElement();
          if (mediaElement) {
            mediaElement.volume = newVolume;
            setVolume(newVolume);
          }
        }
        break;
      case 'KeyF':
        e.preventDefault();
        toggleFullscreen();
        break;
      case 'KeyM':
        e.preventDefault();
        toggleMute();
        break;
      case 'Escape':
        if (playerState.isFullscreen) {
          toggleFullscreen();
        }
        break;
    }
  };

  /**
   * 移动端触摸开始处理
   */
  const handleTouchStart = (e: React.TouchEvent) => {
    if (!isMobile) return;
    
    const touch = e.touches[0];
    setTouchStart({
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now()
    });
    setShowControls(true);
  };

  /**
   * 移动端触摸移动处理
   */
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isMobile || !touchStart) return;
    
    const touch = e.touches[0];
    const deltaX = touch.clientX - touchStart.x;
    const deltaY = touch.clientY - touchStart.y;
    
    // 检测是否为拖拽手势
    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
      setIsDragging(true);
    }
    
    // 水平滑动控制进度（仅视频）
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 20 && currentPlaying.type === 'movie') {
      const mediaElement = getCurrentMediaElement();
      if (mediaElement && mediaElement.duration) {
        const progressDelta = deltaX / window.innerWidth;
        const timeDelta = progressDelta * mediaElement.duration;
        const newTime = Math.max(0, Math.min(mediaElement.duration, mediaElement.currentTime + timeDelta));
        
        // 显示预览时间
        const previewElement = document.getElementById('touch-preview');
        if (previewElement) {
          previewElement.textContent = formatTime(newTime);
          previewElement.style.display = 'block';
        }
      }
    }
    
    // 垂直滑动控制音量
    if (Math.abs(deltaY) > Math.abs(deltaX) && Math.abs(deltaY) > 20) {
      const volumeDelta = -deltaY / window.innerHeight;
      const currentVol = getCurrentMediaElement()?.volume || 0;
      const newVolume = Math.max(0, Math.min(1, currentVol + volumeDelta));
      
      const mediaElement = getCurrentMediaElement();
      if (mediaElement) {
        mediaElement.volume = newVolume;
        setVolume(newVolume);
      }
    }
  };

  /**
   * 移动端触摸结束处理
   */
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!isMobile || !touchStart) return;
    
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStart.x;
    const deltaY = touch.clientY - touchStart.y;
    const deltaTime = Date.now() - touchStart.time;
    
    // 隐藏预览
    const previewElement = document.getElementById('touch-preview');
    if (previewElement) {
      previewElement.style.display = 'none';
    }
    
    // 如果是拖拽手势，应用进度变化
    if (isDragging && Math.abs(deltaX) > Math.abs(deltaY) && currentPlaying.type === 'movie') {
      const mediaElement = getCurrentMediaElement();
      if (mediaElement && mediaElement.duration) {
        const progressDelta = deltaX / window.innerWidth;
        const timeDelta = progressDelta * mediaElement.duration;
        const newTime = Math.max(0, Math.min(mediaElement.duration, mediaElement.currentTime + timeDelta));
        mediaElement.currentTime = newTime;
        setProgress(newTime / mediaElement.duration);
      }
    }
    // 如果是快速点击（非拖拽），切换播放状态
    else if (!isDragging && deltaTime < 300 && Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10) {
      handlePlayPause();
    }
    
    setTouchStart(null);
    setIsDragging(false);
  };

  // 监听媒体元素事件
  useEffect(() => {
    const mediaElement = getCurrentMediaElement();
    if (!mediaElement) return;

    /**
     * 处理时间更新
     */
    const handleTimeUpdate = () => {
      if (mediaElement.duration) {
        const progress = mediaElement.currentTime / mediaElement.duration;
        setProgress(progress);
      }
    };

    /**
     * 处理播放结束
     */
    const handleEnded = () => {
      stopContent();
    };

    /**
     * 处理加载完成
     */
    const handleLoadedData = () => {
      mediaElement.volume = currentPlaying.volume;
    };

    mediaElement.addEventListener('timeupdate', handleTimeUpdate);
    mediaElement.addEventListener('ended', handleEnded);
    mediaElement.addEventListener('loadeddata', handleLoadedData);

    return () => {
      mediaElement.removeEventListener('timeupdate', handleTimeUpdate);
      mediaElement.removeEventListener('ended', handleEnded);
      mediaElement.removeEventListener('loadeddata', handleLoadedData);
    };
  }, [currentPlaying.content, currentPlaying.type]);

  // 监听全屏状态变化
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // 键盘事件监听
  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [currentPlaying.content]);

  // 清理定时器
  useEffect(() => {
    return () => {
      if (controlsTimeout) {
        clearTimeout(controlsTimeout);
      }
    };
  }, [controlsTimeout]);

  // 如果没有正在播放的内容，不显示播放器
  if (!currentPlaying.content) {
    return null;
  }

  const content = currentPlaying.content as Movie | Track | EnhancedMovie;
  const isVideo = currentPlaying.type === 'movie';
  const currentTime = getCurrentMediaElement()?.currentTime || 0;
  const duration = getCurrentMediaElement()?.duration || 0;

  return (
    <div className={`
      relative bg-black text-white transition-all duration-300
      ${isFullscreen ? 'fixed inset-0 z-50' : ''}
      ${isMinimized ? 'h-16' : isMobile ? 'h-64' : 'h-80'}
      ${className}
    `}>
      {/* 媒体元素 */}
      {isVideo ? (
        <div 
          className="relative bg-black h-full"
          onMouseMove={showControlsTemporarily}
          onMouseEnter={() => setShowControls(true)}
          onMouseLeave={() => {
            if (currentPlaying.isPlaying && isFullscreen) {
              setShowControls(false);
            }
          }}
          onTouchStart={() => setShowControls(true)}
        >
          <video
            ref={videoRef}
            src={
              'videoUrl' in content 
                ? (content as Movie).videoUrl 
                : (content as EnhancedMovie).videoQualities?.[0]?.url || ''
            }
            poster={(content as Movie | EnhancedMovie).posterUrl}
            className="w-full h-full object-contain"
            onClick={handlePlayPause}
            playsInline={isMobile}
            controls={false}
            preload="metadata"
            crossOrigin="anonymous"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onLoadStart={() => console.log('视频开始加载')}
            onLoadedMetadata={() => console.log('视频元数据加载完成')}
            onCanPlay={() => console.log('视频可以播放')}
            onError={(e) => {
              console.error('视频加载错误:', e);
              const target = e.target as HTMLVideoElement;
              console.error('错误的视频URL:', target.src);
            }}
          />
          
          {/* 移动端触摸预览 */}
          {isMobile && (
            <div
              id="touch-preview"
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-75 text-white px-4 py-2 rounded-lg text-lg font-mono hidden z-50"
            />
          )}
          
          {/* 桌面端窗口控制按钮 */}
          {!isMobile && !isFullscreen && showControls && (
            <div className="absolute top-2 right-2 flex space-x-2">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                title="设置"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                onClick={handlePictureInPicture}
                className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                title="画中画"
              >
                <PictureInPicture className="w-4 h-4" />
              </button>
              <button
                onClick={handleMinimize}
                className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                title={isMinimized ? "展开" : "最小化"}
              >
                {isMinimized ? <Square className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </button>
              <button
                onClick={handleClose}
                className="p-2 rounded-full bg-red-500/70 hover:bg-red-500 transition-colors"
                title="关闭"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* 设置面板 */}
          {showSettings && !isMobile && (
            <div className="absolute bottom-full right-2 mb-2 bg-black/90 rounded-lg p-4 min-w-48">
              <h4 className="text-sm font-semibold mb-3">播放设置</h4>
              <div className="space-y-2">
                <div>
                  <label className="text-xs text-gray-300 block mb-1">播放速度</label>
                  <div className="flex space-x-1">
                    {([0.5, 0.75, 1, 1.25, 1.5, 2] as PlaybackRate[]).map(rate => (
                      <button
                        key={rate}
                        onClick={() => handlePlaybackRateChange(rate)}
                        className={`
                          px-2 py-1 text-xs rounded transition-colors
                          ${playbackRate === rate 
                            ? 'bg-green-500 text-white' 
                            : 'bg-gray-700 hover:bg-gray-600'
                          }
                        `}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 视频控制栏 - 仅在非统一控制栏模式下显示 */}
          {showControls && !isMinimized && !className?.includes('unified-controls') && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="flex items-center space-x-4">
                <button
                  onClick={handlePlayPause}
                  className="text-white hover:text-blue-400 transition-colors"
                >
                  {currentPlaying.isPlaying ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6" />
                  )}
                </button>
                
                <button
                  onClick={skipBackward}
                  className="text-white hover:text-blue-400 transition-colors"
                >
                  <SkipBack className="w-5 h-5" />
                </button>
                
                <button
                  onClick={skipForward}
                  className="text-white hover:text-blue-400 transition-colors"
                >
                  <SkipForward className="w-5 h-5" />
                </button>
                
                <div className="flex-1 flex items-center space-x-2">
                  <span className="text-white text-sm">
                    {formatTime(currentTime)}
                  </span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={(currentPlaying.progress * 100) || 0}
                    onChange={handleProgressChange}
                    className="flex-1 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <span className="text-white text-sm">
                    {formatTime(duration)}
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={toggleMute}
                    className="text-white hover:text-blue-400 transition-colors"
                  >
                    {currentPlaying.volume === 0 ? (
                      <VolumeX className="w-5 h-5" />
                    ) : (
                      <Volume2 className="w-5 h-5" />
                    )}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={currentPlaying.volume * 100}
                    onChange={handleVolumeChange}
                    className="w-20 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>
                
                <button
                  onClick={resetPlayback}
                  className="text-white hover:text-blue-400 transition-colors"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
                
                <button
                  onClick={toggleFullscreen}
                  className="text-white hover:text-blue-400 transition-colors"
                >
                  {isFullscreen ? (
                    <Minimize className="w-5 h-5" />
                  ) : (
                    <Maximize className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          <audio
            ref={audioRef}
            src={(content as Track).audioUrl}
            preload="metadata"
          />
          {/* 音频播放器UI */}
          <div className="flex items-center justify-center h-full bg-gradient-to-br from-gray-800 to-gray-900">
            <div className="text-center">
              <div className="w-32 h-32 mx-auto mb-4 bg-gray-700 rounded-lg flex items-center justify-center">
                <Volume2 className="w-16 h-16 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{content.title}</h3>
              <p className="text-gray-400">{(content as Track).artist || '未知艺术家'}</p>
            </div>
          </div>
        </>
      )}

      {/* 桌面端窗口控制按钮 - 音频播放器 */}
      {!isVideo && !isMobile && !isFullscreen && (
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            title="设置"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            onClick={handleMinimize}
            className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            title={isMinimized ? "展开" : "最小化"}
          >
            {isMinimized ? <Square className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={handleClose}
            className="p-2 rounded-full bg-red-500/70 hover:bg-red-500 transition-colors"
            title="关闭"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 设置面板 - 音频播放器 */}
      {showSettings && !isMobile && !isVideo && (
        <div className="absolute bottom-full right-2 mb-2 bg-black/90 rounded-lg p-4 min-w-48">
          <h4 className="text-sm font-semibold mb-3">播放设置</h4>
          <div className="space-y-2">
            <div>
              <label className="text-xs text-gray-300 block mb-1">播放速度</label>
              <div className="flex space-x-1">
                {([0.5, 0.75, 1, 1.25, 1.5, 2] as PlaybackRate[]).map(rate => (
                  <button
                    key={rate}
                    onClick={() => handlePlaybackRateChange(rate)}
                    className={`
                      px-2 py-1 text-xs rounded transition-colors
                      ${playbackRate === rate 
                        ? 'bg-green-500 text-white' 
                        : 'hover:bg-gray-700'
                      }
                    `}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 统一控制栏 */}
      <div className={`
        absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent
        transition-all duration-300 p-4
        ${showControls || !currentPlaying.isPlaying || isMinimized ? 'opacity-100' : 'opacity-0'}
        ${isMinimized ? 'bg-black/90' : ''}
      `}>
        {!isMinimized && (
          <>
            {/* 进度条 */}
            <div className="mb-4">
              <div 
                className="w-full h-1 bg-gray-600 rounded-full cursor-pointer group"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = (e.clientX - rect.left) / rect.width;
                  const newTime = percent * duration;
                  const mediaElement = getCurrentMediaElement();
                  if (mediaElement) {
                    mediaElement.currentTime = newTime;
                    setProgress(newTime / duration);
                  }
                }}
              >
                <div 
                  className="h-full bg-green-500 rounded-full relative group-hover:bg-green-400 transition-colors"
                  style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                >
                  <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-green-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <div className="flex justify-between text-xs text-gray-300 mt-1">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* 控制按钮 */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {/* 快退 */}
                <button
                  onClick={skipBackward}
                  className="p-2 rounded-full hover:bg-white/20 transition-colors"
                  title="快退10秒"
                >
                  <SkipBack className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
                </button>

                {/* 播放/暂停 */}
                <button
                  onClick={handlePlayPause}
                  className="p-3 rounded-full bg-green-500 hover:bg-green-600 transition-colors"
                  title={currentPlaying.isPlaying ? "暂停" : "播放"}
                >
                  {currentPlaying.isPlaying ? (
                    <Pause className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
                  ) : (
                    <Play className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
                  )}
                </button>

                {/* 快进 */}
                <button
                  onClick={skipForward}
                  className="p-2 rounded-full hover:bg-white/20 transition-colors"
                  title="快进10秒"
                >
                  <SkipForward className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
                </button>

                {/* 重置 */}
                <button
                  onClick={resetPlayback}
                  className="p-2 rounded-full hover:bg-white/20 transition-colors"
                  title="重新开始"
                >
                  <RotateCcw className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                </button>
              </div>

              <div className="flex items-center space-x-4">
                {/* 音量控制 */}
                <div className="flex items-center space-x-2">
                  <button
                    onClick={toggleMute}
                    className="p-2 rounded-full hover:bg-white/20 transition-colors"
                    title={currentPlaying.volume > 0 ? "静音" : "取消静音"}
                  >
                    {currentPlaying.volume > 0 ? (
                      <Volume2 className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                    ) : (
                      <VolumeX className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                    )}
                  </button>
                  
                  {!isMobile && (
                    <div 
                      className="w-20 h-1 bg-gray-600 rounded-full cursor-pointer group"
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const percent = (e.clientX - rect.left) / rect.width;
                        const newVolume = Math.max(0, Math.min(1, percent));
                        const mediaElement = getCurrentMediaElement();
                        if (mediaElement) {
                          mediaElement.volume = newVolume;
                          setVolume(newVolume);
                        }
                      }}
                    >
                      <div 
                        className="h-full bg-green-500 rounded-full relative group-hover:bg-green-400 transition-colors"
                        style={{ width: `${currentPlaying.volume * 100}%` }}
                      >
                        <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-green-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  )}
                </div>

                {/* 全屏控制 */}
                {isVideo && (
                  <button
                    onClick={toggleFullscreen}
                    className="p-2 rounded-full hover:bg-white/20 transition-colors"
                    title={isFullscreen ? "退出全屏" : "全屏"}
                  >
                    {isFullscreen ? (
                      <Minimize className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                    ) : (
                      <Maximize className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                    )}
                  </button>
                )}
              </div>
            </div>
          </>
        )}

        {/* 最小化状态下的简化控制 */}
        {isMinimized && (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={handlePlayPause}
                className="p-2 rounded-full bg-green-500 hover:bg-green-600 transition-colors"
              >
                {currentPlaying.isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <div className="text-sm">
                <div className="font-medium truncate max-w-48">
                  {content.title}
                </div>
                <div className="text-xs text-gray-400">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleMinimize}
                className="p-1 rounded hover:bg-white/20 transition-colors"
              >
                <Square className="w-4 h-4" />
              </button>
              <button
                onClick={handleClose}
                className="p-1 rounded hover:bg-red-500/50 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaPlayer;