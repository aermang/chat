/**
 * 飞鸽风格即时通讯App - 主界面布局组件
 * 提供应用主界面的整体布局，包含底部导航栏
 * 支持移动端响应式设计和安全区域适配
 */

import React, { useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store';
import { useViewport } from '../../hooks/useViewport';
import { useSafeArea, useSafeAreaCSSVars } from '../../hooks/useSafeArea';
import { useIsMobile } from '../../hooks/useIsMobile';
import BottomNavigation from './BottomNavigation';

/**
 * 主界面布局组件
 * 提供移动端优先的响应式布局，支持安全区域和触控优化
 */
const MainLayout: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, currentUser } = useAppStore();
  const viewport = useViewport();
  const safeArea = useSafeArea();
  const safeAreaVars = useSafeAreaCSSVars();
  const isMobile = useIsMobile();
  
  /**
   * 检查用户认证状态
   */
  useEffect(() => {
    if (!isAuthenticated || !currentUser) {
      navigate('/login', { replace: true });
      return;
    }
  }, [isAuthenticated, currentUser, navigate]);
  
  // 如果未认证，不渲染内容
  if (!isAuthenticated || !currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
      </div>
    );
  }
  
  return (
    <div 
      className={`
        flex flex-col h-screen bg-gray-50 dark:bg-gray-900
        ${isMobile ? 'mobile-layout' : 'desktop-layout'}
      `}
      style={{
        ...safeAreaVars,
        // 确保在有安全区域的设备上正确显示
        paddingTop: safeArea.top > 0 ? `${safeArea.top}px` : undefined,
        paddingLeft: safeArea.left > 0 ? `${safeArea.left}px` : undefined,
        paddingRight: safeArea.right > 0 ? `${safeArea.right}px` : undefined,
      }}
    >
      {/* 响应式容器 */}
      <div className={`
        flex flex-col h-full
        ${isMobile 
          ? 'w-full' 
          : 'max-w-md mx-auto border-x border-gray-200 dark:border-gray-700'
        }
      `}>
        {/* 主内容区域 */}
        <main className={`
          flex-1 overflow-hidden relative
          ${isMobile ? 'mobile-main' : 'desktop-main'}
        `}>
          <div className={`
            h-full w-full
            ${viewport.orientation === 'landscape' && isMobile 
              ? 'landscape-mode' 
              : 'portrait-mode'
            }
          `}>
            <Outlet />
          </div>
        </main>
        
        {/* 底部导航栏 */}
        <BottomNavigation />
      </div>
    </div>
  );
};

export default MainLayout;