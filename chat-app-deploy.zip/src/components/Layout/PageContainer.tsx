/**
 * 飞鸽风格即时通讯App - 页面容器组件
 * 提供统一的页面布局和宽度控制
 */

import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { useSafeArea } from '../../hooks/useSafeArea';

/**
 * 页面容器组件属性
 */
interface PageContainerProps {
  children: React.ReactNode;
  title?: string;
  headerActions?: React.ReactNode;
  actions?: Array<{
    icon: React.ReactNode;
    onClick: () => void;
    label: string;
    disabled?: boolean;
  }>;
  showHeader?: boolean;
  className?: string;
  contentClassName?: string;
  headerClassName?: string;
}

/**
 * 页面容器组件
 * 提供统一的页面布局、宽度控制和响应式设计
 * 
 * 移动端优化说明：
 * - 减少header区域的padding以提升空间利用率
 * - 优化内容区域的垂直间距
 * - 保持触控区域的可用性和美观性
 */
const PageContainer: React.FC<PageContainerProps> = ({
  children,
  title,
  headerActions,
  actions,
  showHeader = true,
  className = '',
  contentClassName = '',
  headerClassName = ''
}) => {
  const isMobile = useIsMobile();
  const { top: safeAreaTop } = useSafeArea();

  return (
    <div className={`
      flex flex-col h-full bg-gray-50 dark:bg-gray-900
      ${isMobile ? 'mobile-layout' : ''}
      ${className}
    `}>
      {/* 统一的顶部标题栏 - 移动端优化：减少padding提升空间利用率 */}
      {showHeader && (
        <header 
          className={`
            bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
            ${headerClassName}
          `}
          style={{ 
            // 移动端优化：减少顶部padding从12px到8px，保持安全区域适配
            paddingTop: isMobile ? `calc(8px + ${safeAreaTop}px)` : '12px',
            paddingLeft: isMobile ? '12px' : '16px', // 移动端减少左右padding
            paddingRight: isMobile ? '12px' : '16px',
            paddingBottom: isMobile ? '12px' : '16px' // 移动端减少底部padding
          }}
        >
          <div className="flex items-center justify-between max-w-md mx-auto">
            {title && (
              <h1 className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-xl' : 'text-lg'}
              `}>
                {title}
              </h1>
            )}
            {(headerActions || actions) && (
              <div className="flex items-center space-x-2">
                {headerActions}
                {actions && actions.map((action, index) => (
                  <button
                    key={index}
                    onClick={action.onClick}
                    disabled={action.disabled}
                    className={`
                      text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white
                      transition-colors p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700
                      ${isMobile ? 'touch-optimized' : ''}
                      ${action.disabled ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                    title={action.label}
                  >
                    {action.icon}
                  </button>
                ))}
              </div>
            )}
          </div>
        </header>
      )}

      {/* 统一的内容区域 - 移动端优化：减少垂直padding提升内容空间 */}
      <div className={`
        flex-1 overflow-y-auto
        ${isMobile ? 'px-4 py-4' : 'px-4 py-4'}
        ${contentClassName}
      `}>
        <div className="max-w-md mx-auto h-full">
          {children}
        </div>
      </div>
    </div>
  );
};

export default PageContainer;