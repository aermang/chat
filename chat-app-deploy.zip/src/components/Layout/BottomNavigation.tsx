/**
 * 飞鸽风格即时通讯App - 底部导航栏组件
 * 提供主要功能页面的导航入口
 * 支持移动端触控优化和响应式设计
 */

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MessageCircle, Users, Compass, User } from 'lucide-react';
import { useAppStore } from '../../store';
import { NotificationBadge } from '../common/NotificationBadge';
import { useSafeArea } from '../../hooks/useSafeArea';
import { useIsMobile } from '../../hooks/useResponsive';
import { useTouchFeedback } from '../../hooks/useTouch';

/**
 * 导航项配置
 */
const navigationItems = [
  {
    id: 'chat',
    label: '飞鸽',
    icon: MessageCircle,
    path: '/app/chats',
    activeColor: 'text-green-600'
  },
  {
    id: 'contacts',
    label: '通讯录',
    icon: Users,
    path: '/app/contacts',
    activeColor: 'text-green-600'
  },
  {
    id: 'discover',
    label: '发现',
    icon: Compass,
    path: '/app/discover',
    activeColor: 'text-green-600'
  },
  {
    id: 'profile',
    label: '我',
    icon: User,
    path: '/app/profile',
    activeColor: 'text-green-600'
  }
];

/**
 * 导航按钮组件 - 支持触控反馈
 */
const NavigationButton: React.FC<{
  item: typeof navigationItems[0];
  active: boolean;
  unreadCount: number;
  onNavigate: (path: string) => void;
}> = ({ item, active, unreadCount, onNavigate }) => {
  const { elementRef, triggerFeedback } = useTouchFeedback({
    haptic: true,
    visual: true,
    scale: 0.95,
    duration: 150
  });
  const isMobile = useIsMobile();

  const Icon = item.icon;

  const handleClick = () => {
    triggerFeedback();
    onNavigate(item.path);
  };

  return (
    <button
      ref={elementRef as React.RefObject<HTMLButtonElement>}
      onClick={handleClick}
      className={`
        flex flex-col items-center justify-center 
        min-w-0 flex-1 relative
        ${isMobile 
          ? 'min-h-touch py-2 px-1' 
          : 'py-1 px-2'
        }
        transition-all duration-mobile
        active:scale-95
        focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50
        rounded-mobile
        max-w-none
      `}
      aria-label={`导航到${item.label}`}
      role="tab"
      aria-selected={active}
    >
      <NotificationBadge count={unreadCount} position="top-right">
        <Icon
          size={isMobile ? 26 : 24}
          className={`
            mb-1 transition-colors duration-mobile
            ${active ? item.activeColor : 'text-gray-500 dark:text-gray-400'}
          `}
        />
      </NotificationBadge>
      <span
        className={`
          text-xs transition-colors duration-mobile
          ${isMobile ? 'mobile-sm' : ''}
          ${active 
            ? item.activeColor 
            : 'text-gray-500 dark:text-gray-400'
          }
        `}
      >
        {item.label}
      </span>
    </button>
  );
};

/**
 * 底部导航栏组件
 * 支持移动端触控优化、安全区域适配和响应式设计
 */
export const BottomNavigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { notifications } = useAppStore();
  const safeArea = useSafeArea();
  const isMobile = useIsMobile();

  /**
   * 处理导航点击
   */
  const handleNavigation = (path: string) => {
    navigate(path);
  };

  /**
   * 检查路径是否激活
   */
  const isActive = (path: string) => {
    if (path === '/app/chats') {
      return location.pathname === '/app/chats' || location.pathname === '/app' || location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  /**
   * 获取导航项的未读数量
   */
  const getUnreadCount = (itemId: string) => {
    switch (itemId) {
      case 'chat':
        // 聊天页面的未读消息数（暂时隐藏）
        return 0;
      case 'contacts':
        // 通讯录页面的好友申请未读数
        return notifications.friendRequestUnreadCount;
      default:
        return 0;
    }
  };

  return (
    <nav 
      className={`
        ${isMobile ? 'fixed' : 'relative'} 
        bottom-0 left-0 right-0 
        bg-white dark:bg-gray-800 
        border-t border-gray-200 dark:border-gray-700 
        z-mobile-nav
        ${isMobile ? 'mobile-shadow' : 'shadow-sm'}
      `}
      style={{
        // 适配安全区域
        paddingBottom: safeArea.bottom > 0 ? `${safeArea.bottom}px` : undefined,
      }}
      role="tablist"
      aria-label="主导航"
    >
      <div className={`
        flex items-center justify-between
        ${isMobile ? 'px-2' : 'py-2'}
      `}>
        {navigationItems.map((item) => {
          const active = isActive(item.path);
          const unreadCount = getUnreadCount(item.id);

          return (
            <NavigationButton
              key={item.id}
              item={item}
              active={active}
              unreadCount={unreadCount}
              onNavigate={handleNavigation}
            />
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNavigation;