/**
 * 飞鸽风格即时通讯App - 设置菜单组件
 * 为通讯录页面提供设置功能的弹出菜单
 */

import React from 'react';
import { Shield, UserX, Download, Upload } from 'lucide-react';
import { useTouchFeedback } from '../hooks/useTouch';

/**
 * 设置菜单项接口
 */
interface SettingsMenuItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  onClick: () => void;
}

/**
 * 设置菜单组件属性
 */
interface SettingsMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onAction: (action: string) => void;
  isMobile: boolean;
}

/**
 * 设置菜单组件
 */
const SettingsMenu: React.FC<SettingsMenuProps> = ({
  isOpen,
  onClose,
  onAction,
  isMobile
}) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  /**
   * 设置菜单项配置
   */
  const menuItems: SettingsMenuItem[] = [
    {
      id: 'friend-management',
      label: '好友管理',
      icon: Shield,
      color: 'text-blue-600',
      onClick: () => onAction('friend-management')
    },
    {
      id: 'privacy-settings',
      label: '隐私设置',
      icon: Shield,
      color: 'text-green-600',
      onClick: () => onAction('privacy-settings')
    },
    {
      id: 'blacklist',
      label: '黑名单管理',
      icon: UserX,
      color: 'text-red-600',
      onClick: () => onAction('blacklist')
    },
    {
      id: 'backup',
      label: '通讯录备份',
      icon: Upload,
      color: 'text-purple-600',
      onClick: () => onAction('backup')
    },
    {
      id: 'restore',
      label: '通讯录恢复',
      icon: Download,
      color: 'text-orange-600',
      onClick: () => onAction('restore')
    }
  ];

  /**
   * 处理菜单项点击
   */
  const handleMenuItemClick = (item: SettingsMenuItem) => {
    item.onClick();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* 遮罩层 */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40"
        onClick={onClose}
      />
      
      {/* 菜单内容 */}
      <div className={`
        fixed z-50 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700
        ${isMobile 
          ? 'bottom-4 left-4 right-4 max-h-96' 
          : 'top-16 right-4 w-64'
        }
      `}>
        {/* 菜单标题 */}
        <div className={`
          px-4 py-3 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'text-center' : ''}
        `}>
          <h3 className={`
            font-semibold text-gray-900 dark:text-white
            ${isMobile ? 'text-lg' : 'text-base'}
          `}>
            通讯录设置
          </h3>
        </div>

        {/* 菜单项列表 */}
        <div className="py-2">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleMenuItemClick(item)}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  w-full flex items-center px-4 py-3 text-left transition-colors
                  hover:bg-gray-50 dark:hover:bg-gray-700
                  ${isMobile ? 'active:bg-gray-100 dark:active:bg-gray-600 touch-optimized' : ''}
                `}
              >
                <Icon className={`
                  w-5 h-5 mr-3 ${item.color}
                  ${isMobile ? 'w-6 h-6' : ''}
                `} />
                <span className={`
                  text-gray-900 dark:text-white
                  ${isMobile ? 'text-base' : 'text-sm'}
                `}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* 取消按钮 (仅移动端显示) */}
        {isMobile && (
          <div className="px-4 pb-4">
            <button
              onClick={onClose}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className="w-full py-3 text-center text-gray-600 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700 touch-optimized"
            >
              取消
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default SettingsMenu;