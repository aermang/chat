/**
 * 飞鸽风格即时通讯App - 主应用组件
 * 应用的根组件，负责路由配置和全局状态初始化
 */

import React, { useEffect } from 'react';
import { RouterProvider } from 'react-router-dom';
import { Toaster } from 'sonner';
import { router } from './router';
import { useAppStore } from './store';
import { CapacitorService } from './services/capacitorService';
import { notificationService } from './services/notificationService';

/**
 * 主应用组件
 */
const App: React.FC = () => {
  const { setTheme, initialize } = useAppStore();
  
  /**
   * 应用初始化
   */
  useEffect(() => {
    // 初始化应用和数据库
    const initApp = async () => {
      try {
        // 初始化Capacitor服务
        await CapacitorService.initialize();
        
        // 初始化应用状态和数据库
        await initialize();
        
        // 初始化通知服务
        await notificationService.initialize();
        console.log('通知服务初始化完成');
        
        console.log('应用初始化完成');
        console.log('运行平台:', CapacitorService.getPlatform());
        console.log('是否原生环境:', CapacitorService.isNative());
      } catch (error) {
        console.error('应用初始化失败:', error);
      }
    };
    
    initApp();
    
    // 检查系统主题偏好
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (prefersDark) {
      setTheme('dark');
    }
    
    // 监听系统主题变化
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleThemeChange = (e: MediaQueryListEvent) => {
      setTheme(e.matches ? 'dark' : 'light');
    };
    
    mediaQuery.addEventListener('change', handleThemeChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleThemeChange);
    };
  }, [setTheme, initialize]);
  
  return (
    <div className="App">
      <RouterProvider router={router} />
      <Toaster 
        position="top-center"
        richColors
        closeButton
        expand={false}
        duration={3000}
      />
    </div>
  );
};

export default App;
