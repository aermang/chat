/**
 * 飞鸽风格即时通讯App - 类型定义文件
 * 定义应用中使用的所有数据类型和接口
 */

// 用户相关类型
export interface User {
  id: string;
  username: string;
  email: string;
  nickname: string;
  phone?: string; // 保持可选，确保向后兼容
  avatar?: string;
  avatar_url?: string;
  bio?: string;
  password?: string; // 添加密码字段（可选，用于注册时）
  created_at: Date;
  updated_at: Date;
  is_online: boolean;
}

// 消息相关类型
export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  message_type: 'text' | 'image' | 'voice';
  created_at: Date;
  is_read: boolean;
}

// 好友关系类型
export interface Friendship {
  id: string;
  user_id: string;
  friend_id: string;
  status: 'pending' | 'accepted' | 'blocked';
  created_at: Date;
  // 扩展字段，用于API返回的好友信息
  user?: User;
  friend?: User;
  remark_name?: string;
  group_tag?: string;
  is_pinned?: boolean;
  // 兼容字段，使Friendship可以作为User使用
  username?: string;
  email?: string;
  nickname?: string;
  updated_at?: Date;
  is_online?: boolean;
  avatar?: string;
  avatar_url?: string;
  bio?: string;
}

// 好友申请类型
export interface FriendRequest {
  id: string;
  from_user_id: string;
  to_user_id: string;
  message: string;
  status: 'pending' | 'accepted' | 'rejected' | 'ignored';
  is_read: boolean;
  created_at: Date;
  updated_at: Date;
}

// 通知类型
export interface Notification {
  id: string;
  user_id: string;
  type: 'friend_request' | 'message' | 'system';
  content: string;
  related_id?: string; // 关联的ID（如好友申请ID、消息ID等）
  is_read: boolean;
  created_at: Date;
}

// 朋友圈动态类型
export interface Moment {
  id: string;
  user_id: string;
  content?: string;
  images?: string[];
  created_at: Date;
  likes_count: number;
  comments_count: number;
}

// 点赞类型
export interface Like {
  id: string;
  moment_id: string;
  user_id: string;
  created_at: Date;
}

// 评论类型
export interface Comment {
  id: string;
  moment_id: string;
  user_id: string;
  content: string;
  created_at: Date;
}

// 聊天会话类型
export interface ChatSession {
  id: string;
  user_id: string;
  friend_id: string;
  last_message?: Message;
  last_message_time: Date;
  unread_count: number;
  updated_at: Date;
}

// 应用状态类型
export interface AppState {
  currentUser: User | null;
  isAuthenticated: boolean;
  theme: 'light' | 'dark';
}

// 好友申请状态类型
export interface FriendRequestState {
  requests: FriendRequest[];
  unreadCount: number;
  isLoading: boolean;
}

// 通知状态类型
export interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  friendRequestUnreadCount: number;
  isLoading: boolean;
}

// 路由参数类型
export interface ChatParams {
  userId: string;
}

// 表单数据类型
export interface LoginForm {
  email: string;
  password: string;
  remember?: boolean;
}

export interface RegisterForm {
  email: string;
  password: string;
  confirmPassword: string;
  nickname: string;
}

// 好友申请表单类型
export interface FriendRequestForm {
  userId: string;
  message: string;
}

// 搜索用户结果类型
export interface SearchUserResult {
  users: User[];
  isLoading: boolean;
  hasMore: boolean;
}

// API响应类型
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

// 好友申请操作类型
export type FriendRequestAction = 'accept' | 'reject' | 'ignore' | 'accepted' | 'rejected';

// 通知类型枚举
export type NotificationType = 'friend_request' | 'message' | 'system';

// 好友申请状态枚举
export type FriendRequestStatus = 'pending' | 'accepted' | 'rejected' | 'ignored';

// ==================== 特药管理系统类型定义 ====================

/**
 * 患者基本信息接口
 * 用于管理患者的完整档案信息
 */
export interface Patient {
  id: string;
  /** 患者姓名 */
  name: string;
  /** 性别 */
  gender: 'male' | 'female';
  /** 出生日期 */
  birthDate?: string;
  /** 年龄 */
  age?: number;
  /** 身份证号 */
  idCard?: string;
  /** 联系电话 */
  phone: string;
  /** 紧急联系人 */
  emergencyContact?: string;
  /** 紧急联系人电话 */
  emergencyPhone?: string;
  /** 家庭住址 */
  address?: string;
  /** 主治医生 */
  doctor: string;
  /** 医院名称 */
  hospital?: string;
  /** 诊断信息 */
  diagnosis: string;
  /** 治疗方案 */
  treatment: string;
  /** 过敏史 */
  allergies?: string[];
  /** 既往病史 */
  medicalHistory?: string;
  /** 患者状态 */
  isActive: boolean;
  /** 备注信息 */
  notes?: string;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 用药记录接口
 * 记录患者的具体用药情况
 */
export interface MedicationRecord {
  id: string;
  /** 患者ID */
  patientId: string;
  /** 药品名称 */
  medicineName: string;
  /** 药品规格 */
  specification?: string;
  /** 剂量 */
  dosage: string;
  /** 用药频次 */
  frequency: string;
  /** 用药日期 */
  takenDate: Date;
  /** 记录日期（兼容性） */
  recordDate?: Date | string;
  /** 用药时间 */
  takenTime: string;
  /** 是否已服用 */
  isTaken: boolean;
  /** 服药方式 */
  administrationRoute?: 'oral' | 'injection' | 'topical' | 'other';
  /** 用药前症状 */
  preSymptoms?: string;
  /** 用药后反应 */
  postReaction?: string;
  /** 不良反应 */
  adverseReaction?: string;
  /** 备注 */
  notes?: string;
  /** 记录人员 */
  recordedBy?: string;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 用药提醒接口
 * 管理患者的个性化用药提醒
 */
export interface MedicationReminder {
  id: string;
  /** 患者ID */
  patientId: string;
  /** 药品名称 */
  medicineName: string;
  /** 药品名称（兼容性） */
  medicationName?: string;
  /** 剂量 */
  dosage?: string;
  /** 提醒时间 */
  reminderTime: string;
  /** 提醒时间列表 */
  reminderTimes?: string[];
  /** 提醒频次 */
  frequency: 'daily' | 'weekly' | 'monthly' | 'custom';
  /** 自定义频次（天数间隔） */
  customInterval?: number;
  /** 自定义单位 */
  customUnit?: 'hours' | 'days';
  /** 提醒天数 */
  reminderDays?: number[];
  /** 周几提醒 */
  weekdays?: number[];
  /** 月份中的第几天 */
  monthDay?: number;
  /** 开始日期 */
  startDate?: string | Date;
  /** 结束日期 */
  endDate?: string | Date;
  /** 备注 */
  notes?: string;
  /** 是否启用 */
  isActive: boolean;
  /** 提醒方式 */
  reminderType?: 'notification' | 'sms' | 'call';
  /** 提前提醒时间（分钟） */
  advanceMinutes?: number;
  /** 最后提醒时间 */
  lastReminded?: Date;
  /** 下次提醒时间 */
  nextReminder?: Date;
  /** 提醒消息模板 */
  messageTemplate?: string;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 销售代表信息接口
 */
export interface SalesRep {
  id: string;
  /** 姓名 */
  name: string;
  /** 工号 */
  employeeId: string;
  /** 联系电话 */
  phone: string;
  /** 邮箱 */
  email?: string;
  /** 负责区域 */
  territory?: string;
  /** 所属公司 */
  company?: string;
  /** 是否激活 */
  isActive: boolean;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 用药依从性记录接口
 */
export interface AdherenceLog {
  id: string;
  /** 患者ID */
  patientId: string;
  /** 用药记录ID */
  medicationRecordId: string;
  /** 依从性评分 (0-100) */
  adherenceScore: number;
  /** 评估日期 */
  assessmentDate: Date;
  /** 评估周期 */
  assessmentPeriod: 'daily' | 'weekly' | 'monthly';
  /** 漏服次数 */
  missedDoses: number;
  /** 总应服次数 */
  totalDoses: number;
  /** 依从性等级 */
  adherenceLevel: 'excellent' | 'good' | 'fair' | 'poor';
  /** 备注 */
  notes?: string;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 工作日志接口
 */
export interface WorkLog {
  id: string;
  /** 销售代表ID */
  salesRepId: string;
  /** 患者ID */
  patientId: string;
  /** 活动类型 */
  activityType: 'visit' | 'call' | 'follow_up' | 'education' | 'other';
  /** 活动描述 */
  description: string;
  /** 活动日期 */
  activityDate: Date;
  /** 持续时间（分钟） */
  duration?: number;
  /** 活动结果 */
  outcome?: string;
  /** 下次跟进计划 */
  nextFollowUp?: Date;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 统计数据接口
 */
export interface StatisticsData {
  /** 患者总数 */
  totalPatients: number;
  /** 活跃患者数 */
  activePatients: number;
  /** 今日用药记录数 */
  todayMedicationRecords: number;
  /** 本周用药记录数 */
  weeklyMedicationRecords: number;
  /** 本月用药记录数 */
  monthlyMedicationRecords: number;
  /** 平均依从性 */
  averageAdherence: number;
  /** 活跃提醒数 */
  activeReminders: number;
  /** 待跟进患者数 */
  pendingFollowUps: number;
}

/**
 * 用药统计接口
 */
export interface MedicationStatistics {
  /** 药品名称 */
  medicineName: string;
  /** 使用患者数 */
  patientCount: number;
  /** 总用药次数 */
  totalDoses: number;
  /** 依从性百分比 */
  adherencePercentage: number;
  /** 最近使用日期 */
  lastUsedDate: Date;
}

/**
 * 患者统计接口
 */
export interface PatientStatistics {
  /** 患者ID */
  patientId: string;
  /** 患者姓名 */
  patientName: string;
  /** 总用药天数 */
  totalMedicationDays: number;
  /** 依从性评分 */
  adherenceScore: number;
  /** 最后用药日期 */
  lastMedicationDate: Date;
  /** 活跃提醒数 */
  activeRemindersCount: number;
}

/**
 * 报告数据接口
 */
export interface ReportData {
  /** 报告类型 */
  type: 'adherence' | 'follow_up' | 'medication_usage' | 'patient_summary';
  /** 报告标题 */
  title: string;
  /** 生成日期 */
  generatedDate: Date;
  /** 报告期间 */
  period: {
    startDate: Date;
    endDate: Date;
  };
  /** 报告数据 */
  data: any;
  /** 总结信息 */
  summary?: string;
}

/**
 * 特药管理系统状态接口
 */
export interface SpecialMedicineState {
  /** 患者列表 */
  patients: Patient[];
  /** 当前选中的患者 */
  currentPatient: Patient | null;
  /** 用药记录列表 */
  medicationRecords: MedicationRecord[];
  /** 提醒列表 */
  reminders: MedicationReminder[];
  /** 销售代表列表 */
  salesReps: SalesRep[];
  /** 依从性记录 */
  adherenceLogs: AdherenceLog[];
  /** 工作日志 */
  workLogs: WorkLog[];
  /** 统计数据 */
  statistics: StatisticsData | null;
  /** 加载状态 */
  isLoading: boolean;
  /** 错误信息 */
  error: string | null;
}

/**
 * 表单数据类型
 */
export interface PatientForm {
  name: string;
  gender: 'male' | 'female';
  age?: number;
  idCard?: string;
  phone: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  address?: string;
  doctor: string;
  hospital?: string;
  diagnosis: string;
  treatment: string;
  allergies?: string[];
  medicalHistory?: string;
  notes?: string;
}

export interface MedicationRecordForm {
  patientId: string;
  medicineName: string;
  specification?: string;
  dosage: string;
  frequency: string;
  takenDate: Date;
  takenTime: string;
  isTaken: boolean;
  administrationRoute?: 'oral' | 'injection' | 'topical' | 'other';
  preSymptoms?: string;
  postReaction?: string;
  adverseReaction?: string;
  notes?: string;
}

export interface MedicationReminderForm {
  patientId: string;
  medicineName: string;
  reminderTime: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'custom';
  customInterval?: number;
  reminderDays?: number[];
  reminderType?: 'notification' | 'sms' | 'call';
  advanceMinutes?: number;
  messageTemplate?: string;
}

/**
 * 筛选和搜索参数接口
 */
export interface PatientFilterParams {
  /** 搜索关键词 */
  keyword?: string;
  /** 性别筛选 */
  gender?: 'male' | 'female';
  /** 年龄范围 */
  ageRange?: {
    min?: number;
    max?: number;
  };
  /** 主治医生 */
  doctor?: string;
  /** 患者状态 */
  isActive?: boolean;
  /** 创建日期范围 */
  dateRange?: {
    startDate?: Date;
    endDate?: Date;
  };
}

export interface MedicationRecordFilterParams {
  /** 患者ID */
  patientId?: string;
  /** 药品名称 */
  medicineName?: string;
  /** 日期范围 */
  dateRange?: {
    startDate?: Date;
    endDate?: Date;
  };
  /** 是否已服用 */
  isTaken?: boolean;
}

/**
 * 分页参数接口
 */
export interface PaginationParams {
  /** 页码 */
  page: number;
  /** 每页数量 */
  pageSize: number;
  /** 排序字段 */
  sortBy?: string;
  /** 排序方向 */
  sortOrder?: 'asc' | 'desc';
}

/**
 * 分页结果接口
 */
export interface PaginatedResult<T> {
  /** 数据列表 */
  data: T[];
  /** 总数量 */
  total: number;
  /** 当前页码 */
  page: number;
  /** 每页数量 */
  pageSize: number;
  /** 总页数 */
  totalPages: number;
  /** 是否有下一页 */
  hasNext: boolean;
  /** 是否有上一页 */
  hasPrev: boolean;
}

// ==================== 影音娱乐模块类型定义 ====================

/**
 * 影视内容接口
 * 用于管理电影、电视剧等影视内容
 */
export interface Movie {
  /** 影视ID */
  id: string;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 海报URL */
  posterUrl: string;
  /** 视频播放URL */
  videoUrl: string;
  /** 评分 */
  rating: number;
  /** 类型标签 */
  genres: string[];
  /** 导演 */
  director?: string;
  /** 演员 */
  actors?: string[];
  /** 发布年份 */
  year?: number;
  /** 发布日期 */
  releaseDate?: string;
  /** 时长（分钟） */
  duration: number;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 音乐内容接口
 * 用于管理歌曲、专辑等音乐内容
 */
export interface Track {
  /** 音乐ID */
  id: string;
  /** 歌曲标题 */
  title: string;
  /** 艺术家 */
  artist: string;
  /** 专辑名称 */
  album: string;
  /** 音频播放URL */
  audioUrl: string;
  /** 封面图片URL */
  coverUrl: string;
  /** 专辑封面URL（兼容性） */
  albumCover: string;
  /** 时长（秒） */
  duration: number;
  /** 音乐流派 */
  genres: string[];
  /** 发布日期 */
  releaseDate?: Date;
  /** 歌词 */
  lyrics?: string;
}

/**
 * 专辑接口
 */
export interface Album {
  /** 专辑ID */
  id: string;
  /** 专辑名称 */
  name: string;
  /** 艺术家 */
  artist: string;
  /** 封面图片URL */
  coverUrl: string;
  /** 专辑中的歌曲列表 */
  tracks: Track[];
  /** 发布日期 */
  releaseDate: Date;
  /** 音乐流派 */
  genres: string[];
}

/**
 * 游戏内容接口
 * 用于管理HTML5小游戏
 */
export interface Game {
  /** 游戏ID */
  id: string;
  /** 游戏标题 */
  title: string;
  /** 游戏描述 */
  description: string;
  /** 缩略图URL */
  thumbnailUrl: string;
  /** 游戏URL */
  gameUrl: string;
  /** 游戏分类 */
  category: string;
  /** 游戏分类列表（兼容性） */
  categories: string[];
  /** 游戏标签 */
  tags: string[];
  /** 游戏开发者 */
  developer?: string;
  /** 游戏次数 */
  playCount: number;
  /** 平均评分 */
  rating?: number;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 用户收藏接口
 */
export interface Favorite {
  /** 收藏ID */
  id: string;
  /** 用户ID */
  userId: string;
  /** 内容ID */
  contentId: string;
  /** 内容类型 */
  contentType: 'movie' | 'track' | 'game';
  /** 收藏时间 */
  createdAt: Date;
}

/**
 * 歌单接口
 */
export interface Playlist {
  /** 歌单ID */
  id: string;
  /** 用户ID */
  userId: string;
  /** 歌单名称 */
  name: string;
  /** 歌单描述 */
  description?: string;
  /** 歌单封面 */
  coverUrl?: string;
  /** 歌曲列表 */
  tracks: Track[];
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 游戏得分记录接口
 */
export interface GameScore {
  /** 记录ID */
  id: string;
  /** 用户ID */
  userId: string;
  /** 游戏ID */
  gameId: string;
  /** 得分 */
  score: number;
  /** 游戏时长（秒） */
  playTime: number;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 播放历史接口
 */
export interface PlayHistory {
  /** 历史记录ID */
  id: string;
  /** 用户ID */
  userId: string;
  /** 内容ID */
  contentId: string;
  /** 内容类型 */
  contentType: 'movie' | 'track' | 'game';
  /** 播放进度（秒） */
  progress?: number;
  /** 播放时间 */
  playedAt: Date;
}

/**
 * 搜索结果接口
 */
export interface SearchResult {
  /** 匹配的电影 */
  movies: EnhancedMovie[];
  /** 匹配的音乐 */
  tracks: Track[];
  /** 匹配的游戏 */
  games: Game[];
  /** 总结果数 */
  totalCount: number;
}

/**
 * 影音娱乐模块状态接口
 */
export interface MediaState {
  /** 当前活跃的模块 */
  activeModule: 'movie' | 'music' | 'game';
  /** 电影列表 */
  movies: EnhancedMovie[];
  /** 音乐列表 */
  tracks: Track[];
  /** 专辑列表 */
  albums: Album[];
  /** 游戏列表 */
  games: Game[];
  /** 用户收藏 */
  favorites: Favorite[];
  /** 用户歌单 */
  playlists: Playlist[];
  /** 游戏得分记录 */
  gameScores: GameScore[];
  /** 播放历史 */
  playHistory: PlayHistory[];
  /** 当前播放的内容 */
  currentPlaying: {
    type: 'movie' | 'track' | null;
    content: Movie | Track | EnhancedMovie | null;
    isPlaying: boolean;
    progress: number;
    volume: number;
  };
  /** 加载状态 */
  isLoading: boolean;
  /** 错误信息 */
  error: string | null;
}

/**
 * 播放器控制接口
 */
export interface MediaPlayerControls {
  /** 播放/暂停 */
  togglePlay: () => void;
  /** 设置进度 */
  setProgress: (progress: number) => void;
  /** 设置音量 */
  setVolume: (volume: number) => void;
  /** 停止播放 */
  stop: () => void;
  /** 快进 */
  fastForward: (seconds: number) => void;
  /** 快退 */
  rewind: (seconds: number) => void;
}

/**
 * API响应类型
 */
export interface MediaApiResponse<T = any> {
  /** 是否成功 */
  success: boolean;
  /** 响应数据 */
  data?: T;
  /** 响应消息 */
  message?: string;
  /** 错误信息 */
  error?: string;
  /** 分页信息 */
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    hasMore: boolean;
  };
}

/**
 * 内容筛选参数接口
 */
export interface MediaFilterParams {
  /** 搜索关键词 */
  keyword?: string;
  /** 内容类型 */
  type?: 'movie' | 'track' | 'game';
  /** 分类/流派 */
  category?: string;
  /** 评分范围 */
  ratingRange?: {
    min: number;
    max: number;
  };
  /** 排序方式 */
  sortBy?: 'rating' | 'date' | 'popularity' | 'title';
  /** 排序方向 */
  sortOrder?: 'asc' | 'desc';
  /** 分页参数 */
  page?: number;
  /** 每页数量 */
  limit?: number;
}

// ==================== 专业视频播放器类型定义 ====================

/**
 * 视频质量选项接口
 * 用于管理不同分辨率的视频源
 */
export interface VideoQuality {
  /** 分辨率标识 */
  resolution: '360p' | '480p' | '720p' | '1080p' | '1440p' | '4K';
  /** 视频URL */
  url: string;
  /** 码率 (kbps) */
  bitrate: number;
  /** 文件大小 (MB) */
  fileSize?: number;
  /** 是否为默认质量 */
  isDefault?: boolean;
}

/**
 * 字幕轨道接口
 * 用于管理多语言字幕
 */
export interface Subtitle {
  /** 字幕ID */
  id: string;
  /** 语言代码 (如: zh-CN, en-US) */
  language: string;
  /** 显示标签 */
  label: string;
  /** 字幕文件URL (WebVTT格式) */
  url: string;
  /** 是否为默认字幕 */
  isDefault?: boolean;
  /** 字幕类型 */
  kind?: 'subtitles' | 'captions' | 'descriptions';
}

/**
 * 音轨接口
 * 用于管理多语言音轨
 */
export interface AudioTrack {
  /** 音轨ID */
  id: string;
  /** 语言代码 */
  language: string;
  /** 显示标签 */
  label: string;
  /** 音轨URL */
  url?: string;
  /** 是否为默认音轨 */
  isDefault?: boolean;
  /** 音轨类型 */
  kind?: 'main' | 'alternative' | 'commentary';
}

/**
 * 播放速度选项
 */
export type PlaybackRate = 0.25 | 0.5 | 0.75 | 1 | 1.25 | 1.5 | 1.75 | 2;

/**
 * 视频播放器设置接口
 */
export interface VideoPlayerSettings {
  /** 默认音量 (0-1) */
  defaultVolume: number;
  /** 默认播放速度 */
  defaultPlaybackRate: PlaybackRate;
  /** 默认质量 */
  defaultQuality: string;
  /** 是否自动播放 */
  autoplay: boolean;
  /** 是否循环播放 */
  loop: boolean;
  /** 是否静音 */
  muted: boolean;
  /** 是否显示字幕 */
  showSubtitles: boolean;
  /** 默认字幕语言 */
  defaultSubtitleLanguage?: string;
  /** 播放器主题 */
  theme: 'dark' | 'light';
  /** 快捷键是否启用 */
  keyboardShortcuts: boolean;
}

/**
 * 扩展的电影接口
 * 继承原有Movie接口并添加专业播放器功能
 */
export interface EnhancedMovie extends Omit<Movie, 'videoUrl'> {
  /** 多质量视频源 */
  videoQualities: VideoQuality[];
  /** 字幕轨道 */
  subtitles: Subtitle[];
  /** 音轨列表 */
  audioTracks: AudioTrack[];
  /** 视频缩略图时间轴 (用于进度条预览) */
  thumbnails?: VideoThumbnail[];
  /** 章节信息 */
  chapters?: VideoChapter[];
  /** 观看次数 */
  viewCount: number;
  /** 点赞数 */
  likeCount: number;
  /** 收藏数 */
  favoriteCount: number;
  /** 评论数 */
  commentCount: number;
  /** 平均评分 */
  averageRating: number;
  /** 评分总数 */
  ratingCount: number;
  /** 视频状态 */
  status: 'active' | 'inactive' | 'processing';
  /** 上传者信息 */
  uploader?: {
    id: string;
    name: string;
    avatar?: string;
  };
}

/**
 * 视频缩略图接口
 * 用于进度条预览功能
 */
export interface VideoThumbnail {
  /** 时间点 (秒) */
  time: number;
  /** 缩略图URL */
  url: string;
  /** 缩略图宽度 */
  width: number;
  /** 缩略图高度 */
  height: number;
}

/**
 * 视频章节接口
 */
export interface VideoChapter {
  /** 章节ID */
  id: string;
  /** 章节标题 */
  title: string;
  /** 开始时间 (秒) */
  startTime: number;
  /** 结束时间 (秒) */
  endTime: number;
  /** 章节缩略图 */
  thumbnail?: string;
}

/**
 * 视频评论接口
 * 支持嵌套回复的评论系统
 */
export interface VideoComment {
  /** 评论ID */
  id: string;
  /** 视频ID */
  videoId: string;
  /** 用户ID */
  userId: string;
  /** 用户名 */
  userName: string;
  /** 用户头像 */
  userAvatar?: string;
  /** 评论内容 */
  content: string;
  /** 点赞数 */
  likeCount: number;
  /** 回复数 */
  replyCount: number;
  /** 父评论ID (用于回复) */
  parentId?: string;
  /** 回复列表 */
  replies?: VideoComment[];
  /** 是否已点赞 */
  isLiked?: boolean;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt?: Date;
  /** 评论状态 */
  status: 'active' | 'deleted' | 'hidden';
}

/**
 * 视频评分接口
 */
export interface VideoRating {
  /** 评分ID */
  id: string;
  /** 视频ID */
  videoId: string;
  /** 用户ID */
  userId: string;
  /** 评分 (1-5星) */
  rating: number;
  /** 评价内容 */
  review?: string;
  /** 创建时间 */
  createdAt: Date;
  /** 更新时间 */
  updatedAt?: Date;
}

/**
 * 播放历史记录接口 (扩展版)
 */
export interface EnhancedPlayHistory extends PlayHistory {
  /** 播放质量 */
  quality?: string;
  /** 播放速度 */
  playbackRate?: PlaybackRate;
  /** 是否完整观看 */
  isCompleted: boolean;
  /** 观看时长 (秒) */
  watchDuration: number;
  /** 设备类型 */
  deviceType?: 'desktop' | 'mobile' | 'tablet';
  /** 浏览器信息 */
  browserInfo?: string;
}

/**
 * 视频推荐接口
 */
export interface VideoRecommendation {
  /** 推荐ID */
  id: string;
  /** 推荐的视频 */
  video: EnhancedMovie;
  /** 推荐原因 */
  reason: string;
  /** 推荐类型 */
  type: 'similar' | 'trending' | 'personalized' | 'category';
  /** 推荐分数 */
  score: number;
  /** 创建时间 */
  createdAt: Date;
}

/**
 * 播放器状态接口
 */
export interface PlayerState {
  /** 当前播放的视频 */
  currentVideo: EnhancedMovie | null;
  /** 是否正在播放 */
  isPlaying: boolean;
  /** 是否暂停 */
  isPaused: boolean;
  /** 是否加载中 */
  isLoading: boolean;
  /** 是否缓冲中 */
  isBuffering: boolean;
  /** 当前播放时间 (秒) */
  currentTime: number;
  /** 视频总时长 (秒) */
  duration: number;
  /** 播放进度 (0-1) */
  progress: number;
  /** 缓冲进度 (0-1) */
  buffered: number;
  /** 音量 (0-1) */
  volume: number;
  /** 是否静音 */
  isMuted: boolean;
  /** 当前播放速度 */
  playbackRate: PlaybackRate;
  /** 当前视频质量 */
  currentQuality: string;
  /** 当前字幕 */
  currentSubtitle?: string;
  /** 当前音轨 */
  currentAudioTrack?: string;
  /** 是否全屏 */
  isFullscreen: boolean;
  /** 是否画中画模式 */
  isPictureInPicture: boolean;
  /** 是否显示控制栏 */
  showControls: boolean;
  /** 错误信息 */
  error?: string;
}

/**
 * 播放器控制动作接口
 */
export interface PlayerActions {
  /** 播放视频 */
  play: (video: EnhancedMovie) => void;
  /** 暂停播放 */
  pause: () => void;
  /** 恢复播放 */
  resume: () => void;
  /** 停止播放 */
  stop: () => void;
  /** 跳转到指定时间 */
  seekTo: (time: number) => void;
  /** 设置音量 */
  setVolume: (volume: number) => void;
  /** 切换静音 */
  toggleMute: () => void;
  /** 设置播放速度 */
  setPlaybackRate: (rate: PlaybackRate) => void;
  /** 切换视频质量 */
  changeQuality: (quality: string) => void;
  /** 切换字幕 */
  changeSubtitle: (subtitleId?: string) => void;
  /** 切换音轨 */
  changeAudioTrack: (trackId?: string) => void;
  /** 切换全屏 */
  toggleFullscreen: () => void;
  /** 切换画中画 */
  togglePictureInPicture: () => void;
  /** 快进 */
  fastForward: (seconds?: number) => void;
  /** 快退 */
  rewind: (seconds?: number) => void;
}

/**
 * 评论系统状态接口
 */
export interface CommentSystemState {
  /** 评论列表 */
  comments: VideoComment[];
  /** 总评论数 */
  totalCount: number;
  /** 是否加载中 */
  isLoading: boolean;
  /** 当前页码 */
  currentPage: number;
  /** 每页数量 */
  pageSize: number;
  /** 是否还有更多 */
  hasMore: boolean;
  /** 排序方式 */
  sortBy: 'newest' | 'oldest' | 'likes';
  /** 错误信息 */
  error?: string;
}

/**
 * 评论操作接口
 */
export interface CommentActions {
  /** 加载评论 */
  loadComments: (videoId: string, page?: number) => Promise<void>;
  /** 发布评论 */
  postComment: (videoId: string, content: string, parentId?: string) => Promise<void>;
  /** 点赞评论 */
  likeComment: (commentId: string) => Promise<void>;
  /** 取消点赞 */
  unlikeComment: (commentId: string) => Promise<void>;
  /** 删除评论 */
  deleteComment: (commentId: string) => Promise<void>;
  /** 举报评论 */
  reportComment: (commentId: string, reason: string) => Promise<void>;
}

/**
 * API请求参数接口
 */
export interface GetVideosRequest {
  /** 分类筛选 */
  category?: string;
  /** 搜索关键词 */
  search?: string;
  /** 页码 */
  page?: number;
  /** 每页数量 */
  limit?: number;
  /** 排序方式 */
  sortBy?: 'newest' | 'popular' | 'rating' | 'views';
  /** 质量筛选 */
  quality?: string[];
  /** 时长筛选 */
  duration?: {
    min?: number;
    max?: number;
  };
}

/**
 * API响应接口
 */
export interface GetVideosResponse {
  /** 视频列表 */
  videos: EnhancedMovie[];
  /** 总数量 */
  total: number;
  /** 是否还有更多 */
  hasMore: boolean;
  /** 当前页码 */
  page: number;
  /** 每页数量 */
  limit: number;
}

/**
 * 视频详情请求接口
 */
export interface GetVideoDetailsRequest {
  /** 视频ID */
  videoId: string;
  /** 是否包含推荐 */
  includeRecommendations?: boolean;
  /** 推荐数量 */
  recommendationLimit?: number;
}

/**
 * 视频详情响应接口
 */
export interface GetVideoDetailsResponse {
  /** 视频详情 */
  video: EnhancedMovie;
  /** 推荐视频 */
  recommendations: VideoRecommendation[];
  /** 用户是否已收藏 */
  isFavorited?: boolean;
  /** 用户评分 */
  userRating?: number;
}

/**
 * 提交评论请求接口
 */
export interface SubmitCommentRequest {
  /** 视频ID */
  videoId: string;
  /** 评论内容 */
  content: string;
  /** 父评论ID */
  parentId?: string;
}

/**
 * 提交评论响应接口
 */
export interface SubmitCommentResponse {
  /** 新创建的评论 */
  comment: VideoComment;
  /** 操作是否成功 */
  success: boolean;
  /** 消息 */
  message?: string;
}