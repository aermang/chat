import { useRef, useEffect, useCallback } from 'react';

/**
 * 触控事件处理器接口
 */
export interface TouchHandlers {
  onTouchStart?: (e: TouchEvent) => void;
  onTouchMove?: (e: TouchEvent) => void;
  onTouchEnd?: (e: TouchEvent) => void;
  onTouchCancel?: (e: TouchEvent) => void;
}

/**
 * 滑动手势处理器接口
 */
export interface SwipeHandlers {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
}

/**
 * 滑动配置接口
 */
export interface SwipeConfig {
  threshold?: number; // 最小滑动距离
  velocity?: number;  // 最小滑动速度
  preventScroll?: boolean; // 是否阻止滚动
}

/**
 * 触控点信息
 */
interface TouchPoint {
  x: number;
  y: number;
  timestamp: number;
}

/**
 * 触控Hook - 处理基础触控事件
 * @param handlers - 触控事件处理器
 * @returns 元素引用
 */
export function useTouch(handlers: TouchHandlers): React.RefObject<HTMLElement> {
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const handleTouchStart = (e: TouchEvent) => {
      handlers.onTouchStart?.(e);
    };

    const handleTouchMove = (e: TouchEvent) => {
      handlers.onTouchMove?.(e);
    };

    const handleTouchEnd = (e: TouchEvent) => {
      handlers.onTouchEnd?.(e);
    };

    const handleTouchCancel = (e: TouchEvent) => {
      handlers.onTouchCancel?.(e);
    };

    element.addEventListener('touchstart', handleTouchStart, { passive: false });
    element.addEventListener('touchmove', handleTouchMove, { passive: false });
    element.addEventListener('touchend', handleTouchEnd, { passive: false });
    element.addEventListener('touchcancel', handleTouchCancel, { passive: false });

    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchmove', handleTouchMove);
      element.removeEventListener('touchend', handleTouchEnd);
      element.removeEventListener('touchcancel', handleTouchCancel);
    };
  }, [handlers]);

  return elementRef;
}

/**
 * 滑动手势Hook - 处理滑动手势
 * @param handlers - 滑动手势处理器
 * @param config - 滑动配置
 * @returns 元素引用
 */
export function useSwipe(
  handlers: SwipeHandlers,
  config: SwipeConfig = {}
): React.RefObject<HTMLElement> {
  const elementRef = useRef<HTMLElement>(null);
  const startPoint = useRef<TouchPoint | null>(null);
  const { threshold = 50, velocity = 0.3, preventScroll = false } = config;

  const handleTouchStart = useCallback((e: TouchEvent) => {
    if (e.touches.length !== 1) return;
    
    const touch = e.touches[0];
    startPoint.current = {
      x: touch.clientX,
      y: touch.clientY,
      timestamp: Date.now(),
    };
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (preventScroll) {
      e.preventDefault();
    }
  }, [preventScroll]);

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    if (!startPoint.current || e.changedTouches.length !== 1) return;

    const touch = e.changedTouches[0];
    const endPoint = {
      x: touch.clientX,
      y: touch.clientY,
      timestamp: Date.now(),
    };

    const deltaX = endPoint.x - startPoint.current.x;
    const deltaY = endPoint.y - startPoint.current.y;
    const deltaTime = endPoint.timestamp - startPoint.current.timestamp;
    
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const speed = distance / deltaTime;

    // 检查是否满足滑动条件
    if (distance < threshold || speed < velocity) {
      startPoint.current = null;
      return;
    }

    // 判断滑动方向
    const absDeltaX = Math.abs(deltaX);
    const absDeltaY = Math.abs(deltaY);

    if (absDeltaX > absDeltaY) {
      // 水平滑动
      if (deltaX > 0) {
        handlers.onSwipeRight?.();
      } else {
        handlers.onSwipeLeft?.();
      }
    } else {
      // 垂直滑动
      if (deltaY > 0) {
        handlers.onSwipeDown?.();
      } else {
        handlers.onSwipeUp?.();
      }
    }

    startPoint.current = null;
  }, [handlers, threshold, velocity]);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    element.addEventListener('touchstart', handleTouchStart, { passive: false });
    element.addEventListener('touchmove', handleTouchMove, { passive: !preventScroll });
    element.addEventListener('touchend', handleTouchEnd, { passive: false });

    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchmove', handleTouchMove);
      element.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd, preventScroll]);

  return elementRef;
}

/**
 * 长按手势Hook - 处理长按手势
 * @param onLongPress - 长按回调
 * @param delay - 长按延迟时间（毫秒）
 * @returns 元素引用
 */
export function useLongPress(
  onLongPress: () => void,
  delay: number = 500
): React.RefObject<HTMLElement> {
  const elementRef = useRef<HTMLElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isLongPressRef = useRef(false);

  const handleTouchStart = useCallback(() => {
    isLongPressRef.current = false;
    timeoutRef.current = setTimeout(() => {
      isLongPressRef.current = true;
      onLongPress();
    }, delay);
  }, [onLongPress, delay]);

  const handleTouchEnd = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);

  const handleTouchMove = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    element.addEventListener('touchstart', handleTouchStart, { passive: false });
    element.addEventListener('touchend', handleTouchEnd, { passive: false });
    element.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchend', handleTouchEnd);
      element.removeEventListener('touchmove', handleTouchMove);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [handleTouchStart, handleTouchEnd, handleTouchMove]);

  return elementRef;
}

/**
 * 触控反馈Hook - 提供触控反馈效果
 * @param options - 反馈配置
 * @returns 触摸事件处理函数
 */
/**
 * 触控反馈Hook - 提供触控时的视觉和触觉反馈
 * @param options - 反馈配置选项
 * @returns 触控反馈相关的处理器和样式
 */
export function useTouchFeedback(options: {
  haptic?: boolean;
  visual?: boolean;
  scale?: number;
  duration?: number;
} = {}) {
  const { haptic = true, visual = true, scale = 0.95, duration = 150 } = options;
  const elementRef = useRef<HTMLElement>(null);

  const handleTouchStart = useCallback((event: React.TouchEvent) => {
    const element = event.currentTarget as HTMLElement;
    
    // 触觉反馈
    if (haptic && 'vibrate' in navigator) {
      navigator.vibrate(10);
    }

    // 视觉反馈
    if (visual) {
      element.style.transform = `scale(${scale})`;
      element.style.transition = `transform ${duration}ms ease-out`;
    }
  }, [haptic, visual, scale, duration]);

  const handleTouchEnd = useCallback((event: React.TouchEvent) => {
    const element = event.currentTarget as HTMLElement;
    
    // 恢复视觉效果
    if (visual) {
      setTimeout(() => {
        element.style.transform = '';
        setTimeout(() => {
          element.style.transition = '';
        }, duration);
      }, 50);
    }
  }, [visual, duration]);

  const triggerFeedback = useCallback(() => {
    const element = elementRef.current;
    if (!element) return;

    // 触觉反馈
    if (haptic && 'vibrate' in navigator) {
      navigator.vibrate(10);
    }

    // 视觉反馈
    if (visual) {
      element.style.transform = `scale(${scale})`;
      element.style.transition = `transform ${duration}ms ease-out`;
      
      setTimeout(() => {
        element.style.transform = '';
        setTimeout(() => {
          element.style.transition = '';
        }, duration);
      }, 50);
    }
  }, [haptic, visual, scale, duration]);

  const touchStyles = {
    cursor: 'pointer',
    userSelect: 'none' as const,
    WebkitUserSelect: 'none' as const,
    WebkitTapHighlightColor: 'transparent',
  };

  return { 
    elementRef,
    handleTouchStart, 
    handleTouchEnd,
    triggerFeedback,
    touchStyles
  };
}