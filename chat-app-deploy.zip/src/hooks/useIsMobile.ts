/**
 * 移动端检测Hook
 * 检测当前设备是否为移动端
 */

import { useState, useEffect } from 'react';

/**
 * 移动端检测Hook
 * @returns 是否为移动端
 */
export const useIsMobile = (): boolean => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    /**
     * 检测是否为移动端设备
     */
    const checkIsMobile = () => {
      // 检查屏幕宽度
      const screenWidth = window.innerWidth;
      const isMobileWidth = screenWidth < 768;

      // 检查用户代理字符串
      const userAgent = navigator.userAgent.toLowerCase();
      const isMobileUA = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent);

      // 检查触摸支持
      const hasTouchSupport = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

      // 综合判断
      const mobile = isMobileWidth || (isMobileUA && hasTouchSupport);
      setIsMobile(mobile);
    };

    // 初始检测
    checkIsMobile();

    // 监听窗口大小变化
    window.addEventListener('resize', checkIsMobile);

    return () => {
      window.removeEventListener('resize', checkIsMobile);
    };
  }, []);

  return isMobile;
};