/**
 * 特药管理状态管理 Hook
 * 基于 Zustand 的特药管理数据状态管理
 * 专为销售代表的患者用药管理场景设计
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  Patient,
  MedicationRecord,
  MedicationReminder,
  SalesRep,
  AdherenceLog,
  WorkLog,
  StatisticsData,
  SpecialMedicineState,
  PatientForm,
  MedicationRecordForm,
  MedicationReminderForm,
  PatientFilterParams,
  MedicationRecordFilterParams,
  PaginationParams,
  PaginatedResult,
  MedicationStatistics,
  PatientStatistics,
  ReportData
} from '../types';

/**
 * 特药管理状态管理接口
 */
interface SpecialMedicineStore extends SpecialMedicineState {
  // ==================== 患者管理方法 ====================
  
  /**
   * 加载患者列表
   * @param filters 筛选参数
   * @param pagination 分页参数
   */
  loadPatients: (filters?: PatientFilterParams, pagination?: PaginationParams) => Promise<PaginatedResult<Patient>>;
  
  /**
   * 创建患者档案
   * @param patientData 患者表单数据
   * @returns 返回新创建患者的ID
   */
  createPatient: (patientData: PatientForm) => Promise<string>;
  
  /**
   * 更新患者信息
   * @param id 患者ID
   * @param updates 更新数据
   */
  updatePatient: (id: string, updates: Partial<Patient>) => Promise<boolean>;
  
  /**
   * 删除患者档案
   * @param id 患者ID
   */
  deletePatient: (id: string) => Promise<boolean>;
  
  /**
   * 根据ID获取患者信息
   * @param id 患者ID
   */
  getPatientById: (id: string) => Patient | undefined;
  
  /**
   * 搜索患者
   * @param keyword 搜索关键词
   */
  searchPatients: (keyword: string) => Patient[];

  /**
   * 设置当前患者
   * @param patient 患者对象
   */
  setCurrentPatient: (patient: Patient | null) => void;

  /**
   * 根据ID设置当前患者
   * @param patientId 患者ID
   */
  setCurrentPatientById: (patientId: string) => void;

  /**
   * 获取当前患者
   */
  getCurrentPatient: () => Patient | null;
  
  // ==================== 用药记录管理方法 ====================
  
  /**
   * 加载用药记录
   * @param filters 筛选参数
   * @param pagination 分页参数
   */
  loadMedicationRecords: (filters?: MedicationRecordFilterParams, pagination?: PaginationParams) => Promise<PaginatedResult<MedicationRecord>>;
  
  /**
   * 创建用药记录
   * @param recordData 用药记录表单数据
   */
  createMedicationRecord: (recordData: MedicationRecordForm) => Promise<boolean>;
  
  /**
   * 更新用药记录
   * @param id 记录ID
   * @param updates 更新数据
   */
  updateMedicationRecord: (id: string, updates: Partial<MedicationRecord>) => Promise<boolean>;
  
  /**
   * 删除用药记录
   * @param id 记录ID
   */
  deleteMedicationRecord: (id: string) => Promise<boolean>;
  
  /**
   * 获取指定患者的用药记录
   * @param patientId 患者ID
   */
  getMedicationRecordsByPatient: (patientId: string) => MedicationRecord[];
  
  /**
   * 标记用药记录为已服用
   * @param id 记录ID
   */
  markMedicationTaken: (id: string) => Promise<boolean>;

  // ==================== 用药提醒管理方法 ====================
  
  /**
   * 加载用药提醒
   * @param patientId 患者ID（可选）
   */
  loadReminders: (patientId?: string) => Promise<void>;
  
  /**
   * 创建用药提醒
   * @param reminderData 提醒表单数据
   */
  createMedicationReminder: (reminderData: MedicationReminderForm) => Promise<boolean>;
  
  /**
   * 更新用药提醒
   * @param id 提醒ID
   * @param updates 更新数据
   */
  updateMedicationReminder: (id: string, updates: Partial<MedicationReminder>) => Promise<boolean>;
  
  /**
   * 删除用药提醒
   * @param id 提醒ID
   */
  deleteMedicationReminder: (id: string) => Promise<boolean>;
  
  /**
   * 获取指定患者的用药提醒
   * @param patientId 患者ID
   */
  getRemindersByPatient: (patientId: string) => MedicationReminder[];
  
  /**
   * 切换提醒状态
   * @param id 提醒ID
   */
  toggleReminderStatus: (id: string) => Promise<boolean>;
  
  /**
   * 获取今日需要提醒的记录
   */
  getTodayReminders: () => MedicationReminder[];

  // ==================== 依从性管理方法 ====================
  
  /**
   * 加载依从性记录
   * @param patientId 患者ID
   */
  loadAdherenceLogs: (patientId?: string) => Promise<void>;
  
  /**
   * 创建依从性记录
   * @param adherenceData 依从性数据
   */
  createAdherenceLog: (adherenceData: Omit<AdherenceLog, 'id' | 'createdAt'>) => Promise<boolean>;
  
  /**
   * 计算患者依从性评分
   * @param patientId 患者ID
   * @param period 评估周期
   */
  calculateAdherenceScore: (patientId: string, period: 'daily' | 'weekly' | 'monthly') => Promise<number>;

  // ==================== 工作日志管理方法 ====================
  
  /**
   * 加载工作日志
   * @param salesRepId 销售代表ID
   */
  loadWorkLogs: (salesRepId?: string) => Promise<void>;
  
  /**
   * 创建工作日志
   * @param workLogData 工作日志数据
   */
  createWorkLog: (workLogData: Omit<WorkLog, 'id' | 'createdAt'>) => Promise<boolean>;

  // ==================== 统计分析方法 ====================
  
  /**
   * 加载统计数据
   */
  loadStatistics: () => Promise<void>;
  
  /**
   * 获取用药统计数据
   * @param period 统计周期
   */
  getMedicationStatistics: (period: 'daily' | 'weekly' | 'monthly') => Promise<MedicationStatistics[]>;
  
  /**
   * 获取患者统计数据
   */
  getPatientStatistics: () => Promise<PatientStatistics[]>;
  
  /**
   * 生成报告数据
   * @param type 报告类型
   * @param patientId 患者ID（可选）
   * @param period 报告期间
   */
  generateReport: (
    type: 'adherence' | 'follow_up' | 'medication_usage' | 'patient_summary',
    patientId?: string,
    period?: { startDate: Date; endDate: Date }
  ) => Promise<ReportData>;

  // ==================== 工具方法 ====================
  
  /**
   * 清除错误信息
   */
  clearError: () => void;
  
  /**
   * 设置加载状态
   * @param loading 加载状态
   */
  setLoading: (loading: boolean) => void;
  
  /**
   * 重置所有数据
   */
  resetStore: () => void;
  
  /**
   * 导出数据
   * @param format 导出格式
   */
  exportData: (format: 'json' | 'csv') => void;
}

/**
 * 生成唯一ID
 */
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

/**
 * 模拟API延迟
 */
const simulateApiDelay = (ms: number = 300): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * 格式化日期为字符串
 */
const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

/**
 * 计算依从性评分
 */
const calculateAdherence = (totalDoses: number, missedDoses: number): number => {
  if (totalDoses === 0) return 0;
  return Math.round(((totalDoses - missedDoses) / totalDoses) * 100);
};

/**
 * 创建特药管理状态存储
 */
export const useSpecialMedicineStore = create<SpecialMedicineStore>()(
  persist(
    (set, get) => ({
      // ==================== 初始状态 ====================
      patients: [],
      currentPatient: null,
      medicationRecords: [],
      reminders: [],
      salesReps: [],
      adherenceLogs: [],
      workLogs: [],
      statistics: null,
      isLoading: false,
      error: null,

      // ==================== 患者管理方法实现 ====================
      
      /**
       * 加载患者列表
       */
      loadPatients: async (filters, pagination) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          // 模拟患者数据
          const mockPatients: Patient[] = [
            {
              id: '1',
              name: '张三',
              gender: 'male',
              age: 45,
              idCard: '110101197901011234',
              phone: '13800138001',
              emergencyContact: '李四',
              emergencyPhone: '13800138002',
              address: '北京市朝阳区某某街道123号',
              doctor: '李医生',
              hospital: '北京协和医院',
              diagnosis: '高血压',
              treatment: '降压药物治疗',
              allergies: ['青霉素'],
              medicalHistory: '无重大疾病史',
              isActive: true,
              notes: '患者配合度较好',
              createdAt: new Date('2024-01-15'),
              updatedAt: new Date('2024-01-15')
            },
            {
              id: '2',
              name: '王芳',
              gender: 'female',
              age: 38,
              idCard: '110101198601011234',
              phone: '13800138003',
              emergencyContact: '王强',
              emergencyPhone: '13800138004',
              address: '北京市海淀区某某路456号',
              doctor: '王医生',
              hospital: '北京大学第一医院',
              diagnosis: '糖尿病',
              treatment: '胰岛素治疗',
              allergies: [],
              medicalHistory: '家族糖尿病史',
              isActive: true,
              notes: '需要定期监测血糖',
              createdAt: new Date('2024-01-20'),
              updatedAt: new Date('2024-01-20')
            },
            {
              id: '3',
              name: '刘强',
              gender: 'male',
              age: 52,
              idCard: '110101197201011234',
              phone: '13800138005',
              emergencyContact: '刘丽',
              emergencyPhone: '13800138006',
              address: '北京市西城区某某胡同789号',
              doctor: '赵医生',
              hospital: '北京天坛医院',
              diagnosis: '心脏病',
              treatment: '心脏药物治疗',
              allergies: ['磺胺类药物'],
              medicalHistory: '心肌梗死病史',
              isActive: false,
              notes: '已转院治疗',
              createdAt: new Date('2024-01-10'),
              updatedAt: new Date('2024-01-25')
            }
          ];

          // 应用筛选条件
          let filteredPatients = mockPatients;
          if (filters) {
            if (filters.keyword) {
              const keyword = filters.keyword.toLowerCase();
              filteredPatients = filteredPatients.filter(patient =>
                patient.name.toLowerCase().includes(keyword) ||
                patient.phone.includes(keyword) ||
                patient.doctor.toLowerCase().includes(keyword)
              );
            }
            if (filters.gender) {
              filteredPatients = filteredPatients.filter(patient => patient.gender === filters.gender);
            }
            if (filters.isActive !== undefined) {
              filteredPatients = filteredPatients.filter(patient => patient.isActive === filters.isActive);
            }
            if (filters.doctor) {
              filteredPatients = filteredPatients.filter(patient => patient.doctor === filters.doctor);
            }
          }

          // 应用分页
          const page = pagination?.page || 1;
          const pageSize = pagination?.pageSize || 10;
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize;
          const paginatedData = filteredPatients.slice(startIndex, endIndex);

          // 如果本地没有数据，使用模拟数据
          const currentPatients = get().patients;
          if (currentPatients.length === 0) {
            set({ patients: mockPatients });
          }

          const result: PaginatedResult<Patient> = {
            data: paginatedData,
            total: filteredPatients.length,
            page,
            pageSize,
            totalPages: Math.ceil(filteredPatients.length / pageSize),
            hasNext: endIndex < filteredPatients.length,
            hasPrev: page > 1
          };

          return result;
        } catch (error) {
          console.error('加载患者列表失败:', error);
          set({ error: '加载患者列表失败' });
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 创建患者档案
       * @param patientData 患者数据
       * @returns 返回新创建患者的ID字符串
       */
      createPatient: async (patientData) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const newPatient: Patient = {
            ...patientData,
            id: generateId(),
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date()
          };

          // 立即更新患者列表，确保新患者能被找到
          set(state => {
            const updatedPatients = [...state.patients, newPatient];
            console.log('创建患者成功，更新患者列表:', {
              newPatientId: newPatient.id,
              newPatientName: newPatient.name,
              totalPatients: updatedPatients.length
            });
            
            return {
              patients: updatedPatients
            };
          });

          // 直接返回新创建的患者ID，保持与接口定义一致
          return newPatient.id;
        } catch (error) {
          console.error('创建患者档案失败:', error);
          set({ error: '创建患者档案失败' });
          // 抛出错误，让调用方能够捕获并处理
          throw new Error('创建患者档案失败');
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 更新患者信息
       */
      updatePatient: async (id, updates) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            patients: state.patients.map(patient =>
              patient.id === id
                ? { ...patient, ...updates, updatedAt: new Date() }
                : patient
            )
          }));

          return true;
        } catch (error) {
          console.error('更新患者信息失败:', error);
          set({ error: '更新患者信息失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 删除患者档案
       */
      deletePatient: async (id) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            patients: state.patients.filter(patient => patient.id !== id),
            medicationRecords: state.medicationRecords.filter(record => record.patientId !== id),
            reminders: state.reminders.filter(reminder => reminder.patientId !== id),
            adherenceLogs: state.adherenceLogs.filter(log => log.patientId !== id),
            workLogs: state.workLogs.filter(log => log.patientId !== id)
          }));

          return true;
        } catch (error) {
          console.error('删除患者档案失败:', error);
          set({ error: '删除患者档案失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 根据ID获取患者信息
       */
      getPatientById: (id) => {
        return get().patients.find(patient => patient.id === id);
      },

      /**
       * 搜索患者
       */
      searchPatients: (keyword) => {
        const patients = get().patients;
        const searchTerm = keyword.toLowerCase();
        return patients.filter(patient =>
          patient.name.toLowerCase().includes(searchTerm) ||
          patient.phone.includes(searchTerm) ||
          patient.doctor.toLowerCase().includes(searchTerm) ||
          patient.diagnosis.toLowerCase().includes(searchTerm)
        );
      },

      // ==================== 用药记录管理方法实现 ====================
      
      /**
       * 加载用药记录
       */
      loadMedicationRecords: async (filters, pagination) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          // 模拟用药记录数据
          const mockRecords: MedicationRecord[] = [
            {
              id: '1',
              patientId: '1',
              medicineName: '降压药A',
              specification: '10mg',
              dosage: '1片',
              frequency: '每日一次',
              takenDate: new Date('2024-01-25'),
              takenTime: '08:00',
              isTaken: true,
              administrationRoute: 'oral',
              preSymptoms: '头晕',
              postReaction: '症状缓解',
              notes: '按时服用',
              recordedBy: '销售代表A',
              createdAt: new Date('2024-01-25'),
              updatedAt: new Date('2024-01-25')
            },
            {
              id: '2',
              patientId: '1',
              medicineName: '降压药A',
              specification: '10mg',
              dosage: '1片',
              frequency: '每日一次',
              takenDate: new Date('2024-01-26'),
              takenTime: '08:00',
              isTaken: false,
              administrationRoute: 'oral',
              notes: '忘记服用',
              recordedBy: '销售代表A',
              createdAt: new Date('2024-01-26'),
              updatedAt: new Date('2024-01-26')
            },
            {
              id: '3',
              patientId: '2',
              medicineName: '胰岛素',
              specification: '100IU/ml',
              dosage: '20单位',
              frequency: '每日两次',
              takenDate: new Date('2024-01-25'),
              takenTime: '07:00',
              isTaken: true,
              administrationRoute: 'injection',
              preSymptoms: '血糖偏高',
              postReaction: '血糖正常',
              recordedBy: '销售代表B',
              createdAt: new Date('2024-01-25'),
              updatedAt: new Date('2024-01-25')
            }
          ];

          // 应用筛选条件
          let filteredRecords = mockRecords;
          if (filters) {
            if (filters.patientId) {
              filteredRecords = filteredRecords.filter(record => record.patientId === filters.patientId);
            }
            if (filters.medicineName) {
              filteredRecords = filteredRecords.filter(record => 
                record.medicineName.toLowerCase().includes(filters.medicineName!.toLowerCase())
              );
            }
            if (filters.isTaken !== undefined) {
              filteredRecords = filteredRecords.filter(record => record.isTaken === filters.isTaken);
            }
            if (filters.dateRange) {
              filteredRecords = filteredRecords.filter(record => {
                const recordDate = record.takenDate;
                const { startDate, endDate } = filters.dateRange!;
                return (!startDate || recordDate >= startDate) && (!endDate || recordDate <= endDate);
              });
            }
          }

          // 应用分页
          const page = pagination?.page || 1;
          const pageSize = pagination?.pageSize || 10;
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize;
          const paginatedData = filteredRecords.slice(startIndex, endIndex);

          // 如果本地没有数据，使用模拟数据
          const currentRecords = get().medicationRecords;
          if (currentRecords.length === 0) {
            set({ medicationRecords: mockRecords });
          }

          const result: PaginatedResult<MedicationRecord> = {
            data: paginatedData,
            total: filteredRecords.length,
            page,
            pageSize,
            totalPages: Math.ceil(filteredRecords.length / pageSize),
            hasNext: endIndex < filteredRecords.length,
            hasPrev: page > 1
          };

          return result;
        } catch (error) {
          console.error('加载用药记录失败:', error);
          set({ error: '加载用药记录失败' });
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 创建用药记录
       */
      createMedicationRecord: async (recordData) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const newRecord: MedicationRecord = {
            ...recordData,
            id: generateId(),
            recordedBy: '当前销售代表', // 实际应用中应该从用户状态获取
            createdAt: new Date(),
            updatedAt: new Date()
          };

          set(state => ({
            medicationRecords: [...state.medicationRecords, newRecord]
          }));

          return true;
        } catch (error) {
          console.error('创建用药记录失败:', error);
          set({ error: '创建用药记录失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 更新用药记录
       */
      updateMedicationRecord: async (id, updates) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            medicationRecords: state.medicationRecords.map(record =>
              record.id === id
                ? { ...record, ...updates, updatedAt: new Date() }
                : record
            )
          }));

          return true;
        } catch (error) {
          console.error('更新用药记录失败:', error);
          set({ error: '更新用药记录失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 删除用药记录
       */
      deleteMedicationRecord: async (id) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            medicationRecords: state.medicationRecords.filter(record => record.id !== id)
          }));

          return true;
        } catch (error) {
          console.error('删除用药记录失败:', error);
          set({ error: '删除用药记录失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 获取指定患者的用药记录
       */
      getMedicationRecordsByPatient: (patientId) => {
        return get().medicationRecords.filter(record => record.patientId === patientId);
      },

      /**
       * 标记用药记录为已服用
       */
      markMedicationTaken: async (id) => {
        return get().updateMedicationRecord(id, { isTaken: true, updatedAt: new Date() });
      },

      // ==================== 用药提醒管理方法实现 ====================
      
      /**
       * 加载用药提醒
       */
      loadReminders: async (patientId) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          // 模拟提醒数据 - 修复：添加缺失的字段，确保数据结构完整
          const mockReminders: MedicationReminder[] = [
            {
              id: '1',
              patientId: '1',
              medicineName: '降压药A',
              dosage: '10mg',
              reminderTime: '08:00',
              reminderTimes: ['08:00', '20:00'],
              frequency: 'daily',
              isActive: true,
              reminderType: 'notification',
              advanceMinutes: 15,
              lastReminded: new Date('2024-01-25'),
              nextReminder: new Date('2024-01-26T08:00:00'),
              messageTemplate: '请记得服用{medicineName}',
              notes: '饭后服用',
              createdAt: new Date('2024-01-15'),
              updatedAt: new Date('2024-01-25')
            },
            {
              id: '2',
              patientId: '2',
              medicineName: '胰岛素',
              dosage: '20单位',
              reminderTime: '07:00',
              reminderTimes: ['07:00', '19:00'],
              frequency: 'daily',
              isActive: true,
              reminderType: 'notification',
              advanceMinutes: 30,
              lastReminded: new Date('2024-01-25'),
              nextReminder: new Date('2024-01-26T07:00:00'),
              messageTemplate: '请记得注射{medicineName}',
              notes: '餐前注射',
              createdAt: new Date('2024-01-20'),
              updatedAt: new Date('2024-01-25')
            },
            {
              id: '3',
              patientId: '2',
              medicineName: '维生素D',
              dosage: '400IU',
              reminderTime: '19:00',
              reminderTimes: ['19:00'],
              frequency: 'daily',
              isActive: false,
              reminderType: 'notification',
              advanceMinutes: 30,
              messageTemplate: '请记得服用{medicineName}',
              notes: '晚餐后服用',
              createdAt: new Date('2024-01-20'),
              updatedAt: new Date('2024-01-22')
            }
          ];

          // 获取当前存储的提醒数据
          const currentReminders = get().reminders;
          
          // 如果本地没有数据，使用模拟数据初始化
          if (currentReminders.length === 0) {
            set({ reminders: mockReminders });
          }
          
          // 修复：如果指定了患者ID，不需要在这里过滤，因为MedicationReminders组件会处理过滤
          // 这里只负责确保数据已加载
          
        } catch (error) {
          console.error('加载用药提醒失败:', error);
          set({ error: '加载用药提醒失败' });
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 创建用药提醒
       */
      createMedicationReminder: async (reminderData) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const newReminder: MedicationReminder = {
            ...reminderData,
            id: generateId(),
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date()
          };

          set(state => ({
            reminders: [...state.reminders, newReminder]
          }));

          return true;
        } catch (error) {
          console.error('创建用药提醒失败:', error);
          set({ error: '创建用药提醒失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 更新用药提醒
       */
      updateMedicationReminder: async (id, updates) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            reminders: state.reminders.map(reminder =>
              reminder.id === id
                ? { ...reminder, ...updates, updatedAt: new Date() }
                : reminder
            )
          }));

          return true;
        } catch (error) {
          console.error('更新用药提醒失败:', error);
          set({ error: '更新用药提醒失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 删除用药提醒
       */
      deleteMedicationReminder: async (id) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          set(state => ({
            reminders: state.reminders.filter(reminder => reminder.id !== id)
          }));

          return true;
        } catch (error) {
          console.error('删除用药提醒失败:', error);
          set({ error: '删除用药提醒失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 获取指定患者的用药提醒
       */
      getRemindersByPatient: (patientId) => {
        return get().reminders.filter(reminder => reminder.patientId === patientId);
      },

      /**
       * 切换提醒状态
       */
      toggleReminderStatus: async (id) => {
        const reminder = get().reminders.find(r => r.id === id);
        if (!reminder) return false;
        
        return get().updateMedicationReminder(id, { isActive: !reminder.isActive });
      },

      /**
       * 获取今日需要提醒的记录
       */
      getTodayReminders: () => {
        const today = new Date();
        const todayStr = formatDate(today);
        
        return get().reminders.filter(reminder => {
          if (!reminder.isActive || !reminder.nextReminder) return false;
          
          const reminderDateStr = formatDate(reminder.nextReminder);
          return reminderDateStr === todayStr;
        });
      },

      // ==================== 其他方法实现 ====================
      
      /**
       * 加载依从性记录
       */
      loadAdherenceLogs: async (patientId) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          // 模拟依从性记录
          const mockLogs: AdherenceLog[] = [
            {
              id: '1',
              patientId: '1',
              medicationRecordId: '1',
              adherenceScore: 85,
              assessmentDate: new Date('2024-01-25'),
              assessmentPeriod: 'weekly',
              missedDoses: 2,
              totalDoses: 14,
              adherenceLevel: 'good',
              notes: '整体依从性良好',
              createdAt: new Date('2024-01-25')
            }
          ];

          const filteredLogs = patientId 
            ? mockLogs.filter(log => log.patientId === patientId)
            : mockLogs;

          set({ adherenceLogs: filteredLogs });
        } catch (error) {
          console.error('加载依从性记录失败:', error);
          set({ error: '加载依从性记录失败' });
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 创建依从性记录
       */
      createAdherenceLog: async (adherenceData) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const newLog: AdherenceLog = {
            ...adherenceData,
            id: generateId(),
            createdAt: new Date()
          };

          set(state => ({
            adherenceLogs: [...state.adherenceLogs, newLog]
          }));

          return true;
        } catch (error) {
          console.error('创建依从性记录失败:', error);
          set({ error: '创建依从性记录失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 计算患者依从性评分
       */
      calculateAdherenceScore: async (patientId, period) => {
        try {
          const records = get().getMedicationRecordsByPatient(patientId);
          
          // 根据周期筛选记录
          const now = new Date();
          let startDate: Date;
          
          switch (period) {
            case 'daily':
              startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
              break;
            case 'weekly':
              startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
              break;
            case 'monthly':
              startDate = new Date(now.getFullYear(), now.getMonth(), 1);
              break;
          }
          
          const periodRecords = records.filter(record => record.takenDate >= startDate);
          const totalDoses = periodRecords.length;
          const takenDoses = periodRecords.filter(record => record.isTaken).length;
          
          return calculateAdherence(totalDoses, totalDoses - takenDoses);
        } catch (error) {
          console.error('计算依从性评分失败:', error);
          return 0;
        }
      },

      /**
       * 加载工作日志
       */
      loadWorkLogs: async (salesRepId) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          // 模拟工作日志
          const mockLogs: WorkLog[] = [
            {
              id: '1',
              salesRepId: 'rep1',
              patientId: '1',
              activityType: 'visit',
              description: '患者随访，检查用药情况',
              activityDate: new Date('2024-01-25'),
              duration: 30,
              outcome: '患者依从性良好',
              nextFollowUp: new Date('2024-02-01'),
              createdAt: new Date('2024-01-25')
            }
          ];

          const filteredLogs = salesRepId 
            ? mockLogs.filter(log => log.salesRepId === salesRepId)
            : mockLogs;

          set({ workLogs: filteredLogs });
        } catch (error) {
          console.error('加载工作日志失败:', error);
          set({ error: '加载工作日志失败' });
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 创建工作日志
       */
      createWorkLog: async (workLogData) => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const newLog: WorkLog = {
            ...workLogData,
            id: generateId(),
            createdAt: new Date()
          };

          set(state => ({
            workLogs: [...state.workLogs, newLog]
          }));

          return true;
        } catch (error) {
          console.error('创建工作日志失败:', error);
          set({ error: '创建工作日志失败' });
          return false;
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 加载统计数据
       */
      loadStatistics: async () => {
        set({ isLoading: true, error: null });
        
        try {
          await simulateApiDelay();
          
          const state = get();
          const statistics: StatisticsData = {
            totalPatients: state.patients.length,
            activePatients: state.patients.filter(p => p.isActive).length,
            todayMedicationRecords: state.medicationRecords.filter(r => 
              formatDate(r.takenDate) === formatDate(new Date())
            ).length,
            weeklyMedicationRecords: state.medicationRecords.filter(r => 
              r.takenDate >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
            ).length,
            monthlyMedicationRecords: state.medicationRecords.filter(r => 
              r.takenDate >= new Date(new Date().getFullYear(), new Date().getMonth(), 1)
            ).length,
            averageAdherence: 85, // 模拟数据
            activeReminders: state.reminders.filter(r => r.isActive).length,
            pendingFollowUps: 5 // 模拟数据
          };

          set({ statistics });
        } catch (error) {
          console.error('加载统计数据失败:', error);
          set({ error: '加载统计数据失败' });
        } finally {
          set({ isLoading: false });
        }
      },

      /**
       * 获取用药统计数据
       */
      getMedicationStatistics: async (period) => {
        try {
          await simulateApiDelay();
          
          // 模拟用药统计数据
          const mockStats: MedicationStatistics[] = [
            {
              medicineName: '降压药A',
              patientCount: 15,
              totalDoses: 450,
              adherencePercentage: 85,
              lastUsedDate: new Date('2024-01-25')
            },
            {
              medicineName: '胰岛素',
              patientCount: 8,
              totalDoses: 240,
              adherencePercentage: 92,
              lastUsedDate: new Date('2024-01-25')
            }
          ];

          return mockStats;
        } catch (error) {
          console.error('获取用药统计数据失败:', error);
          return [];
        }
      },

      /**
       * 获取患者统计数据
       */
      getPatientStatistics: async () => {
        try {
          await simulateApiDelay();
          
          // 模拟患者统计数据
          const mockStats: PatientStatistics[] = [
            {
              patientId: '1',
              patientName: '张三',
              totalMedicationDays: 30,
              adherenceScore: 85,
              lastMedicationDate: new Date('2024-01-25'),
              activeRemindersCount: 2
            },
            {
              patientId: '2',
              patientName: '王芳',
              totalMedicationDays: 25,
              adherenceScore: 92,
              lastMedicationDate: new Date('2024-01-25'),
              activeRemindersCount: 1
            }
          ];

          return mockStats;
        } catch (error) {
          console.error('获取患者统计数据失败:', error);
          return [];
        }
      },

      /**
       * 生成报告数据
       */
      generateReport: async (type, patientId, period) => {
        try {
          await simulateApiDelay();
          
          const now = new Date();
          const defaultPeriod = period || {
            startDate: new Date(now.getFullYear(), now.getMonth(), 1),
            endDate: now
          };

          const report: ReportData = {
            type,
            title: `${type === 'adherence' ? '用药依从性' : type === 'follow_up' ? '随访' : type === 'medication_usage' ? '用药使用' : '患者总结'}报告`,
            generatedDate: now,
            period: defaultPeriod,
            data: {}, // 实际应用中应该包含具体的报告数据
            summary: '报告生成成功'
          };

          return report;
        } catch (error) {
          console.error('生成报告失败:', error);
          throw error;
        }
      },

      /**
       * 清除错误信息
       */
      clearError: () => {
        set({ error: null });
      },

      /**
       * 设置加载状态
       */
      setLoading: (loading) => {
        set({ isLoading: loading });
      },

      /**
       * 重置存储状态
       */
      resetStore: () => {
        set({
          patients: [],
          currentPatient: null,
          medicationRecords: [],
          reminders: [],
          statistics: null,
          isLoading: false,
          error: null
        });
      },

      /**
       * 设置当前患者
       */
      setCurrentPatient: (patient) => {
        set({ currentPatient: patient });
      },

      /**
       * 根据ID设置当前患者
       */
      setCurrentPatientById: (patientId) => {
        const state = get();
        const patient = state.patients.find(p => p.id === patientId);
        if (patient) {
          set({ currentPatient: patient });
        } else {
          console.warn(`未找到ID为 ${patientId} 的患者`);
        }
      },

      /**
       * 获取当前患者
       */
      getCurrentPatient: () => {
        return get().currentPatient;
      },

      /**
       * 导出数据
       */
      exportData: (format) => {
        const state = get();
        const exportData = {
          patients: state.patients,
          medicationRecords: state.medicationRecords,
          reminders: state.reminders,
          statistics: state.statistics,
          exportDate: new Date().toISOString()
        };

        if (format === 'json') {
          const dataStr = JSON.stringify(exportData, null, 2);
          const dataBlob = new Blob([dataStr], { type: 'application/json' });
          const url = URL.createObjectURL(dataBlob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `special-medicine-data-${new Date().toISOString().split('T')[0]}.json`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        } else if (format === 'csv') {
          // 简单的CSV导出实现
          const csvData = state.patients.map(patient => ({
            患者姓名: patient.name,
            性别: patient.gender === 'male' ? '男' : '女',
            年龄: patient.age || '',
            电话: patient.phone,
            主治医生: patient.doctor,
            诊断: patient.diagnosis
          }));
          
          const csvHeaders = Object.keys(csvData[0] || {});
          const csvContent = [
            csvHeaders.join(','),
            ...csvData.map(row => csvHeaders.map(header => `"${row[header] || ''}"`).join(','))
          ].join('\n');
          
          const dataBlob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(dataBlob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `patients-data-${new Date().toISOString().split('T')[0]}.csv`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }
      }
    }),
    {
      name: 'special-medicine-store',
      partialize: (state) => ({
        patients: state.patients,
        medicationRecords: state.medicationRecords,
        reminders: state.reminders
      })
    }
  )
);