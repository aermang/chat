/**
 * 移动端检测和适配Hook
 * 提供移动端环境检测、屏幕尺寸监听等功能
 */

import { useState, useEffect } from 'react';
import { CapacitorService } from '../services/capacitorService';

interface MobileInfo {
  isMobile: boolean;
  isNative: boolean;
  platform: string;
  screenWidth: number;
  screenHeight: number;
  orientation: 'portrait' | 'landscape';
  isKeyboardVisible: boolean;
}

/**
 * 移动端适配Hook
 */
export const useMobile = (): MobileInfo => {
  const [mobileInfo, setMobileInfo] = useState<MobileInfo>({
    isMobile: false,
    isNative: false,
    platform: 'web',
    screenWidth: window.innerWidth,
    screenHeight: window.innerHeight,
    orientation: window.innerWidth < window.innerHeight ? 'portrait' : 'landscape',
    isKeyboardVisible: false
  });

  useEffect(() => {
    /**
     * 检测是否为移动端设备
     */
    const checkMobile = (): boolean => {
      // 检查用户代理字符串
      const userAgent = navigator.userAgent.toLowerCase();
      const mobileKeywords = ['android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'];
      const isMobileUA = mobileKeywords.some(keyword => userAgent.includes(keyword));
      
      // 检查屏幕尺寸
      const isMobileScreen = window.innerWidth <= 768;
      
      // 检查触摸支持
      const hasTouchSupport = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      
      return isMobileUA || (isMobileScreen && hasTouchSupport);
    };

    /**
     * 更新移动端信息
     */
    const updateMobileInfo = () => {
      const isMobile = checkMobile();
      const isNative = CapacitorService.isNative();
      const platform = CapacitorService.getPlatform();
      
      setMobileInfo(prev => ({
        ...prev,
        isMobile,
        isNative,
        platform,
        screenWidth: window.innerWidth,
        screenHeight: window.innerHeight,
        orientation: window.innerWidth < window.innerHeight ? 'portrait' : 'landscape'
      }));
    };

    // 初始化
    updateMobileInfo();

    /**
     * 监听窗口大小变化
     */
    const handleResize = () => {
      updateMobileInfo();
    };

    /**
     * 监听屏幕方向变化
     */
    const handleOrientationChange = () => {
      // 延迟更新，等待屏幕方向变化完成
      setTimeout(updateMobileInfo, 100);
    };

    // 添加事件监听器
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);

    // 如果是原生环境，添加键盘监听
    if (CapacitorService.isNative()) {
      // 导入Capacitor键盘插件
      import('@capacitor/keyboard').then(({ Keyboard }) => {
        Keyboard.addListener('keyboardWillShow', () => {
          setMobileInfo(prev => ({ ...prev, isKeyboardVisible: true }));
        });

        Keyboard.addListener('keyboardWillHide', () => {
          setMobileInfo(prev => ({ ...prev, isKeyboardVisible: false }));
        });
      }).catch(error => {
        console.warn('Keyboard plugin not available:', error);
      });
    }

    // 清理函数
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  return mobileInfo;
};

/**
 * 移动端样式适配Hook
 */
export const useMobileStyles = () => {
  const { isMobile, isNative, orientation, isKeyboardVisible } = useMobile();

  /**
   * 获取容器样式类名
   */
  const getContainerClassName = (baseClassName: string = ''): string => {
    const classes = [baseClassName];
    
    if (isMobile) {
      classes.push('mobile-container');
    }
    
    if (isNative) {
      classes.push('native-container');
    }
    
    if (orientation === 'landscape') {
      classes.push('landscape-mode');
    } else {
      classes.push('portrait-mode');
    }
    
    if (isKeyboardVisible) {
      classes.push('keyboard-visible');
    }
    
    return classes.filter(Boolean).join(' ');
  };

  /**
   * 获取安全区域样式
   */
  const getSafeAreaStyles = (): React.CSSProperties => {
    if (!isNative) {
      return {};
    }

    return {
      paddingTop: 'env(safe-area-inset-top)',
      paddingBottom: 'env(safe-area-inset-bottom)',
      paddingLeft: 'env(safe-area-inset-left)',
      paddingRight: 'env(safe-area-inset-right)'
    };
  };

  /**
   * 获取移动端优化的输入框样式
   */
  const getInputStyles = (): React.CSSProperties => {
    if (!isMobile) {
      return {};
    }

    return {
      fontSize: '16px', // 防止iOS缩放
      WebkitAppearance: 'none', // 移除默认样式
      borderRadius: '8px'
    };
  };

  return {
    isMobile,
    isNative,
    orientation,
    isKeyboardVisible,
    getContainerClassName,
    getSafeAreaStyles,
    getInputStyles
  };
};