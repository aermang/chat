import { useState, useEffect } from 'react';

/**
 * 视口信息接口
 */
export interface ViewportInfo {
  width: number;
  height: number;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
  orientation: 'portrait' | 'landscape';
  aspectRatio: number;
}

/**
 * 视口Hook - 获取当前视口信息
 * @returns 视口信息对象
 */
export function useViewport(): ViewportInfo {
  const [viewport, setViewport] = useState<ViewportInfo>(() => {
    if (typeof window === 'undefined') {
      return {
        width: 1024,
        height: 768,
        isMobile: false,
        isTablet: false,
        isDesktop: true,
        orientation: 'landscape',
        aspectRatio: 1024 / 768,
      };
    }

    const width = window.innerWidth;
    const height = window.innerHeight;
    const isMobile = width < 768;
    const isTablet = width >= 768 && width < 1024;
    const isDesktop = width >= 1024;
    const orientation = width > height ? 'landscape' : 'portrait';
    const aspectRatio = width / height;

    return {
      width,
      height,
      isMobile,
      isTablet,
      isDesktop,
      orientation,
      aspectRatio,
    };
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const isMobile = width < 768;
      const isTablet = width >= 768 && width < 1024;
      const isDesktop = width >= 1024;
      const orientation = width > height ? 'landscape' : 'portrait';
      const aspectRatio = width / height;

      setViewport({
        width,
        height,
        isMobile,
        isTablet,
        isDesktop,
        orientation,
        aspectRatio,
      });
    };

    // 使用 ResizeObserver 获得更好的性能
    let resizeObserver: ResizeObserver | null = null;
    
    if (window && 'ResizeObserver' in window) {
      resizeObserver = new ResizeObserver(handleResize);
      resizeObserver.observe(document.documentElement);
    } else if (window) {
      // 降级到 resize 事件
      window.addEventListener('resize', handleResize);
    }

    return () => {
      if (resizeObserver) {
        resizeObserver.disconnect();
      } else if (window) {
        window.removeEventListener('resize', handleResize);
      }
    };
  }, []);

  return viewport;
}

/**
 * 视口尺寸Hook - 仅获取宽高信息
 * @returns 视口宽高
 */
export function useViewportSize(): { width: number; height: number } {
  const [size, setSize] = useState(() => {
    if (typeof window !== 'undefined') {
      return {
        width: window.innerWidth,
        height: window.innerHeight,
      };
    }
    return { width: 1024, height: 768 };
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleResize = () => {
      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    if (window) {
      window.addEventListener('resize', handleResize);
    }
    
    return () => {
      if (window) {
        window.removeEventListener('resize', handleResize);
      }
    };
  }, []);

  return size;
}

/**
 * 屏幕方向Hook - 获取屏幕方向信息
 * @returns 屏幕方向
 */
export function useOrientation(): 'portrait' | 'landscape' {
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
    }
    return 'landscape';
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOrientationChange = () => {
      setOrientation(window.innerWidth > window.innerHeight ? 'landscape' : 'portrait');
    };

    if (window) {
      // 监听 orientationchange 事件（移动端）
      window.addEventListener('orientationchange', handleOrientationChange);
      // 监听 resize 事件作为备选
      window.addEventListener('resize', handleOrientationChange);
    }

    return () => {
      if (window) {
        window.removeEventListener('orientationchange', handleOrientationChange);
        window.removeEventListener('resize', handleOrientationChange);
      }
    };
  }, []);

  return orientation;
}