import { useState, useEffect } from 'react';

/**
 * 响应式断点值接口
 */
interface BreakpointValues<T> {
  xs?: T;
  sm?: T;
  md?: T;
  lg?: T;
  xl?: T;
  '2xl'?: T;
}

/**
 * 响应式断点配置
 */
const breakpoints = {
  xs: 320,
  sm: 480,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
} as const;

/**
 * 获取当前断点
 * @param width - 当前窗口宽度
 * @returns 当前断点名称
 */
function getCurrentBreakpoint(width: number): keyof typeof breakpoints {
  if (width >= breakpoints['2xl']) return '2xl';
  if (width >= breakpoints.xl) return 'xl';
  if (width >= breakpoints.lg) return 'lg';
  if (width >= breakpoints.md) return 'md';
  if (width >= breakpoints.sm) return 'sm';
  return 'xs';
}

/**
 * 根据断点值获取对应的值
 * @param values - 断点值配置
 * @param currentBreakpoint - 当前断点
 * @returns 对应的值
 */
function getValueForBreakpoint<T>(
  values: BreakpointValues<T>,
  currentBreakpoint: keyof typeof breakpoints
): T | undefined {
  // 按优先级顺序查找值
  const orderedBreakpoints: (keyof typeof breakpoints)[] = ['2xl', 'xl', 'lg', 'md', 'sm', 'xs'];
  const currentIndex = orderedBreakpoints.indexOf(currentBreakpoint);
  
  // 从当前断点开始向下查找
  for (let i = currentIndex; i < orderedBreakpoints.length; i++) {
    const breakpoint = orderedBreakpoints[i];
    if (values[breakpoint] !== undefined) {
      return values[breakpoint];
    }
  }
  
  return undefined;
}

/**
 * 响应式Hook - 根据屏幕尺寸返回对应的值
 * @param values - 不同断点对应的值
 * @returns 当前断点对应的值
 */
export function useResponsive<T>(values: BreakpointValues<T>): T | undefined {
  const [windowWidth, setWindowWidth] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth;
    }
    return 1024; // 默认值
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const currentBreakpoint = getCurrentBreakpoint(windowWidth);
  return getValueForBreakpoint(values, currentBreakpoint);
}

/**
 * 断点检查Hook - 检查当前是否匹配指定断点
 * @param breakpoint - 要检查的断点
 * @returns 是否匹配指定断点
 */
export function useBreakpoint(breakpoint: keyof typeof breakpoints): boolean {
  const [matches, setMatches] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= breakpoints[breakpoint];
    }
    return false;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleResize = () => {
      setMatches(window.innerWidth >= breakpoints[breakpoint]);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [breakpoint]);

  return matches;
}

/**
 * 移动端检查Hook - 检查当前是否为移动端
 * @returns 是否为移动端
 */
export function useIsMobile(): boolean {
  return !useBreakpoint('md');
}

/**
 * 平板检查Hook - 检查当前是否为平板
 * @returns 是否为平板
 */
export function useIsTablet(): boolean {
  const isMd = useBreakpoint('md');
  const isLg = useBreakpoint('lg');
  return isMd && !isLg;
}

/**
 * 桌面端检查Hook - 检查当前是否为桌面端
 * @returns 是否为桌面端
 */
export function useIsDesktop(): boolean {
  return useBreakpoint('lg');
}