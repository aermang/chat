import { useState, useEffect } from 'react';

/**
 * 安全区域边距接口
 */
export interface SafeAreaInsets {
  top: number;
  bottom: number;
  left: number;
  right: number;
}

/**
 * 获取CSS环境变量值
 * @param variable - CSS环境变量名
 * @returns 环境变量值（像素）
 */
function getCSSEnvValue(variable: string): number {
  if (typeof window === 'undefined' || !window.CSS?.supports) {
    return 0;
  }

  // 检查是否支持 env() 函数
  if (!window.CSS.supports('padding', `env(${variable})`)) {
    return 0;
  }

  // 创建临时元素来获取计算值
  const testElement = document.createElement('div');
  testElement.style.position = 'absolute';
  testElement.style.visibility = 'hidden';
  testElement.style.padding = `env(${variable})`;
  
  document.body.appendChild(testElement);
  
  const computedStyle = window.getComputedStyle(testElement);
  const paddingValue = computedStyle.paddingTop;
  
  document.body.removeChild(testElement);
  
  // 解析像素值
  const match = paddingValue.match(/^(\d+(?:\.\d+)?)px$/);
  return match ? parseFloat(match[1]) : 0;
}

/**
 * 安全区域Hook - 获取设备安全区域边距
 * @returns 安全区域边距信息
 */
export function useSafeArea(): SafeAreaInsets {
  const [safeArea, setSafeArea] = useState<SafeAreaInsets>(() => ({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  }));

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const updateSafeArea = () => {
      const top = getCSSEnvValue('safe-area-inset-top');
      const bottom = getCSSEnvValue('safe-area-inset-bottom');
      const left = getCSSEnvValue('safe-area-inset-left');
      const right = getCSSEnvValue('safe-area-inset-right');

      setSafeArea({ top, bottom, left, right });
    };

    // 初始化
    updateSafeArea();

    // 监听视口变化
    window.addEventListener('resize', updateSafeArea);
    window.addEventListener('orientationchange', updateSafeArea);

    // 监听视觉视口变化（虚拟键盘等）
    if ('visualViewport' in window && window.visualViewport) {
      window.visualViewport.addEventListener('resize', updateSafeArea);
    }

    return () => {
      window.removeEventListener('resize', updateSafeArea);
      window.removeEventListener('orientationchange', updateSafeArea);
      
      if ('visualViewport' in window && window.visualViewport) {
        window.visualViewport.removeEventListener('resize', updateSafeArea);
      }
    };
  }, []);

  return safeArea;
}

/**
 * 安全区域样式Hook - 生成安全区域相关的CSS样式
 * @param options - 配置选项
 * @returns CSS样式对象
 */
export function useSafeAreaStyles(options: {
  top?: boolean;
  bottom?: boolean;
  left?: boolean;
  right?: boolean;
} = {}) {
  const safeArea = useSafeArea();
  const { top = true, bottom = true, left = true, right = true } = options;

  return {
    paddingTop: top ? `${safeArea.top}px` : undefined,
    paddingBottom: bottom ? `${safeArea.bottom}px` : undefined,
    paddingLeft: left ? `${safeArea.left}px` : undefined,
    paddingRight: right ? `${safeArea.right}px` : undefined,
  };
}

/**
 * 检查是否有安全区域
 * @returns 是否存在安全区域
 */
export function useHasSafeArea(): boolean {
  const safeArea = useSafeArea();
  
  return safeArea.top > 0 || safeArea.bottom > 0 || safeArea.left > 0 || safeArea.right > 0;
}

/**
 * 获取安全区域CSS变量
 * @returns CSS变量对象
 */
export function useSafeAreaCSSVars(): Record<string, string> {
  const safeArea = useSafeArea();
  
  return {
    '--safe-area-inset-top': `${safeArea.top}px`,
    '--safe-area-inset-bottom': `${safeArea.bottom}px`,
    '--safe-area-inset-left': `${safeArea.left}px`,
    '--safe-area-inset-right': `${safeArea.right}px`,
  };
}