/**
 * 飞鸽风格即时通讯App - 状态管理
 * 使用Zustand管理全局状态
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  User, 
  Message, 
  Friendship, 
  Moment, 
  ChatSession,
  FriendRequest,
  Notification,
  FriendRequestState,
  NotificationState,
  FriendRequestAction
} from '../types';
import { ApiService as DatabaseService } from '../lib/apiService';
import { 
  Patient, 
  Medication, 
  MedicationRecord, 
  PatientService,
  MedicationService,
  ReminderService,
  StatisticsService,
  initializeMedicineDatabase
} from '../lib/medicineDatabase';
import { MedicationReminder } from '../types';
import { Reminder } from '../lib/medicineDatabase';

/**
 * 将 Reminder 转换为 MedicationReminder
 */
const convertReminderToMedicationReminder = (reminder: Reminder, medication?: Medication): MedicationReminder => {
  return {
    id: reminder.id || '',
    patientId: medication?.patientId || '',
    medicineName: medication?.medicineName || '',
    dosage: '1片', // 默认值，需要从 medication 获取
    reminderTime: reminder.reminderTime, // 主要提醒时间
    reminderTimes: [reminder.reminderTime],
    frequency: 'daily', // 默认值
    customInterval: 1,
    customUnit: 'days',
    reminderDays: [],
    weekdays: [],
    monthDay: 1,
    startDate: medication?.startDate || new Date(),
    endDate: medication?.endDate,
    notes: '',
    isActive: reminder.enabled,
    createdAt: reminder.createdAt,
    updatedAt: reminder.updatedAt
  };
};

/**
 * 应用状态接口
 */
interface AppStore {
  // 用户状态
  currentUser: User | null;
  isAuthenticated: boolean;
  theme: 'light' | 'dark';
  
  // 聊天状态
  messages: Message[];
  chatSessions: ChatSession[];
  
  // 好友状态
  friends: Friendship[];
  
  // 朋友圈状态
  moments: Moment[];
  
  // 好友申请状态
  friendRequests: FriendRequest[];
  
  // 通知状态
  notifications: NotificationState;
  
  // 轮询状态
  pollingInterval: NodeJS.Timeout | null;
  
  // 用户列表
  users: User[];
  
  // 特药管理状态
  patients: Patient[];
  medications: Medication[];
  medicationRecords: MedicationRecord[];
  reminders: MedicationReminder[];
  medicineStatistics: {
    totalPatients: number;
    activePatients: number;
    totalMedications: number;
    activeMedications: number;
  } | null;

  // 数据完整性和恢复
  lastSyncTime: number;
  dataVersion: string;
  isDataCorrupted: boolean;
  hasBackupData: boolean;
  initRetryCount: number;
  
  // 用户相关方法
  login: (username: string, password: string) => Promise<boolean>;
  register: (userData: any) => Promise<boolean>;
  logout: () => void;
  
  // 数据完整性和恢复方法
  initialize: () => Promise<void>;
  validateDataIntegrity: () => Promise<boolean>;
  handleDataCorruption: () => Promise<boolean>;
  backupUserData: () => Promise<boolean>;
  restoreUserData: () => Promise<boolean>;
  clearCorruptedData: () => Promise<void>;
  syncUserState: () => Promise<boolean>;
  
  // 聊天相关方法
  sendMessage: (receiverId: string, content: string, type?: 'text' | 'image' | 'voice') => Promise<boolean>;
  loadMessages: (friendId: string) => Promise<void>;
  loadChatSessions: () => Promise<void>;
  
  // 好友相关方法
  loadFriends: () => Promise<void>;
  addFriend: (friendId: string) => Promise<boolean>;
  
  // 朋友圈相关方法
  loadMoments: () => Promise<void>;
  createMoment: (content?: string, images?: string[]) => Promise<boolean>;
  
  // 好友申请相关方法
  loadFriendRequests: () => Promise<void>;
  sendFriendRequest: (toUserId: string, message?: string) => Promise<boolean>;
  handleFriendRequest: (requestId: string, action: FriendRequestAction) => Promise<boolean>;
  markFriendRequestAsRead: (requestId: string) => Promise<void>;
  
  // 搜索相关方法
  searchUsers: (query: string, currentUserId?: string) => Promise<User[]>;
  getUserById: (userId: string) => Promise<User | null>;
  
  // 通知相关方法
  loadNotifications: () => Promise<void>;
  markNotificationAsRead: (notificationId: string) => Promise<void>;
  clearNotificationBadge: (type?: string) => Promise<void>;
  
  // 实时轮询相关方法
  startPolling: () => void;
  stopPolling: () => void;
  checkForUpdates: () => Promise<void>;
  
  // 主题相关方法
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
  
  // 特药管理相关方法
  initializeMedicineData: () => Promise<void>;
  loadPatients: (options?: { page?: number; limit?: number; search?: string }) => Promise<void>;
  createPatient: (patientData: { name: string; gender: 'male' | 'female'; phone: string; doctor: string; diagnosis: string; treatment: string }) => Promise<boolean>;
  addPatient: (patientData: any) => Promise<boolean>;
  updatePatient: (id: string, updates: Partial<Patient>) => Promise<boolean>;
  deletePatient: (id: string) => Promise<boolean>;
  loadMedications: (patientId?: string) => Promise<void>;
  createMedication: (medicationData: { patientId: string; medicineName: string; cycleDays: number; dailyFrequency: number; startDate: Date; endDate?: Date }) => Promise<boolean>;
  recordMedicationTaken: (medicationId: string, takenData: { takenDate: Date; takenTime: string; isTaken: boolean; notes?: string }) => Promise<boolean>;
  loadMedicationRecords: () => Promise<void>;
  addMedicationRecord: (recordData: { patientId: string; medicationName: string; dosage: string; frequency: string; recordDate: string; notes?: string }) => Promise<boolean>;
  updateMedicationRecord: (id: string, updates: { patientId?: string; medicationName?: string; dosage?: string; frequency?: string; recordDate?: string; notes?: string }) => Promise<boolean>;
  loadReminders: () => Promise<void>;
  setMedicationReminder: (medicationId: string, settings: { enabled: boolean; advanceDays: number; reminderTime: string; soundEnabled: boolean }) => Promise<boolean>;
  loadMedicineStatistics: () => Promise<void>;
}

/**
 * 创建应用状态存储
 */
export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // 初始状态
      currentUser: null,
      isAuthenticated: false,
      theme: 'light',
      messages: [],
      chatSessions: [],
      friends: [],
      moments: [],
      friendRequests: [],
      notifications: {
        notifications: [],
        unreadCount: 0,
        friendRequestUnreadCount: 0,
        isLoading: false
      },
      pollingInterval: null,
      users: [],
      
      // 特药管理初始状态
      patients: [],
      medications: [],
      medicationRecords: [],
      reminders: [],
      medicineStatistics: null,

      // 数据完整性和恢复初始状态
      lastSyncTime: 0,
      dataVersion: '1.0.0',
      isDataCorrupted: false,
      hasBackupData: false,
      initRetryCount: 0,
  
      /**
       * 应用初始化 - 增强版本，包含数据完整性检查、自动登录和恢复机制
       */
      initialize: async () => {
        try {
          console.log('开始初始化应用...');
          
          // 初始化数据库
          await DatabaseService.initializeDatabase();
          
          // 初始化医疗数据库
          await get().initializeMedicineData();
          
          // 检查持久化状态中的用户信息
          const { currentUser, isAuthenticated, isDataCorrupted } = get();
          
          // 如果检测到数据损坏，先尝试恢复
          if (isDataCorrupted) {
            console.log('检测到数据损坏标记，尝试自动恢复...');
            const recovered = await get().handleDataCorruption();
            
            if (!recovered) {
              console.warn('自动恢复失败，需要用户重新登录');
              return;
            }
          }
          
          // 自动登录检查
          if (currentUser && isAuthenticated) {
            console.log('检测到已登录用户，执行状态同步...');
            
            // 使用syncUserState进行完整的状态同步
            const syncSuccess = await get().syncUserState();
            
            if (syncSuccess) {
              console.log('用户状态同步成功，自动登录完成');
              
              // 启动实时轮询
              get().startPolling();
              
              // 加载医疗相关数据
              await Promise.all([
                get().loadPatients(),
                get().loadMedications(),
                get().loadMedicationRecords(),
                get().loadReminders(),
                get().loadMedicineStatistics()
              ]);
              
              console.log('所有用户数据已加载完成');
            } else {
              console.error('用户状态同步失败，清除认证状态');
              set({ 
                currentUser: null, 
                isAuthenticated: false,
                isDataCorrupted: true 
              });
            }
          } else {
            console.log('未检测到已登录用户');
            
            // 检查是否有备份数据可以恢复
            try {
              const backupInfo = await DatabaseService.getBackupInfo();
              if (backupInfo && backupInfo.hasBackup) {
                console.log('发现备份数据，等待用户登录后自动恢复');
                // 设置提示标记，在登录时可以提示用户恢复数据
                set({ 
                  hasBackupData: true 
                });
              }
            } catch (error) {
              console.warn('检查备份数据失败:', error);
            }
          }
          
          // 设置定期数据完整性检查
          setInterval(async () => {
            const { currentUser, isAuthenticated } = get();
            if (currentUser && isAuthenticated) {
              const isValid = await get().validateDataIntegrity();
              if (!isValid) {
                console.warn('定期检查发现数据完整性问题');
                await get().handleDataCorruption();
              }
            }
          }, 10 * 60 * 1000); // 每10分钟检查一次
          
          console.log('应用初始化完成');
        } catch (error) {
          console.error('应用初始化失败:', error);
          set({ isDataCorrupted: true });
          
          // 尝试恢复机制
          try {
            console.log('尝试启动紧急恢复流程...');
            const recovered = await get().handleDataCorruption();
            
            if (recovered) {
              console.log('紧急恢复成功，重新初始化');
              // 递归调用初始化，但限制递归次数
              const retryCount = (get() as any).initRetryCount || 0;
              if (retryCount < 2) {
                set({ initRetryCount: retryCount + 1 });
                await get().initialize();
              }
            } else {
              console.error('紧急恢复失败，应用可能需要重置');
            }
          } catch (recoveryError) {
            console.error('紧急恢复流程失败:', recoveryError);
          }
        }
      },
      
      /**
       * 用户登录 - 使用API服务
       */
      login: async (username, password) => {
        try {
          console.log('开始用户登录...');
          
          const { user, token } = await DatabaseService.login(username, password);
          if (!user) {
            console.warn('用户认证失败');
            return false;
          }
          
          // 设置用户状态
          set({ 
            currentUser: user, 
            isAuthenticated: true,
            lastSyncTime: Date.now(),
            isDataCorrupted: false
          });
          
          // 登录成功后加载数据
          await Promise.all([
            get().loadChatSessions(),
            get().loadFriends(),
            get().loadFriendRequests(),
            get().loadNotifications()
          ]);
          
          // 启动实时轮询
          get().startPolling();
          
          console.log('用户登录成功，数据加载完成');
          return true;
        } catch (error) {
          console.error('登录失败:', error);
          set({ isDataCorrupted: true });
          return false;
        }
      },
      
      /**
       * 用户注册 - 使用API服务
       */
      register: async (userData) => {
        try {
          console.log('Store: 开始注册用户，数据:', userData);
          
          // 确保userData包含所有必需字段
          const completeUserData = {
            username: userData.username,
            password: userData.password,
            email: userData.email || `${userData.username}@example.com`, // 提供默认邮箱
            nickname: userData.nickname || userData.username, // 提供默认昵称
            is_online: false
          };
          
          const { user, token } = await DatabaseService.register(completeUserData);
          console.log('Store: 注册成功，用户数据:', user);
          
          // 设置用户状态
          set({ 
            currentUser: user, 
            isAuthenticated: true,
            lastSyncTime: Date.now(),
            isDataCorrupted: false
          });
          
          // 注册成功后加载初始数据
          await Promise.all([
            get().loadChatSessions(),
            get().loadFriends(),
            get().loadFriendRequests(),
            get().loadNotifications()
          ]);
          
          // 启动实时轮询
          get().startPolling();
          
          console.log('用户注册成功');
          return true;
        } catch (error) {
          console.error('Store: 注册失败:', error);
          set({ isDataCorrupted: true });
          return false;
        }
      },
      
      /**
       * 用户登出
       */
      /**
       * 用户登出 - 改进版本，保留用户数据，仅清除会话状态
       */
      logout: () => {
        console.log('用户登出，保留账户数据...');
        
        // 停止轮询
        get().stopPolling();
        
        // 备份当前用户数据（如果存在）
        const { currentUser } = get();
        if (currentUser) {
          get().backupUserData().catch(error => {
            console.error('登出时备份数据失败:', error);
          });
        }
        
        // 只清除会话相关状态，保留用户账户数据在IndexedDB中
        set({
          currentUser: null,
          isAuthenticated: false,
          messages: [],
          chatSessions: [],
          friends: [],
          moments: [],
          friendRequests: [],
          notifications: {
            notifications: [],
            unreadCount: 0,
            friendRequestUnreadCount: 0,
            isLoading: false
          },
          pollingInterval: null,
          users: [],
          // 保留数据完整性字段，不重置
          lastSyncTime: get().lastSyncTime,
          dataVersion: get().dataVersion,
          isDataCorrupted: false
        });
        
        console.log('用户已登出，账户数据已保留');
      },
      
      /**
       * 加载聊天会话列表
       */
      loadChatSessions: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
          
          const sessions = await DatabaseService.getChatSessions(currentUser.id);
          set({ chatSessions: sessions });
        } catch (error) {
          console.error('加载聊天会话失败:', error);
        }
      },
      
      /**
       * 加载与特定好友的聊天消息
       */
      loadMessages: async (friendId) => {
        try {
          const { currentUser } = get();
          if (!currentUser || !friendId) return;
          
          const messages = await DatabaseService.getMessages(friendId);
          set({ messages });
        } catch (error) {
          console.error('加载聊天消息失败:', error);
        }
      },
      
      /**
       * 发送消息
       */
      sendMessage: async (content, receiverId, type = 'text') => {
        try {
          const { currentUser } = get();
          if (!currentUser) return false;
          
          const messageData = {
            sender_id: currentUser.id,
            receiver_id: receiverId,
            content,
            message_type: type,
            is_read: false
          };
          
          const newMessage = await DatabaseService.sendMessage(messageData);
          if (!newMessage) return false;
          
          // 更新当前聊天消息列表
          const { messages } = get();
          set({ messages: [...messages, newMessage] });
          
          // 重新加载会话列表
          await get().loadChatSessions();
          
          return true;
        } catch (error) {
          console.error('发送消息失败:', error);
          return false;
        }
      },
      
      /**
       * 设置当前聊天
       */
      setCurrentChat: (friendId) => {
        if (friendId) {
          get().loadMessages(friendId);
        } else {
          set({ messages: [] });
        }
      },
      
      /**
       * 加载好友列表
       */
      loadFriends: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
          
          const friends = await DatabaseService.getFriends(currentUser.id);
          set({ friends });
        } catch (error) {
          console.error('加载好友列表失败:', error);
        }
      },
      
      /**
       * 添加好友
       */
      addFriend: async (friendId) => {
        try {
          const { currentUser } = get();
          if (!currentUser) return false;
          
          // 使用API服务添加好友
          const result = await DatabaseService.addFriend(currentUser.id, friendId);
          if (!result) return false;
          
          // 重新加载好友列表
          await get().loadFriends();
          
          return true;
        } catch (error) {
          console.error('添加好友失败:', error);
          return false;
        }
      },
      
      /**
       * 加载朋友圈动态
       */
      loadMoments: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
          
          const moments = await DatabaseService.getMoments(currentUser.id);
          set({ moments });
        } catch (error) {
          console.error('加载朋友圈动态失败:', error);
        }
      },
      
      /**
       * 发布朋友圈动态
       */
      createMoment: async (content, images) => {
        try {
          const { currentUser } = get();
          if (!currentUser) return false;
          
          const momentData = {
            user_id: currentUser.id,
            content,
            images
          };
          
          const newMoment = await DatabaseService.createMoment(momentData);
          if (!newMoment) return false;
          
          // 更新朋友圈列表
          set({ moments: [newMoment, ...get().moments] });
          
          return true;
        } catch (error) {
          console.error('发布朋友圈动态失败:', error);
          return false;
        }
      },
      
      /**
       * 好友申请相关方法
       */
  
      /**
       * 加载好友申请列表
       */
      loadFriendRequests: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
  
          const requests = await DatabaseService.getFriendRequests(currentUser.id);
          const unreadCount = await DatabaseService.getUnreadRequestCount(currentUser.id);
  
          set({ friendRequests: requests });
  
          // 同时更新通知状态中的好友申请未读数
          set(state => ({
            notifications: {
              ...state.notifications,
              friendRequestUnreadCount: unreadCount
            }
          }));
  
          console.log('好友申请列表加载完成:', requests.length, '个申请，', unreadCount, '个未读');
        } catch (error) {
          console.error('加载好友申请失败:', error);
        }
      },
  
      /**
       * 发送好友申请
       */
      sendFriendRequest: async (toUserId: string, message = '') => {
        try {
          const { currentUser } = get();
          if (!currentUser) return false;
  
          const request = await DatabaseService.sendFriendRequest(currentUser.id, toUserId, message);
          if (!request) return false;
  
          console.log('好友申请发送成功');
          return true;
        } catch (error) {
          console.error('发送好友申请失败:', error);
          return false;
        }
      },
  
      /**
       * 处理好友申请
       */
      handleFriendRequest: async (requestId: string, action: FriendRequestAction) => {
        try {
          // 将FriendRequestAction转换为DatabaseService期望的类型
          let dbAction: 'accept' | 'reject' | 'ignore';
          switch (action) {
            case 'accepted':
            case 'accept':
              dbAction = 'accept';
              break;
            case 'rejected':
            case 'reject':
              dbAction = 'reject';
              break;
            case 'ignore':
              dbAction = 'ignore';
              break;
            default:
              throw new Error(`不支持的操作类型: ${action}`);
          }

          await DatabaseService.handleFriendRequest(requestId, dbAction);
  
          // 重新加载好友申请列表
          await get().loadFriendRequests();
  
          // 如果接受了申请，重新加载好友列表
          if (dbAction === 'accept') {
            await get().loadFriends();
          }
  
          console.log('好友申请处理成功:', action);
          return true;
        } catch (error) {
          console.error('处理好友申请失败:', error);
          return false;
        }
      },
  
      /**
       * 标记好友申请为已读
       */
      markFriendRequestAsRead: async (requestId: string) => {
        try {
          await DatabaseService.markRequestAsRead(requestId);
          
          // 重新加载好友申请列表以更新未读数
          await get().loadFriendRequests();
          
          console.log('好友申请已标记为已读');
        } catch (error) {
          console.error('标记申请已读失败:', error);
        }
      },
  
      /**
       * 搜索用户
       */
      searchUsers: async (query: string, currentUserId?: string) => {
        try {
          const { currentUser } = get();
          const userId = currentUserId || currentUser?.id;
          
          if (!userId || !query.trim()) return [];

          const users = await DatabaseService.searchUsers(query.trim(), userId);
          console.log('搜索到用户:', users.length, '个');
          return users;
        } catch (error) {
          console.error('搜索用户失败:', error);
          return [];
        }
      },

      /**
       * 根据ID获取用户信息
       */
      getUserById: async (userId: string) => {
        try {
          const user = await DatabaseService.getUserById(userId);
          return user;
        } catch (error) {
          console.error('获取用户信息失败:', error);
          throw error;
        }
      },
  
      /**
       * 通知相关方法
       */
  
      /**
       * 加载通知列表
       */
      loadNotifications: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
  
          set(state => ({
            notifications: { ...state.notifications, isLoading: true }
          }));
  
          const notifications = await DatabaseService.getNotifications(currentUser.id);
          const unreadCount = await DatabaseService.getUnreadNotificationCount(currentUser.id);
          const friendRequestUnreadCount = await DatabaseService.getUnreadNotificationCount(currentUser.id, 'friend_request');
  
          set({
            notifications: {
              notifications,
              unreadCount,
              friendRequestUnreadCount,
              isLoading: false
            }
          });
  
          console.log('通知列表加载完成:', notifications.length, '个通知，', unreadCount, '个未读');
        } catch (error) {
          console.error('加载通知失败:', error);
          set(state => ({
            notifications: { ...state.notifications, isLoading: false }
          }));
        }
      },
  
      /**
       * 标记通知为已读
       */
      markNotificationAsRead: async (notificationId: string) => {
        try {
          await DatabaseService.markNotificationAsRead(notificationId);
          
          // 重新加载通知列表
          await get().loadNotifications();
          
          console.log('通知已标记为已读');
        } catch (error) {
          console.error('标记通知已读失败:', error);
        }
      },
  
      /**
       * 清除通知徽章
       */
      clearNotificationBadge: async (type?: string) => {
        try {
          const { currentUser } = get();
          if (!currentUser) return;
  
          await DatabaseService.clearNotificationBadge(currentUser.id, type);
          
          // 重新加载通知和好友申请状态
          await Promise.all([
            get().loadNotifications(),
            get().loadFriendRequests()
          ]);
          
          console.log('通知徽章已清除');
        } catch (error) {
          console.error('清除通知徽章失败:', error);
        }
      },
  
      /**
       * 实时轮询相关方法
       */
  
      /**
       * 开始轮询
       */
      startPolling: () => {
        const { pollingInterval } = get();
        
        // 如果已经在轮询，先停止
        if (pollingInterval) {
          clearInterval(pollingInterval);
        }
  
        // 立即检查一次
        get().checkForUpdates();
  
        // 每3秒轮询一次
        const interval = setInterval(() => {
          get().checkForUpdates();
        }, 3000);
  
        set({ pollingInterval: interval });
        console.log('实时轮询已启动');
      },
  
      /**
       * 停止轮询
       */
      stopPolling: () => {
        const { pollingInterval } = get();
        
        if (pollingInterval) {
          clearInterval(pollingInterval);
          set({ pollingInterval: null });
          console.log('实时轮询已停止');
        }
      },
  
      /**
       * 检查更新
       */
      checkForUpdates: async () => {
        try {
          const { currentUser, isAuthenticated, lastSyncTime } = get();
          if (!currentUser || !isAuthenticated) return;

          // 每5分钟进行一次数据完整性检查
          const now = Date.now();
          const shouldCheckIntegrity = (now - lastSyncTime) > 5 * 60 * 1000; // 5分钟

          if (shouldCheckIntegrity) {
            console.log('执行定期数据完整性检查...');
            
            const isValid = await get().validateDataIntegrity();
            if (!isValid) {
              console.warn('数据完整性检查失败，尝试恢复...');
              
              const restored = await get().restoreUserData();
              if (!restored) {
                console.error('数据恢复失败，标记数据损坏');
                set({ isDataCorrupted: true });
                return;
              }
            }
            
            // 定期备份数据
            await get().backupUserData();
          }
  
          // 并行检查好友申请和通知更新
          await Promise.all([
            get().loadFriendRequests(),
            get().loadNotifications()
          ]);
        } catch (error) {
          console.error('检查更新失败:', error);
          
          // 如果检查更新失败，可能是数据问题
          const { currentUser } = get();
          if (currentUser) {
            const isValid = await get().validateDataIntegrity();
            if (!isValid) {
              set({ isDataCorrupted: true });
            }
          }
        }
      },
  
      /**
       * 切换主题
       */
      toggleTheme: () => {
        const { theme } = get();
        const newTheme = theme === 'light' ? 'dark' : 'light';
        set({ theme: newTheme });
        
        // 更新HTML元素的class
        if (newTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      },
      
      /**
       * 设置主题
       */
      setTheme: (theme) => {
        set({ theme });
        
        // 保存主题设置到localStorage
        localStorage.setItem('theme', theme);
        
        // 更新HTML元素的class
        if (theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      },
      
      /**
       * 特药管理相关方法
       */
      
      /**
       * 初始化特药管理数据
       */
      initializeMedicineData: async () => {
        try {
          await initializeMedicineDatabase();
          console.log('特药管理数据初始化完成');
        } catch (error) {
          console.error('特药管理数据初始化失败:', error);
        }
      },
      
      /**
       * 加载患者列表
       */
      loadPatients: async (options = {}) => {
        try {
          const result = await PatientService.getPatients(options);
          set({ patients: result.patients });
          console.log('患者列表加载完成:', result.patients.length, '个患者');
        } catch (error) {
          console.error('加载患者列表失败:', error);
        }
      },
      
      /**
       * 创建患者
       */
      createPatient: async (patientData) => {
        try {
          const patient = await PatientService.createPatient(patientData);
          if (patient) {
            // 重新加载患者列表
            await get().loadPatients();
            console.log('患者创建成功');
            return true;
          }
          return false;
        } catch (error) {
          console.error('创建患者失败:', error);
          return false;
        }
      },

      /**
       * 添加患者（createPatient的别名）
       */
      addPatient: async (patientData) => {
        return get().createPatient(patientData);
      },
      
      /**
       * 更新患者信息
       */
      updatePatient: async (id, updates) => {
        try {
          const success = await PatientService.updatePatient(id, updates);
          if (success) {
            // 重新加载患者列表
            await get().loadPatients();
            console.log('患者信息更新成功');
          }
          return success;
        } catch (error) {
          console.error('更新患者信息失败:', error);
          return false;
        }
      },
      
      /**
       * 删除患者
       */
      deletePatient: async (id) => {
        try {
          const success = await PatientService.deletePatient(id);
          if (success) {
            // 重新加载患者列表
            await get().loadPatients();
            console.log('患者删除成功');
          }
          return success;
        } catch (error) {
          console.error('删除患者失败:', error);
          return false;
        }
      },
      
      /**
       * 加载用药记录
       */
      loadMedications: async (patientId) => {
        try {
          const medications = await MedicationService.getPatientMedications(patientId);
          set({ medications });
          console.log('用药记录加载完成:', medications.length, '条记录');
        } catch (error) {
          console.error('加载用药记录失败:', error);
        }
      },
      
      /**
       * 创建用药记录
       */
      createMedication: async (medicationData) => {
        try {
          const medication = await MedicationService.createMedication(medicationData);
          if (medication) {
            // 重新加载用药记录
            await get().loadMedications();
            console.log('用药记录创建成功');
            return true;
          }
          return false;
        } catch (error) {
          console.error('创建用药记录失败:', error);
          return false;
        }
      },
      
      /**
       * 记录用药情况
       */
      recordMedicationTaken: async (medicationId, takenData) => {
        try {
          const record = await MedicationService.recordMedicationTaken(medicationId, takenData);
          if (record) {
            // 重新加载用药记录
            await get().loadMedications();
            console.log('用药情况记录成功');
            return true;
          }
          return false;
        } catch (error) {
          console.error('记录用药情况失败:', error);
          return false;
        }
      },

      /**
       * 加载所有用药记录
       */
      loadMedicationRecords: async () => {
        try {
          const records = await MedicationService.getAllMedicationRecords();
          set({ medicationRecords: records });
          console.log('用药记录加载完成:', records.length, '条记录');
        } catch (error) {
          console.error('加载用药记录失败:', error);
        }
      },

      /**
       * 添加用药记录
       */
      addMedicationRecord: async (recordData) => {
        try {
          const record = await MedicationService.addMedicationRecord(recordData);
          if (record) {
            // 重新加载用药记录
            await get().loadMedicationRecords();
            console.log('用药记录添加成功');
            return true;
          }
          return false;
        } catch (error) {
          console.error('添加用药记录失败:', error);
          return false;
        }
      },

      /**
       * 更新用药记录
       */
      updateMedicationRecord: async (id, updates) => {
        try {
          const success = await MedicationService.updateMedicationRecord(id, updates);
          if (success) {
            // 重新加载用药记录
            await get().loadMedicationRecords();
            console.log('用药记录更新成功');
          }
          return success;
        } catch (error) {
          console.error('更新用药记录失败:', error);
          return false;
        }
      },
      
      /**
       * 加载用药提醒
       */
      loadReminders: async () => {
        try {
          const rawReminders = await ReminderService.getPendingReminders();
          // 获取相关的用药信息来转换提醒数据
          const medications = await MedicationService.getActiveMedications();
          const medicationMap = new Map(medications.map(m => [m.id!, m]));
          
          const reminders: MedicationReminder[] = rawReminders.map(reminder => {
            const medication = medicationMap.get(reminder.medicationId);
            return convertReminderToMedicationReminder(reminder, medication);
          });
          
          set({ reminders });
          console.log('用药提醒加载完成:', reminders.length, '个提醒');
        } catch (error) {
          console.error('加载用药提醒失败:', error);
        }
      },
      
      /**
       * 设置用药提醒
       */
      setMedicationReminder: async (medicationId, settings) => {
        try {
          const reminder = await ReminderService.setMedicationReminder(medicationId, settings);
          const success = !!reminder;
          if (success) {
            // 重新加载提醒列表
            await get().loadReminders();
            console.log('用药提醒设置成功');
          }
          return success;
        } catch (error) {
          console.error('设置用药提醒失败:', error);
          return false;
        }
      },
      
      /**
       * 加载用药统计数据
       */
      loadMedicineStatistics: async () => {
        try {
          const statistics = await StatisticsService.getPatientStatistics();
          set({ medicineStatistics: statistics });
          console.log('特药统计数据加载完成:', statistics);
        } catch (error) {
          console.error('加载特药统计数据失败:', error);
        }
      },

      /**
       * 验证数据完整性
       */
      validateDataIntegrity: async () => {
        try {
          const { currentUser, isAuthenticated, dataVersion } = get();
          
          // 检查基本状态一致性
          if (isAuthenticated && !currentUser) {
            console.warn('数据不一致：已认证但无用户信息');
            return false;
          }
          
          // 检查用户是否存在于数据库中
          if (currentUser) {
            const isValid = await DatabaseService.validateUserDataIntegrity(currentUser.id);
            if (!isValid) {
              console.warn('数据不一致：用户数据验证失败');
              return false;
            }
          }
          
          // 检查数据版本
          if (!dataVersion || dataVersion !== '1.0.0') {
            console.warn('数据版本不匹配');
            return false;
          }
          
          console.log('数据完整性验证通过');
          return true;
        } catch (error) {
          console.error('数据完整性验证失败:', error);
          return false;
        }
      },

      /**
       * 全局错误恢复机制
       */
      handleDataCorruption: async () => {
        try {
          console.log('检测到数据损坏，开始恢复流程...');
          
          // 尝试从备份恢复
          const restored = await get().restoreUserData();
          if (restored) {
            console.log('数据恢复成功');
            set({ isDataCorrupted: false });
            return true;
          }
          
          // 如果恢复失败，清除损坏数据
          console.warn('数据恢复失败，清除损坏数据');
          await get().clearCorruptedData();
          
          // 提示用户重新登录
          console.log('请重新登录以重建数据');
          return false;
        } catch (error) {
          console.error('数据恢复流程失败:', error);
          return false;
        }
      },

      /**
       * 备份用户数据
       */
      backupUserData: async () => {
        const { currentUser } = get();
        if (!currentUser) return false;

        try {
          // 使用DatabaseService的备份方法
          const success = await DatabaseService.backupUserDataToStorage(currentUser.id);
          
          if (success) {
            set({ lastSyncTime: Date.now() });
          }
          
          return success;
        } catch (error) {
          console.error('备份用户数据失败:', error);
          return false;
        }
      },

      /**
       * 恢复用户数据
       */
      restoreUserData: async () => {
        try {
          const { currentUser } = get();
          if (!currentUser) {
            return false;
          }
          
          // 使用DatabaseService的恢复方法
          const success = await DatabaseService.restoreUserDataFromStorage(currentUser.id);
          
          if (success) {
            // 重新加载数据到状态中
            const [friends, chatSessions, notifications] = await Promise.all([
              DatabaseService.getFriends(currentUser.id),
              DatabaseService.getChatSessions(currentUser.id),
              DatabaseService.getNotifications(currentUser.id)
            ]);

            set({
              friends,
              chatSessions,
              notifications: {
                notifications,
                unreadCount: notifications.filter(n => !n.is_read).length,
                friendRequestUnreadCount: notifications.filter(n => n.type === 'friend_request' && !n.is_read).length,
                isLoading: false
              },
              lastSyncTime: Date.now(),
              isDataCorrupted: false
            });
          }

          return success;
        } catch (error) {
          console.error('恢复用户数据失败:', error);
          return false;
        }
      },

      /**
       * 清除损坏的数据
       */
      clearCorruptedData: async () => {
        try {
          console.log('清除损坏的数据...');
          
          const { currentUser } = get();
          if (currentUser) {
            // 使用DatabaseService清除损坏的数据
            await DatabaseService.clearCorruptedUserData(currentUser.id);
          }
          
          // 清除状态
          set({
            currentUser: null,
            isAuthenticated: false,
            messages: [],
            chatSessions: [],
            friends: [],
            moments: [],
            friendRequests: [],
            notifications: {
              notifications: [],
              unreadCount: 0,
              friendRequestUnreadCount: 0,
              isLoading: false
            },
            users: [],
            isDataCorrupted: false,
            lastSyncTime: 0
          });
          
          // 清除相关的localStorage备份
          const keys = Object.keys(localStorage);
          keys.forEach(key => {
            if (key.startsWith('user_backup_')) {
              localStorage.removeItem(key);
            }
          });
          
          console.log('损坏数据已清除');
      } catch (error) {
        console.error('清除损坏数据失败:', error);
      }
    },

    /**
     * 同步用户状态 - 确保认证状态与数据库数据一致
     */
    syncUserState: async () => {
      const { currentUser, isAuthenticated } = get();
      
      if (!currentUser || !isAuthenticated) {
        return false;
      }

      try {
        console.log('开始同步用户状态...');
        
        // 验证用户数据完整性
        const isValid = await DatabaseService.validateUserDataIntegrity(currentUser.id);
        
        if (!isValid) {
          console.warn('用户数据验证失败，尝试恢复...');
          
          // 尝试从备份恢复
          const restored = await get().restoreUserData();
          
          if (!restored) {
            console.error('数据恢复失败，清除认证状态');
            set({
              currentUser: null,
              isAuthenticated: false,
              isDataCorrupted: true
            });
            return false;
          }
        }
        
        // 重新加载用户数据以确保同步
        const [friends, chatSessions, notifications] = await Promise.all([
          DatabaseService.getFriends(currentUser.id),
          DatabaseService.getChatSessions(currentUser.id),
          DatabaseService.getNotifications(currentUser.id)
        ]);

        // 更新状态
        set({
          friends,
          chatSessions,
          notifications: {
            notifications,
            unreadCount: notifications.filter(n => !n.is_read).length,
            friendRequestUnreadCount: notifications.filter(n => n.type === 'friend_request' && !n.is_read).length,
            isLoading: false
          },
          lastSyncTime: Date.now(),
          isDataCorrupted: false
        });

        // 备份最新数据
        await get().backupUserData();
        
        console.log('用户状态同步完成');
        return true;
      } catch (error) {
        console.error('用户状态同步失败:', error);
        set({ isDataCorrupted: true });
        return false;
      }
    }
    }),
    {
      name: 'chat-app-storage',
      partialize: (state) => ({
        // 基本用户状态
        currentUser: state.currentUser,
        isAuthenticated: state.isAuthenticated,
        theme: state.theme,
        
        // 数据完整性状态
        lastSyncTime: state.lastSyncTime,
        dataVersion: state.dataVersion,
        isDataCorrupted: state.isDataCorrupted,
        hasBackupData: state.hasBackupData,
        
        // 用户数据
        friends: state.friends,
        chatSessions: state.chatSessions
      }),
      
      // 添加存储选项，提高数据持久性
      storage: {
        getItem: (name) => {
          try {
            const item = localStorage.getItem(name);
            return item ? JSON.parse(item) : null;
          } catch (error) {
            console.error('读取持久化数据失败:', error);
            return null;
          }
        },
        setItem: (name, value) => {
          try {
            localStorage.setItem(name, JSON.stringify(value));
            // 同时创建一个备份副本
            localStorage.setItem(`${name}_backup`, JSON.stringify({
              data: value,
              timestamp: Date.now()
            }));
          } catch (error) {
            console.error('保存持久化数据失败:', error);
          }
        },
        removeItem: (name) => {
          try {
            localStorage.removeItem(name);
            localStorage.removeItem(`${name}_backup`);
          } catch (error) {
            console.error('删除持久化数据失败:', error);
          }
        }
      },
      
      // 版本控制和迁移
      version: 1,
      migrate: (persistedState: any, version: number) => {
        console.log('执行数据迁移，版本:', version);
        
        // 如果是旧版本数据，进行迁移
        if (version === 0) {
          return {
            ...persistedState,
            lastSyncTime: 0,
            dataVersion: '1.0.0',
            isDataCorrupted: false,
            friends: [],
            chatSessions: []
          };
        }
        
        return persistedState;
      }
    }
  )
);

// 导出默认的应用状态存储
export default useAppStore;

// 导出特药管理相关的状态管理（作为 useAppStore 的别名）
export const useSpecialMedicineStore = () => {
  const store = useAppStore();
  return {
    // 患者相关
    patients: store.patients,
    loadPatients: store.loadPatients,
    createPatient: store.createPatient,
    addPatient: store.addPatient,
    updatePatient: store.updatePatient,
    deletePatient: store.deletePatient,
    
    // 用药记录相关
    medications: store.medications,
    medicationRecords: store.medicationRecords,
    loadMedications: store.loadMedications,
    createMedication: store.createMedication,
    recordMedicationTaken: store.recordMedicationTaken,
    loadMedicationRecords: store.loadMedicationRecords,
    addMedicationRecord: store.addMedicationRecord,
    updateMedicationRecord: store.updateMedicationRecord,
    
    // 提醒相关
    reminders: store.reminders,
    loadReminders: store.loadReminders,
    setMedicationReminder: store.setMedicationReminder,
    
    // 统计相关
    medicineStatistics: store.medicineStatistics,
    loadMedicineStatistics: store.loadMedicineStatistics,
    
    // 初始化
    initializeMedicineData: store.initializeMedicineData,
    
    // 状态管理
    loading: false,
    error: null,
    
    // 用药提醒相关（为了兼容现有代码）
    medicationReminders: store.reminders,
    loadMedicationReminders: store.loadReminders,
    createMedicationReminder: async (reminderData: Omit<MedicationReminder, 'id' | 'createdAt' | 'updatedAt'>) => {
      // 创建提醒的逻辑
      console.log('创建提醒:', reminderData);
      return true;
    },
    deleteMedicationReminder: async (id: string) => {
      // 这里需要实现删除提醒的逻辑
      console.log('删除提醒:', id);
      return true;
    },
    updateMedicationReminder: async (id: string, updates: any) => {
      // 这里需要实现更新提醒的逻辑
      console.log('更新提醒:', id, updates);
      return true;
    },
    clearError: () => {
      // 清除错误状态
      console.log('清除错误状态');
    }
  };
};