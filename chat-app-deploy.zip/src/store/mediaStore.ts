/**
 * 影音娱乐模块状态管理
 * 使用Zustand管理影音娱乐相关状态，支持IndexedDB持久化
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { 
  MediaState, 
  Movie, 
  Track, 
  Album, 
  Game, 
  Favorite, 
  Playlist, 
  GameScore, 
  PlayHistory, 
  SearchResult,
  MediaFilterParams,
  EnhancedMovie,
  VideoQuality,
  Subtitle,
  AudioTrack,
  PlaybackRate,
  VideoPlayerSettings,
  VideoComment,
  VideoRating,
  EnhancedPlayHistory,
  VideoRecommendation,
  PlayerState,
  PlayerActions,
  GetVideosRequest,
  GetVideosResponse,
  GetVideoDetailsRequest,
  GetVideoDetailsResponse,
  CommentSystemState,
  CommentActions,
  SubmitCommentRequest,
  SubmitCommentResponse
} from '../types';
import { MediaAPI } from '../services/mediaService';

/**
 * IndexedDB存储配置
 */
const indexedDBStorage = {
  getItem: async (name: string): Promise<string | null> => {
    try {
      const db = await openDB();
      const transaction = db.transaction(['media-store'], 'readonly');
      const store = transaction.objectStore('media-store');
      const result = await store.get(name);
      return result ? JSON.stringify(result) : null;
    } catch (error) {
      console.error('IndexedDB读取失败:', error);
      return localStorage.getItem(name);
    }
  },
  setItem: async (name: string, value: string): Promise<void> => {
    try {
      const db = await openDB();
      const transaction = db.transaction(['media-store'], 'readwrite');
      const store = transaction.objectStore('media-store');
      await store.put(JSON.parse(value), name);
    } catch (error) {
      console.error('IndexedDB写入失败:', error);
      localStorage.setItem(name, value);
    }
  },
  removeItem: async (name: string): Promise<void> => {
    try {
      const db = await openDB();
      const transaction = db.transaction(['media-store'], 'readwrite');
      const store = transaction.objectStore('media-store');
      await store.delete(name);
    } catch (error) {
      console.error('IndexedDB删除失败:', error);
      localStorage.removeItem(name);
    }
  },
};

/**
 * 打开IndexedDB数据库
 */
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('MediaPlayerDB', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('media-store')) {
        db.createObjectStore('media-store');
      }
    };
  });
};

/**
 * 扩展的影音娱乐状态接口
 */
interface EnhancedMediaStore extends MediaState {
  // 原有数据加载方法
  loadMovies: (page?: number, limit?: number) => Promise<void>;
  loadMoviesByCategory: (category: string, page?: number, limit?: number) => Promise<void>;
  loadTracks: (page?: number, limit?: number) => Promise<void>;
  loadTracksByGenre: (genre: string, page?: number, limit?: number) => Promise<void>;
  loadGames: (page?: number, limit?: number) => Promise<void>;
  loadGamesByCategory: (category: string, page?: number, limit?: number) => Promise<void>;
  
  // 增强的视频相关方法
  loadEnhancedMovies: (request: GetVideosRequest) => Promise<GetVideosResponse>;
  getVideoDetails: (request: GetVideoDetailsRequest) => Promise<GetVideoDetailsResponse>;
  getVideoRecommendations: (videoId: string, limit?: number) => Promise<VideoRecommendation[]>;
  
  // 播放器状态管理
  playerState: PlayerState;
  playerActions: PlayerActions;
  updatePlayerState: (updates: Partial<PlayerState>) => void;
  setVideoQuality: (quality: VideoQuality) => void;
  setSubtitle: (subtitle: Subtitle | null) => void;
  setAudioTrack: (audioTrack: AudioTrack) => void;
  setPlaybackRate: (rate: PlaybackRate) => void;
  toggleFullscreen: () => void;
  togglePictureInPicture: () => void;
  
  // 视频播放器设置
  videoSettings: VideoPlayerSettings;
  updateVideoSettings: (settings: Partial<VideoPlayerSettings>) => void;
  
  // 评论系统状态
  commentState: CommentSystemState;
  commentActions: CommentActions;
  loadComments: (videoId: string, page?: number, limit?: number) => Promise<void>;
  submitComment: (request: SubmitCommentRequest) => Promise<SubmitCommentResponse>;
  likeComment: (commentId: string) => Promise<void>;
  dislikeComment: (commentId: string) => Promise<void>;
  replyToComment: (parentId: string, content: string) => Promise<void>;
  
  // 视频评分系统
  submitVideoRating: (videoId: string, rating: number, review?: string) => Promise<void>;
  getVideoRatings: (videoId: string) => Promise<VideoRating[]>;
  
  // 增强的播放历史
  enhancedPlayHistory: EnhancedPlayHistory[];
  addToEnhancedHistory: (videoId: string, progress: number, quality: string, watchTime: number) => Promise<void>;
  getWatchProgress: (videoId: string) => number;
  
  // 原有搜索方法
  searchContent: (query: string, type?: 'all' | 'movie' | 'music' | 'game') => Promise<void>;
  clearSearchResults: () => void;
  
  // 原有收藏管理方法
  addToFavorites: (contentId: string, contentType: 'movie' | 'track' | 'game') => Promise<void>;
  removeFromFavorites: (contentId: string, contentType: 'movie' | 'track' | 'game') => Promise<void>;
  loadFavorites: () => Promise<void>;
  isFavorite: (contentId: string, contentType: 'movie' | 'track' | 'game') => boolean;
  
  // 原有歌单管理方法
  createPlaylist: (name: string, description?: string) => Promise<void>;
  addToPlaylist: (playlistId: string, trackId: string) => Promise<void>;
  removeFromPlaylist: (playlistId: string, trackId: string) => Promise<void>;
  deletePlaylist: (playlistId: string) => Promise<void>;
  loadPlaylists: () => Promise<void>;
  
  // 原有播放控制方法
  playContent: (content: Movie | Track | EnhancedMovie, type: 'movie' | 'track') => void;
  pauseContent: () => void;
  resumeContent: () => void;
  stopContent: () => void;
  setProgress: (progress: number) => void;
  setVolume: (volume: number) => void;
  
  // 原有播放历史方法
  addToHistory: (contentId: string, contentType: 'movie' | 'track' | 'game', progress?: number) => Promise<void>;
  loadPlayHistory: () => Promise<void>;
  clearPlayHistory: () => Promise<void>;
  
  // 原有游戏得分方法
  saveGameScore: (gameId: string, score: number, playTime: number) => Promise<void>;
  loadGameScores: (gameId?: string) => Promise<void>;
  getHighScore: (gameId: string) => number;
  
  // 原有模块切换方法
  setActiveModule: (module: 'movie' | 'music' | 'game') => void;
  
  // 原有错误处理方法
  setError: (error: string | null) => void;
  clearError: () => void;
  
  // 原有加载状态方法
  setLoading: (loading: boolean) => void;
  
  // 原有搜索结果状态
  searchResults: SearchResult | null;
  
  // 缓存管理
  clearCache: () => Promise<void>;
  getCacheSize: () => Promise<number>;
}

/**
 * 创建增强的影音娱乐状态存储
 */
export const useMediaStore = create<EnhancedMediaStore>()(
  persist(
    (set, get) => ({
      // 原有初始状态
      activeModule: 'movie',
      movies: [],
      tracks: [],
      albums: [],
      games: [],
      favorites: [],
      playlists: [],
      gameScores: [],
      playHistory: [],
      currentPlaying: {
        type: null,
        content: null,
        isPlaying: false,
        progress: 0,
        volume: 1,
      },
      isLoading: false,
      error: null,
      searchResults: null,

      /**
       * 加载电影列表
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadMovies: async (page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Movie.getPopularMovies(page, limit);
          if (response.success && response.data) {
            // 将Movie[]转换为EnhancedMovie[]
            const enhancedMovies: EnhancedMovie[] = response.data.map(movie => ({
              ...movie,
              videoQualities: [
                { resolution: '1080p', url: movie.videoUrl, bitrate: 5000, isDefault: true },
                { resolution: '720p', url: movie.videoUrl, bitrate: 2500, isDefault: false },
                { resolution: '480p', url: movie.videoUrl, bitrate: 1000, isDefault: false }
              ],
              subtitles: [],
              audioTracks: [],
              viewCount: 0,
              likeCount: 0,
              favoriteCount: 0,
              commentCount: 0,
              averageRating: movie.rating || 0,
              ratingCount: 0,
              status: 'active' as const,
              uploader: undefined
            }));
            
            set(state => ({
              movies: page === 1 ? enhancedMovies : [...state.movies, ...enhancedMovies],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载电影失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载电影失败', isLoading: false });
        }
      },

      /**
       * 根据分类加载电影
       * @param category - 电影分类
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadMoviesByCategory: async (category: string, page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Movie.getMoviesByCategory(category, page, limit);
          if (response.success && response.data) {
            // 将Movie[]转换为EnhancedMovie[]
            const enhancedMovies: EnhancedMovie[] = response.data.map(movie => ({
              ...movie,
              videoQualities: [
                { resolution: '1080p', url: movie.videoUrl, bitrate: 5000, isDefault: true },
                { resolution: '720p', url: movie.videoUrl, bitrate: 2500, isDefault: false },
                { resolution: '480p', url: movie.videoUrl, bitrate: 1000, isDefault: false }
              ],
              subtitles: [],
              audioTracks: [],
              viewCount: 0,
              likeCount: 0,
              favoriteCount: 0,
              commentCount: 0,
              averageRating: movie.rating || 0,
              ratingCount: 0,
              status: 'active' as const,
              uploader: undefined
            }));
            
            set(state => ({
              movies: page === 1 ? enhancedMovies : [...state.movies, ...enhancedMovies],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载分类电影失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载分类电影失败', isLoading: false });
        }
      },

      /**
       * 加载音乐列表
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadTracks: async (page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Music.getPopularTracks(page, limit);
          if (response.success && response.data) {
            set(state => ({
              tracks: page === 1 ? response.data! : [...state.tracks, ...response.data!],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载音乐失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载音乐失败', isLoading: false });
        }
      },

      /**
       * 根据流派加载音乐
       * @param genre - 音乐流派
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadTracksByGenre: async (genre: string, page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Music.getTracksByGenre(genre, page, limit);
          if (response.success && response.data) {
            set(state => ({
              tracks: page === 1 ? response.data! : [...state.tracks, ...response.data!],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载流派音乐失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载流派音乐失败', isLoading: false });
        }
      },

      /**
       * 加载游戏列表
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadGames: async (page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Game.getPopularGames(page, limit);
          if (response.success && response.data) {
            set(state => ({
              games: page === 1 ? response.data! : [...state.games, ...response.data!],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载游戏失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载游戏失败', isLoading: false });
        }
      },

      /**
       * 根据分类加载游戏
       * @param category - 游戏分类
       * @param page - 页码
       * @param limit - 每页数量
       */
      loadGamesByCategory: async (category: string, page = 1, limit = 20) => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Game.getGamesByCategory(category, page, limit);
          if (response.success && response.data) {
            set(state => ({
              games: page === 1 ? response.data! : [...state.games, ...response.data!],
              isLoading: false,
            }));
          } else {
            set({ error: response.error || '加载分类游戏失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '加载分类游戏失败', isLoading: false });
        }
      },

      /**
       * 搜索内容
       * @param query - 搜索关键词
       * @param type - 搜索类型
       */
      searchContent: async (query: string, type: 'all' | 'movie' | 'music' | 'game' = 'all') => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Search.searchContent(query, type);
          if (response.success && response.data) {
            set({
              searchResults: response.data,
              isLoading: false,
            });
          } else {
            set({ error: response.error || '搜索失败', isLoading: false });
          }
        } catch (error) {
          set({ error: '搜索失败', isLoading: false });
        }
      },

      /**
       * 清除搜索结果
       */
      clearSearchResults: () => {
        set({ searchResults: null });
      },

      /**
       * 添加到收藏
       * @param contentId - 内容ID
       * @param contentType - 内容类型
       */
      addToFavorites: async (contentId: string, contentType: 'movie' | 'track' | 'game') => {
        try {
          const newFavorite: Favorite = {
            id: `fav_${Date.now()}`,
            userId: 'current_user', // 实际应用中应该从用户状态获取
            contentId,
            contentType,
            createdAt: new Date(),
          };

          set(state => ({
            favorites: [...state.favorites, newFavorite],
          }));
        } catch (error) {
          set({ error: '添加收藏失败' });
        }
      },

      /**
       * 从收藏中移除
       * @param contentId - 内容ID
       * @param contentType - 内容类型
       */
      removeFromFavorites: async (contentId: string, contentType: 'movie' | 'track' | 'game') => {
        try {
          set(state => ({
            favorites: state.favorites.filter(
              fav => !(fav.contentId === contentId && fav.contentType === contentType)
            ),
          }));
        } catch (error) {
          set({ error: '移除收藏失败' });
        }
      },

      /**
       * 加载收藏列表
       */
      loadFavorites: async () => {
        // 实际应用中应该从本地存储或服务器加载
        // 这里使用持久化存储，数据会自动加载
      },

      /**
       * 检查是否已收藏
       * @param contentId - 内容ID
       * @param contentType - 内容类型
       * @returns 是否已收藏
       */
      isFavorite: (contentId: string, contentType: 'movie' | 'track' | 'game') => {
        const { favorites } = get();
        return favorites.some(fav => fav.contentId === contentId && fav.contentType === contentType);
      },

      /**
       * 创建歌单
       * @param name - 歌单名称
       * @param description - 歌单描述
       */
      createPlaylist: async (name: string, description?: string) => {
        try {
          const newPlaylist: Playlist = {
            id: `playlist_${Date.now()}`,
            userId: 'current_user', // 实际应用中应该从用户状态获取
            name,
            description,
            tracks: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          };

          set(state => ({
            playlists: [...state.playlists, newPlaylist],
          }));
        } catch (error) {
          set({ error: '创建歌单失败' });
        }
      },

      /**
       * 添加到歌单
       * @param playlistId - 歌单ID
       * @param trackId - 音乐ID
       */
      addToPlaylist: async (playlistId: string, trackId: string) => {
        try {
          const { tracks } = get();
          const track = tracks.find(t => t.id === trackId);
          
          if (!track) {
            set({ error: '音乐不存在' });
            return;
          }

          set(state => ({
            playlists: state.playlists.map(playlist => 
              playlist.id === playlistId
                ? {
                    ...playlist,
                    tracks: [...playlist.tracks, track],
                    updatedAt: new Date(),
                  }
                : playlist
            ),
          }));
        } catch (error) {
          set({ error: '添加到歌单失败' });
        }
      },

      /**
       * 从歌单中移除
       * @param playlistId - 歌单ID
       * @param trackId - 音乐ID
       */
      removeFromPlaylist: async (playlistId: string, trackId: string) => {
        try {
          set(state => ({
            playlists: state.playlists.map(playlist => 
              playlist.id === playlistId
                ? {
                    ...playlist,
                    tracks: playlist.tracks.filter(track => track.id !== trackId),
                    updatedAt: new Date(),
                  }
                : playlist
            ),
          }));
        } catch (error) {
          set({ error: '从歌单移除失败' });
        }
      },

      /**
       * 删除歌单
       * @param playlistId - 歌单ID
       */
      deletePlaylist: async (playlistId: string) => {
        try {
          set(state => ({
            playlists: state.playlists.filter(playlist => playlist.id !== playlistId),
          }));
        } catch (error) {
          set({ error: '删除歌单失败' });
        }
      },

      /**
       * 加载歌单列表
       */
      loadPlaylists: async () => {
        // 实际应用中应该从本地存储或服务器加载
        // 这里使用持久化存储，数据会自动加载
      },

      /**
       * 播放内容
       * @param content - 内容对象
       * @param type - 内容类型
       */
      playContent: (content: Movie | Track | EnhancedMovie, type: 'movie' | 'track') => {
        set({
          currentPlaying: {
            type,
            content,
            isPlaying: true,
            progress: 0,
            volume: get().currentPlaying.volume,
          },
        });

        // 添加到播放历史
        get().addToHistory(content.id, type);
      },

      /**
       * 暂停播放
       */
      pauseContent: () => {
        set(state => ({
          currentPlaying: {
            ...state.currentPlaying,
            isPlaying: false,
          },
        }));
      },

      /**
       * 恢复播放
       */
      resumeContent: () => {
        set(state => ({
          currentPlaying: {
            ...state.currentPlaying,
            isPlaying: true,
          },
        }));
      },

      /**
       * 停止播放
       */
      stopContent: () => {
        set({
          currentPlaying: {
            type: null,
            content: null,
            isPlaying: false,
            progress: 0,
            volume: get().currentPlaying.volume,
          },
        });
      },

      /**
       * 设置播放进度
       * @param progress - 播放进度（0-1）
       */
      setProgress: (progress: number) => {
        set(state => ({
          currentPlaying: {
            ...state.currentPlaying,
            progress: Math.max(0, Math.min(1, progress)),
          },
        }));
      },

      /**
       * 设置音量
       * @param volume - 音量（0-1）
       */
      setVolume: (volume: number) => {
        set(state => ({
          currentPlaying: {
            ...state.currentPlaying,
            volume: Math.max(0, Math.min(1, volume)),
          },
        }));
      },

      /**
       * 添加到播放历史
       * @param contentId - 内容ID
       * @param contentType - 内容类型
       * @param progress - 播放进度
       */
      addToHistory: async (contentId: string, contentType: 'movie' | 'track' | 'game', progress?: number) => {
        try {
          const newHistory: PlayHistory = {
            id: `history_${Date.now()}`,
            userId: 'current_user', // 实际应用中应该从用户状态获取
            contentId,
            contentType,
            progress,
            playedAt: new Date(),
          };

          set(state => ({
            playHistory: [newHistory, ...state.playHistory.slice(0, 99)], // 保留最近100条记录
          }));
        } catch (error) {
          console.error('添加播放历史失败:', error);
        }
      },

      /**
       * 加载播放历史
       */
      loadPlayHistory: async () => {
        // 实际应用中应该从本地存储或服务器加载
        // 这里使用持久化存储，数据会自动加载
      },

      /**
       * 清除播放历史
       */
      clearPlayHistory: async () => {
        set({ playHistory: [] });
      },

      /**
       * 保存游戏得分
       * @param gameId - 游戏ID
       * @param score - 得分
       * @param playTime - 游戏时长
       */
      saveGameScore: async (gameId: string, score: number, playTime: number) => {
        try {
          const newScore: GameScore = {
            id: `score_${Date.now()}`,
            userId: 'current_user', // 实际应用中应该从用户状态获取
            gameId,
            score,
            playTime,
            createdAt: new Date(),
          };

          set(state => ({
            gameScores: [...state.gameScores, newScore],
          }));

          // 添加到播放历史
          get().addToHistory(gameId, 'game');
        } catch (error) {
          set({ error: '保存游戏得分失败' });
        }
      },

      /**
       * 加载游戏得分
       * @param gameId - 游戏ID（可选，不传则加载所有）
       */
      loadGameScores: async (gameId?: string) => {
        // 实际应用中应该从本地存储或服务器加载
        // 这里使用持久化存储，数据会自动加载
      },

      /**
       * 获取最高分
       * @param gameId - 游戏ID
       * @returns 最高分
       */
      getHighScore: (gameId: string) => {
        const { gameScores } = get();
        const gameScoreList = gameScores.filter(score => score.gameId === gameId);
        return gameScoreList.length > 0 ? Math.max(...gameScoreList.map(score => score.score)) : 0;
      },

      /**
       * 设置活跃模块
       * @param module - 模块名称
       */
      setActiveModule: (module: 'movie' | 'music' | 'game') => {
        set({ activeModule: module });
      },

      /**
       * 设置错误信息
       * @param error - 错误信息
       */
      setError: (error: string | null) => {
        set({ error });
      },

      /**
       * 清除错误信息
       */
      clearError: () => {
        set({ error: null });
      },

      /**
       * 设置加载状态
       * @param loading - 加载状态
       */
      setLoading: (loading: boolean) => {
        set({ isLoading: loading });
      },

      // 增强的视频相关方法
      loadEnhancedMovies: async (request: GetVideosRequest): Promise<GetVideosResponse> => {
        set({ isLoading: true, error: null });
        try {
          const response = await MediaAPI.Movie.getPopularMovies(request.page || 1, request.limit || 20);
          if (response.success && response.data) {
            // 将Movie[]转换为EnhancedMovie[]
            const enhancedMovies: EnhancedMovie[] = response.data.map(movie => ({
              ...movie,
              videoQualities: [
                { resolution: '1080p', url: movie.videoUrl, bitrate: 5000, isDefault: true },
                { resolution: '720p', url: movie.videoUrl, bitrate: 2500, isDefault: false },
                { resolution: '480p', url: movie.videoUrl, bitrate: 1000, isDefault: false }
              ],
              subtitles: [],
              audioTracks: [],
              viewCount: 0,
              likeCount: 0,
              favoriteCount: 0,
              commentCount: 0,
              averageRating: movie.rating || 0,
              ratingCount: 0,
              status: 'active' as const,
              uploader: undefined
            }));
            
            set({ 
              movies: enhancedMovies,
              isLoading: false 
            });
            return {
              videos: enhancedMovies,
              total: enhancedMovies.length,
              page: request.page || 1,
              limit: request.limit || 20,
              hasMore: false
            };
          } else {
            set({ error: response.error || '加载视频失败', isLoading: false });
            throw new Error(response.error || '加载视频失败');
          }
        } catch (error) {
          set({ 
            error: error instanceof Error ? error.message : '加载视频失败',
            isLoading: false 
          });
          throw error;
        }
      },

      getVideoDetails: async (request: GetVideoDetailsRequest): Promise<GetVideoDetailsResponse> => {
        set({ isLoading: true, error: null });
        try {
          const { movies } = get();
          const movie = movies.find(m => m.id === request.videoId);
          
          if (!movie) {
            throw new Error('视频不存在');
          }

          set({ isLoading: false });
          return {
            video: movie,
            recommendations: [],
            isFavorited: get().isFavorite(request.videoId, 'movie'),
            userRating: undefined
          };
        } catch (error) {
          set({ 
            error: error instanceof Error ? error.message : '获取视频详情失败',
            isLoading: false 
          });
          throw error;
        }
      },

      getVideoRecommendations: async (videoId: string, limit = 10) => {
        // TODO: 实现视频推荐
        return [];
      },

      // 播放器状态管理
      playerState: {
        currentVideo: null,
        isPlaying: false,
        isPaused: false,
        isLoading: false,
        isBuffering: false,
        currentTime: 0,
        duration: 0,
        progress: 0,
        buffered: 0,
        volume: 1,
        isMuted: false,
        playbackRate: 1,
        currentQuality: '1080p',
        isFullscreen: false,
        isPictureInPicture: false,
        showControls: true,
      },

      playerActions: {
        play: (video: any) => {},
        pause: () => {},
        resume: () => {},
        stop: () => {},
        seekTo: (time: number) => {},
        setVolume: (volume: number) => {},
        toggleMute: () => {},
        setPlaybackRate: (rate: any) => {},
        changeQuality: (quality: string) => {},
        changeSubtitle: (subtitleId?: string) => {},
        changeAudioTrack: (trackId?: string) => {},
        toggleFullscreen: () => {},
        togglePictureInPicture: () => {},
        fastForward: (seconds?: number) => {},
        rewind: (seconds?: number) => {},
      },

      updatePlayerState: (updates: any) => {
        set(state => ({
          playerState: { ...state.playerState, ...updates }
        }));
      },

      setVideoQuality: (quality: any) => {
        set(state => ({
          playerState: { ...state.playerState, currentQuality: quality }
        }));
      },

      setSubtitle: (subtitle: any) => {
        set(state => ({
          playerState: { ...state.playerState, currentSubtitle: subtitle }
        }));
      },

      setAudioTrack: (audioTrack: any) => {
        set(state => ({
          playerState: { ...state.playerState, currentAudioTrack: audioTrack }
        }));
      },

      setPlaybackRate: (rate: any) => {
        set(state => ({
          playerState: { ...state.playerState, playbackRate: rate }
        }));
      },

      toggleFullscreen: () => {
        set(state => ({
          playerState: { ...state.playerState, isFullscreen: !state.playerState.isFullscreen }
        }));
      },

      togglePictureInPicture: () => {
        set(state => ({
          playerState: { ...state.playerState, isPictureInPicture: !state.playerState.isPictureInPicture }
        }));
      },

      // 视频播放器设置
      videoSettings: {
        defaultVolume: 1,
        defaultPlaybackRate: 1,
        defaultQuality: '1080p',
        autoplay: false,
        loop: false,
        muted: false,
        showSubtitles: true,
        defaultSubtitleLanguage: 'zh-CN',
        theme: 'dark' as const,
        keyboardShortcuts: true,
      },

      updateVideoSettings: (settings: any) => {
        set(state => ({
          videoSettings: { ...state.videoSettings, ...settings }
        }));
      },

      // 评论系统状态
      commentState: {
        comments: [],
        totalCount: 0,
        isLoading: false,
        currentPage: 1,
        pageSize: 20,
        hasMore: true,
        sortBy: 'newest' as const,
        error: undefined,
      },

      commentActions: {
        loadComments: async () => {},
        postComment: async () => {},
        likeComment: async () => {},
        unlikeComment: async () => {},
        deleteComment: async () => {},
        reportComment: async () => {},
      },

      loadComments: async (videoId: string, page = 1, limit = 20) => {
        // TODO: 实现评论加载
      },

      submitComment: async (request: any) => {
        // TODO: 实现评论提交
        return { 
          success: true, 
          comment: {
            id: Date.now().toString(),
            videoId: request.videoId,
            userId: 'current-user',
            userName: '当前用户',
            userAvatar: '',
            content: request.content,
            likeCount: 0,
            replyCount: 0,
            parentId: request.parentId || null,
            replies: [],
            isLiked: false,
            createdAt: new Date(),
            updatedAt: new Date(),
            status: 'active' as const,
            user: {
              id: 'current-user',
              name: '当前用户',
              avatarUrl: '',
            },
            userInteraction: {
              isLiked: false,
              isDisliked: false,
              isReported: false,
            }
          }
        };
      },

        likeComment: async (commentId: string) => {
        // TODO: 实现评论点赞
      },

      dislikeComment: async (commentId: string) => {
        // TODO: 实现评论点踩
      },

      replyToComment: async (parentId: string, content: string) => {
        // TODO: 实现评论回复
      },

      // 视频评分系统
      submitVideoRating: async (videoId: string, rating: number, review?: string) => {
        // TODO: 实现视频评分
      },

      getVideoRatings: async (videoId: string) => {
        // TODO: 实现获取视频评分
        return [];
      },

      // 增强的播放历史
      enhancedPlayHistory: [],

      addToEnhancedHistory: async (videoId: string, progress: number, quality: string, watchTime: number) => {
        // TODO: 实现增强播放历史
      },

      getWatchProgress: (videoId: string) => {
        // TODO: 实现获取观看进度
        return 0;
      },

      // 缓存管理
      clearCache: async () => {
        // TODO: 实现缓存清理
      },

      getCacheSize: async () => {
        // TODO: 实现获取缓存大小
        return 0;
      },
    }),
    {
      name: 'media-store', // 持久化存储的key
      storage: createJSONStorage(() => indexedDBStorage),
      partialize: (state) => ({
        // 持久化需要的状态
        favorites: state.favorites,
        playlists: state.playlists,
        gameScores: state.gameScores,
        playHistory: state.playHistory,
        enhancedPlayHistory: state.enhancedPlayHistory,
        videoSettings: state.videoSettings,
        currentPlaying: {
          ...state.currentPlaying,
          isPlaying: false, // 重新加载时不自动播放
        },
        playerState: {
          ...state.playerState,
          isPlaying: false,
          isBuffering: false,
          isFullscreen: false,
          isPictureInPicture: false,
        },
        commentState: {
          ...state.commentState,
          isLoading: false,
          error: null,
        },
      }),
      version: 2, // 版本号，用于数据迁移
      migrate: (persistedState: any, version: number) => {
        // 数据迁移逻辑
        if (version < 2) {
          // 从版本1升级到版本2的迁移逻辑
          return {
            ...persistedState,
            enhancedPlayHistory: [],
            videoSettings: {
              defaultVolume: 1,
              defaultPlaybackRate: 1,
              defaultQuality: '1080p',
              autoplay: false,
              loop: false,
              muted: false,
              showSubtitles: true,
              defaultSubtitleLanguage: 'zh-CN',
              theme: 'dark' as const,
              keyboardShortcuts: true,
            },
          };
        }
        return persistedState;
      },
    }
  )
);

export default useMediaStore;