/**
 * 飞鸽风格即时通讯App - 路由配置
 * 使用React Router进行页面路由管理
 */

import { createBrowserRouter, Navigate } from 'react-router-dom';
import { lazy, Suspense } from 'react';

// 懒加载组件
const Login = lazy(() => import('../pages/Login'));
const Register = lazy(() => import('../pages/Register'));
const ForgotPassword = lazy(() => import('../pages/ForgotPassword'));
const ResetPassword = lazy(() => import('../pages/ResetPassword'));
const MainLayout = lazy(() => import('../components/Layout/MainLayout'));
const ChatList = lazy(() => import('../pages/ChatList'));
const Chat = lazy(() => import('../pages/Chat'));
const Contacts = lazy(() => import('../pages/Contacts'));
const AddFriend = lazy(() => import('../pages/AddFriend'));
const FriendRequests = lazy(() => import('../pages/FriendRequests'));
const Discover = lazy(() => import('../pages/Discover'));
const Moments = lazy(() => import('../pages/Moments'));
const Profile = lazy(() => import('../pages/Profile'));
const WorkManagement = lazy(() => import('../pages/WorkManagement'));
const InventoryManagement = lazy(() => import('../pages/InventoryManagement'));
const ProductInventoryDetail = lazy(() => import('../pages/ProductInventoryDetail'));
const PurchaseSalesInventory = lazy(() => import('../pages/PurchaseSalesInventory'));
const SpecialMedicine = lazy(() => import('../pages/SpecialMedicine'));
const PatientManagement = lazy(() => import('../pages/PatientManagement'));
const PatientDetail = lazy(() => import('../pages/PatientDetail'));
const PatientForm = lazy(() => import('../pages/PatientForm'));
const MedicationRecords = lazy(() => import('../pages/MedicationRecords'));
const MedicationForm = lazy(() => import('../pages/MedicationForm'));
const MedicationReminders = lazy(() => import('../pages/MedicationReminders'));
const ReminderForm = lazy(() => import('../pages/ReminderForm'));
const MedicationStatistics = lazy(() => import('../pages/MedicationStatistics'));

// 影音娱乐模块组件
const Media = lazy(() => import('../pages/Media'));
const VideoPlayer = lazy(() => import('../pages/VideoPlayer'));
const VideoDetail = lazy(() => import('../pages/VideoDetail'));

// 原生功能测试页面
const NativeFeaturesTest = lazy(() => import('../pages/NativeFeaturesTest'));

/**
 * 加载中组件
 */
const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
  </div>
);

/**
 * 路由配置
 */
// 导入路由保护组件
const ProtectedRoute = lazy(() => import('../components/ProtectedRoute'));

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/login" replace />
  },
  {
    path: '/login',
    element: (
      <Suspense fallback={<LoadingSpinner />}>
        <Login />
      </Suspense>
    )
  },
  {
    path: '/register',
    element: (
      <Suspense fallback={<LoadingSpinner />}>
        <Register />
      </Suspense>
    )
  },
  {
    path: '/forgot-password',
    element: (
      <Suspense fallback={<LoadingSpinner />}>
        <ForgotPassword />
      </Suspense>
    )
  },
  {
    path: '/reset-password',
    element: (
      <Suspense fallback={<LoadingSpinner />}>
        <ResetPassword />
      </Suspense>
    )
  },
  {
    path: '/app',
    element: (
      <Suspense fallback={<LoadingSpinner />}>
        <ProtectedRoute>
          <MainLayout />
        </ProtectedRoute>
      </Suspense>
    ),
    children: [
      {
        index: true,
        element: <Navigate to="/app/chats" replace />
      },
      {
        path: 'chats',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <ChatList />
          </Suspense>
        )
      },
      {
        path: 'chat/:friendId',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Chat />
          </Suspense>
        )
      },
      {
        path: 'contacts',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Contacts />
          </Suspense>
        )
      },
      {
        path: 'add-friend',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <AddFriend />
          </Suspense>
        )
      },
      {
        path: 'friend-requests',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <FriendRequests />
          </Suspense>
        )
      },
      {
        path: 'discover',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Discover />
          </Suspense>
        )
      },
      {
        path: 'moments',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Moments />
          </Suspense>
        )
      },
      {
        path: 'profile',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Profile />
          </Suspense>
        )
      },
      // 影音娱乐模块路由
      {
        path: 'media',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <Media />
          </Suspense>
        )
      },
      // 视频播放页面路由
      {
        path: 'video/play/:videoId',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <VideoPlayer />
          </Suspense>
        )
      },
      // 视频详情页面路由
      {
        path: 'video/detail/:videoId',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <VideoDetail />
          </Suspense>
        )
      },
      {
        path: 'work-management',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <WorkManagement />
          </Suspense>
        )
      },
      {
        path: 'inventory-management',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <InventoryManagement />
          </Suspense>
        )
      },
      {
        path: 'product-inventory/:productId',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <ProductInventoryDetail />
          </Suspense>
        )
      },
      {
        path: 'purchase-sales-inventory',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <PurchaseSalesInventory />
          </Suspense>
        )
      },
      {
        path: 'special-medicine',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <SpecialMedicine />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/patients',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <PatientManagement />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/patient-detail/:patientId',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <PatientDetail />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/patient-form',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <PatientForm />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/records',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <MedicationRecords />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/medication-form',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <MedicationForm />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/reminders',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <MedicationReminders />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/reminder-form',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <ReminderForm />
          </Suspense>
        )
      },
      {
        path: 'special-medicine/statistics',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <MedicationStatistics />
          </Suspense>
        )
      },
      // 原生功能测试页面
      {
        path: 'native-test',
        element: (
          <Suspense fallback={<LoadingSpinner />}>
            <NativeFeaturesTest />
          </Suspense>
        )
      }
    ]
  },
  {
    path: '*',
    element: <Navigate to="/login" replace />
  }
]);