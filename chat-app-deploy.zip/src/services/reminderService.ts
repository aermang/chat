/**
 * 特药管理系统 - 用药提醒服务
 * 处理用药提醒的调度、通知发送和状态管理
 */

import { MedicationReminder, Patient } from '../types';

/**
 * 提醒通知接口
 */
interface ReminderNotification {
  id: string;
  reminderId: string;
  patientId: string;
  medicationName: string;
  dosage: string;
  scheduledTime: Date | string;
  actualTime?: Date | string;
  sentTime?: string;
  status: 'pending' | 'sent' | 'dismissed' | 'taken';
  notificationId?: string;
  takenTime?: string;
  dismissedTime?: string;
}

/**
 * 提醒服务类
 * 负责处理用药提醒的调度、通知发送和状态管理
 */
export class ReminderService {
  private scheduledReminders: Map<string, NodeJS.Timeout> = new Map();
  private notificationHistory: ReminderNotification[] = [];
  private isInitialized = false;
  private serviceWorkerRegistration: ServiceWorkerRegistration | null = null;
  private activeReminders: Map<string, NodeJS.Timeout> = new Map();
  private notifications: ReminderNotification[] = [];

  /**
   * 初始化提醒服务
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // 注册 Service Worker
      if ('serviceWorker' in navigator) {
        this.serviceWorkerRegistration = await navigator.serviceWorker.register('/sw.js');
        console.log('Service Worker registered:', this.serviceWorkerRegistration);

        // 监听 Service Worker 消息
        navigator.serviceWorker.addEventListener('message', this.handleServiceWorkerMessage.bind(this));
      }

      // 请求通知权限
      if ('Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }

      this.isInitialized = true;
      console.log('ReminderService initialized successfully');
    } catch (error) {
      console.error('Failed to initialize ReminderService:', error);
      throw error;
    }
  }

  /**
   * 处理来自 Service Worker 的消息
   */
  private handleServiceWorkerMessage(event: MessageEvent): void {
    const { type, data } = event.data;

    switch (type) {
      case 'REMINDER_TRIGGERED':
        this.handleReminderTriggered(data);
        break;
      case 'MEDICATION_TAKEN':
        this.handleMedicationTaken(data);
        break;
      case 'MEDICATION_DISMISSED':
        this.handleMedicationDismissed(data);
        break;
      case 'NOTIFICATION_CLICKED':
        this.handleNotificationClick(data);
        break;
      case 'NOTIFICATION_CLOSED':
        this.handleNotificationClose(data);
        break;
      default:
        console.log('Unknown Service Worker message type:', type);
    }
  }

  /**
   * 处理提醒触发事件
   */
  private handleReminderTriggered(data: any): void {
    const notification: ReminderNotification = {
      id: data.notificationId,
      reminderId: data.reminderId,
      patientId: data.patientId,
      medicationName: data.medicationName,
      dosage: data.dosage,
      scheduledTime: new Date().toISOString(),
      sentTime: new Date().toISOString(),
      status: 'sent'
    };

    this.notificationHistory.push(notification);
    
    // 派发自定义事件
    this.dispatchEvent('medicationReminderTriggered', {
      reminder: { id: data.reminderId, medicationName: data.medicationName, dosage: data.dosage },
      patient: { id: data.patientId, name: '患者' }, // 这里需要从数据库获取患者信息
      notification
    });
  }

  /**
   * 处理服药确认事件
   */
  private handleMedicationTaken(data: any): void {
    const notification = this.notificationHistory.find(n => n.id === data.notificationId);
    if (notification) {
      notification.status = 'taken';
      notification.takenTime = data.timestamp;
    }

    this.dispatchEvent('medicationTaken', data);
  }

  /**
   * 处理提醒忽略事件
   */
  private handleMedicationDismissed(data: any): void {
    const notification = this.notificationHistory.find(n => n.id === data.notificationId);
    if (notification) {
      notification.status = 'dismissed';
      notification.dismissedTime = data.timestamp;
    }

    this.dispatchEvent('medicationDismissed', data);
  }

  /**
   * 处理通知关闭事件
   */
  private handleNotificationClose(data: any): void {
    this.dispatchEvent('reminderNotificationClose', data);
  }

  /**
   * 派发自定义事件
   */
  private dispatchEvent(eventType: string, data: any): void {
    const event = new CustomEvent(eventType, { detail: data });
    window.dispatchEvent(event);
  }

  /**
   * 调度提醒
   */
  async scheduleReminder(reminder: MedicationReminder): Promise<void> {
    if (!reminder.isActive) return;

    // 清除之前的调度
    await this.clearReminder(reminder.id);

    const nextTriggerTime = this.calculateNextTriggerTime(reminder);
    if (!nextTriggerTime) return;

    // 如果支持 Service Worker，使用 Service Worker 调度
    if (this.serviceWorkerRegistration && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SCHEDULE_REMINDER',
        data: {
          reminder,
          nextTriggerTime: nextTriggerTime.toISOString()
        }
      });
    } else {
      // 降级到前台调度
      const now = new Date().getTime();
      const triggerTime = nextTriggerTime.getTime();
      const delay = triggerTime - now;

      if (delay > 0) {
        const timeoutId = setTimeout(() => {
          // 发送通知逻辑
          this.triggerReminder(reminder, { id: reminder.patientId, name: '患者' } as Patient);
        }, delay);

        this.scheduledReminders.set(reminder.id, timeoutId);
      }
    }

    console.log(`Reminder scheduled for ${reminder.medicationName} at ${nextTriggerTime.toISOString()}`);
  }

  /**
   * 调度下一次提醒
   */
  private scheduleNextReminder(reminder: MedicationReminder): void {
    // 递归调度下一次提醒
    setTimeout(() => {
      this.scheduleReminder(reminder);
    }, 1000); // 1秒后重新调度
  }

  /**
   * 触发提醒
   */
  private triggerReminder(reminder: MedicationReminder, patient: Patient): void {
    const notification: ReminderNotification = {
      id: this.generateNotificationId(),
      reminderId: reminder.id,
      patientId: patient.id,
      medicationName: reminder.medicationName,
      dosage: reminder.dosage,
      scheduledTime: new Date(reminder.nextReminder || new Date()),
      actualTime: new Date(),
      status: 'pending'
    };

    this.notifications.push(notification);

    // 发送浏览器通知
    this.sendBrowserNotification(reminder, patient, notification);

    // 触发自定义事件
    this.dispatchReminderEvent(reminder, patient, notification);
  }

  /**
   * 发送浏览器通知
   */
  private sendBrowserNotification(
    reminder: MedicationReminder,
    patient: Patient,
    notification: ReminderNotification
  ): void {
    if (Notification.permission !== 'granted') {
      return;
    }

    const title = `用药提醒 - ${reminder.medicationName}`;
    const body = `患者：${patient.name}\n剂量：${reminder.dosage}\n${reminder.notes || ''}`;
    const icon = '/favicon.ico';

    try {
      const browserNotification = new Notification(title, {
        body,
        icon,
        tag: `reminder-${reminder.id}`,
        requireInteraction: true
      });

      notification.notificationId = browserNotification.tag;
      notification.status = 'sent';

      // 处理通知点击事件
      browserNotification.onclick = () => {
        this.handleNotificationClick(notification);
        browserNotification.close();
      };

      // 自动关闭通知（5分钟后）
      setTimeout(() => {
        browserNotification.close();
        if (notification.status === 'sent') {
          notification.status = 'dismissed';
        }
      }, 5 * 60 * 1000);

    } catch (error) {
      console.error('Failed to send browser notification:', error);
    }
  }

  /**
   * 处理通知点击事件
   */
  private handleNotificationClick(notification: ReminderNotification): void {
    // 打开应用到提醒页面
    if (window.focus) {
      window.focus();
    }

    // 导航到提醒详情页面
    const event = new CustomEvent('reminderNotificationClick', {
      detail: notification
    });
    window.dispatchEvent(event);
  }

  /**
   * 分发提醒事件
   */
  private dispatchReminderEvent(
    reminder: MedicationReminder,
    patient: Patient,
    notification: ReminderNotification
  ): void {
    const event = new CustomEvent('medicationReminderTriggered', {
      detail: {
        reminder,
        patient,
        notification
      }
    });
    window.dispatchEvent(event);
  }

  /**
   * 计算下次提醒时间
   */
  private calculateNextTriggerTime(reminder: MedicationReminder): Date | null {
    const now = new Date();
    const startDate = new Date(reminder.startDate);
    const endDate = reminder.endDate ? new Date(reminder.endDate) : null;

    // 检查是否在有效期内
    if (endDate && now > endDate) {
      return null;
    }

    const baseDate = startDate > now ? startDate : now;
    
    // 获取今天的提醒时间
    const todayReminders = this.getTodayReminderTimes(reminder, baseDate);
    
    // 找到下一个未来的提醒时间
    for (const reminderTime of todayReminders) {
      if (reminderTime > now) {
        return reminderTime;
      }
    }

    // 如果今天没有未来的提醒时间，计算明天的第一个提醒时间
    const tomorrow = new Date(baseDate);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const tomorrowReminders = this.getTodayReminderTimes(reminder, tomorrow);
    return tomorrowReminders.length > 0 ? tomorrowReminders[0] : null;
  }

  /**
   * 获取指定日期的提醒时间列表
   */
  private getTodayReminderTimes(reminder: MedicationReminder, date: Date): Date[] {
    const reminderTimes: Date[] = [];

    // 检查是否应该在这一天提醒
    if (!this.shouldRemindOnDate(reminder, date)) {
      return reminderTimes;
    }

    // 为每个时间点创建提醒时间
    const times = reminder.reminderTimes || [reminder.reminderTime || '09:00'];
    for (const timeStr of times) {
      const [hours, minutes] = timeStr.split(':').map(Number);
      const reminderTime = new Date(date);
      reminderTime.setHours(hours, minutes, 0, 0);
      reminderTimes.push(reminderTime);
    }

    return reminderTimes.sort((a, b) => a.getTime() - b.getTime());
  }

  /**
   * 检查是否应该在指定日期提醒
   */
  private shouldRemindOnDate(reminder: MedicationReminder, date: Date): boolean {
    const startDate = new Date(reminder.startDate);
    const endDate = reminder.endDate ? new Date(reminder.endDate) : null;

    // 检查日期范围
    if (date < startDate || (endDate && date > endDate)) {
      return false;
    }

    switch (reminder.frequency) {
      case 'daily':
        return true;

      case 'weekly':
        const weekday = date.getDay();
        return reminder.weekdays ? reminder.weekdays.includes(weekday) : false;

      case 'monthly':
        const dayOfMonth = date.getDate();
        return reminder.monthDay === dayOfMonth;

      case 'custom':
        if (!reminder.customInterval || !reminder.customUnit) {
          return false;
        }

        const diffTime = date.getTime() - startDate.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        if (reminder.customUnit === 'days') {
          return diffDays % reminder.customInterval === 0;
        } else if (reminder.customUnit === 'hours') {
          const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
          return diffHours % reminder.customInterval === 0;
        }

        return false;

      default:
        return false;
    }
  }

  /**
   * 清除提醒
   */
  async clearReminder(reminderId: string): Promise<void> {
    // 清除前台调度
    const timeoutId = this.scheduledReminders.get(reminderId);
    if (timeoutId) {
      clearTimeout(timeoutId);
      this.scheduledReminders.delete(reminderId);
    }

    // 清除 Service Worker 调度
    if (this.serviceWorkerRegistration && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'CLEAR_REMINDER',
        data: { reminderId }
      });
    }

    console.log(`Reminder ${reminderId} cleared`);
  }

  /**
   * 清除所有提醒
   */
  clearAllReminders(): void {
    for (const timeoutId of this.activeReminders.values()) {
      clearTimeout(timeoutId);
    }
    this.activeReminders.clear();
  }

  /**
   * 标记提醒为已服药
   */
  markReminderAsTaken(notificationId: string): void {
    const notification = this.notificationHistory.find(n => n.id === notificationId);
    if (notification) {
      notification.status = 'taken';
      notification.takenTime = new Date().toISOString();
      
      // 派发事件
      this.dispatchEvent('medicationTaken', notification);
      
      console.log(`Medication taken for notification ${notificationId}`);
    }
  }

  /**
   * 推迟提醒
   */
  snoozeReminder(notificationId: string, minutes: number = 10): void {
    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.status = 'dismissed';
      
      // 设置推迟提醒
      setTimeout(() => {
        // 重新发送通知
        const event = new CustomEvent('reminderSnoozed', {
          detail: { notification, snoozeMinutes: minutes }
        });
        window.dispatchEvent(event);
      }, minutes * 60 * 1000);
    }
  }

  /**
   * 获取通知历史
   */
  getNotificationHistory(): ReminderNotification[] {
    return [...this.notifications];
  }

  /**
   * 清理过期通知
   */
  cleanupExpiredNotifications(): void {
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);

    this.notifications = this.notifications.filter(
      notification => notification.actualTime > oneDayAgo
    );
  }

  /**
   * 生成通知ID
   */
  private generateNotificationId(): string {
    return `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 获取活跃提醒数量
   */
  getActiveRemindersCount(): number {
    return this.activeReminders.size;
  }

  /**
   * 获取今日通知统计
   */
  getTodayNotificationStats(): {
    total: number;
    sent: number;
    taken: number;
    dismissed: number;
  } {
    const today = new Date().toDateString();
    const todayNotifications = this.notificationHistory.filter(n => 
      new Date(n.scheduledTime).toDateString() === today
    );

    return {
      total: todayNotifications.length,
      sent: todayNotifications.filter(n => n.status === 'sent' || n.status === 'taken' || n.status === 'dismissed').length,
      taken: todayNotifications.filter(n => n.status === 'taken').length,
      dismissed: todayNotifications.filter(n => n.status === 'dismissed').length
    };
  }
}

// 创建单例实例
export const reminderService = new ReminderService();

// 导出类型
export type { ReminderNotification };