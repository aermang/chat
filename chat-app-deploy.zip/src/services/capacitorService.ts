import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { PushNotifications } from '@capacitor/push-notifications';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Device } from '@capacitor/device';
import { Network } from '@capacitor/network';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Keyboard } from '@capacitor/keyboard';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

/**
 * Capacitor服务类，提供原生功能的统一接口
 */
export class CapacitorService {
  /**
   * 检查是否在原生环境中运行
   */
  static isNative(): boolean {
    return Capacitor.isNativePlatform();
  }

  /**
   * 获取平台信息
   */
  static getPlatform(): string {
    return Capacitor.getPlatform();
  }

  /**
   * 相机功能
   */
  static async takePicture(): Promise<string | null> {
    try {
      if (!this.isNative()) {
        console.warn('Camera not available in web environment');
        return null;
      }

      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera
      });

      return image.dataUrl || null;
    } catch (error) {
      console.error('Error taking picture:', error);
      return null;
    }
  }

  /**
   * 从相册选择图片
   */
  static async selectFromGallery(): Promise<string | null> {
    try {
      if (!this.isNative()) {
        console.warn('Gallery not available in web environment');
        return null;
      }

      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Photos
      });

      return image.dataUrl || null;
    } catch (error) {
      console.error('Error selecting from gallery:', error);
      return null;
    }
  }

  /**
   * 文件系统操作
   */
  static async saveFile(fileName: string, data: string): Promise<boolean> {
    try {
      if (!this.isNative()) {
        console.warn('File system not available in web environment');
        return false;
      }

      await Filesystem.writeFile({
        path: fileName,
        data: data,
        directory: Directory.Documents,
        encoding: Encoding.UTF8
      });

      return true;
    } catch (error) {
      console.error('Error saving file:', error);
      return false;
    }
  }

  /**
   * 读取文件
   */
  static async readFile(fileName: string): Promise<string | null> {
    try {
      if (!this.isNative()) {
        console.warn('File system not available in web environment');
        return null;
      }

      const result = await Filesystem.readFile({
        path: fileName,
        directory: Directory.Documents,
        encoding: Encoding.UTF8
      });

      return result.data as string;
    } catch (error) {
      console.error('Error reading file:', error);
      return null;
    }
  }

  /**
   * 推送通知功能
   */
  static async initializePushNotifications(): Promise<void> {
    try {
      if (!this.isNative()) {
        console.warn('Push notifications not available in web environment');
        return;
      }

      // 请求权限
      const permStatus = await PushNotifications.requestPermissions();
      
      if (permStatus.receive === 'granted') {
        // 注册推送通知
        await PushNotifications.register();
        
        // 监听注册成功事件
        PushNotifications.addListener('registration', (token) => {
          console.log('Push registration success, token: ' + token.value);
        });

        // 监听注册失败事件
        PushNotifications.addListener('registrationError', (error) => {
          console.error('Error on registration: ' + JSON.stringify(error));
        });

        // 监听推送通知接收事件
        PushNotifications.addListener('pushNotificationReceived', (notification) => {
          console.log('Push received: ' + JSON.stringify(notification));
        });

        // 监听推送通知点击事件
        PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
          console.log('Push action performed: ' + JSON.stringify(notification));
        });
      }
    } catch (error) {
      console.error('Error initializing push notifications:', error);
    }
  }

  /**
   * 本地通知
   */
  static async showLocalNotification(title: string, body: string): Promise<void> {
    try {
      if (!this.isNative()) {
        console.warn('Local notifications not available in web environment');
        return;
      }

      await LocalNotifications.schedule({
        notifications: [
          {
            title: title,
            body: body,
            id: Date.now(),
            schedule: { at: new Date(Date.now() + 1000) }
          }
        ]
      });
    } catch (error) {
      console.error('Error showing local notification:', error);
    }
  }

  /**
   * 获取设备信息
   */
  static async getDeviceInfo(): Promise<any> {
    try {
      if (!this.isNative()) {
        return {
          platform: 'web',
          model: 'Unknown',
          operatingSystem: 'web',
          osVersion: 'Unknown'
        };
      }

      const info = await Device.getInfo();
      return info;
    } catch (error) {
      console.error('Error getting device info:', error);
      return null;
    }
  }

  /**
   * 网络状态监听
   */
  static async getNetworkStatus(): Promise<any> {
    try {
      const status = await Network.getStatus();
      return status;
    } catch (error) {
      console.error('Error getting network status:', error);
      return null;
    }
  }

  /**
   * 监听网络状态变化
   */
  static addNetworkListener(callback: (status: any) => void): void {
    Network.addListener('networkStatusChange', callback);
  }

  /**
   * 状态栏控制
   */
  static async setStatusBarStyle(style: 'light' | 'dark'): Promise<void> {
    try {
      if (!this.isNative()) {
        return;
      }

      await StatusBar.setStyle({
        style: style === 'light' ? Style.Light : Style.Dark
      });
    } catch (error) {
      console.error('Error setting status bar style:', error);
    }
  }

  /**
   * 键盘控制
   */
  static addKeyboardListeners(): void {
    if (!this.isNative()) {
      return;
    }

    Keyboard.addListener('keyboardWillShow', info => {
      console.log('keyboard will show with height:', info.keyboardHeight);
    });

    Keyboard.addListener('keyboardDidShow', info => {
      console.log('keyboard did show with height:', info.keyboardHeight);
    });

    Keyboard.addListener('keyboardWillHide', () => {
      console.log('keyboard will hide');
    });

    Keyboard.addListener('keyboardDidHide', () => {
      console.log('keyboard did hide');
    });
  }

  /**
   * 触觉反馈
   */
  static async vibrate(style: 'light' | 'medium' | 'heavy' = 'medium'): Promise<void> {
    try {
      if (!this.isNative()) {
        return;
      }

      let impactStyle: ImpactStyle;
      switch (style) {
        case 'light':
          impactStyle = ImpactStyle.Light;
          break;
        case 'heavy':
          impactStyle = ImpactStyle.Heavy;
          break;
        default:
          impactStyle = ImpactStyle.Medium;
      }

      await Haptics.impact({ style: impactStyle });
    } catch (error) {
      console.error('Error triggering haptic feedback:', error);
    }
  }

  /**
   * 初始化所有Capacitor服务
   */
  static async initialize(): Promise<void> {
    console.log('Initializing Capacitor services...');
    
    if (this.isNative()) {
      await this.initializePushNotifications();
      this.addKeyboardListeners();
      await this.setStatusBarStyle('dark');
      
      console.log('Capacitor services initialized for native platform:', this.getPlatform());
    } else {
      console.log('Running in web environment, some features may be limited');
    }
  }
}