/**
 * 文件处理服务
 * 处理Web和原生环境下的文件操作功能
 */

import { CapacitorService } from './capacitorService';

export interface FileInfo {
  name: string;
  size: number;
  type: string;
  data: string; // base64编码的文件数据
  uri?: string; // 原生环境下的文件URI
}

export interface ImageInfo extends FileInfo {
  width?: number;
  height?: number;
}

export class FileService {
  private static instance: FileService;

  private constructor() {}

  /**
   * 获取单例实例
   */
  public static getInstance(): FileService {
    if (!FileService.instance) {
      FileService.instance = new FileService();
    }
    return FileService.instance;
  }

  /**
   * 从相机拍照
   */
  public async capturePhoto(): Promise<ImageInfo> {
    try {
      if (CapacitorService.isNative()) {
        return await this.capturePhotoNative();
      } else {
        return await this.capturePhotoWeb();
      }
    } catch (error) {
      console.error('拍照失败:', error);
      throw new Error('拍照失败，请检查相机权限');
    }
  }

  /**
   * 原生环境拍照
   */
  private async capturePhotoNative(): Promise<ImageInfo> {
    try {
      const { Camera, CameraResultType, CameraSource } = await import('@capacitor/camera');
      
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Camera
      });

      return {
        name: `photo_${Date.now()}.jpg`,
        size: 0, // Base64数据无法直接获取原始大小
        type: 'image/jpeg',
        data: image.base64String || '',
        uri: image.path,
        width: (image as any).width,
        height: (image as any).height
      };
    } catch (error) {
      console.error('原生拍照失败:', error);
      throw error;
    }
  }

  /**
   * Web环境拍照（使用getUserMedia）
   */
  private async capturePhotoWeb(): Promise<ImageInfo> {
    return new Promise((resolve, reject) => {
      // 创建文件输入元素
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.capture = 'environment'; // 使用后置摄像头

      input.onchange = async (event) => {
        const file = (event.target as HTMLInputElement).files?.[0];
        if (!file) {
          reject(new Error('未选择文件'));
          return;
        }

        try {
          const imageInfo = await this.fileToImageInfo(file);
          resolve(imageInfo);
        } catch (error) {
          reject(error);
        }
      };

      input.onerror = () => {
        reject(new Error('文件选择失败'));
      };

      // 触发文件选择
      input.click();
    });
  }

  /**
   * 从图库选择图片
   */
  public async selectFromGallery(): Promise<ImageInfo> {
    try {
      if (CapacitorService.isNative()) {
        return await this.selectFromGalleryNative();
      } else {
        return await this.selectFromGalleryWeb();
      }
    } catch (error) {
      console.error('选择图片失败:', error);
      throw new Error('选择图片失败，请检查存储权限');
    }
  }

  /**
   * 原生环境选择图片
   */
  private async selectFromGalleryNative(): Promise<ImageInfo> {
    try {
      const { Camera, CameraResultType, CameraSource } = await import('@capacitor/camera');
      
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Photos
      });

      return {
        name: `image_${Date.now()}.jpg`,
        size: 0,
        type: 'image/jpeg',
        data: image.base64String || '',
        uri: image.path,
        width: (image as any).width,
        height: (image as any).height
      };
    } catch (error) {
      console.error('原生选择图片失败:', error);
      throw error;
    }
  }

  /**
   * Web环境选择图片
   */
  private async selectFromGalleryWeb(): Promise<ImageInfo> {
    return new Promise((resolve, reject) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';

      input.onchange = async (event) => {
        const file = (event.target as HTMLInputElement).files?.[0];
        if (!file) {
          reject(new Error('未选择文件'));
          return;
        }

        try {
          const imageInfo = await this.fileToImageInfo(file);
          resolve(imageInfo);
        } catch (error) {
          reject(error);
        }
      };

      input.onerror = () => {
        reject(new Error('文件选择失败'));
      };

      input.click();
    });
  }

  /**
   * 选择文件
   */
  public async selectFile(accept?: string): Promise<FileInfo> {
    try {
      if (CapacitorService.isNative()) {
        return await this.selectFileNative(accept);
      } else {
        return await this.selectFileWeb(accept);
      }
    } catch (error) {
      console.error('选择文件失败:', error);
      throw new Error('选择文件失败');
    }
  }

  /**
   * 原生环境选择文件
   */
  private async selectFileNative(accept?: string): Promise<FileInfo> {
    try {
      // 在原生环境中，可以使用Filesystem插件或第三方文件选择器
      // 这里简化处理，使用相机插件选择图片
      if (accept?.includes('image')) {
        return await this.selectFromGalleryNative();
      }
      
      throw new Error('原生环境暂不支持选择非图片文件');
    } catch (error) {
      console.error('原生选择文件失败:', error);
      throw error;
    }
  }

  /**
   * Web环境选择文件
   */
  private async selectFileWeb(accept?: string): Promise<FileInfo> {
    return new Promise((resolve, reject) => {
      const input = document.createElement('input');
      input.type = 'file';
      if (accept) {
        input.accept = accept;
      }

      input.onchange = async (event) => {
        const file = (event.target as HTMLInputElement).files?.[0];
        if (!file) {
          reject(new Error('未选择文件'));
          return;
        }

        try {
          const fileInfo = await this.fileToFileInfo(file);
          resolve(fileInfo);
        } catch (error) {
          reject(error);
        }
      };

      input.onerror = () => {
        reject(new Error('文件选择失败'));
      };

      input.click();
    });
  }

  /**
   * 将File对象转换为FileInfo
   */
  private async fileToFileInfo(file: File): Promise<FileInfo> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = () => {
        const result = reader.result as string;
        const base64Data = result.split(',')[1]; // 移除data:type;base64,前缀
        
        resolve({
          name: file.name,
          size: file.size,
          type: file.type,
          data: base64Data
        });
      };
      
      reader.onerror = () => {
        reject(new Error('文件读取失败'));
      };
      
      reader.readAsDataURL(file);
    });
  }

  /**
   * 将File对象转换为ImageInfo
   */
  private async fileToImageInfo(file: File): Promise<ImageInfo> {
    const fileInfo = await this.fileToFileInfo(file);
    
    // 获取图片尺寸
    const dimensions = await this.getImageDimensions(file);
    
    return {
      ...fileInfo,
      width: dimensions.width,
      height: dimensions.height
    };
  }

  /**
   * 获取图片尺寸
   */
  private async getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      
      img.onload = () => {
        URL.revokeObjectURL(url);
        resolve({
          width: img.naturalWidth,
          height: img.naturalHeight
        });
      };
      
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('无法获取图片尺寸'));
      };
      
      img.src = url;
    });
  }

  /**
   * 压缩图片
   */
  public async compressImage(imageInfo: ImageInfo, quality: number = 0.8): Promise<ImageInfo> {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('无法创建Canvas上下文');
      }

      // 创建图片对象
      const img = new Image();
      const imageUrl = `data:${imageInfo.type};base64,${imageInfo.data}`;
      
      return new Promise((resolve, reject) => {
        img.onload = () => {
          // 设置画布尺寸
          canvas.width = imageInfo.width || img.naturalWidth;
          canvas.height = imageInfo.height || img.naturalHeight;
          
          // 绘制图片
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          
          // 压缩并导出
          canvas.toBlob((blob) => {
            if (!blob) {
              reject(new Error('图片压缩失败'));
              return;
            }
            
            const reader = new FileReader();
            reader.onload = () => {
              const result = reader.result as string;
              const base64Data = result.split(',')[1];
              
              resolve({
                ...imageInfo,
                data: base64Data,
                size: blob.size
              });
            };
            reader.onerror = () => reject(new Error('压缩后图片读取失败'));
            reader.readAsDataURL(blob);
          }, imageInfo.type, quality);
        };
        
        img.onerror = () => reject(new Error('图片加载失败'));
        img.src = imageUrl;
      });
    } catch (error) {
      console.error('图片压缩失败:', error);
      throw error;
    }
  }

  /**
   * 保存文件到设备
   */
  public async saveFile(fileInfo: FileInfo, filename?: string): Promise<void> {
    try {
      if (CapacitorService.isNative()) {
        await this.saveFileNative(fileInfo, filename);
      } else {
        await this.saveFileWeb(fileInfo, filename);
      }
    } catch (error) {
      console.error('保存文件失败:', error);
      throw new Error('保存文件失败');
    }
  }

  /**
   * 原生环境保存文件
   */
  private async saveFileNative(fileInfo: FileInfo, filename?: string): Promise<void> {
    try {
      const { Filesystem, Directory } = await import('@capacitor/filesystem');
      
      const fileName = filename || fileInfo.name;
      
      await Filesystem.writeFile({
        path: fileName,
        data: fileInfo.data,
        directory: Directory.Documents
      });
      
      console.log('文件保存成功:', fileName);
    } catch (error) {
      console.error('原生保存文件失败:', error);
      throw error;
    }
  }

  /**
   * Web环境保存文件
   */
  private async saveFileWeb(fileInfo: FileInfo, filename?: string): Promise<void> {
    try {
      // 创建Blob对象
      const byteCharacters = atob(fileInfo.data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: fileInfo.type });
      
      // 创建下载链接
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename || fileInfo.name;
      
      // 触发下载
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // 清理URL
      URL.revokeObjectURL(url);
      
      console.log('文件下载成功:', filename || fileInfo.name);
    } catch (error) {
      console.error('Web保存文件失败:', error);
      throw error;
    }
  }
}

// 导出单例实例
export const fileService = FileService.getInstance();