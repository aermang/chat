/**
 * 推送通知服务
 * 处理Web和原生环境下的推送通知功能
 */

import { CapacitorService } from './capacitorService';

export interface NotificationOptions {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  data?: any;
  actions?: NotificationAction[];
  silent?: boolean;
  vibrate?: number[];
}

export interface NotificationAction {
  action: string;
  title: string;
  icon?: string;
}

export class NotificationService {
  private static instance: NotificationService;
  private isInitialized = false;
  private permission: NotificationPermission = 'default';

  private constructor() {}

  /**
   * 获取单例实例
   */
  public static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  /**
   * 初始化通知服务
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    try {
      if (CapacitorService.isNative()) {
        // 原生环境：使用Capacitor推送通知
        await this.initializeNativeNotifications();
      } else {
        // Web环境：使用Web Notifications API
        await this.initializeWebNotifications();
      }
      
      this.isInitialized = true;
      console.log('通知服务初始化成功');
    } catch (error) {
      console.error('通知服务初始化失败:', error);
      throw error;
    }
  }

  /**
   * 初始化原生推送通知
   */
  private async initializeNativeNotifications(): Promise<void> {
    try {
      // 动态导入Capacitor推送通知插件
      const { PushNotifications } = await import('@capacitor/push-notifications');
      
      // 请求权限
      const permissionResult = await PushNotifications.requestPermissions();
      
      if (permissionResult.receive === 'granted') {
        // 注册推送通知
        await PushNotifications.register();
        
        // 监听注册成功事件
        PushNotifications.addListener('registration', (token) => {
          console.log('推送通知注册成功:', token.value);
          // TODO: 将token发送到服务器
        });

        // 监听注册失败事件
        PushNotifications.addListener('registrationError', (error) => {
          console.error('推送通知注册失败:', error);
        });

        // 监听推送通知接收事件
        PushNotifications.addListener('pushNotificationReceived', (notification) => {
          console.log('收到推送通知:', notification);
          this.handleNotificationReceived(notification);
        });

        // 监听推送通知点击事件
        PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
          console.log('推送通知被点击:', notification);
          this.handleNotificationClicked(notification);
        });

        this.permission = 'granted';
      } else {
        this.permission = 'denied';
        console.warn('推送通知权限被拒绝');
      }
    } catch (error) {
      console.error('初始化原生推送通知失败:', error);
      throw error;
    }
  }

  /**
   * 初始化Web通知
   */
  private async initializeWebNotifications(): Promise<void> {
    if (!('Notification' in window)) {
      console.warn('浏览器不支持Web通知');
      return;
    }

    // 检查当前权限状态
    this.permission = Notification.permission;

    if (this.permission === 'default') {
      // 请求权限
      this.permission = await Notification.requestPermission();
    }

    if (this.permission === 'granted') {
      console.log('Web通知权限已获取');
    } else {
      console.warn('Web通知权限被拒绝');
    }
  }

  /**
   * 发送本地通知
   */
  public async sendLocalNotification(options: NotificationOptions): Promise<void> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (this.permission !== 'granted') {
      console.warn('没有通知权限，无法发送通知');
      return;
    }

    try {
      if (CapacitorService.isNative()) {
        // 原生环境：使用Capacitor本地通知
        await this.sendNativeLocalNotification(options);
      } else {
        // Web环境：使用Web Notifications API
        await this.sendWebNotification(options);
      }
    } catch (error) {
      console.error('发送本地通知失败:', error);
      throw error;
    }
  }

  /**
   * 发送原生本地通知
   */
  private async sendNativeLocalNotification(options: NotificationOptions): Promise<void> {
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // 请求权限
      const permissionResult = await LocalNotifications.requestPermissions();
      
      if (permissionResult.display === 'granted') {
        // 发送本地通知
        await LocalNotifications.schedule({
          notifications: [
            {
              title: options.title,
              body: options.body,
              id: Date.now(),
              schedule: { at: new Date(Date.now() + 1000) }, // 1秒后显示
              sound: undefined,
              attachments: undefined,
              actionTypeId: '',
              extra: options.data
            }
          ]
        });
      }
    } catch (error) {
      console.error('发送原生本地通知失败:', error);
      throw error;
    }
  }

  /**
   * 发送Web通知
   */
  private async sendWebNotification(options: NotificationOptions): Promise<void> {
    try {
      const notificationOptions: any = {
        body: options.body,
        icon: options.icon || '/favicon.ico',
        badge: options.badge,
        tag: options.tag,
        data: options.data,
        silent: options.silent
      };
      
      // 添加vibrate属性（如果支持）
      if (options.vibrate && 'vibrate' in navigator) {
        notificationOptions.vibrate = options.vibrate;
      }
      
      const notification = new Notification(options.title, notificationOptions);

      // 监听点击事件
      notification.onclick = (event) => {
        event.preventDefault();
        this.handleNotificationClicked({ notification: options });
        notification.close();
      };

      // 自动关闭通知
      setTimeout(() => {
        notification.close();
      }, 5000);
    } catch (error) {
      console.error('发送Web通知失败:', error);
      throw error;
    }
  }

  /**
   * 处理通知接收事件
   */
  private handleNotificationReceived(notification: any): void {
    console.log('处理通知接收:', notification);
    
    // 触发自定义事件
    window.dispatchEvent(new CustomEvent('notificationReceived', {
      detail: notification
    }));
  }

  /**
   * 处理通知点击事件
   */
  private handleNotificationClicked(notification: any): void {
    console.log('处理通知点击:', notification);
    
    // 触发自定义事件
    window.dispatchEvent(new CustomEvent('notificationClicked', {
      detail: notification
    }));

    // 如果应用在后台，将其带到前台
    if (document.hidden) {
      window.focus();
    }
  }

  /**
   * 检查通知权限
   */
  public getPermission(): NotificationPermission {
    return this.permission;
  }

  /**
   * 请求通知权限
   */
  public async requestPermission(): Promise<NotificationPermission> {
    if (CapacitorService.isNative()) {
      try {
        const { PushNotifications } = await import('@capacitor/push-notifications');
        const result = await PushNotifications.requestPermissions();
        this.permission = result.receive === 'granted' ? 'granted' : 'denied';
      } catch (error) {
        console.error('请求原生通知权限失败:', error);
        this.permission = 'denied';
      }
    } else {
      if ('Notification' in window) {
        this.permission = await Notification.requestPermission();
      }
    }
    
    return this.permission;
  }

  /**
   * 清除所有通知
   */
  public async clearAllNotifications(): Promise<void> {
    try {
      if (CapacitorService.isNative()) {
        const { LocalNotifications } = await import('@capacitor/local-notifications');
        await LocalNotifications.cancel({ notifications: [] });
      }
      // Web环境下无法清除已显示的通知
    } catch (error) {
      console.error('清除通知失败:', error);
    }
  }

  /**
   * 销毁服务
   */
  public destroy(): void {
    this.isInitialized = false;
    this.permission = 'default';
  }
}

// 导出单例实例
export const notificationService = NotificationService.getInstance();