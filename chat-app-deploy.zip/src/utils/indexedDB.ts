/**
 * 飞鸽风格即时通讯App - IndexedDB数据存储工具
 * 提供产品和进销存数据的本地存储功能
 */

/**
 * 产品数据接口
 * 定义产品的完整数据结构
 */
export interface Product {
  /** 产品唯一标识符 */
  id: string;
  /** 产品名称 */
  name: string;
  /** 产品SKU编码 */
  sku: string;
  /** 产品分类 */
  category: string;
  /** 产品价格 */
  price: number;
  /** 当前库存数量 */
  stock: number;
  /** 最小库存警戒线 */
  minStock: number;
  /** 产品描述（可选） */
  description?: string;
  /** 创建时间 */
  createdAt: Date;
  /** 最后更新时间 */
  updatedAt: Date;
}

/**
 * 进销存记录数据接口
 * 定义单次进销存操作的完整数据结构
 */
export interface InventoryRecord {
  /** 记录唯一标识符 */
  id: string;
  /** 关联的产品ID */
  productId: string;
  /** 记录日期 */
  date: string;
  /** 采购数量 */
  purchaseQuantity: number;
  /** 库存数量 */
  stockQuantity: number;
  /** 纯销数量（计算得出） */
  netSales: number;
  /** 上一次库存数量 */
  previousStock: number;
  /** 创建时间 */
  createdAt: Date;
  /** 最后更新时间 */
  updatedAt: Date;
}

/**
 * 数据库操作错误类型
 */
export type DatabaseError = {
  /** 错误消息 */
  message: string;
  /** 错误代码（可选） */
  code?: string;
  /** 原始错误对象（可选） */
  originalError?: Error;
};

/**
 * 产品创建时的输入类型
 * 排除自动生成的时间戳字段
 */
export type ProductInput = Omit<Product, 'createdAt' | 'updatedAt'>;

/**
 * 产品更新时的输入类型
 * 排除ID和时间戳字段，其他字段可选
 */
export type ProductUpdateInput = Partial<Omit<Product, 'id' | 'createdAt' | 'updatedAt'>>;

/**
 * 进销存记录创建时的输入类型
 * 排除自动生成的时间戳字段
 */
export type InventoryRecordInput = Omit<InventoryRecord, 'createdAt' | 'updatedAt'>;

/**
 * 进销存记录更新时的输入类型
 * 排除ID和时间戳字段，其他字段可选
 */
export type InventoryRecordUpdateInput = Partial<Omit<InventoryRecord, 'id' | 'createdAt' | 'updatedAt'>>;

/**
 * IndexedDB数据库管理类
 * 提供产品和进销存数据的完整CRUD操作
 */
class InventoryDB {
  /** 数据库名称 */
  private readonly dbName = 'InventoryManagementDB';
  /** 数据库版本号 */
  private readonly version = 1;
  /** 数据库连接实例 */
  private db: IDBDatabase | null = null;

  /**
   * 初始化数据库连接
   * 创建必要的对象存储和索引
   * @returns Promise<void> 初始化完成的Promise
   * @throws {DatabaseError} 当数据库初始化失败时抛出错误
   */
  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to open database',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // 创建产品表
        if (!db.objectStoreNames.contains('products')) {
          const productStore = db.createObjectStore('products', { keyPath: 'id' });
          productStore.createIndex('sku', 'sku', { unique: true });
          productStore.createIndex('category', 'category', { unique: false });
          productStore.createIndex('name', 'name', { unique: false });
        }

        // 创建进销存记录表
        if (!db.objectStoreNames.contains('inventoryRecords')) {
          const recordStore = db.createObjectStore('inventoryRecords', { keyPath: 'id' });
          recordStore.createIndex('productId', 'productId', { unique: false });
          recordStore.createIndex('date', 'date', { unique: false });
        }
      };
    });
  }

  /**
   * 确保数据库已初始化
   * 如果数据库未初始化，则自动初始化
   * @returns Promise<IDBDatabase> 数据库实例
   * @throws {DatabaseError} 当数据库未能正确初始化时抛出错误
   */
  private async ensureDB(): Promise<IDBDatabase> {
    if (!this.db) {
      await this.init();
    }
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    return this.db;
  }

  // ==================== 产品管理 ====================

  /**
   * 添加新产品
   * @param product 产品数据（不包含时间戳）
   * @returns Promise<Product> 添加成功的产品数据（包含时间戳）
   * @throws {DatabaseError} 当产品添加失败时抛出错误
   */
  async addProduct(product: ProductInput): Promise<Product> {
    const db = await this.ensureDB();
    const now = new Date();
    const newProduct: Product = {
      ...product,
      createdAt: now,
      updatedAt: now
    };

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products'], 'readwrite');
      const store = transaction.objectStore('products');
      const request = store.add(newProduct);

      request.onsuccess = () => {
        resolve(newProduct);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to add product',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 更新现有产品
   * @param id 产品ID
   * @param updates 要更新的产品字段
   * @returns Promise<Product> 更新后的产品数据
   * @throws {DatabaseError} 当产品不存在或更新失败时抛出错误
   */
  async updateProduct(id: string, updates: ProductUpdateInput): Promise<Product> {
    const db = await this.ensureDB();
    const existingProduct = await this.getProduct(id);
    
    if (!existingProduct) {
      throw new Error('Product not found');
    }

    const updatedProduct: Product = {
      ...existingProduct,
      ...updates,
      updatedAt: new Date()
    };

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products'], 'readwrite');
      const store = transaction.objectStore('products');
      const request = store.put(updatedProduct);

      request.onsuccess = () => {
        resolve(updatedProduct);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to update product',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 删除产品及其相关的进销存记录
   * @param id 产品ID
   * @returns Promise<void> 删除完成的Promise
   * @throws {DatabaseError} 当删除失败时抛出错误
   */
  async deleteProduct(id: string): Promise<void> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products', 'inventoryRecords'], 'readwrite');
      const productStore = transaction.objectStore('products');
      const recordStore = transaction.objectStore('inventoryRecords');

      // 删除产品
      const deleteProductRequest = productStore.delete(id);
      
      // 删除相关的进销存记录
      const index = recordStore.index('productId');
      const deleteRecordsRequest = index.openCursor(IDBKeyRange.only(id));
      
      deleteRecordsRequest.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };

      transaction.oncomplete = () => {
        resolve();
      };

      transaction.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to delete product',
          originalError: new Error(transaction.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 根据ID获取单个产品
   * @param id 产品ID
   * @returns Promise<Product | null> 产品数据，如果不存在则返回null
   * @throws {DatabaseError} 当查询失败时抛出错误
   */
  async getProduct(id: string): Promise<Product | null> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products'], 'readonly');
      const store = transaction.objectStore('products');
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to get product',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 获取所有产品列表
   * @returns Promise<Product[]> 所有产品的数组
   * @throws {DatabaseError} 当查询失败时抛出错误
   */
  async getAllProducts(): Promise<Product[]> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products'], 'readonly');
      const store = transaction.objectStore('products');
      const request = store.getAll();

      request.onsuccess = () => {
        resolve(request.result || []);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to get products',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 根据分类获取产品列表
   * @param category 产品分类
   * @returns Promise<Product[]> 指定分类的产品数组
   * @throws {DatabaseError} 当查询失败时抛出错误
   */
  async getProductsByCategory(category: string): Promise<Product[]> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products'], 'readonly');
      const store = transaction.objectStore('products');
      const index = store.index('category');
      const request = index.getAll(category);

      request.onsuccess = () => {
        resolve(request.result || []);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to get products by category',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  // ==================== 进销存记录管理 ====================

  /**
   * 添加新的进销存记录
   * @param record 进销存记录数据（不包含时间戳）
   * @returns Promise<InventoryRecord> 添加成功的记录数据（包含时间戳）
   * @throws {DatabaseError} 当记录添加失败时抛出错误
   */
  async addInventoryRecord(record: InventoryRecordInput): Promise<InventoryRecord> {
    const db = await this.ensureDB();
    const now = new Date();
    const newRecord: InventoryRecord = {
      ...record,
      createdAt: now,
      updatedAt: now
    };

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readwrite');
      const store = transaction.objectStore('inventoryRecords');
      const request = store.add(newRecord);

      request.onsuccess = () => {
        resolve(newRecord);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to add inventory record',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 更新现有的进销存记录
   * @param id 记录ID
   * @param updates 要更新的记录字段
   * @returns Promise<InventoryRecord> 更新后的记录数据
   * @throws {DatabaseError} 当记录不存在或更新失败时抛出错误
   */
  async updateInventoryRecord(id: string, updates: InventoryRecordUpdateInput): Promise<InventoryRecord> {
    const db = await this.ensureDB();
    const existingRecord = await this.getInventoryRecord(id);
    
    if (!existingRecord) {
      throw new Error('Inventory record not found');
    }

    const updatedRecord: InventoryRecord = {
      ...existingRecord,
      ...updates,
      updatedAt: new Date()
    };

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readwrite');
      const store = transaction.objectStore('inventoryRecords');
      const request = store.put(updatedRecord);

      request.onsuccess = () => {
        resolve(updatedRecord);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to update inventory record',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 删除进销存记录
   * @param id 记录ID
   * @returns Promise<void> 删除完成的Promise
   * @throws {DatabaseError} 当删除失败时抛出错误
   */
  async deleteInventoryRecord(id: string): Promise<void> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readwrite');
      const store = transaction.objectStore('inventoryRecords');
      const request = store.delete(id);

      request.onsuccess = () => {
        resolve();
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to delete inventory record',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 根据ID获取单个进销存记录
   * @param id 记录ID
   * @returns Promise<InventoryRecord | null> 记录数据，如果不存在则返回null
   * @throws {DatabaseError} 当查询失败时抛出错误
   */
  async getInventoryRecord(id: string): Promise<InventoryRecord | null> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readonly');
      const store = transaction.objectStore('inventoryRecords');
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to get inventory record',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 获取指定产品的所有进销存记录
   * @param productId 产品ID
   * @returns Promise<InventoryRecord[]> 按日期排序的记录数组
   * @throws {DatabaseError} 当查询失败时抛出错误
   */
  async getInventoryRecordsByProduct(productId: string): Promise<InventoryRecord[]> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readonly');
      const store = transaction.objectStore('inventoryRecords');
      const index = store.index('productId');
      const request = index.getAll(productId);

      request.onsuccess = () => {
        const records = request.result || [];
        // 按日期排序（从早到晚）
        records.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        resolve(records);
      };

      request.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to get inventory records',
          originalError: new Error(request.error?.toString())
        };
        reject(error);
      };
    });
  }

  /**
   * 批量添加进销存记录
   * @param records 记录数组（不包含时间戳）
   * @returns Promise<InventoryRecord[]> 添加成功的记录数组（包含时间戳）
   * @throws {DatabaseError} 当批量添加失败时抛出错误
   */
  async batchAddInventoryRecords(records: InventoryRecordInput[]): Promise<InventoryRecord[]> {
    const db = await this.ensureDB();
    const now = new Date();
    const newRecords: InventoryRecord[] = records.map(record => ({
      ...record,
      createdAt: now,
      updatedAt: now
    }));

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['inventoryRecords'], 'readwrite');
      const store = transaction.objectStore('inventoryRecords');
      const results: InventoryRecord[] = [];
      let completed = 0;

      newRecords.forEach(record => {
        const request = store.add(record);
        
        request.onsuccess = () => {
          results.push(record);
          completed++;
          if (completed === newRecords.length) {
            resolve(results);
          }
        };

        request.onerror = () => {
          const error: DatabaseError = {
            message: 'Failed to batch add inventory records',
            originalError: new Error(request.error?.toString())
          };
          reject(error);
        };
      });

      if (newRecords.length === 0) {
        resolve([]);
      }
    });
  }

  /**
   * 清空所有数据
   * 删除所有产品和进销存记录
   * @returns Promise<void> 清空完成的Promise
   * @throws {DatabaseError} 当清空失败时抛出错误
   */
  async clearAllData(): Promise<void> {
    const db = await this.ensureDB();

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['products', 'inventoryRecords'], 'readwrite');
      const productStore = transaction.objectStore('products');
      const recordStore = transaction.objectStore('inventoryRecords');

      const clearProducts = productStore.clear();
      const clearRecords = recordStore.clear();

      transaction.oncomplete = () => {
        resolve();
      };

      transaction.onerror = () => {
        const error: DatabaseError = {
          message: 'Failed to clear all data',
          originalError: new Error(transaction.error?.toString())
        };
        reject(error);
      };
    });
  }
}

// 创建单例实例
export const inventoryDB = new InventoryDB();

/**
 * 初始化数据库（应用启动时调用）
 * 这是应用程序的入口点，确保数据库在使用前已正确初始化
 * @returns Promise<void> 初始化完成的Promise
 * @throws {DatabaseError} 当数据库初始化失败时抛出错误
 */
export const initInventoryDB = async (): Promise<void> => {
  try {
    await inventoryDB.init();
    console.log('Inventory database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize inventory database:', error);
    throw error;
  }
};