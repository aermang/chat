import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  ArrowLeft,
  User,
  Phone,
  Calendar,
  MapPin,
  Edit,
  FileText,
  Bell,
  BarChart3,
  Plus,
  Clock,
  Pill,
  Activity,
  AlertCircle,
  CheckCircle,
  ChevronRight
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
// 修复导入错误：从正确的位置导入 useSpecialMedicineStore
// setCurrentPatient 函数在 hooks/useSpecialMedicineStore 中定义，而不是在 store/index.ts 中
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { Patient } from '../types';

/**
 * 患者详情页面组件
 * 集成用药记录、用药提醒、统计分析、患者信息编辑四个功能模块
 */
const PatientDetail: React.FC = () => {
  const navigate = useNavigate();
  const { patientId } = useParams<{ patientId: string }>();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 添加调试信息
  console.log('PatientDetail 组件渲染，patientId:', patientId);
  
  // 获取状态管理中的数据
  const { 
    patients, 
    medicationRecords, 
    reminders,
    loadPatients,
    loadMedicationRecords,
    loadReminders,
    setCurrentPatient
  } = useSpecialMedicineStore();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [patientStats, setPatientStats] = useState({
    totalRecords: 0,
    activeReminders: 0,
    todayRecords: 0,
    completionRate: 0
  });

  /**
   * 加载患者数据
   */
  useEffect(() => {
    const loadData = async () => {
      try {
        console.log('开始加载数据...');
        setLoading(true);
        setError(null);
        
        await Promise.all([
          loadPatients(),
          loadMedicationRecords(),
          loadReminders()
        ]);
        
        console.log('数据加载完成');
      } catch (err) {
        console.error('数据加载失败:', err);
        setError('数据加载失败，请重试');
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [loadPatients, loadMedicationRecords, loadReminders]);

  /**
   * 查找当前患者并设置为当前患者
   * 改进的患者查找逻辑，包含重试机制和更好的错误处理
   */
  useEffect(() => {
    console.log('查找患者，patientId:', patientId, 'patients.length:', patients.length, 'loading:', loading);
    
    // 如果没有patientId，直接返回
    if (!patientId) {
      console.warn('没有提供患者ID');
      setError('患者ID无效');
      return;
    }

    // 如果正在加载中，等待加载完成
    if (loading) {
      console.log('数据正在加载中，等待加载完成...');
      return;
    }

    // 如果患者列表为空，尝试重新加载数据
    if (patients.length === 0) {
      console.log('患者列表为空，尝试重新加载数据...');
      const reloadData = async () => {
        try {
          await loadPatients();
          console.log('重新加载患者数据完成');
        } catch (err) {
          console.error('重新加载患者数据失败:', err);
          setError('数据加载失败，请刷新页面重试');
        }
      };
      reloadData();
      return;
    }

    // 查找患者
    console.log('患者列表:', patients.map(p => ({ id: p.id, name: p.name })));
    
    const foundPatient = patients.find(p => p.id === patientId);
    console.log('找到的患者:', foundPatient);
    
    if (foundPatient) {
      setPatient(foundPatient);
      setCurrentPatient(foundPatient);
      setError(null);
      console.log('成功设置当前患者:', foundPatient.name);
    } else {
      console.error('未找到患者，patientId:', patientId);
      console.log('可用的患者ID列表:', patients.map(p => p.id));
      
      // 设置错误信息，但给用户更多时间查看
      setError(`未找到ID为 ${patientId} 的患者，可能是数据同步问题`);
      
      // 延迟跳转，给用户看到错误信息，并尝试一次重新加载
      setTimeout(async () => {
        console.log('尝试重新加载数据后再次查找患者...');
        try {
          await loadPatients();
          const retryFoundPatient = patients.find(p => p.id === patientId);
          if (retryFoundPatient) {
            console.log('重试后找到患者:', retryFoundPatient.name);
            setPatient(retryFoundPatient);
            setCurrentPatient(retryFoundPatient);
            setError(null);
            return;
          }
        } catch (err) {
          console.error('重试加载数据失败:', err);
        }
        
        // 如果重试后仍未找到，跳转回患者列表
        console.log('重试后仍未找到患者，跳转回患者列表');
        navigate('/app/special-medicine/patients');
      }, 3000); // 增加延迟时间到3秒
    }
  }, [patientId, patients, setCurrentPatient, navigate, loading, loadPatients]);

  /**
   * 计算患者相关统计数据
   */
   useEffect(() => {
     if (patient) {
       const patientRecords = medicationRecords.filter(record => record.patientId === patient.id);
       const patientReminders = reminders.filter(reminder => reminder.patientId === patient.id);
       
       const today = new Date().toDateString();
       const todayRecordsCount = patientRecords.filter(record => 
         new Date(record.recordDate).toDateString() === today
       ).length;
       
       const activeRemindersCount = patientReminders.filter(reminder => 
         reminder.isActive
       ).length;

       // 计算完成率（基于最近30天的记录）
       const thirtyDaysAgo = new Date();
       thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
       
       const recentRecords = patientRecords.filter(record => 
         new Date(record.recordDate) >= thirtyDaysAgo
       );
       
       // 计算今日概览数据
       const todayMedicationRecords = recentRecords.filter(record => 
         new Date(record.takenDate).toDateString() === new Date().toDateString()
       );
       const completedRecords = recentRecords.filter(record => record.isTaken);
       const completionRate = recentRecords.length > 0 
         ? Math.round((completedRecords.length / recentRecords.length) * 100)
         : 0;

       setPatientStats({
         totalRecords: patientRecords.length,
         activeReminders: activeRemindersCount,
         todayRecords: todayRecordsCount,
         completionRate
       });
     }
   }, [patient, medicationRecords, reminders]);

  /**
   * 处理返回患者管理页面
   */
  const handleGoBack = () => {
    navigate('/app/special-medicine/patients');
  };

  /**
   * 处理编辑患者信息
   */
  const handleEditPatient = () => {
    navigate(`/app/special-medicine/patient-form/${patient?.id}`);
  };

  /**
   * 处理功能模块导航
   */
  const handleModuleNavigation = (path: string) => {
    navigate(path);
  };

  /**
   * 计算年龄
   */
  const calculateAge = (birthDate: string): number => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  /**
   * 格式化性别显示
   */
  const formatGender = (gender: string): string => {
    return gender === 'male' ? '男' : gender === 'female' ? '女' : '未知';
  };

  /**
   * 功能模块配置
   */
  const functionModules = [
    {
      id: 'records',
      title: '用药记录',
      description: '查看和管理用药记录',
      icon: <FileText className="w-5 h-5" />,
      color: 'from-green-500 to-green-600',
      count: patientStats.totalRecords,
      path: `/app/special-medicine/records?patientId=${patient?.id}`,
      actionText: '查看记录'
    },
    {
      id: 'reminders',
      title: '用药提醒',
      description: '设置和管理用药提醒',
      icon: <Bell className="w-5 h-5" />,
      color: 'from-orange-500 to-orange-600',
      count: patientStats.activeReminders,
      path: `/app/special-medicine/reminders?patientId=${patient?.id}`,
      actionText: '管理提醒'
    },
    {
      id: 'statistics',
      title: '统计分析',
      description: '查看用药数据统计',
      icon: <BarChart3 className="w-5 h-5" />,
      color: 'from-purple-500 to-purple-600',
      count: `${patientStats.completionRate}%`,
      path: `/app/special-medicine/statistics?patientId=${patient?.id}`,
      actionText: '查看统计'
    }
  ];

  // 显示错误状态
  if (error) {
    return (
      <PageContainer
        title="患者详情"
        actions={[
          {
            icon: <ArrowLeft className="w-5 h-5" />,
            onClick: handleGoBack,
            label: "返回"
          }
        ]}
      >
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <p className="text-red-500 dark:text-red-400 mb-4">{error}</p>
            <button
              onClick={handleGoBack}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              返回患者列表
            </button>
          </div>
        </div>
      </PageContainer>
    );
  }

  // 显示加载状态
  if (loading || !patient) {
    return (
      <PageContainer
        title="患者详情"
        actions={[
          {
            icon: <ArrowLeft className="w-5 h-5" />,
            onClick: handleGoBack,
            label: "返回"
          }
        ]}
      >
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">加载中...</p>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title="患者详情"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <Edit className="w-5 h-5" />,
          onClick: handleEditPatient,
          label: "编辑"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 患者基本信息卡片 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
        `}>
          <div className="flex items-start space-x-4">
            {/* 头像 */}
            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-full p-4 text-white">
              <User className="w-8 h-8" />
            </div>
            
            {/* 基本信息 - 调整为只显示核心五个字段：姓名、年龄、性别、联系电话、诊断 */}
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className={`font-bold text-gray-900 dark:text-white ${isMobile ? 'text-xl' : 'text-2xl'}`}>
                  {patient.name}
                </h1>
                <span className={`
                  px-2 py-1 rounded-full text-xs font-medium
                  ${patient.isActive 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' 
                    : 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400'
                  }
                `}>
                  {patient.isActive ? '活跃' : '非活跃'}
                </span>
              </div>
              
              {/* 核心信息网格布局 - 性别年龄、联系电话、诊断信息 */}
              <div className="grid grid-cols-1 gap-3 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-2">
                   <User className="w-4 h-4" />
                   <span>{formatGender(patient.gender)} · {patient.age}岁</span>
                 </div>
                 <div className="flex items-center space-x-2">
                   <Phone className="w-4 h-4" />
                   <span>{patient.phone}</span>
                 </div>
                 {/* 显示诊断信息 */}
                 {patient.diagnosis && (
                   <div className="flex items-center space-x-2">
                     <FileText className="w-4 h-4" />
                     <span>诊断: {patient.diagnosis}</span>
                   </div>
                 )}
              </div>
            </div>
          </div>
        </div>

        {/* 今日概览 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
        `}>
          <div className="flex items-center space-x-2 mb-4">
            <Activity className="w-5 h-5 text-blue-500" />
            <h2 className={`
              font-semibold text-gray-900 dark:text-white
              ${isMobile ? 'text-base' : 'text-lg'}
            `}>
              今日概览
            </h2>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {patientStats.todayRecords}
              </div>
              <div className="text-sm text-blue-600 dark:text-blue-400">
                今日记录
              </div>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {patientStats.activeReminders}
              </div>
              <div className="text-sm text-green-600 dark:text-green-400">
                活跃提醒
              </div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                {patientStats.completionRate}%
              </div>
              <div className="text-sm text-purple-600 dark:text-purple-400">
                完成率
              </div>
            </div>
          </div>
        </div>

        {/* 功能模块 */}
        <div className="flex-1 overflow-y-auto">
          <div className={`${isMobile ? 'px-4 py-4' : 'px-6 py-6'}`}>
            <h2 className={`
              font-semibold text-gray-900 dark:text-white mb-4
              ${isMobile ? 'text-base' : 'text-lg'}
            `}>
              管理功能
            </h2>
            
            <div className="space-y-4">
              {functionModules.map((module) => (
                <div
                  key={module.id}
                  onClick={() => handleModuleNavigation(module.path)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md
                    border border-gray-200 dark:border-gray-700
                    p-4 cursor-pointer transition-all duration-300
                    transform hover:scale-105 active:scale-95
                    hover:border-gray-300 dark:hover:border-gray-600
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`
                        bg-gradient-to-r ${module.color} 
                        rounded-lg p-3 text-white
                      `}>
                        {module.icon}
                      </div>
                      
                      <div>
                        <h3 className={`
                          font-semibold text-gray-900 dark:text-white
                          ${isMobile ? 'text-base' : 'text-lg'}
                        `}>
                          {module.title}
                        </h3>
                        <p className={`
                          text-gray-600 dark:text-gray-400
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}>
                          {module.description}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <div className="text-xl font-bold text-gray-900 dark:text-white">
                          {module.count}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          {module.actionText}
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* 快速操作 */}
            <div className="mt-6">
              <h3 className={`
                font-semibold text-gray-900 dark:text-white mb-4
                ${isMobile ? 'text-base' : 'text-lg'}
              `}>
                快速操作
              </h3>
              
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => navigate(`/app/special-medicine/medication-form?patientId=${patient.id}`)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700
                    text-white rounded-lg p-4 flex items-center justify-center space-x-2
                    transition-all duration-300 transform hover:scale-105 active:scale-95
                    shadow-md hover:shadow-lg
                  `}
                >
                  <Plus className="w-5 h-5" />
                  <span className={`font-medium ${isMobile ? 'text-sm' : 'text-base'}`}>
                    添加记录
                  </span>
                </button>
                
                <button
                  onClick={() => navigate(`/app/special-medicine/reminder-form?patientId=${patient.id}`)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700
                    text-white rounded-lg p-4 flex items-center justify-center space-x-2
                    transition-all duration-300 transform hover:scale-105 active:scale-95
                    shadow-md hover:shadow-lg
                  `}
                >
                  <Bell className="w-5 h-5" />
                  <span className={`font-medium ${isMobile ? 'text-sm' : 'text-base'}`}>
                    设置提醒
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 底部信息 */}
        <div className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span className={`
                text-gray-600 dark:text-gray-300
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                患者档案完整
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className={`
                text-gray-600 dark:text-gray-300
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                最后更新: {new Date().toLocaleTimeString('zh-CN', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default PatientDetail;