/**
 * 视频播放页面组件
 * 提供专业的视频播放体验，包括全屏播放、画中画、播放控制等功能
 */

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Share2, Download, Heart, MessageCircle, MoreHorizontal, Music, Maximize2, Minimize2 } from 'lucide-react';
import MediaPlayer from '../components/MediaPlayer';
import VideoDetails from '../components/VideoDetails';
import CommentSystem from '../components/CommentSystem';
import { useMediaStore } from '../store/mediaStore';
import { useIsMobile } from '../hooks/useIsMobile';
import type { Movie, Track } from '../types';
import { EnhancedMovie } from '../types';

/**
 * 视频播放页面组件
 */
export default function VideoPlayer() {
  const { videoId } = useParams<{ videoId: string }>();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  
  // 状态管理
  const { 
    currentPlaying, 
    isLoading, 
    error,
    playContent,
    movies,
    tracks,
    loadMovies,
    loadTracks
  } = useMediaStore();
  
  const [showDetails, setShowDetails] = useState(!isMobile);
  const [showComments, setShowComments] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [contentNotFound, setContentNotFound] = useState(false);
  
  // 判断当前播放的内容类型
  const isAudioContent = currentPlaying.type === 'track';
  const isVideoContent = currentPlaying.type === 'movie';

  /**
   * 根据videoId加载对应的视频或音频数据
   */
  useEffect(() => {
    const loadContent = async () => {
      if (!videoId) {
        setContentNotFound(true);
        return;
      }

      try {
        setContentNotFound(false);
        
        // 确保数据已加载
        if (movies.length === 0) {
          await loadMovies();
        }
        if (tracks.length === 0) {
          await loadTracks();
        }

        // 等待数据加载完成后再查找
        await new Promise(resolve => setTimeout(resolve, 100));

        // 查找视频内容
        const movie = movies.find(m => m.id === videoId);
        if (movie) {
          console.log('找到视频内容:', movie);
          // 确保视频有有效的URL
          const videoUrl = 'videoUrl' in movie ? movie.videoUrl : 
                          (movie as EnhancedMovie).videoQualities?.[0]?.url;
          
          if (videoUrl) {
            playContent(movie, 'movie');
            return;
          } else {
            console.error('视频URL无效:', movie);
          }
        }

        // 查找音频内容
        const track = tracks.find(t => t.id === videoId);
        if (track) {
          console.log('找到音频内容:', track);
          // 确保音频有有效的URL
          if (track.audioUrl) {
            playContent(track, 'track');
            return;
          } else {
            console.error('音频URL无效:', track);
          }
        }

        // 如果都没找到，设置内容未找到
        console.warn('未找到内容，videoId:', videoId, 'movies:', movies.length, 'tracks:', tracks.length);
        setContentNotFound(true);
      } catch (error) {
        console.error('加载内容失败:', error);
        setContentNotFound(true);
      }
    };

    loadContent();
  }, [videoId, movies, tracks, loadMovies, loadTracks, playContent]);

  /**
   * 处理返回操作
   */
  const handleBack = () => {
    navigate(-1);
  };

  /**
   * 处理分享操作
   */
  const handleShare = async () => {
    const currentContent = currentPlaying.content;
    if (navigator.share && currentContent) {
      try {
        await navigator.share({
          title: currentContent.title,
          text: isVideoContent ? (currentContent as EnhancedMovie).description : `音乐: ${currentContent.title}`,
          url: window.location.href,
        });
      } catch (error) {
        console.log('分享取消或失败:', error);
      }
    } else {
      // 复制链接到剪贴板
      navigator.clipboard.writeText(window.location.href);
      // 这里可以添加提示消息
    }
  };

  /**
   * 处理下载操作
   */
  const handleDownload = () => {
    const content = currentPlaying.content;
    if (!content) return;
    
    const link = document.createElement('a');
    
    if (isVideoContent) {
      const movie = content as EnhancedMovie;
      if (movie.videoQualities && movie.videoQualities.length > 0) {
        link.href = movie.videoQualities[0].url;
        link.download = `${movie.title}.mp4`;
      }
    } else if (isAudioContent) {
      const track = content as Track;
      link.href = track.audioUrl;
      link.download = `${track.title}.mp3`;
    }
    
    if (link.href) {
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  /**
   * 处理收藏切换
   */
  const handleToggleFavorite = () => {
    // TODO: 实现收藏功能
    console.log('Toggle favorite');
  };

  /**
   * 处理全屏状态变化
   */
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // 加载状态
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  // 错误状态
  if (error || contentNotFound || (!currentPlaying.content && videoId && !isLoading)) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">内容加载失败</h2>
          <p className="text-gray-400 mb-6">
            {error || (contentNotFound ? '未找到指定的内容' : '内容不存在或已被删除')}
          </p>
          <button
            onClick={handleBack}
            className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
          >
            返回
          </button>
        </div>
      </div>
    );
  }

  const currentContent = currentPlaying.content as EnhancedMovie | Track;
  const currentMovie = isVideoContent ? (currentContent as EnhancedMovie) : null;
  const currentTrack = isAudioContent ? (currentContent as Track) : null;

  return (
    <div className={`min-h-screen bg-gray-900 text-white ${isFullscreen ? 'fullscreen-app' : ''}`}>
      {/* 移动端布局 */}
      {isMobile ? (
        <div className={`flex flex-col ${isFullscreen ? 'h-screen video-player-fullscreen' : 'min-h-screen'}`}>
          {/* 顶部导航栏 */}
          {!isFullscreen && (
            <div className="flex items-center justify-between p-4 bg-gray-800 flex-shrink-0">
              <button
                onClick={handleBack}
                className="flex items-center text-blue-400 hover:text-blue-300"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                返回
              </button>
              <h1 className="text-lg font-semibold truncate mx-4">
                {currentPlaying.content?.title || '播放器'}
              </h1>
              <button
                onClick={toggleFullscreen}
                className="p-2 text-gray-400 hover:text-white"
              >
                {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
            </div>
          )}

          {/* 内容区域 - 修复滚动问题 */}
          <div className={`${isFullscreen ? 'flex-1 h-full overflow-hidden' : 'flex-1 overflow-y-auto'}`}>
            {/* 视频播放器 */}
            <div className={`${isFullscreen ? 'h-full' : 'aspect-video'} bg-black flex-shrink-0`}>
              <MediaPlayer className="unified-controls" />
            </div>

            {/* 视频信息和评论 - 只在非全屏时显示 */}
            {!isFullscreen && (
              <div className="p-4 space-y-4 flex-shrink-0">
                {/* 切换按钮 */}
                <div className="flex border-b border-gray-800">
                  <button
                    onClick={() => {
                      setShowDetails(true);
                      setShowComments(false);
                    }}
                    className={`flex-1 py-3 px-4 text-center transition-colors ${
                      showDetails && !showComments
                        ? 'text-green-500 border-b-2 border-green-500'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    详情
                  </button>
                  <button
                    onClick={() => {
                      setShowDetails(false);
                      setShowComments(true);
                    }}
                    className={`flex-1 py-3 px-4 text-center transition-colors ${
                      showComments
                        ? 'text-green-500 border-b-2 border-green-500'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-center space-x-2">
                      <MessageCircle className="w-4 h-4" />
                      <span>评论</span>
                    </div>
                  </button>
                </div>
                
                {/* 内容区域 */}
                <div className="overflow-y-auto">
                  {showDetails && !showComments && (
                    <>
                      {isVideoContent && currentMovie && (
                        <VideoDetails movie={currentMovie} />
                      )}
                      {isAudioContent && currentTrack && (
                        <div className="space-y-4">
                          {/* 音频详情 */}
                          <div className="text-center">
                            <div className="w-32 h-32 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                              <Music className="w-16 h-16 text-white" />
                            </div>
                            <h2 className="text-xl font-bold mb-2">{currentTrack.title}</h2>
                            <p className="text-gray-400 mb-1">{currentTrack.artist}</p>
                            <p className="text-gray-500 text-sm">{currentTrack.album}</p>
                          </div>
                          
                          {/* 音频信息 */}
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-gray-400">时长</span>
                              <span>{Math.floor(currentTrack.duration / 60)}:{(currentTrack.duration % 60).toString().padStart(2, '0')}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-gray-400">流派</span>
                              <div className="flex flex-wrap gap-1">
                                {currentTrack.genres.map((genre, index) => (
                                  <span key={index} className="px-2 py-1 bg-gray-700 text-xs rounded">
                                    {genre}
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-gray-400">发布日期</span>
                              <span>{new Date(currentTrack.releaseDate).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                  {showComments && (
                    <CommentSystem 
                      videoId={currentContent.id}
                      comments={[]}
                      totalComments={0}
                    />
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        // 桌面端布局
        <div className="flex h-screen">
          {/* 左侧视频播放器 */}
          <div className={`${isFullscreen ? 'w-full' : 'flex-1'} bg-black`}>
            <MediaPlayer className="unified-controls" />
          </div>
          
          {/* 右侧详情和评论 */}
          {!isFullscreen && (
            <div className="w-96 flex flex-col border-l border-gray-800">
              {/* 切换按钮 */}
              <div className="flex border-b border-gray-800">
                <button
                  onClick={() => {
                    setShowDetails(true);
                    setShowComments(false);
                  }}
                  className={`flex-1 py-3 px-4 text-center transition-colors ${
                    showDetails && !showComments
                      ? 'text-green-500 border-b-2 border-green-500'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  详情
                </button>
                <button
                  onClick={() => {
                    setShowDetails(false);
                    setShowComments(true);
                  }}
                  className={`flex-1 py-3 px-4 text-center transition-colors ${
                    showComments
                      ? 'text-green-500 border-b-2 border-green-500'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <MessageCircle className="w-4 h-4" />
                    <span>评论</span>
                  </div>
                </button>
              </div>
              
              {/* 内容区域 */}
              <div className="flex-1 overflow-y-auto">
                {showDetails && !showComments && (
                  <>
                    {isVideoContent && currentMovie && (
                      <VideoDetails movie={currentMovie} />
                    )}
                    {isAudioContent && currentTrack && (
                      <div className="p-4 space-y-4">
                        {/* 音频详情 */}
                        <div className="text-center">
                          <div className="w-32 h-32 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                            <Music className="w-16 h-16 text-white" />
                          </div>
                          <h2 className="text-xl font-bold mb-2">{currentTrack.title}</h2>
                          <p className="text-gray-400 mb-1">{currentTrack.artist}</p>
                          <p className="text-gray-500 text-sm">{currentTrack.album}</p>
                        </div>
                        
                        {/* 音频信息 */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">时长</span>
                            <span>{Math.floor(currentTrack.duration / 60)}:{(currentTrack.duration % 60).toString().padStart(2, '0')}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">流派</span>
                            <div className="flex flex-wrap gap-1">
                              {currentTrack.genres.map((genre, index) => (
                                <span key={index} className="px-2 py-1 bg-gray-700 text-xs rounded">
                                  {genre}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">发布日期</span>
                            <span>{new Date(currentTrack.releaseDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
                {showComments && (
                  <CommentSystem 
                    videoId={currentContent.id}
                    comments={[]}
                    totalComments={0}
                  />
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}