/**
 * 飞鸽风格即时通讯App - 影音娱乐主页面
 * 提供影视、音乐、游戏三个模块的统一入口和切换功能
 * 优化版本：修复滚动功能，增强响应式设计和跨平台兼容性
 */

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Film, Music, Gamepad2, Search } from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import MovieModule from '../components/MovieModule';
import MusicModule from '../components/MusicModule';
import GameModule from '../components/GameModule';
import MediaPlayer from '../components/MediaPlayer';
import { useMediaStore } from '../store/mediaStore';
import '../styles/scrollbar.css';

/**
 * 媒体模块类型
 */
type MediaModuleType = 'movie' | 'music' | 'game';

/**
 * 标签页配置
 */
const tabs = [
  { id: 'movie' as MediaModuleType, label: '影视', icon: Film },
  { id: 'music' as MediaModuleType, label: '音乐', icon: Music },
  { id: 'game' as MediaModuleType, label: '游戏', icon: Gamepad2 },
];

/**
 * 影音娱乐主页面组件
 */
const Media: React.FC = () => {
  const [activeTab, setActiveTab] = useState<MediaModuleType>('movie');
  const [searchQuery, setSearchQuery] = useState('');
  const isMobile = useIsMobile();
  const location = useLocation();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  const { setActiveModule, searchContent, currentPlaying } = useMediaStore();
  
  // 检查是否在VideoPlayer页面或其他播放页面
  const isVideoPlayerPage = location.pathname.includes('/video/play/') || 
                           location.pathname.includes('/player/') ||
                           location.pathname.includes('/play/') ||
                           location.pathname.includes('/app/video/play/') ||
                           location.pathname.includes('/app/player/') ||
                           location.pathname.includes('/app/play/');

  /**
   * 初始化时设置活跃模块
   */
  useEffect(() => {
    setActiveModule(activeTab);
  }, [activeTab, setActiveModule]);

  /**
   * 处理标签页切换
   */
  const handleTabChange = (tabId: MediaModuleType) => {
    setActiveTab(tabId);
    setSearchQuery(''); // 切换标签时清空搜索
  };

  /**
   * 处理搜索
   */
  const handleSearch = async () => {
    if (searchQuery.trim()) {
      await searchContent(searchQuery, activeTab);
    }
  };

  /**
   * 处理搜索输入
   */
  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  /**
   * 处理回车搜索
   */
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  /**
   * 渲染当前活跃的模块
   */
  const renderActiveModule = () => {
    switch (activeTab) {
      case 'movie':
        return <MovieModule />;
      case 'music':
        return <MusicModule />;
      case 'game':
        return <GameModule />;
      default:
        return <MovieModule />;
    }
  };

  return (
    <PageContainer 
      title="影音娱乐"
      contentClassName="px-0 py-0"
    >
      {/* 主容器 - 修复滚动问题 */}
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 relative">
        {/* 搜索栏 - 固定在顶部 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          sticky top-0 z-10 shadow-sm
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center space-x-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchInput}
                onKeyPress={handleKeyPress}
                placeholder={`搜索${tabs.find(tab => tab.id === activeTab)?.label}...`}
                className={`
                  w-full bg-gray-100 dark:bg-gray-700 rounded-full
                  text-gray-900 dark:text-white placeholder-gray-500
                  border-0 focus:ring-2 focus:ring-green-500 focus:bg-white dark:focus:bg-gray-600
                  transition-all duration-200
                  ${isMobile ? 'px-4 py-3 text-base' : 'px-4 py-2 text-sm'}
                `}
              />
            </div>
            <button
              onClick={handleSearch}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`
                bg-green-500 hover:bg-green-600 text-white rounded-full
                transition-all duration-200 flex items-center justify-center
                ${isMobile 
                  ? 'w-12 h-12 active:bg-green-700' 
                  : 'w-10 h-10 hover:shadow-md'
                }
              `}
            >
              <Search className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
            </button>
          </div>
        </div>

        {/* 标签页导航 - 固定在搜索栏下方 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          sticky top-[${isMobile ? '76px' : '72px'}] z-10 shadow-sm
          ${isMobile ? 'px-4' : 'px-6'}
        `}>
          <div className="flex space-x-0">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    flex-1 flex items-center justify-center space-x-2
                    transition-all duration-200 relative
                    touch-feedback button-touch touch-target
                    ${isMobile ? 'py-4' : 'py-3'}
                    ${isActive 
                      ? 'text-green-600 dark:text-green-400' 
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                    }
                    ${isMobile && 'active:bg-gray-50 dark:active:bg-gray-700'}
                  `}
                >
                  <Icon className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                  <span className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
                    {tab.label}
                  </span>
                  
                  {/* 活跃指示器 */}
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-500 rounded-full" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* 模块内容区域 - 修复滚动功能 */}
        <div className={`
          flex-1 overflow-y-auto overflow-x-hidden
          ${currentPlaying.content ? 'pb-20' : 'pb-4'}
          ${isMobile ? 'px-4' : 'px-6'}
          pt-4
          media-scroll smooth-scroll elastic-scroll
        `}>
          {/* 内容容器 - 确保可以正常滚动 */}
          <div className="min-h-full">
            {renderActiveModule()}
          </div>
        </div>

        {/* 媒体播放器 - 固定在底部，但在VideoPlayer页面时不显示 */}
        {currentPlaying.content && !isVideoPlayerPage && (
          <div className="
            fixed bottom-0 left-0 right-0 z-20
            border-t border-gray-200 dark:border-gray-700
            bg-white dark:bg-gray-800 shadow-lg
          ">
            <MediaPlayer />
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default Media;