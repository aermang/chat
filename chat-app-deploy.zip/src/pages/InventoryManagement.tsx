/**
 * 飞鸽风格即时通讯App - 库存管理主页面
 * 提供产品目录的完整增删改查功能
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Plus, 
  Package, 
  Edit3, 
  Trash2, 
  Eye,
  ShoppingCart,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import { useIsMobile } from '../hooks/useIsMobile';
import { useTouchFeedback } from '../hooks/useTouch';
import { inventoryDB, Product, initInventoryDB } from '../utils/indexedDB';
import PageContainer from '../components/Layout/PageContainer';

/**
 * 产品表单数据类型
 */
interface ProductFormData {
  name: string;
  sku: string;
  category: string;
  price: string;
  stock: string;
  minStock: string;
  description: string;
}

/**
 * 产品卡片组件
 */
interface ProductCardProps {
  product: Product;
  onView: (product: Product) => void;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  isMobile: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onView, 
  onEdit, 
  onDelete, 
  isMobile 
}) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  const isLowStock = product.stock <= product.minStock;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <h3 
              className={`
                font-semibold text-gray-900 dark:text-white cursor-pointer
                hover:text-green-600 dark:hover:text-green-400 transition-colors
                ${isMobile ? 'text-base' : 'text-sm'}
              `}
              onClick={() => onView(product)}
            >
              {product.name}
            </h3>
            {isLowStock && (
              <AlertTriangle className="w-4 h-4 text-orange-500" />
            )}
          </div>
          <p className={`
            text-gray-500 dark:text-gray-400 mb-2
            ${isMobile ? 'text-sm' : 'text-xs'}
          `}>
            SKU: {product.sku} | 分类: {product.category}
          </p>
          <div className="flex items-center space-x-4">
            <span className={`
              font-medium
              ${isLowStock 
                ? 'text-orange-600 dark:text-orange-400' 
                : 'text-green-600 dark:text-green-400'
              }
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}>
              库存: {product.stock}
            </span>
            <span className={`
              text-blue-600 dark:text-blue-400 font-medium
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}>
              ¥{product.price.toFixed(2)}
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <button
            onClick={() => onView(product)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`
              p-2 text-gray-400 rounded-lg transition-colors
              ${isMobile 
                ? 'active:bg-gray-100 dark:active:bg-gray-700' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }
            `}
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => onEdit(product)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`
              p-2 text-gray-400 rounded-lg transition-colors
              ${isMobile 
                ? 'active:bg-gray-100 dark:active:bg-gray-700' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }
            `}
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(product)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`
              p-2 text-red-400 rounded-lg transition-colors
              ${isMobile 
                ? 'active:bg-red-50 dark:active:bg-red-900' 
                : 'hover:bg-red-50 dark:hover:bg-red-900'
              }
            `}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      {product.description && (
        <p className={`
          text-gray-600 dark:text-gray-300 line-clamp-2
          ${isMobile ? 'text-sm' : 'text-xs'}
        `}>
          {product.description}
        </p>
      )}
    </div>
  );
};

/**
 * 产品表单模态框组件
 */
interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: ProductFormData) => void;
  product?: Product;
  isMobile: boolean;
}

const ProductModal: React.FC<ProductModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  product, 
  isMobile 
}) => {
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    sku: '',
    category: '',
    price: '',
    stock: '',
    minStock: '',
    description: ''
  });

  /**
   * 初始化表单数据
   */
  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        sku: product.sku,
        category: product.category,
        price: product.price.toString(),
        stock: product.stock.toString(),
        minStock: product.minStock.toString(),
        description: product.description || ''
      });
    } else {
      setFormData({
        name: '',
        sku: '',
        category: '',
        price: '',
        stock: '',
        minStock: '',
        description: ''
      });
    }
  }, [product, isOpen]);

  /**
   * 处理表单提交
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  /**
   * 处理输入变化
   */
  const handleInputChange = (field: keyof ProductFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className={`
        bg-white dark:bg-gray-800 rounded-2xl shadow-xl
        ${isMobile ? 'w-full max-w-sm' : 'w-full max-w-md'}
        max-h-[90vh] overflow-y-auto
      `}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className={`
              font-semibold text-gray-900 dark:text-white
              ${isMobile ? 'text-lg' : 'text-base'}
            `}>
              {product ? '编辑产品' : '添加产品'}
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg"
            >
              ×
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className={`
                block text-gray-700 dark:text-gray-300 mb-2
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                产品名称 *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className={`
                  w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                  rounded-xl px-4 py-3 text-gray-900 dark:text-white
                  focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                  ${isMobile ? 'text-base' : 'text-sm'}
                `}
                placeholder="请输入产品名称"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={`
                  block text-gray-700 dark:text-gray-300 mb-2
                  ${isMobile ? 'text-sm' : 'text-xs'}
                `}>
                  SKU *
                </label>
                <input
                  type="text"
                  value={formData.sku}
                  onChange={(e) => handleInputChange('sku', e.target.value)}
                  className={`
                    w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                    rounded-xl px-4 py-3 text-gray-900 dark:text-white
                    focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                    ${isMobile ? 'text-base' : 'text-sm'}
                  `}
                  placeholder="SKU编码"
                  required
                />
              </div>
              <div>
                <label className={`
                  block text-gray-700 dark:text-gray-300 mb-2
                  ${isMobile ? 'text-sm' : 'text-xs'}
                `}>
                  分类 *
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => handleInputChange('category', e.target.value)}
                  className={`
                    w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                    rounded-xl px-4 py-3 text-gray-900 dark:text-white
                    focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                    ${isMobile ? 'text-base' : 'text-sm'}
                  `}
                  placeholder="产品分类"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className={`
                  block text-gray-700 dark:text-gray-300 mb-2
                  ${isMobile ? 'text-sm' : 'text-xs'}
                `}>
                  价格 *
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  className={`
                    w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                    rounded-xl px-4 py-3 text-gray-900 dark:text-white
                    focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                    ${isMobile ? 'text-base' : 'text-sm'}
                  `}
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <label className={`
                  block text-gray-700 dark:text-gray-300 mb-2
                  ${isMobile ? 'text-sm' : 'text-xs'}
                `}>
                  库存 *
                </label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => handleInputChange('stock', e.target.value)}
                  className={`
                    w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                    rounded-xl px-4 py-3 text-gray-900 dark:text-white
                    focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                    ${isMobile ? 'text-base' : 'text-sm'}
                  `}
                  placeholder="0"
                  required
                />
              </div>
              <div>
                <label className={`
                  block text-gray-700 dark:text-gray-300 mb-2
                  ${isMobile ? 'text-sm' : 'text-xs'}
                `}>
                  最低库存
                </label>
                <input
                  type="number"
                  value={formData.minStock}
                  onChange={(e) => handleInputChange('minStock', e.target.value)}
                  className={`
                    w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                    rounded-xl px-4 py-3 text-gray-900 dark:text-white
                    focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                    ${isMobile ? 'text-base' : 'text-sm'}
                  `}
                  placeholder="0"
                />
              </div>
            </div>

            <div>
              <label className={`
                block text-gray-700 dark:text-gray-300 mb-2
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                产品描述
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={3}
                className={`
                  w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
                  rounded-xl px-4 py-3 text-gray-900 dark:text-white
                  focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                  resize-none
                  ${isMobile ? 'text-base' : 'text-sm'}
                `}
                placeholder="请输入产品描述（可选）"
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className={`
                  flex-1 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200
                  rounded-xl py-3 px-4 font-medium transition-colors
                  ${isMobile 
                    ? 'text-base active:bg-gray-300 dark:active:bg-gray-500' 
                    : 'text-sm hover:bg-gray-300 dark:hover:bg-gray-500'
                  }
                `}
              >
                取消
              </button>
              <button
                type="submit"
                className={`
                  flex-1 bg-green-500 hover:bg-green-600 text-white
                  rounded-xl py-3 px-4 font-medium transition-colors
                  ${isMobile 
                    ? 'text-base active:bg-green-700' 
                    : 'text-sm hover:shadow-md'
                  }
                `}
              >
                {product ? '更新' : '添加'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

/**
 * 库存管理主页面组件
 */
const InventoryManagement: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | undefined>();

  /**
   * 初始化数据库并加载产品数据
   */
  useEffect(() => {
    const initializeData = async () => {
      try {
        await initInventoryDB();
        const existingProducts = await inventoryDB.getAllProducts();
        
        if (existingProducts.length === 0) {
          // 如果没有数据，添加示例数据
          const sampleProducts: Omit<Product, 'createdAt' | 'updatedAt'>[] = [
            {
              id: '1',
              name: 'iPhone 15 Pro',
              sku: 'IPH15P001',
              category: '电子产品',
              price: 7999,
              stock: 25,
              minStock: 10,
              description: '苹果最新旗舰手机，搭载A17 Pro芯片'
            },
            {
              id: '2',
              name: 'MacBook Air M3',
              sku: 'MBA13M3001',
              category: '电子产品',
              price: 8999,
              stock: 8,
              minStock: 10,
              description: '轻薄便携的笔记本电脑，搭载M3芯片'
            },
            {
              id: '3',
              name: 'AirPods Pro 2',
              sku: 'APP2001',
              category: '配件',
              price: 1899,
              stock: 45,
              minStock: 20,
              description: '主动降噪无线耳机'
            }
          ];
          
          // 添加示例产品到数据库
          for (const product of sampleProducts) {
            await inventoryDB.addProduct(product);
          }
          
          // 重新加载产品列表
          const newProducts = await inventoryDB.getAllProducts();
          setProducts(newProducts);
        } else {
          setProducts(existingProducts);
        }
      } catch (error) {
        console.error('Failed to initialize inventory data:', error);
      }
    };

    initializeData();
  }, []);

  /**
   * 处理返回
   */
  const handleGoBack = () => {
    navigate('/app/work-management');
  };

  /**
   * 处理查看产品详情
   */
  const handleViewProduct = (product: Product) => {
    navigate(`/app/product-inventory/${product.id}`, { state: { product } });
  };

  /**
   * 处理编辑产品
   */
  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };

  /**
   * 处理删除产品
   */
  const handleDeleteProduct = async (product: Product) => {
    if (window.confirm(`确定要删除产品 "${product.name}" 吗？`)) {
      try {
        await inventoryDB.deleteProduct(product.id);
        setProducts(prev => prev.filter(p => p.id !== product.id));
      } catch (error) {
        console.error('Failed to delete product:', error);
        alert('删除产品失败，请重试');
      }
    }
  };

  /**
   * 处理添加新产品
   */
  const handleAddProduct = () => {
    setEditingProduct(undefined);
    setIsModalOpen(true);
  };

  /**
   * 处理保存产品
   */
  const handleSaveProduct = async (formData: ProductFormData) => {
    try {
      if (editingProduct) {
        // 更新现有产品
        const updatedProduct = await inventoryDB.updateProduct(editingProduct.id, {
          name: formData.name,
          sku: formData.sku,
          category: formData.category,
          price: parseFloat(formData.price),
          stock: parseInt(formData.stock),
          minStock: parseInt(formData.minStock || '0'),
          description: formData.description
        });
        
        setProducts(prev => prev.map(p => 
          p.id === editingProduct.id ? updatedProduct : p
        ));
      } else {
        // 添加新产品
        const newProductData = {
          id: Date.now().toString(),
          name: formData.name,
          sku: formData.sku,
          category: formData.category,
          price: parseFloat(formData.price),
          stock: parseInt(formData.stock),
          minStock: parseInt(formData.minStock || '0'),
          description: formData.description
        };
        
        const newProduct = await inventoryDB.addProduct(newProductData);
        setProducts(prev => [...prev, newProduct]);
      }
      
      setIsModalOpen(false);
      setEditingProduct(undefined);
    } catch (error) {
      console.error('Failed to save product:', error);
      alert('保存产品失败，请重试');
    }
  };

  /**
   * 过滤产品列表
   */
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  /**
   * 获取所有分类
   */
  const categories = Array.from(new Set(products.map(p => p.category)));

  /**
   * 计算统计数据
   */
  const totalProducts = products.length;
  const lowStockProducts = products.filter(p => p.stock <= p.minStock).length;
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);

  return (
    <PageContainer
      title="库存管理"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 统计概览 */}
        <div className="bg-white dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Package className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {totalProducts}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                总产品数
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {lowStockProducts}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                低库存
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                ¥{totalValue.toLocaleString()}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                库存价值
              </p>
            </div>
          </div>
        </div>

        {/* 搜索和操作栏 */}
        <div className="bg-white dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex space-x-3 mb-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="搜索产品名称或SKU..."
                className={`
                  w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 
                  rounded-xl pl-10 pr-4 py-3 text-gray-900 dark:text-white
                  focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                  ${isMobile ? 'text-base' : 'text-sm'}
                `}
              />
            </div>
            <button
              onClick={handleAddProduct}
              className={`
                bg-green-500 hover:bg-green-600 text-white rounded-xl px-4 py-3
                flex items-center space-x-2 font-medium transition-colors
                ${isMobile 
                  ? 'text-base active:bg-green-700' 
                  : 'text-sm hover:shadow-md'
                }
              `}
            >
              <Plus className="w-4 h-4" />
              <span>添加</span>
            </button>
          </div>

          {/* 分类筛选 */}
          {categories.length > 0 && (
            <div className="flex space-x-2 overflow-x-auto">
              <button
                onClick={() => setSelectedCategory('')}
                className={`
                  px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors
                  ${!selectedCategory
                    ? 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                  }
                `}
              >
                全部
              </button>
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`
                    px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors
                    ${selectedCategory === category
                      ? 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                    }
                  `}
                >
                  {category}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 产品列表 */}
        <div className={`
          flex-1 overflow-y-auto
          ${isMobile ? 'px-4 py-4' : 'px-4 py-4'}
        `}>
          {filteredProducts.length > 0 ? (
            <div className="space-y-3">
              {filteredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onView={handleViewProduct}
                  onEdit={handleEditProduct}
                  onDelete={handleDeleteProduct}
                  isMobile={isMobile}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className={`
                font-medium text-gray-900 dark:text-white mb-2
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {searchTerm || selectedCategory ? '未找到匹配的产品' : '暂无产品'}
              </h3>
              <p className={`
                text-gray-500 dark:text-gray-400 mb-4
                ${isMobile ? 'text-base' : 'text-sm'}
              `}>
                {searchTerm || selectedCategory 
                  ? '请尝试调整搜索条件或筛选器' 
                  : '点击添加按钮创建您的第一个产品'
                }
              </p>
              {!searchTerm && !selectedCategory && (
                <button
                  onClick={handleAddProduct}
                  className={`
                    bg-green-500 hover:bg-green-600 text-white rounded-xl px-6 py-3
                    font-medium transition-colors
                    ${isMobile 
                      ? 'text-base active:bg-green-700' 
                      : 'text-sm hover:shadow-md'
                    }
                  `}
                >
                  添加产品
                </button>
              )}
            </div>
          )}
        </div>

        {/* 产品表单模态框 */}
        <ProductModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setEditingProduct(undefined);
          }}
          onSave={handleSaveProduct}
          product={editingProduct}
          isMobile={isMobile}
        />
      </div>
    </PageContainer>
  );
};

export default InventoryManagement;