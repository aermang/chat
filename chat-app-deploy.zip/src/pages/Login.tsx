import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, User, Lock } from 'lucide-react';
import { useAppStore } from '../store';
import { useIsMobile, useSafeArea, useTouchFeedback } from '../hooks';

/**
 * 登录表单数据接口
 */
interface LoginFormData {
  username: string;
  password: string;
}

/**
 * 验证用户名格式
 * @param username 用户名
 * @returns 是否有效
 */
const validateUsername = (username: string): boolean => {
  // 用户名规则：2-20个字符，支持字母、数字、下划线
  const usernameRegex = /^[a-zA-Z0-9_]{2,20}$/;
  return usernameRegex.test(username);
};

/**
 * 登录页面组件
 */
const Login: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, login } = useAppStore();
  const isMobile = useIsMobile();
  const safeArea = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 表单数据状态
  const [formData, setFormData] = useState<LoginFormData>({
    username: '',
    password: ''
  });
  
  // 本地状态管理
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  /**
   * 如果用户已登录，重定向到聊天页面
   */
  useEffect(() => {
    if (currentUser) {
      navigate('/app/chats');
    }
  }, [currentUser, navigate]);

  /**
   * 处理表单提交
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 表单验证
    if (!formData.username.trim()) {
      setError('请输入用户名');
      return;
    }
    
    if (!validateUsername(formData.username)) {
      setError('用户名格式不正确');
      return;
    }
    
    if (!formData.password.trim()) {
      setError('请输入密码');
      return;
    }
    
    if (formData.password.length < 6) {
      setError('密码长度不能少于6位');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      await login(formData.username, formData.password);
      // 登录成功后会自动跳转（通过useEffect监听currentUser变化）
    } catch (err) {
      setError(err instanceof Error ? err.message : '登录失败，请重试');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * 处理输入变化
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 清除错误信息
    if (error) {
      setError(null);
    }
  };

  return (
    <div 
      className={`min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center ${
        isMobile ? 'p-4 mobile-layout' : 'p-8'
      }`}
      style={{
        paddingTop: isMobile ? `${safeArea.top + 16}px` : undefined,
        paddingBottom: isMobile ? `${safeArea.bottom + 16}px` : undefined,
      }}
    >
      <div className={`w-full space-y-8 ${
        isMobile ? 'max-w-sm' : 'max-w-md'
      }`}>
        {/* Logo和标题 */}
        <div className="text-center">
          <div className={`mx-auto bg-green-500 rounded-xl flex items-center justify-center ${
            isMobile ? 'h-16 w-16' : 'h-12 w-12'
          }`}>
            <User className={`text-white ${isMobile ? 'h-8 w-8' : 'h-6 w-6'}`} />
          </div>
          <h2 className={`mt-6 font-bold text-gray-900 dark:text-white ${
            isMobile ? 'text-2xl' : 'text-3xl'
          }`}>
            欢迎回来
          </h2>
          <p className={`mt-2 text-gray-600 dark:text-gray-400 ${
            isMobile ? 'text-sm' : 'text-sm'
          }`}>
            登录您的账户继续使用
          </p>
        </div>

        {/* 登录表单 */}
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className={`space-y-4 ${isMobile ? 'space-y-5' : ''}`}>
            {/* 用户名输入 */}
            <div>
              <label 
                htmlFor="username" 
                className={`block font-medium text-gray-700 dark:text-gray-300 mb-2 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}
              >
                用户名
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className={`block w-full border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 transition-colors ${
                    isMobile 
                      ? 'pl-12 pr-4 py-4 text-base touch-optimized' 
                      : 'pl-10 pr-3 py-3 text-sm'
                  }`}
                  placeholder="请输入用户名"
                />
              </div>
            </div>

            {/* 密码输入 */}
            <div>
              <label 
                htmlFor="password" 
                className={`block font-medium text-gray-700 dark:text-gray-300 mb-2 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}
              >
                密码
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`block w-full border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 transition-colors ${
                    isMobile 
                      ? 'pl-12 pr-12 py-4 text-base touch-optimized' 
                      : 'pl-10 pr-10 py-3 text-sm'
                  }`}
                  placeholder="请输入密码"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`absolute inset-y-0 right-0 flex items-center transition-colors ${
                    isMobile ? 'pr-4 touch-optimized' : 'pr-3'
                  }`}
                >
                  {showPassword ? (
                    <EyeOff className={`text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  ) : (
                    <Eye className={`text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* 错误信息 */}
          {error && (
            <div className={`bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg ${
              isMobile ? 'p-4' : 'p-3'
            }`}>
              <p className={`text-red-600 dark:text-red-400 ${
                isMobile ? 'text-base' : 'text-sm'
              }`}>{error}</p>
            </div>
          )}

          {/* 登录按钮 */}
          <button
            type="submit"
            disabled={isLoading}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`group relative w-full flex justify-center border border-transparent font-medium rounded-lg text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${
              isMobile 
                ? 'py-4 px-6 text-base touch-optimized mobile-shadow' 
                : 'py-3 px-4 text-sm'
            }`}

          >
            {isLoading ? '登录中...' : '登录'}
          </button>

          {/* 注册链接 */}
          <div className="text-center">
            <p className={`text-gray-600 dark:text-gray-400 ${
              isMobile ? 'text-base' : 'text-sm'
            }`}>
              还没有账户？{' '}
              <Link
                to="/register"
                className={`font-medium text-green-600 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300 transition-colors ${
                  isMobile ? 'touch-optimized' : ''
                }`}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
              >
                立即注册
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;