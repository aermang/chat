/**
 * 飞鸽风格即时通讯App - 发现页面
 * 提供工作管理、朋友圈、影音娱乐等功能入口
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  Users, 
  Camera, 
  Play, 
  Settings,
  ChevronRight
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';

/**
 * 功能卡片组件
 */
interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  onClick: () => void;
  isMobile: boolean;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  icon, 
  title, 
  subtitle, 
  onClick, 
  isMobile 
}) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  return (
    <button
      onClick={onClick}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className={`
        w-full bg-white dark:bg-gray-800 rounded-2xl p-6 
        flex items-center justify-between
        transition-all duration-200 shadow-sm
        ${isMobile 
          ? 'active:bg-gray-50 dark:active:bg-gray-700 touch-optimized min-h-touch' 
          : 'hover:bg-gray-50 dark:hover:bg-gray-700 hover:shadow-md'
        }
      `}
    >
      <div className="flex items-center space-x-4">
        <div className={`
          bg-green-100 dark:bg-green-900 rounded-xl p-3
          ${isMobile ? 'w-14 h-14' : 'w-12 h-12'}
          flex items-center justify-center
        `}>
          <div className="text-green-600 dark:text-green-400">
            {icon}
          </div>
        </div>
        <div className="text-left">
          <h3 className={`
            font-semibold text-gray-900 dark:text-white
            ${isMobile ? 'text-lg' : 'text-base'}
          `}>
            {title}
          </h3>
          <p className={`
            text-gray-500 dark:text-gray-400
            ${isMobile ? 'text-base' : 'text-sm'}
          `}>
            {subtitle}
          </p>
        </div>
      </div>
      <ChevronRight className={`
        text-gray-400
        ${isMobile ? 'w-6 h-6' : 'w-5 h-5'}
      `} />
    </button>
  );
};

/**
 * 发现页面组件
 */
const Discover: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  /**
   * 处理功能导航
   */
  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <PageContainer 
      title="发现"
      contentClassName="px-0 py-0 bg-gray-50 dark:bg-gray-900"
    >
      {/* 功能列表 */}
      <div className={`
        flex-1 overflow-y-auto
        ${isMobile ? 'px-4 py-4' : 'px-4 py-4'}
      `}>
        <div className="space-y-4 max-w-md mx-auto">
          {/* 工作管理 */}
          <FeatureCard
            icon={<Briefcase className={isMobile ? 'w-7 h-7' : 'w-6 h-6'} />}
            title="工作管理"
            subtitle="进销存管理系统"
            onClick={() => handleNavigation('/app/work-management')}
            isMobile={isMobile}
          />

          {/* 朋友圈 */}
          <FeatureCard
            icon={<Camera className={isMobile ? 'w-7 h-7' : 'w-6 h-6'} />}
            title="朋友圈"
            subtitle="分享生活动态"
            onClick={() => handleNavigation('/app/moments')}
            isMobile={isMobile}
          />

          {/* 影音娱乐 - 替换原来的扫一扫模块 */}
          <FeatureCard
            icon={<Play className={isMobile ? 'w-7 h-7' : 'w-6 h-6'} />}
            title="影音娱乐"
            subtitle="电影、音乐、游戏"
            onClick={() => handleNavigation('/app/media')}
            isMobile={isMobile}
          />

          {/* 群聊管理 */}
          <FeatureCard
            icon={<Users className={isMobile ? 'w-7 h-7' : 'w-6 h-6'} />}
            title="群聊管理"
            subtitle="管理群聊设置"
            onClick={() => {
              // TODO: 实现群聊管理功能
              console.log('群聊管理功能');
            }}
            isMobile={isMobile}
          />

          {/* 设置 */}
          <FeatureCard
            icon={<Settings className={isMobile ? 'w-7 h-7' : 'w-6 h-6'} />}
            title="设置"
            subtitle="应用设置和偏好"
            onClick={() => {
              // TODO: 实现设置功能
              console.log('设置功能');
            }}
            isMobile={isMobile}
          />
        </div>
      </div>
    </PageContainer>
  );
};

export default Discover;