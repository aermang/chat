/**
 * 特药管理系统 - 用药提醒表单页面
 * 提供创建和编辑用药提醒的表单界面
 * 支持精确的时间、剂量、频次设置和提醒执行跟踪
 */

import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Clock, Calendar, Pill, Bell, Save, AlertCircle, Plus, Trash2 } from 'lucide-react';
// 修复：统一使用正确的状态管理系统，确保提醒表单与患者数据同步
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { useIsMobile, useTouchFeedback } from '../hooks';
import { MedicationReminder, Patient, MedicationRecord } from '../types';
import { toast } from 'sonner';

/**
 * 提醒频次选项
 */
const FREQUENCY_OPTIONS = [
  { value: 'daily', label: '每日', description: '每天固定时间' },
  { value: 'weekly', label: '每周', description: '每周固定日期' },
  { value: 'monthly', label: '每月', description: '每月固定日期' },
  { value: 'custom', label: '自定义', description: '自定义间隔' }
];

/**
 * 星期选项
 */
const WEEKDAY_OPTIONS = [
  { value: 1, label: '周一' },
  { value: 2, label: '周二' },
  { value: 3, label: '周三' },
  { value: 4, label: '周四' },
  { value: 5, label: '周五' },
  { value: 6, label: '周六' },
  { value: 0, label: '周日' }
];

/**
 * 用药提醒表单数据接口
 */
interface ReminderFormData {
  patientId: string;
  medicineName: string;
  dosage: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'custom';
  reminderTimes: string[];
  reminderDays: number[];
  weekdays: number[];
  monthDay: number;
  customInterval: number;
  customUnit: 'hours' | 'days';
  startDate: string;
  endDate: string;
  notes: string;
  isActive: boolean;
}

/**
 * 用药提醒表单页面组件
 */
const ReminderForm: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  // 获取URL参数
  const patientId = searchParams.get('patientId');
  const reminderId = searchParams.get('id');
  const isEdit = !!reminderId;

  // Store状态
  const {
    patients,
    medicationRecords,
    reminders,
    isLoading: loading,
    error,
    loadPatients,
    loadMedicationRecords,
    loadReminders,
    createMedicationReminder,
    updateMedicationReminder,
    clearError
  } = useSpecialMedicineStore();

  // 表单状态
  const [formData, setFormData] = useState<ReminderFormData>({
    patientId: patientId || '',
    medicineName: '',
    dosage: '',
    frequency: 'daily',
    reminderTimes: ['08:00'],
    reminderDays: [],
    weekdays: [1, 2, 3, 4, 5],
    monthDay: 1,
    customInterval: 1,
    customUnit: 'days',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    notes: '',
    isActive: true
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  /**
   * 初始化数据
   */
  useEffect(() => {
    const initializeData = async () => {
      try {
        await Promise.all([
          loadPatients(),
          loadMedicationRecords(),
          loadReminders()
        ]);
      } catch (error) {
        console.error('Failed to load data:', error);
        toast.error('数据加载失败');
      }
    };

    initializeData();
  }, [loadPatients, loadMedicationRecords, loadReminders]);

  /**
   * 编辑模式下加载提醒数据
   */
  useEffect(() => {
    if (isEdit && reminderId && reminders.length > 0) {
      const reminder = reminders.find(r => r.id === reminderId);
      if (reminder) {
        setFormData({
          patientId: reminder.patientId,
          medicineName: reminder.medicineName,
          dosage: reminder.dosage,
          frequency: reminder.frequency,
          reminderTimes: reminder.reminderTimes,
          reminderDays: reminder.reminderDays || [],
          weekdays: reminder.weekdays || [1, 2, 3, 4, 5],
          monthDay: reminder.monthDay || 1,
          customInterval: reminder.customInterval || 1,
          customUnit: reminder.customUnit || 'days',
          startDate: typeof reminder.startDate === 'string' ? reminder.startDate : reminder.startDate?.toISOString().split('T')[0] || '',
          endDate: typeof reminder.endDate === 'string' ? reminder.endDate : reminder.endDate?.toISOString().split('T')[0] || '',
          notes: reminder.notes || '',
          isActive: reminder.isActive
        });
      }
    }
  }, [isEdit, reminderId, reminders]);

  /**
   * 获取患者的用药记录
   */
  const getPatientMedications = (patientId: string): MedicationRecord[] => {
    return medicationRecords.filter(record => record.patientId === patientId);
  };

  /**
   * 表单验证
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.patientId) {
      newErrors.patientId = '请选择患者';
    }

    if (!formData.medicineName.trim()) {
      newErrors.medicineName = '请输入药品名称';
    }

    if (!formData.dosage.trim()) {
      newErrors.dosage = '请输入用药剂量';
    }

    if (formData.reminderTimes.length === 0) {
      newErrors.reminderTimes = '请至少设置一个提醒时间';
    }

    if (!formData.startDate) {
      newErrors.startDate = '请选择开始日期';
    }

    if (formData.endDate && formData.endDate <= formData.startDate) {
      newErrors.endDate = '结束日期必须晚于开始日期';
    }

    if (formData.frequency === 'weekly' && formData.weekdays.length === 0) {
      newErrors.weekdays = '请选择至少一个星期';
    }

    if (formData.frequency === 'custom' && formData.customInterval <= 0) {
      newErrors.customInterval = '自定义间隔必须大于0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * 添加提醒时间
   */
  const addReminderTime = () => {
    setFormData(prev => ({
      ...prev,
      reminderTimes: [...prev.reminderTimes, '12:00']
    }));
  };

  /**
   * 删除提醒时间
   */
  const removeReminderTime = (index: number) => {
    if (formData.reminderTimes.length > 1) {
      setFormData(prev => ({
        ...prev,
        reminderTimes: prev.reminderTimes.filter((_, i) => i !== index)
      }));
    }
  };

  /**
   * 更新提醒时间
   */
  const updateReminderTime = (index: number, time: string) => {
    setFormData(prev => ({
      ...prev,
      reminderTimes: prev.reminderTimes.map((t, i) => i === index ? time : t)
    }));
  };

  /**
   * 切换星期选择
   */
  const toggleWeekday = (weekday: number) => {
    setFormData(prev => ({
      ...prev,
      weekdays: prev.weekdays.includes(weekday)
        ? prev.weekdays.filter(w => w !== weekday)
        : [...prev.weekdays, weekday].sort()
    }));
  };

  /**
   * 提交表单
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('请检查表单信息');
      return;
    }

    setIsSubmitting(true);
    clearError();

    try {
      const reminderData: Omit<MedicationReminder, 'id' | 'createdAt' | 'updatedAt'> = {
        patientId: formData.patientId,
        medicineName: formData.medicineName.trim(),
        dosage: formData.dosage.trim(),
        frequency: formData.frequency,
        reminderTime: formData.reminderTimes[0] || '08:00', // 使用第一个提醒时间作为主要提醒时间
        reminderTimes: formData.reminderTimes,
        reminderDays: formData.reminderDays,
        weekdays: formData.frequency === 'weekly' ? formData.weekdays : undefined,
        monthDay: formData.frequency === 'monthly' ? formData.monthDay : undefined,
        customInterval: formData.frequency === 'custom' ? formData.customInterval : undefined,
        customUnit: formData.frequency === 'custom' ? formData.customUnit : undefined,
        startDate: formData.startDate,
        endDate: formData.endDate || undefined,
        notes: formData.notes.trim() || undefined,
        isActive: formData.isActive,
        lastReminded: undefined,
        nextReminder: new Date(calculateNextTrigger())
      };

      if (isEdit && reminderId) {
        await updateMedicationReminder(reminderId, reminderData);
        toast.success('用药提醒更新成功');
      } else {
        await createMedicationReminder(reminderData);
        toast.success('用药提醒创建成功');
      }

      navigate('/app/special-medicine/reminders');
    } catch (error) {
      console.error('Failed to save reminder:', error);
      toast.error(isEdit ? '更新提醒失败' : '创建提醒失败');
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * 计算下次提醒时间
   */
  const calculateNextTrigger = (): string => {
    const now = new Date();
    const startDate = new Date(formData.startDate);
    const baseDate = startDate > now ? startDate : now;
    
    // 获取今天的第一个提醒时间
    const firstTime = formData.reminderTimes[0];
    const [hours, minutes] = firstTime.split(':').map(Number);
    
    const nextTrigger = new Date(baseDate);
    nextTrigger.setHours(hours, minutes, 0, 0);
    
    // 如果是今天且时间已过，则设置为明天
    if (nextTrigger <= now) {
      nextTrigger.setDate(nextTrigger.getDate() + 1);
    }
    
    return nextTrigger.toISOString();
  };

  /**
   * 返回上一页
   */
  const handleGoBack = () => {
    navigate(-1);
  };

  // 获取选中的患者信息
  const selectedPatient = patients.find(p => p.id === formData.patientId);
  const patientMedications = selectedPatient ? getPatientMedications(selectedPatient.id) : [];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 头部导航 */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={handleGoBack}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className="flex items-center space-x-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>返回</span>
          </button>
          <h1 className="text-lg font-semibold text-gray-900 dark:text-white">
            {isEdit ? '编辑用药提醒' : '新建用药提醒'}
          </h1>
          <div className="w-16" />
        </div>
      </div>

      {/* 表单内容 */}
      <div className="p-4 max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 患者选择 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              选择患者 *
            </label>
            <select
              value={formData.patientId}
              onChange={(e) => setFormData(prev => ({ ...prev, patientId: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
              disabled={!!patientId}
            >
              <option value="">请选择患者</option>
              {patients.map(patient => (
                <option key={patient.id} value={patient.id}>
                  {patient.name} - {patient.phone}
                </option>
              ))}
            </select>
            {errors.patientId && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                <AlertCircle className="w-4 h-4 mr-1" />
                {errors.patientId}
              </p>
            )}
          </div>

          {/* 药品信息 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
              <Pill className="w-5 h-5 mr-2 text-green-500" />
              药品信息
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  药品名称 *
                </label>
                <input
                  type="text"
                  value={formData.medicineName}
                  onChange={(e) => setFormData(prev => ({ ...prev, medicineName: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                  placeholder="请输入药品名称"
                  list="medication-suggestions"
                />
                <datalist id="medication-suggestions">
                  {patientMedications.map(med => (
                    <option key={med.id} value={med.medicineName} />
                  ))}
                </datalist>
                {errors.medicineName && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {errors.medicineName}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  用药剂量 *
                </label>
                <input
                  type="text"
                  value={formData.dosage}
                  onChange={(e) => setFormData(prev => ({ ...prev, dosage: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                  placeholder="例如：1片、5ml、2粒"
                />
                {errors.dosage && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {errors.dosage}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* 提醒设置 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
              <Bell className="w-5 h-5 mr-2 text-green-500" />
              提醒设置
            </h3>

            <div className="space-y-4">
              {/* 提醒频次 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  提醒频次
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {FREQUENCY_OPTIONS.map(option => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, frequency: option.value as any }))}
                      className={`p-3 rounded-lg border text-left transition-colors ${
                        formData.frequency === option.value
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300'
                          : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
                      }`}
                    >
                      <div className="font-medium text-gray-900 dark:text-white">{option.label}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{option.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 星期选择（仅周频次显示） */}
              {formData.frequency === 'weekly' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    选择星期 *
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {WEEKDAY_OPTIONS.map(option => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => toggleWeekday(option.value)}
                        className={`px-3 py-2 rounded-md text-sm transition-colors ${
                          formData.weekdays.includes(option.value)
                            ? 'bg-green-500 text-white'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                  {errors.weekdays && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                      <AlertCircle className="w-4 h-4 mr-1" />
                      {errors.weekdays}
                    </p>
                  )}
                </div>
              )}

              {/* 月日期选择（仅月频次显示） */}
              {formData.frequency === 'monthly' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    每月日期
                  </label>
                  <select
                    value={formData.monthDay}
                    onChange={(e) => setFormData(prev => ({ ...prev, monthDay: parseInt(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                  >
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                      <option key={day} value={day}>每月{day}日</option>
                    ))}
                  </select>
                </div>
              )}

              {/* 自定义间隔（仅自定义频次显示） */}
              {formData.frequency === 'custom' && (
                <div className="flex space-x-2">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      间隔数量 *
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={formData.customInterval}
                      onChange={(e) => setFormData(prev => ({ ...prev, customInterval: parseInt(e.target.value) || 1 }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                    />
                    {errors.customInterval && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.customInterval}
                      </p>
                    )}
                  </div>
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      间隔单位
                    </label>
                    <select
                      value={formData.customUnit}
                      onChange={(e) => setFormData(prev => ({ ...prev, customUnit: e.target.value as 'hours' | 'days' }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="hours">小时</option>
                      <option value="days">天</option>
                    </select>
                  </div>
                </div>
              )}

              {/* 提醒时间 */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    提醒时间 *
                  </label>
                  <button
                    type="button"
                    onClick={addReminderTime}
                    className="flex items-center space-x-1 text-sm text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300"
                  >
                    <Plus className="w-4 h-4" />
                    <span>添加时间</span>
                  </button>
                </div>
                <div className="space-y-2">
                  {formData.reminderTimes.map((time, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <input
                        type="time"
                        value={time}
                        onChange={(e) => updateReminderTime(index, e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                      />
                      {formData.reminderTimes.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeReminderTime(index)}
                          className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {errors.reminderTimes && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {errors.reminderTimes}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* 日期设置 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-green-500" />
              日期设置
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  开始日期 *
                </label>
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                />
                {errors.startDate && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {errors.startDate}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  结束日期（可选）
                </label>
                <input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white"
                />
                {errors.endDate && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {errors.endDate}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* 备注和状态 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  备注信息
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white resize-none"
                  placeholder="请输入备注信息（可选）"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                  className="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-500 dark:focus:ring-green-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
                <label htmlFor="isActive" className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                  启用提醒
                </label>
              </div>
            </div>
          </div>

          {/* 错误提示 */}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <div className="flex items-center">
                <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                <span className="text-red-700 dark:text-red-300">{error}</span>
              </div>
            </div>
          )}

          {/* 提交按钮 */}
          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={handleGoBack}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isSubmitting || loading}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`flex-1 px-4 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center space-x-2 ${
                isSubmitting || loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>保存中...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{isEdit ? '更新提醒' : '创建提醒'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReminderForm;