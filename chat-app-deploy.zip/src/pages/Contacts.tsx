/**
 * 飞鸽风格即时通讯App - 通讯录页面
 * 显示用户的好友列表和联系人管理功能
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, UserPlus, Users, Settings, Shield, UserX, Download, Upload } from 'lucide-react';
import { useAppStore } from '../store';
import { Friendship } from '../types';
import { getInitials, getAvatarColor } from '../utils';
import NotificationBadge from '../components/common/NotificationBadge';
import PageContainer from '../components/Layout/PageContainer';
import SettingsMenu from '../components/SettingsMenu';
import { useIsMobile } from '../hooks/useResponsive';
import { useSafeArea } from '../hooks/useSafeArea';
import { useTouchFeedback } from '../hooks/useTouch';

/**
 * 功能菜单项组件
 */
interface MenuItemProps {
  item: {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    onClick: () => void;
    badge?: number;
  };
  isLast: boolean;
  isMobile: boolean;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, isLast, isMobile }) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  const Icon = item.icon;

  return (
    <div>
      <button
        onClick={item.onClick}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className={`w-full flex items-center transition-colors relative ${
          isMobile 
            ? 'p-4 active:bg-gray-100 dark:active:bg-gray-700 touch-optimized' 
            : 'p-4 hover:bg-gray-50 dark:hover:bg-gray-800'
        }`}
      >
        <div className={`${isMobile ? 'w-12 h-12' : 'w-10 h-10'} rounded-lg ${item.color} flex items-center justify-center relative`}>
          <Icon className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'} text-white`} />
          {/* 好友申请徽章 */}
          {item.badge && item.badge > 0 && (
            <NotificationBadge 
              count={item.badge}
              position="top-right"
              className="absolute -top-1 -right-1"
            />
          )}
        </div>
        <span className={`ml-3 text-gray-900 dark:text-white ${
          isMobile ? 'text-lg' : 'text-base'
        }`}>
          {item.label}
        </span>
      </button>
      {!isLast && (
        <div className={`border-b border-gray-200 dark:border-gray-700 ${
          isMobile ? 'ml-20' : 'ml-16'
        }`}></div>
      )}
    </div>
  );
};

/**
 * 好友列表项组件
 */
interface FriendItemProps {
  friend: Friendship;
  onClick: (friendId: string) => void;
  isMobile: boolean;
}

const FriendItem: React.FC<FriendItemProps> = ({ friend, onClick, isMobile }) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  return (
    <div
      onClick={() => onClick(friend.id)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className={`flex items-center cursor-pointer transition-colors ${
        isMobile 
          ? 'p-4 active:bg-gray-100 dark:active:bg-gray-700 touch-optimized' 
          : 'p-4 hover:bg-gray-50 dark:hover:bg-gray-800'
      }`}
    >
      {/* 头像 */}
      <div className="flex-shrink-0">
        {friend.avatar ? (
          <img
            src={friend.avatar}
            alt={friend.username}
            className={`rounded-lg object-cover ${
              isMobile ? 'w-14 h-14' : 'w-12 h-12'
            }`}
          />
        ) : (
          <div
            className={`rounded-lg flex items-center justify-center text-white font-medium ${
              isMobile ? 'w-14 h-14 text-lg' : 'w-12 h-12 text-base'
            }`}
            style={{ backgroundColor: getAvatarColor(friend.username) }}
          >
            {getInitials(friend.username)}
          </div>
        )}
      </div>
      
      {/* 好友信息 */}
      <div className="flex-1 ml-3 min-w-0">
        <h3 className={`font-medium text-gray-900 dark:text-white truncate ${
          isMobile ? 'text-lg' : 'text-base'
        }`}>
          {friend.username}
        </h3>
        {friend.bio && (
          <p className={`text-gray-600 dark:text-gray-400 truncate mt-1 ${
            isMobile ? 'text-base' : 'text-sm'
          }`}>
            {friend.bio}
          </p>
        )}
      </div>
    </div>
  );
};

/**
 * 通讯录页面组件
 */
const Contacts: React.FC = () => {
  const navigate = useNavigate();
  const { 
    friends, 
    loadFriends, 
    friendRequests,
    loadFriendRequests 
  } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  
  // 移动端优化Hooks
  const isMobile = useIsMobile();
  const { top: safeAreaTop } = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  /**
   * 加载好友列表和好友申请
   */
  useEffect(() => {
    loadFriends();
    loadFriendRequests();
  }, [loadFriends, loadFriendRequests]);
  
  /**
   * 过滤好友列表
   */
  const filteredFriends = friends.filter(friend =>
    friend.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    friend.email.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  /**
   * 处理好友点击
   */
  const handleFriendClick = (friendId: string) => {
    navigate(`/app/chat/${friendId}`);
  };

  /**
   * 处理添加好友按钮点击
   */
  const handleAddFriendClick = () => {
    navigate('/app/add-friend');
  };

  /**
   * 处理新的朋友点击
   */
  const handleNewFriendsClick = () => {
    navigate('/app/friend-requests');
  };

  /**
   * 处理设置按钮点击
   */
  const handleSettingsClick = () => {
    setShowSettingsMenu(true);
  };

  /**
   * 处理设置菜单操作
   */
  const handleSettingsAction = (action: string) => {
    switch (action) {
      case 'friend-management':
        // TODO: 实现好友管理功能
        console.log('好友管理');
        break;
      case 'privacy-settings':
        // TODO: 实现隐私设置功能
        console.log('隐私设置');
        break;
      case 'blacklist':
        // TODO: 实现黑名单管理功能
        console.log('黑名单管理');
        break;
      case 'backup':
        // TODO: 实现通讯录备份功能
        console.log('通讯录备份');
        break;
      case 'restore':
        // TODO: 实现通讯录恢复功能
        console.log('通讯录恢复');
        break;
      default:
        console.log('未知操作:', action);
    }
  };
  
  /**
   * 功能菜单项
   */
  const menuItems = [
    {
      id: 'new-friends',
      label: '新的朋友',
      icon: UserPlus,
      color: 'bg-orange-500',
      onClick: handleNewFriendsClick,
      badge: friendRequests.length
    },
    {
      id: 'group-chats',
      label: '群聊',
      icon: Users,
      color: 'bg-green-500',
      onClick: () => {
        // TODO: 实现群聊功能
        console.log('群聊');
      }
    }
  ];
  
  return (
    <>
      <PageContainer
        title="通讯录"
        headerActions={
          <button 
            onClick={handleSettingsClick}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`text-gray-600 dark:text-gray-400 transition-colors ${
              isMobile 
                ? 'p-3 active:text-gray-900 dark:active:text-white touch-optimized' 
                : 'p-2 hover:text-gray-900 dark:hover:text-white'
            }`}
            aria-label="设置"
          >
            <Settings className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />
          </button>
        }
        contentClassName="px-0 py-0"
      >
        {/* 搜索栏 */}
        <div className={`bg-gray-50 dark:bg-gray-800 ${
          isMobile ? 'px-4 py-4' : 'px-4 py-3'
        }`}>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`block w-full border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 ${
                isMobile 
                  ? 'pl-12 pr-4 py-3 text-lg mobile-border-radius' 
                  : 'pl-10 pr-3 py-2 text-base'
              }`}
              placeholder="搜索联系人"
            />
          </div>
        </div>
        
        {/* 内容区域 */}
        <div className={`flex-1 overflow-y-auto ${
          isMobile ? 'scroll-smooth-mobile' : ''
        }`}>
          {/* 功能菜单 */}
          <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
            {menuItems.map((item, index) => (
              <MenuItem
                key={item.id}
                item={item}
                isLast={index === menuItems.length - 1}
                isMobile={isMobile}
              />
            ))}
          </div>
          
          {/* 好友列表 */}
          <div className="bg-white dark:bg-gray-900">
            {filteredFriends.length === 0 ? (
              <div className={`flex flex-col items-center justify-center text-center ${
                isMobile ? 'py-20 px-6' : 'py-16'
              }`}>
                {searchQuery ? (
                  <>
                    <Search className={`text-gray-400 mb-4 ${
                      isMobile ? 'w-16 h-16' : 'w-12 h-12'
                    }`} />
                    <h3 className={`font-medium text-gray-900 dark:text-white mb-2 ${
                      isMobile ? 'text-xl' : 'text-lg'
                    }`}>
                      未找到联系人
                    </h3>
                    <p className={`text-gray-500 dark:text-gray-400 ${
                      isMobile ? 'text-lg' : 'text-base'
                    }`}>
                      尝试使用其他关键词搜索
                    </p>
                  </>
                ) : (
                  <>
                    <Users className={`text-gray-400 mb-4 ${
                      isMobile ? 'w-16 h-16' : 'w-12 h-12'
                    }`} />
                    <h3 className={`font-medium text-gray-900 dark:text-white mb-2 ${
                      isMobile ? 'text-xl' : 'text-lg'
                    }`}>
                      暂无联系人
                    </h3>
                    <p className={`text-gray-500 dark:text-gray-400 mb-6 ${
                      isMobile ? 'text-lg' : 'text-base'
                    }`}>
                      添加好友开始聊天吧
                    </p>
                    <button 
                      onClick={handleAddFriendClick}
                      onTouchStart={handleTouchStart}
                      onTouchEnd={handleTouchEnd}
                      className={`bg-green-500 text-white transition-colors ${
                        isMobile 
                          ? 'px-8 py-4 text-lg rounded-xl active:bg-green-600 touch-optimized' 
                          : 'px-6 py-2 text-base rounded-lg hover:bg-green-600'
                      }`}
                    >
                      添加好友
                    </button>
                  </>
                )}
              </div>
            ) : (
              <>
                {/* 好友数量统计 */}
                <div className={`bg-gray-50 dark:bg-gray-800 ${
                  isMobile ? 'px-4 py-3' : 'px-4 py-2'
                }`}>
                  <p className={`text-gray-600 dark:text-gray-400 ${
                    isMobile ? 'text-base' : 'text-sm'
                  }`}>
                    {filteredFriends.length} 位联系人
                  </p>
                </div>
                
                {/* 好友列表 */}
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredFriends.map((friend) => (
                    <FriendItem
                      key={friend.id}
                      friend={friend}
                      onClick={handleFriendClick}
                      isMobile={isMobile}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </PageContainer>

      {/* 设置菜单 */}
      <SettingsMenu
        isOpen={showSettingsMenu}
        onClose={() => setShowSettingsMenu(false)}
        onAction={handleSettingsAction}
        isMobile={isMobile}
      />
    </>
  );
};

export default Contacts;