/**
 * 视频详情页面组件
 * 提供视频的详细信息展示，包括视频预览、详细信息、评论系统和相关推荐
 */

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Play, 
  Share2, 
  Download, 
  Heart, 
  Star,
  Calendar,
  Clock,
  Eye,
  ThumbsUp,
  MessageCircle,
  MoreHorizontal,
  Info,
  Settings,
  Bookmark
} from 'lucide-react';
import VideoDetails from '../components/VideoDetails';
import CommentSystem from '../components/CommentSystem';
import { useMediaStore } from '../store/mediaStore';
import { useIsMobile } from '../hooks/useIsMobile';
import type { Movie, EnhancedMovie, VideoRecommendation } from '../types';

/**
 * 视频详情页面组件
 */
export default function VideoDetail() {
  const { videoId } = useParams<{ videoId: string }>();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  
  // 状态管理
  const { 
    currentPlaying, 
    isLoading, 
    error,
    playContent
  } = useMediaStore();
  
  const [recommendations, setRecommendations] = useState<VideoRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState<'details' | 'comments' | 'related'>('details');
  const [showFullDescription, setShowFullDescription] = useState(false);

  // 加载视频详情
  useEffect(() => {
    if (videoId) {
      // TODO: 实现视频详情加载逻辑
      console.log('Loading video details for:', videoId);
    }
  }, [videoId]);

  /**
   * 处理返回操作
   */
  const handleBack = () => {
    navigate(-1);
  };

  /**
   * 处理播放按钮点击
   */
  const handlePlay = () => {
    if (currentMovie) {
      playContent(currentMovie, 'movie');
      navigate(`/app/video/play/${currentMovie.id}`);
    }
  };

  /**
   * 处理分享操作
   */
  const handleShare = async () => {
    if (navigator.share && currentMovie) {
      try {
        await navigator.share({
          title: currentMovie.title,
          text: currentMovie.description,
          url: window.location.href,
        });
      } catch (error) {
        console.log('分享取消或失败:', error);
      }
    } else {
      // 复制链接到剪贴板
      navigator.clipboard.writeText(window.location.href);
    }
  };

  /**
   * 处理下载操作
   */
  const handleDownload = () => {
    if (currentMovie?.videoQualities && currentMovie.videoQualities.length > 0) {
      const defaultQuality = currentMovie.videoQualities.find(q => q.isDefault) || currentMovie.videoQualities[0];
      const link = document.createElement('a');
      link.href = defaultQuality.url;
      link.download = `${currentMovie.title}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  /**
   * 处理收藏操作
   */
  const handleToggleFavorite = () => {
    // TODO: 实现收藏功能
    console.log('收藏功能待实现');
  };

  /**
   * 处理推荐视频点击
   * @param recommendation - 推荐视频
   */
  const handleRecommendationClick = (recommendation: any) => {
    navigate(`/video/${recommendation.video.id}`);
  };

  /**
   * 格式化数字显示
   */
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  /**
   * 格式化时长
   */
  const formatDuration = (minutes: number): string => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  // 加载状态
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  // 错误状态
  if (error || !currentPlaying.content) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">视频加载失败</h2>
          <p className="text-gray-400 mb-6">{error || '未找到指定的视频'}</p>
          <button
            onClick={handleBack}
            className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
          >
            返回
          </button>
        </div>
      </div>
    );
  }

  const currentMovie = currentPlaying.content as EnhancedMovie;

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* 顶部导航栏 */}
      <div className="sticky top-0 z-40 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBack}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1 min-w-0">
              <h1 className="text-lg font-semibold truncate">视频详情</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={handleShare}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              title="分享"
            >
              <Share2 className="w-5 h-5" />
            </button>
            <button
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              title="更多"
            >
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* 主要内容区域 */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-3'}`}>
          {/* 左侧主要内容 */}
          <div className={`${isMobile ? 'col-span-1' : 'col-span-1 lg:col-span-2'} space-y-6`}>
            {/* 视频预览区域 */}
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden group">
              <img
                src={currentMovie.posterUrl}
                alt={currentMovie.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={handlePlay}
                  className="w-20 h-20 bg-green-600 hover:bg-green-700 rounded-full flex items-center justify-center transition-colors"
                >
                  <Play className="w-8 h-8 ml-1" fill="currentColor" />
                </button>
              </div>
              
              {/* 视频信息覆盖层 */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <div className="flex items-center space-x-4 text-sm text-gray-300">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{formatDuration(currentMovie.duration)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="w-4 h-4" />
                    <span>0 观看</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span>{currentMovie.rating}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 视频标题和基本信息 */}
            <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-bold mb-2">{currentMovie.title}</h1>
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{currentMovie.year}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Info className="w-4 h-4" />
                    <span>{currentMovie.director}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {currentMovie.genres.map((g, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-gray-800 rounded-full text-xs"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* 操作按钮 */}
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handlePlay}
                  className="flex items-center space-x-2 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg transition-colors font-medium"
                >
                  <Play className="w-5 h-5" fill="currentColor" />
                  <span>播放</span>
                </button>
                <button
                  onClick={handleToggleFavorite}
                  className="flex items-center space-x-2 px-6 py-3 rounded-lg transition-colors font-medium bg-gray-800 hover:bg-gray-700 text-gray-300"
                >
                  <Heart className="w-5 h-5" />
                  <span>收藏</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="flex items-center space-x-2 px-6 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors font-medium text-gray-300"
                >
                  <Download className="w-5 h-5" />
                  <span>下载</span>
                </button>
                <button className="flex items-center space-x-2 px-6 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors font-medium text-gray-300">
                  <Bookmark className="w-5 h-5" />
                  <span>稍后观看</span>
                </button>
              </div>
            </div>

            {/* 标签页切换 */}
            <div className="border-b border-gray-800">
              <div className="flex space-x-8">
                <button
                  onClick={() => setActiveTab('details')}
                  className={`py-3 px-1 border-b-2 transition-colors ${
                    activeTab === 'details'
                      ? 'border-green-500 text-green-500'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  详细信息
                </button>
                <button
                  onClick={() => setActiveTab('comments')}
                  className={`py-3 px-1 border-b-2 transition-colors ${
                    activeTab === 'comments'
                      ? 'border-green-500 text-green-500'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <MessageCircle className="w-4 h-4" />
                    <span>评论</span>
                  </div>
                </button>
                {!isMobile && (
                  <button
                    onClick={() => setActiveTab('related')}
                    className={`py-3 px-1 border-b-2 transition-colors ${
                      activeTab === 'related'
                        ? 'border-green-500 text-green-500'
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    相关推荐
                  </button>
                )}
              </div>
            </div>

            {/* 标签页内容 */}
            <div className="min-h-[400px]">
              {activeTab === 'details' && (
                <VideoDetails movie={currentMovie} />
              )}
              {activeTab === 'comments' && (
                <CommentSystem 
                      videoId={currentMovie.id}
                      comments={[]}
                      totalComments={0}
                    />
              )}
              {activeTab === 'related' && !isMobile && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {recommendations.map((rec) => (
                    <div
                      key={rec.id}
                      onClick={() => handleRecommendationClick(rec)}
                      className="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-750 transition-colors cursor-pointer"
                    >
                      <div className="aspect-video relative">
                        <img
                          src={rec.video.posterUrl}
                          alt={rec.video.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs">
                          {formatDuration(rec.video.duration)}
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium mb-2 line-clamp-2">{rec.video.title}</h3>
                        <div className="flex items-center justify-between text-sm text-gray-400">
                          <span>{formatNumber(rec.video.viewCount)} 观看</span>
                          <div className="flex items-center space-x-1">
                            <Star className="w-3 h-3 text-yellow-500" />
                            <span>{rec.video.averageRating.toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 右侧推荐区域 - 仅桌面端显示 */}
          {!isMobile && (
            <div className="col-span-1 space-y-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">相关推荐</h3>
                <div className="space-y-4">
                  {recommendations.slice(0, 6).map((rec) => (
                    <div
                      key={rec.id}
                      onClick={() => handleRecommendationClick(rec)}
                      className="flex space-x-3 hover:bg-gray-700 rounded-lg p-2 transition-colors cursor-pointer"
                    >
                      <div className="w-24 aspect-video relative flex-shrink-0">
                        <img
                          src={rec.video.posterUrl}
                          alt={rec.video.title}
                          className="w-full h-full object-cover rounded"
                        />
                        <div className="absolute bottom-1 right-1 bg-black/80 px-1 py-0.5 rounded text-xs">
                          {formatDuration(rec.video.duration)}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm line-clamp-2 mb-1">{rec.video.title}</h4>
                        <div className="text-xs text-gray-400 space-y-1">
                          <div>{formatNumber(rec.video.viewCount)} 观看</div>
                          <div className="flex items-center space-x-1">
                            <Star className="w-3 h-3 text-yellow-500" />
                            <span>{rec.video.averageRating.toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}