import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Package, 
  ArrowLeft,
  Pill
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';

/**
 * 工作管理页面组件 - 简化版，只包含进销存管理入口
 */
const WorkManagement: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  /**
   * 处理返回到发现页面
   */
  const handleGoBack = () => {
    navigate('/app/discover');
  };

  /**
   * 处理进销存管理导航
   */
  const handleInventoryManagement = () => {
    navigate('/app/purchase-sales-inventory');
  };

  /**
   * 处理特药管理导航
   */
  const handleSpecialMedicine = () => {
    navigate('/app/special-medicine');
  };

  return (
    <PageContainer
      title="工作管理"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 内容区域 */}
        <div className={`
          flex-1 flex items-center justify-center
          ${isMobile ? 'px-6 py-8' : 'px-8 py-12'}
        `}>
          <div className="w-full max-w-2xl">
            <div className="grid gap-6 grid-cols-1">
              {/* 进销存管理按钮 */}
              <button
                onClick={handleInventoryManagement}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  w-full bg-gradient-to-r from-blue-500 to-blue-600 
                  hover:from-blue-600 hover:to-blue-700
                  active:from-blue-700 active:to-blue-800
                  text-white rounded-2xl shadow-lg hover:shadow-xl
                  transition-all duration-300 transform hover:scale-105 active:scale-95
                  ${isMobile 
                    ? 'py-8 px-6 min-h-touch' 
                    : 'py-10 px-8'
                  }
                  flex flex-col items-center justify-center space-y-4
                  border-0 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800
                `}
              >
                {/* 图标 */}
                <div className={`
                  bg-white bg-opacity-20 rounded-full p-4
                  ${isMobile ? 'w-16 h-16' : 'w-20 h-20'}
                  flex items-center justify-center
                `}>
                  <Package className={`
                    text-white
                    ${isMobile ? 'w-8 h-8' : 'w-10 h-10'}
                  `} />
                </div>
                
                {/* 标题 */}
                <div className="text-center">
                  <h2 className={`
                    font-bold text-white mb-2
                    ${isMobile ? 'text-xl' : 'text-2xl'}
                  `}>
                    进销存管理
                  </h2>
                  <p className={`
                    text-blue-100 font-medium
                    ${isMobile ? 'text-sm' : 'text-base'}
                  `}>
                    点击进入库存管理系统
                  </p>
                </div>
              </button>

              {/* 特药管理按钮 */}
              <button
                onClick={handleSpecialMedicine}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  w-full bg-gradient-to-r from-green-500 to-green-600 
                  hover:from-green-600 hover:to-green-700
                  active:from-green-700 active:to-green-800
                  text-white rounded-2xl shadow-lg hover:shadow-xl
                  transition-all duration-300 transform hover:scale-105 active:scale-95
                  ${isMobile 
                    ? 'py-8 px-6 min-h-touch' 
                    : 'py-10 px-8'
                  }
                  flex flex-col items-center justify-center space-y-4
                  border-0 focus:outline-none focus:ring-4 focus:ring-green-300 dark:focus:ring-green-800
                `}
              >
                {/* 图标 */}
                <div className={`
                  bg-white bg-opacity-20 rounded-full p-4
                  ${isMobile ? 'w-16 h-16' : 'w-20 h-20'}
                  flex items-center justify-center
                `}>
                  <Pill className={`
                    text-white
                    ${isMobile ? 'w-8 h-8' : 'w-10 h-10'}
                  `} />
                </div>
                
                {/* 标题 */}
                <div className="text-center">
                  <h2 className={`
                    font-bold text-white mb-2
                    ${isMobile ? 'text-xl' : 'text-2xl'}
                  `}>
                    特药管理
                  </h2>
                  <p className={`
                    text-green-100 font-medium
                    ${isMobile ? 'text-sm' : 'text-base'}
                  `}>
                    患者用药记录与提醒
                  </p>
                </div>
              </button>
            </div>

            {/* 提示文字 */}
            <div className="text-center mt-8">
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-base'}
              `}>
                选择您需要管理的业务模块
              </p>
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default WorkManagement;