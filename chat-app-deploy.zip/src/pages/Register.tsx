/**
 * 飞鸽风格即时通讯App - 注册页面
 * 提供用户注册功能，包含表单验证和密码强度检查
 */

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, MessageCircle, Lock, User } from 'lucide-react';
import { useAppStore } from '../store';
import { validatePassword } from '../utils';
import { useIsMobile, useSafeArea, useTouchFeedback } from '../hooks';

/**
 * 注册表单数据接口
 */
interface RegisterFormData {
  username: string;
  password: string;
  confirmPassword: string;
}

/**
 * 验证用户名格式
 * @param username 用户名
 * @returns 是否有效
 */
const validateUsername = (username: string): boolean => {
  // 用户名规则：2-20个字符，支持字母、数字、下划线
  const usernameRegex = /^[a-zA-Z0-9_]{2,20}$/;
  return usernameRegex.test(username);
};

/**
 * 注册页面组件
 */
export default function Register() {
  const navigate = useNavigate();
  const { register, isAuthenticated } = useAppStore();
  const isMobile = useIsMobile();
  const safeArea = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  const [formData, setFormData] = useState<RegisterFormData>({
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formErrors, setFormErrors] = useState<Partial<RegisterFormData>>({});
  const [passwordStrength, setPasswordStrength] = useState<'weak' | 'medium' | 'strong'>('weak');

  /**
   * 如果已登录，重定向到主页
   * 注意：这里只处理页面初始加载时的重定向，不处理注册成功后的跳转
   */
  useEffect(() => {
    // 只在组件初始挂载时检查，避免与注册成功后的跳转冲突
    if (isAuthenticated && !isLoading) {
      navigate('/app/chats');
    }
  }, []); // 空依赖数组，只在组件挂载时执行一次

  /**
   * 处理输入框变化
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 清除对应字段的错误
    if (formErrors[name as keyof RegisterFormData]) {
      setFormErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
    
    // 更新密码强度
    if (name === 'password') {
      setPasswordStrength(validatePassword(value));
    }
  };

  /**
   * 验证表单数据
   */
  const validateForm = (): boolean => {
    const errors: Partial<RegisterFormData> = {};
    
    // 验证用户名
    if (!formData.username) {
      errors.username = '请输入用户名';
    } else if (!validateUsername(formData.username)) {
      errors.username = '用户名格式不正确（2-20个字符，支持字母、数字、下划线）';
    }
    
    // 验证密码
    if (!formData.password) {
      errors.password = '请输入密码';
    } else if (formData.password.length < 6) {
      errors.password = '密码长度至少6位';
    }
    
    // 验证确认密码
    if (!formData.confirmPassword) {
      errors.confirmPassword = '请确认密码';
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = '两次输入的密码不一致';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  /**
   * 处理表单提交
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      console.log('开始注册流程，表单数据:', formData);
      
      const success = await register({
        username: formData.username,
        password: formData.password
      });
      
      console.log('注册结果:', success);
      
      if (success) {
        console.log('注册成功，准备跳转到聊天页面');
        // 注册成功后立即跳转，不等待状态更新
        navigate('/app/chats', { replace: true });
      } else {
        setError('注册失败，请稍后重试');
      }
    } catch (error) {
      console.error('注册过程中出现错误:', error);
      setError('注册失败，请稍后重试');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * 切换密码显示状态
   */
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  /**
   * 切换确认密码显示状态
   */
  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  /**
   * 获取密码强度颜色
   */
  const getPasswordStrengthColor = () => {
    switch (passwordStrength) {
      case 'weak':
        return 'bg-red-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'strong':
        return 'bg-green-500';
      default:
        return 'bg-gray-300';
    }
  };

  /**
   * 获取密码强度文本
   */
  const getPasswordStrengthText = () => {
    switch (passwordStrength) {
      case 'weak':
        return '弱';
      case 'medium':
        return '中';
      case 'strong':
        return '强';
      default:
        return '';
    }
  };

  return (
    <div 
      className={`min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center ${
        isMobile ? 'p-4 mobile-layout' : 'p-8'
      }`}
      style={{
        paddingTop: isMobile ? `${safeArea.top + 16}px` : undefined,
        paddingBottom: isMobile ? `${safeArea.bottom + 16}px` : undefined,
      }}
    >
      <div className={`w-full ${isMobile ? 'max-w-sm' : 'max-w-md'}`}>
        {/* Logo区域 */}
        <div className={`text-center ${isMobile ? 'mb-6' : 'mb-8'}`}>
          <div className={`inline-flex items-center justify-center bg-green-500 rounded-2xl ${
            isMobile ? 'w-20 h-20 mb-4' : 'w-16 h-16 mb-4'
          }`}>
            <MessageCircle className={`text-white ${isMobile ? 'w-10 h-10' : 'w-8 h-8'}`} />
          </div>
          <h1 className={`font-bold text-gray-900 mb-2 ${
            isMobile ? 'text-xl' : 'text-2xl'
          }`}>创建账户</h1>
          <p className={`text-gray-600 ${isMobile ? 'text-sm' : 'text-base'}`}>
            加入我们，开始聊天之旅
          </p>
        </div>

        {/* 注册表单 */}
        <div className={`bg-white rounded-2xl shadow-xl ${
          isMobile ? 'p-6 mobile-shadow' : 'p-8'
        }`}>
          <form onSubmit={handleSubmit} className={`space-y-6 ${
            isMobile ? 'space-y-5' : ''
          }`}>
            {/* 错误提示 */}
            {error && (
              <div className={`bg-red-50 border border-red-200 rounded-lg ${
                isMobile ? 'p-4' : 'p-3'
              }`}>
                <p className={`text-red-600 ${isMobile ? 'text-base' : 'text-sm'}`}>
                  {error}
                </p>
              </div>
            )}

            {/* 用户名输入框 */}
            <div>
              <label 
                htmlFor="username" 
                className={`block font-medium text-gray-700 mb-2 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}
              >
                用户名
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  className={`block w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors ${
                    formErrors.username ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  } ${
                    isMobile 
                      ? 'pl-12 pr-4 py-4 text-base touch-optimized' 
                      : 'pl-10 pr-3 py-3 text-sm'
                  }`}
                  placeholder="请输入用户名（2-20个字符）"
                  value={formData.username}
                  onChange={handleInputChange}
                />
              </div>
              {formErrors.username && (
                <p className={`mt-1 text-red-600 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}>{formErrors.username}</p>
              )}
            </div>

            {/* 密码输入框 */}
            <div>
              <label 
                htmlFor="password" 
                className={`block font-medium text-gray-700 mb-2 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}
              >
                密码
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  className={`block w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors ${
                    formErrors.password ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  } ${
                    isMobile 
                      ? 'pl-12 pr-12 py-4 text-base touch-optimized' 
                      : 'pl-10 pr-10 py-3 text-sm'
                  }`}
                  placeholder="请输入密码"
                  value={formData.password}
                  onChange={handleInputChange}
                />
                <button
                  type="button"
                  className={`absolute inset-y-0 right-0 flex items-center transition-colors ${
                    isMobile ? 'pr-4 touch-optimized' : 'pr-3'
                  }`}
                  onClick={togglePasswordVisibility}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                >
                  {showPassword ? (
                    <EyeOff className={`text-gray-400 hover:text-gray-600 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  ) : (
                    <Eye className={`text-gray-400 hover:text-gray-600 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  )}
                </button>
              </div>
              {formErrors.password && (
                <p className={`mt-1 text-red-600 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}>{formErrors.password}</p>
              )}
              
              {/* 密码强度指示器 */}
              {formData.password && (
                <div className="mt-2">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                        style={{
                          width: passwordStrength === 'weak' ? '33%' : passwordStrength === 'medium' ? '66%' : '100%'
                        }}
                      />
                    </div>
                    <span className={`text-gray-600 ${
                      isMobile ? 'text-sm' : 'text-xs'
                    }`}>
                      密码强度: {getPasswordStrengthText()}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* 确认密码输入框 */}
            <div>
              <label 
                htmlFor="confirmPassword" 
                className={`block font-medium text-gray-700 mb-2 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}
              >
                确认密码
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={`text-gray-400 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
                </div>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  className={`block w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors ${
                    formErrors.confirmPassword ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  } ${
                    isMobile 
                      ? 'pl-12 pr-12 py-4 text-base touch-optimized' 
                      : 'pl-10 pr-10 py-3 text-sm'
                  }`}
                  placeholder="请再次输入密码"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                />
                <button
                  type="button"
                  className={`absolute inset-y-0 right-0 flex items-center transition-colors ${
                    isMobile ? 'pr-4 touch-optimized' : 'pr-3'
                  }`}
                  onClick={toggleConfirmPasswordVisibility}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                >
                  {showConfirmPassword ? (
                    <EyeOff className={`text-gray-400 hover:text-gray-600 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  ) : (
                    <Eye className={`text-gray-400 hover:text-gray-600 ${
                      isMobile ? 'h-6 w-6' : 'h-5 w-5'
                    }`} />
                  )}
                </button>
              </div>
              {formErrors.confirmPassword && (
                <p className={`mt-1 text-red-600 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}>{formErrors.confirmPassword}</p>
              )}
            </div>

            {/* 注册按钮 */}
            <button
              type="submit"
              disabled={isLoading}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`w-full flex justify-center border border-transparent rounded-lg shadow-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${
                isMobile 
                  ? 'py-4 px-6 text-base touch-optimized mobile-shadow' 
                  : 'py-3 px-4 text-sm'
              }`}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  注册中...
                </div>
              ) : (
                '创建账户'
              )}
            </button>
          </form>

          {/* 登录链接 */}
          <div className={`text-center ${isMobile ? 'mt-5' : 'mt-6'}`}>
            <p className={`text-gray-600 ${isMobile ? 'text-base' : 'text-sm'}`}>
              已有账户？{' '}
              <Link
                to="/login"
                className={`font-medium text-green-600 hover:text-green-500 transition-colors ${
                  isMobile ? 'touch-optimized' : ''
                }`}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
              >
                立即登录
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}