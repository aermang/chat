/**
 * 飞鸽风格即时通讯App - 好友申请页面
 * 显示收到的好友申请并提供处理功能
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, X, Loader2, User as UserIcon, Mail, Clock, UserPlus } from 'lucide-react';
import { useAppStore } from '../store';
import { FriendRequest, User } from '../types';
import { getInitials, getAvatarColor, formatTime } from '../utils';
import PageContainer from '../components/Layout/PageContainer';
import { useIsMobile } from '../hooks/useIsMobile';
import { toast } from 'sonner';

/**
 * 好友申请卡片组件
 */
interface FriendRequestCardProps {
  request: FriendRequest;
  fromUser: User | null;
  onAccept: (requestId: string) => void;
  onReject: (requestId: string) => void;
  isProcessing: boolean;
}

const FriendRequestCard: React.FC<FriendRequestCardProps> = ({
  request,
  fromUser,
  onAccept,
  onReject,
  isProcessing
}) => {
  const isMobile = useIsMobile();

  /**
   * 格式化申请时间
   */
  const formatTime = (timestamp: number): string => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    
    return new Date(timestamp).toLocaleDateString('zh-CN');
  };

  if (!fromUser) {
    return (
      <div className={`
        bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700
        ${isMobile ? 'mx-4' : ''}
      `}>
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gray-300 dark:bg-gray-600 rounded-full animate-pulse"></div>
          <div className="flex-1">
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded animate-pulse mb-2"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded animate-pulse w-2/3"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`
      bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700
      ${isMobile ? 'mx-4' : ''}
      ${!request.is_read ? 'ring-2 ring-blue-500 ring-opacity-20' : ''}
    `}>
      <div className="flex items-start space-x-4">
        {/* 用户头像 */}
        <div className="flex-shrink-0">
          {fromUser.avatar_url ? (
            <img
              src={fromUser.avatar_url}
              alt={fromUser.username}
              className="w-12 h-12 rounded-full object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.nextElementSibling?.classList.remove('hidden');
              }}
            />
          ) : null}
          <div
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold ${
              fromUser.avatar_url ? 'hidden' : ''
            }`}
            style={{ backgroundColor: getAvatarColor(fromUser.username) }}
          >
            {getInitials(fromUser.username)}
          </div>
        </div>

        {/* 申请信息 */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            <h3 className="font-medium text-gray-900 dark:text-white truncate">
              {fromUser.nickname || fromUser.username}
            </h3>
            {fromUser.is_online && (
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            )}
            {!request.is_read && (
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            )}
          </div>
          
          <div className="flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400 mb-2">
            <UserIcon className="w-3 h-3" />
            <span className="truncate">{fromUser.username}</span>
          </div>
          
          {fromUser.email && (
            <div className="flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400 mb-2">
              <Mail className="w-3 h-3" />
              <span className="truncate">{fromUser.email}</span>
            </div>
          )}

          {request.message && (
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-2 bg-gray-50 dark:bg-gray-700 p-2 rounded">
              "{request.message}"
            </p>
          )}

          <div className="flex items-center space-x-1 text-xs text-gray-400 dark:text-gray-500">
            <Clock className="w-3 h-3" />
            <span>{formatTime(new Date(request.created_at).getTime())}</span>
          </div>
        </div>

        {/* 操作按钮 */}
        {request.status === 'pending' && (
          <div className="flex flex-col space-y-2 flex-shrink-0">
            <button
              onClick={() => onAccept(request.id)}
              disabled={isProcessing}
              className="
                px-3 py-2 bg-green-500 text-white rounded-lg text-sm font-medium
                hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed
                transition-colors flex items-center space-x-1
              "
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              <span>接受</span>
            </button>
            
            <button
              onClick={() => onReject(request.id)}
              disabled={isProcessing}
              className="
                px-3 py-2 bg-red-500 text-white rounded-lg text-sm font-medium
                hover:bg-red-600 disabled:bg-gray-400 disabled:cursor-not-allowed
                transition-colors flex items-center space-x-1
              "
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <X className="w-4 h-4" />
              )}
              <span>拒绝</span>
            </button>
          </div>
        )}

        {/* 已处理状态 */}
        {request.status !== 'pending' && (
          <div className="flex-shrink-0">
            <div className={`
              px-3 py-2 rounded-lg text-sm font-medium
              ${request.status === 'accepted' 
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
              }
            `}>
              {request.status === 'accepted' ? '已接受' : '已拒绝'}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * 好友申请页面组件
 */
const FriendRequests: React.FC = () => {
  const navigate = useNavigate();
  const {
    friendRequests,
    loadFriendRequests,
    handleFriendRequest,
    markFriendRequestAsRead,
    getUserById
  } = useAppStore();

  const [processingRequestId, setProcessingRequestId] = useState<string | null>(null);
  const [userCache, setUserCache] = useState<Record<string, User>>({});
  const [isLoading, setIsLoading] = useState(true);

  const isMobile = useIsMobile();

  // 加载好友申请列表
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        await loadFriendRequests();
      } catch (error) {
        console.error('加载好友申请失败:', error);
        toast.error('加载好友申请失败');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [loadFriendRequests]);

  // 加载用户信息
  useEffect(() => {
    const loadUsers = async () => {
      const userIds = friendRequests
        .map(request => request.from_user_id)
        .filter(id => !userCache[id]);

      if (userIds.length === 0) return;

      const users: Record<string, User> = {};
      
      for (const userId of userIds) {
        try {
          const user = await getUserById(userId);
          if (user) {
            users[userId] = user;
          }
        } catch (error) {
          console.error(`加载用户 ${userId} 信息失败:`, error);
        }
      }

      setUserCache(prev => ({ ...prev, ...users }));
    };

    if (friendRequests.length > 0) {
      loadUsers();
    }
  }, [friendRequests, userCache, getUserById]);

  /**
   * 处理接受好友申请
   */
  const handleAccept = async (requestId: string) => {
    setProcessingRequestId(requestId);
    
    try {
      const success = await handleFriendRequest(requestId, 'accepted');
      
      if (success) {
        toast.success('已接受好友申请');
        // 标记为已读
        await markFriendRequestAsRead(requestId);
        // 重新加载申请列表
        await loadFriendRequests();
      } else {
        toast.error('接受好友申请失败');
      }
    } catch (error) {
      console.error('接受好友申请失败:', error);
      toast.error('接受好友申请失败，请重试');
    } finally {
      setProcessingRequestId(null);
    }
  };

  /**
   * 处理拒绝好友申请
   */
  const handleReject = async (requestId: string) => {
    setProcessingRequestId(requestId);
    
    try {
      const success = await handleFriendRequest(requestId, 'rejected');
      
      if (success) {
        toast.success('已拒绝好友申请');
        // 标记为已读
        await markFriendRequestAsRead(requestId);
        // 重新加载申请列表
        await loadFriendRequests();
      } else {
        toast.error('拒绝好友申请失败');
      }
    } catch (error) {
      console.error('拒绝好友申请失败:', error);
      toast.error('拒绝好友申请失败，请重试');
    } finally {
      setProcessingRequestId(null);
    }
  };

  /**
   * 处理返回按钮点击
   */
  const handleBack = () => {
    navigate(-1);
  };

  // 按时间倒序排列申请
  const sortedRequests = [...friendRequests].sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  return (
    <PageContainer
      title="好友申请"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full">
        {isLoading ? (
          // 加载状态
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400">加载中...</p>
            </div>
          </div>
        ) : sortedRequests.length > 0 ? (
          // 申请列表
          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {sortedRequests.map((request) => (
              <FriendRequestCard
                key={request.id}
                request={request}
                fromUser={userCache[request.from_user_id] || null}
                onAccept={handleAccept}
                onReject={handleReject}
                isProcessing={processingRequestId === request.id}
              />
            ))}
          </div>
        ) : (
          // 空状态
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <UserPlus className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400">暂无好友申请</p>
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                当有人向你发送好友申请时，会在这里显示
              </p>
            </div>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default FriendRequests;