/**
 * 飞鸽风格即时通讯App - 朋友圈页面
 * 显示朋友圈动态，支持浏览、点赞和评论功能
 */

import React, { useEffect, useState } from 'react';
import { Camera, Heart, MessageCircle, MoreHorizontal, Plus } from 'lucide-react';
import { useAppStore } from '../store';
import { formatTime, getInitials, getAvatarColor } from '../utils';
import PageContainer from '../components/Layout/PageContainer';

/**
 * 朋友圈页面组件
 */
const Moments: React.FC = () => {
  const { currentUser, moments, friends, loadMoments, createMoment } = useAppStore();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newMomentContent, setNewMomentContent] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [likedMoments, setLikedMoments] = useState<Set<string>>(new Set());
  const [momentLikes, setMomentLikes] = useState<Record<string, number>>({});
  const [showMoreMenu, setShowMoreMenu] = useState<string | null>(null);
  
  /**
   * 加载朋友圈数据
   */
  useEffect(() => {
    loadMoments();
  }, [loadMoments]);

  /**
   * 获取用户信息
   */
  const getUserInfo = (userId: string) => {
    if (userId === currentUser?.id) return currentUser;
    return friends.find(friend => friend.id === userId);
  };

  /**
   * 处理发布动态
   */
  const handleCreateMoment = async () => {
    if (!newMomentContent.trim()) return;
    
    setIsCreating(true);
    try {
      const success = await createMoment(newMomentContent.trim(), []);
      if (success) {
        setNewMomentContent('');
        setShowCreateModal(false);
      }
    } catch (error) {
      console.error('发布动态失败:', error);
    } finally {
      setIsCreating(false);
    }
  };

  /**
   * 处理点赞
   */
  const handleLike = (momentId: string) => {
    const newLikedMoments = new Set(likedMoments);
    const newMomentLikes = { ...momentLikes };
    
    if (likedMoments.has(momentId)) {
      // 取消点赞
      newLikedMoments.delete(momentId);
      newMomentLikes[momentId] = Math.max(0, (newMomentLikes[momentId] || 0) - 1);
    } else {
      // 点赞
      newLikedMoments.add(momentId);
      newMomentLikes[momentId] = (newMomentLikes[momentId] || 0) + 1;
    }
    
    setLikedMoments(newLikedMoments);
    setMomentLikes(newMomentLikes);
  };

  /**
   * 处理评论
   */
  const handleComment = (momentId: string) => {
    // TODO: 实现评论功能
    console.log('评论动态:', momentId);
  };

  /**
   * 处理更多菜单
   */
  const handleMoreMenu = (momentId: string) => {
    setShowMoreMenu(showMoreMenu === momentId ? null : momentId);
  };

  /**
   * 处理删除动态
   */
  const handleDeleteMoment = (momentId: string) => {
    // TODO: 实现删除动态功能
    console.log('删除动态:', momentId);
    setShowMoreMenu(null);
  };

  return (
    <PageContainer
      title="朋友圈"
      actions={[
        {
          icon: <Camera className="w-5 h-5" />,
          onClick: () => setShowCreateModal(true),
          label: "发布动态"
        }
      ]}
    >
      
      {/* 个人信息卡片 */}
      <div className="bg-gradient-to-r from-green-400 to-green-600 p-6 relative">
        <div className="absolute inset-0 bg-black bg-opacity-20"></div>
        <div className="relative flex items-end justify-between">
          <div className="flex items-end space-x-4">
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.username}
                className="w-16 h-16 rounded-lg object-cover border-2 border-white"
              />
            ) : (
              <div
                className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-medium text-lg border-2 border-white"
                style={{ backgroundColor: getAvatarColor(currentUser?.username || '') }}
              >
                {getInitials(currentUser?.username || '')}
              </div>
            )}
            <div className="pb-2">
              <h2 className="text-white font-semibold text-lg">
                {currentUser?.username}
              </h2>
              {currentUser?.bio && (
                <p className="text-white text-sm opacity-90 mt-1">
                  {currentUser.bio}
                </p>
              )}
            </div>
          </div>
          
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-lg transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      {/* 朋友圈动态列表 */}
      <div className="flex-1 overflow-y-auto">
        {moments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Camera className="w-12 h-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              暂无动态
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6">
              发布第一条朋友圈动态吧
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg transition-colors"
            >
              发布动态
            </button>
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {moments.map((moment) => {
              const user = getUserInfo(moment.user_id);
              if (!user) return null;
              
              return (
                <div key={moment.id} className="p-4">
                  {/* 用户信息 */}
                  <div className="flex items-start space-x-3">
                    {/* 头像 */}
                    <div className="flex-shrink-0">
                      {user.avatar ? (
                        <img
                          src={user.avatar}
                          alt={user.username}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      ) : (
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white font-medium text-sm"
                          style={{ backgroundColor: getAvatarColor(user.username) }}
                        >
                          {getInitials(user.username)}
                        </div>
                      )}
                    </div>
                    
                    {/* 动态内容 */}
                    <div className="flex-1 min-w-0">
                      {/* 用户名和时间 */}
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-base font-medium text-gray-900 dark:text-white">
                          {user.username}
                        </h3>
                        <button 
                          onClick={() => handleMoreMenu(moment.id)}
                          className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                      
                      {/* 动态文本 */}
                      {moment.content && (
                        <p className="text-gray-900 dark:text-white text-sm leading-relaxed mb-3 whitespace-pre-wrap">
                          {moment.content}
                        </p>
                      )}
                      
                      {/* 动态图片 */}
                      {moment.images && moment.images.length > 0 && (
                        <div className="grid grid-cols-3 gap-2 mb-3">
                          {moment.images.slice(0, 9).map((image, index) => (
                            <div key={index} className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                              <img
                                src={image}
                                alt={`动态图片 ${index + 1}`}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* 时间和互动 */}
                      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                        <span>{formatTime(moment.created_at)}</span>
                        
                        <div className="flex items-center space-x-4">
                          <button 
                            onClick={() => handleLike(moment.id)}
                            className={`flex items-center space-x-1 transition-colors ${
                              likedMoments.has(moment.id) 
                                ? 'text-red-500' 
                                : 'hover:text-red-500'
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${likedMoments.has(moment.id) ? 'fill-current' : ''}`} />
                            <span>{momentLikes[moment.id] || 0}</span>
                          </button>
                          <button 
                            onClick={() => handleComment(moment.id)}
                            className="flex items-center space-x-1 hover:text-blue-500 transition-colors"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span>0</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      
      {/* 发布动态模态框 */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-2xl mx-4 w-full max-w-md">
            {/* 模态框标题 */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                发布动态
              </h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 transition-colors"
              >
                ✕
              </button>
            </div>
            
            {/* 输入区域 */}
            <div className="p-4">
              <textarea
                value={newMomentContent}
                onChange={(e) => setNewMomentContent(e.target.value)}
                placeholder="分享新鲜事..."
                className="w-full h-32 p-3 border border-gray-300 dark:border-gray-600 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
            
            {/* 操作按钮 */}
            <div className="flex items-center justify-end space-x-3 p-4 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleCreateMoment}
                disabled={!newMomentContent.trim() || isCreating}
                className="px-6 py-2 bg-green-500 hover:bg-green-600 disabled:bg-green-300 dark:disabled:bg-green-700 text-white rounded-lg transition-colors"
              >
                {isCreating ? '发布中...' : '发布'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 更多菜单弹窗 */}
      {showMoreMenu && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setShowMoreMenu(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-2xl mx-4 w-full max-w-xs" onClick={(e) => e.stopPropagation()}>
            <div className="p-2">
              <button
                onClick={() => handleDeleteMoment(showMoreMenu)}
                className="w-full text-left px-4 py-3 text-red-600 dark:text-red-400 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                删除动态
              </button>
            </div>
          </div>
        </div>
      )}
    </PageContainer>
  );
};

export default Moments;