/**
 * 飞鸽风格即时通讯App - 聊天列表页面
 * 显示用户的聊天会话列表
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Users, UserPlus, QrCode, MessageSquare } from 'lucide-react';
import { useAppStore } from '../store';
import { formatChatTime, getInitials, getAvatarColor } from '../utils';
import { useIsMobile, useSafeArea, useTouchFeedback } from '../hooks';
import PageContainer from '../components/Layout/PageContainer';

/**
 * 加号按钮子菜单组件
 */
const PlusMenu: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onAction: (action: string) => void;
  isMobile: boolean;
}> = ({ isOpen, onClose, onAction, isMobile }) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  if (!isOpen) return null;

  const menuItems = [
    { id: 'group-chat', label: '发起群聊', icon: Users },
    { id: 'add-friend', label: '添加好友', icon: UserPlus },
    { id: 'scan', label: '扫一扫', icon: QrCode },
    { id: 'create-room', label: '创建聊天室', icon: MessageSquare }
  ];

  return (
    <>
      {/* 遮罩层 */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-30 z-40"
        onClick={onClose}
      />
      
      {/* 菜单内容 */}
      <div className={`
        fixed top-16 right-4 bg-white dark:bg-gray-800 rounded-2xl shadow-lg z-50
        ${isMobile ? 'w-48' : 'w-44'}
        border border-gray-200 dark:border-gray-700
      `}>
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                onAction(item.id);
                onClose();
              }}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`
                w-full flex items-center space-x-3 px-4 py-3
                text-gray-700 dark:text-gray-300
                transition-colors duration-200
                ${isMobile 
                  ? 'active:bg-gray-100 dark:active:bg-gray-700 touch-optimized' 
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }
                ${index === 0 ? 'rounded-t-2xl' : ''}
                ${index === menuItems.length - 1 ? 'rounded-b-2xl' : ''}
              `}
            >
              <Icon className={`${isMobile ? 'w-5 h-5' : 'w-4 h-4'} text-green-600`} />
              <span className={`${isMobile ? 'text-base' : 'text-sm'} font-medium`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </>
  );
};

/**
 * 聊天列表页面组件
 */
const ChatList: React.FC = () => {
  const navigate = useNavigate();
  const { chatSessions, friends, loadChatSessions, loadFriends } = useAppStore();
  const isMobile = useIsMobile();
  const { top } = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  
  /**
   * 加载聊天数据
   */
  useEffect(() => {
    loadChatSessions();
    loadFriends();
  }, [loadChatSessions, loadFriends]);
  
  /**
   * 处理聊天项点击
   */
  const handleChatClick = (friendId: string) => {
    navigate(`/app/chat/${friendId}`);
  };
  
  /**
   * 获取好友信息
   */
  const getFriendInfo = (friendId: string) => {
    return friends.find(friend => friend.id === friendId);
  };

  /**
   * 处理加号菜单操作
   */
  const handlePlusMenuAction = (action: string) => {
    switch (action) {
      case 'group-chat':
        // TODO: 实现发起群聊功能
        console.log('发起群聊');
        break;
      case 'add-friend':
        navigate('/app/contacts');
        break;
      case 'scan':
        // TODO: 实现扫一扫功能
        console.log('扫一扫');
        break;
      case 'create-room':
        // TODO: 实现创建聊天室功能
        console.log('创建聊天室');
        break;
      default:
        break;
    }
  };

  /**
   * 聊天项组件 - 优化移动端触控体验
   */
  const ChatItem: React.FC<{ session: any; friend: any }> = ({ session, friend }) => (
    <div
      onClick={() => handleChatClick(session.friend_id)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className={`
        flex items-center cursor-pointer transition-all duration-200
        ${isMobile 
          ? 'p-4 min-h-touch active:bg-gray-100 dark:active:bg-gray-700' 
          : 'p-4 hover:bg-gray-50 dark:hover:bg-gray-800'
        }
        touch-optimized
      `}
      data-testid="chat-item"
    >
      {/* 头像 */}
      <div className="relative flex-shrink-0">
        {friend.avatar ? (
          <img
            src={friend.avatar}
            alt={friend.username}
            className={`
              object-cover rounded-lg
              ${isMobile ? 'w-12 h-12 sm:w-14 sm:h-14' : 'w-12 h-12'}
            `}
          />
        ) : (
          <div
            className={`
              rounded-lg flex items-center justify-center text-white font-medium
              ${isMobile ? 'w-12 h-12 sm:w-14 sm:h-14 text-sm sm:text-base' : 'w-12 h-12'}
            `}
            style={{ backgroundColor: getAvatarColor(friend.username) }}
          >
            {getInitials(friend.username)}
          </div>
        )}
        
        {/* 未读消息徽章 */}
        {session.unread_count > 0 && (
          <div className={`
            absolute bg-red-500 text-white rounded-full flex items-center justify-center px-1
            ${isMobile 
              ? '-top-1 -right-1 text-xs min-w-[20px] h-[20px] font-medium' 
              : '-top-1 -right-1 text-xs min-w-[18px] h-[18px]'
            }
            unread-badge
          `}>
            {session.unread_count > 99 ? '99+' : session.unread_count}
          </div>
        )}
      </div>
      
      {/* 聊天信息 */}
      <div className="flex-1 ml-3 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <h3 className={`
            font-medium text-gray-900 dark:text-white truncate
            ${isMobile ? 'text-base sm:text-lg' : 'text-base'}
            friend-name
          `}>
            {friend.username}
          </h3>
          <span className={`
            text-gray-500 dark:text-gray-400 flex-shrink-0 ml-2
            ${isMobile ? 'text-xs sm:text-sm' : 'text-xs'}
            message-time
          `}>
            {formatChatTime(session.last_message_time)}
          </span>
        </div>
        
        <div className="flex items-center">
          <p className={`
            text-gray-600 dark:text-gray-400 truncate flex-1
            ${isMobile ? 'text-sm sm:text-base' : 'text-sm'}
            last-message
          `}>
            {session.last_message ? 
              (typeof session.last_message === 'string' ? 
                session.last_message : 
                session.last_message.content
              ) : 
              '暂无消息'
            }
          </p>
          
          {/* 消息状态指示器 */}
          {session.unread_count === 0 && session.last_message && (
            <div className={`
              bg-gray-400 rounded-full flex-shrink-0 ml-2
              ${isMobile ? 'w-2 h-2' : 'w-2 h-2'}
            `}></div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      <PageContainer
        title="飞鸽"
        headerActions={
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => navigate('/app/search')}
              className={`
                text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
                transition-colors touch-optimized
                ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
              `}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              aria-label="搜索"
            >
              <Search className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
            </button>
            <button 
              onClick={() => setShowPlusMenu(true)}
              className={`
                text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
                transition-colors touch-optimized
                ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
              `}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              aria-label="更多功能"
            >
              <Plus className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
            </button>
          </div>
        }
        contentClassName="px-0 py-0"
      >
      
        {/* 聊天列表 */}
        <div className={`
          h-full overflow-y-auto
          ${isMobile ? 'mobile-scroll' : ''}
        `}>
          {chatSessions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className={`text-gray-400 mb-4 ${
                isMobile ? 'w-16 h-16' : 'w-12 h-12'
              }`}>
                <Search className="w-full h-full" />
              </div>
              <h3 className={`font-medium text-gray-900 dark:text-white mb-2 ${
                isMobile ? 'text-xl' : 'text-lg'
              }`}>
                暂无聊天记录
              </h3>
              <p className={`text-gray-500 dark:text-gray-400 ${
                isMobile ? 'text-base' : 'text-sm'
              }`}>
                开始与好友聊天吧
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              {chatSessions.map((session) => {
                const friend = getFriendInfo(session.friend_id);
                if (!friend) return null;
                
                return (
                  <ChatItem 
                    key={session.id} 
                    session={session} 
                    friend={friend} 
                  />
                );
              })}
            </div>
          )}
        </div>
      </PageContainer>

      {/* 加号按钮子菜单 */}
      <PlusMenu
        isOpen={showPlusMenu}
        onClose={() => setShowPlusMenu(false)}
        onAction={handlePlusMenuAction}
        isMobile={isMobile}
      />
    </>
  );
};

export default ChatList;