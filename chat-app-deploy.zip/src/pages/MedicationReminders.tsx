import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft,
  Plus,
  Search,
  Bell,
  BellOff,
  Clock,
  User,
  Pill,
  Calendar,
  Edit,
  Trash2,
  AlertCircle,
  Filter,
  CheckCircle,
  Settings
} from 'lucide-react';
// 修复：统一使用正确的状态管理系统，确保提醒数据与患者数据同步
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { useIsMobile, useTouchFeedback } from '../hooks';
import { MedicationReminder, MedicationRecord } from '../types';
import NotificationPermission from '../components/NotificationPermission';
import PageContainer from '../components/Layout/PageContainer';
import { reminderService, ReminderNotification } from '../services/reminderService';
import { toast } from 'sonner';

/**
 * 用药提醒页面组件
 */
const MedicationReminders: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 获取URL参数中的patientId
  const patientId = searchParams.get('patientId');
  
  // 获取状态管理中的数据
  // 修复：使用正确的方法名 loadReminders 而不是 loadMedicationReminders，确保与状态管理接口一致
  const { 
    reminders,
    patients,
    loadReminders,
    loadPatients,
    deleteMedicationReminder,
    updateMedicationReminder
  } = useSpecialMedicineStore();

  const [filteredReminders, setFilteredReminders] = useState<MedicationReminder[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [notificationPermission, setNotificationPermission] = useState<'default' | 'granted' | 'denied'>('default');
  const [todayStats, setTodayStats] = useState({ total: 0, sent: 0, taken: 0, dismissed: 0 });

  /**
   * 初始化提醒服务
   */
  useEffect(() => {
    const initializeReminderService = async () => {
      try {
        await reminderService.initialize();
        setTodayStats(reminderService.getTodayNotificationStats());
      } catch (error) {
        console.error('Failed to initialize reminder service:', error);
      }
    };

    initializeReminderService();

    // 监听提醒事件
    const handleReminderTriggered = (event: CustomEvent) => {
      const { reminder, patient, notification } = event.detail;
      toast.info(`用药提醒：${patient.name} - ${reminder.medicineName || reminder.medicationName}`, {
        description: `剂量：${reminder.dosage}`,
        action: {
          label: '已服药',
          onClick: () => reminderService.markReminderAsTaken(notification.id)
        }
      });
      setTodayStats(reminderService.getTodayNotificationStats());
    };

    const handleMedicationTaken = (event: CustomEvent) => {
      const notification: ReminderNotification = event.detail;
      toast.success('已记录服药');
      setTodayStats(reminderService.getTodayNotificationStats());
    };

    const handleNotificationClick = (event: CustomEvent) => {
      const notification: ReminderNotification = event.detail;
      // 可以导航到特定的提醒详情页面
      console.log('Notification clicked:', notification);
    };

    window.addEventListener('medicationReminderTriggered', handleReminderTriggered as EventListener);
    window.addEventListener('medicationTaken', handleMedicationTaken as EventListener);
    window.addEventListener('reminderNotificationClick', handleNotificationClick as EventListener);

    return () => {
      window.removeEventListener('medicationReminderTriggered', handleReminderTriggered as EventListener);
      window.removeEventListener('medicationTaken', handleMedicationTaken as EventListener);
      window.removeEventListener('reminderNotificationClick', handleNotificationClick as EventListener);
    };
  }, []);

  /**
   * 加载数据
   */
  useEffect(() => {
    const loadData = async () => {
      try {
        await Promise.all([
          loadReminders(),
          loadPatients()
        ]);
      } catch (error) {
        console.error('加载数据失败:', error);
        toast.error('数据加载失败');
      }
    };

    loadData();
  }, [loadReminders, loadPatients]);

  /**
   * 检查通知权限
   */
  useEffect(() => {
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  /**
   * 调度所有活跃的提醒
   */
  useEffect(() => {
    const scheduleActiveReminders = async () => {
      // 修复：使用 reminders 字段并添加防御性编程，确保数组不为空
      const activeReminders = (reminders || []).filter(reminder => reminder.isActive);
      
      for (const reminder of activeReminders) {
        try {
          await reminderService.scheduleReminder(reminder);
        } catch (error) {
          console.error(`Failed to schedule reminder ${reminder.id}:`, error);
        }
      }
    };

    // 修复：使用 reminders 字段并添加防御性检查
    if (reminders && reminders.length > 0) {
      scheduleActiveReminders();
    }
  }, [reminders]);

  /**
   * 过滤和排序提醒数据
   * 根据URL参数中的patientId过滤特定患者的提醒
   */
  useEffect(() => {
    // 修复：使用 reminders 字段并添加防御性编程，确保数组不为空
    let filtered = [...(reminders || [])];

    // 如果URL中有patientId参数，只显示该患者的提醒
    if (patientId) {
      filtered = filtered.filter(reminder => reminder.patientId === patientId);
    }

    // 搜索过滤
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(reminder => {
        const patient = patients.find(p => p.id === reminder.patientId);
        const patientName = patient?.name || '';
        const medicationName = reminder.medicineName || reminder.medicationName || '';
        
        return (
          patientName.toLowerCase().includes(term) ||
          medicationName.toLowerCase().includes(term) ||
          reminder.dosage.toLowerCase().includes(term) ||
          (reminder.notes && reminder.notes.toLowerCase().includes(term))
        );
      });
    }

    // 状态过滤
    if (filterStatus !== 'all') {
      filtered = filtered.filter(reminder => 
        filterStatus === 'active' ? reminder.isActive : !reminder.isActive
      );
    }

    // 按下次提醒时间排序
    filtered.sort((a, b) => {
      if (!a.isActive && b.isActive) return 1;
      if (a.isActive && !b.isActive) return -1;
      
      const nextTimeA = getNextReminderTime(a);
      const nextTimeB = getNextReminderTime(b);
      
      if (!nextTimeA && nextTimeB) return 1;
      if (nextTimeA && !nextTimeB) return -1;
      if (!nextTimeA && !nextTimeB) return 0;
      
      return nextTimeA.getTime() - nextTimeB.getTime();
    });

    setFilteredReminders(filtered);
  }, [reminders, patients, searchTerm, filterStatus, patientId]);

  /**
   * 获取患者姓名
   */
  const getPatientName = (patientId: string): string => {
    const patient = patients.find(p => p.id === patientId);
    return patient ? patient.name : '未知患者';
  };

  /**
   * 获取页面标题
   * 如果有patientId参数，显示患者姓名；否则显示通用标题
   */
  const getPageTitle = (): string => {
    if (patientId) {
      const patientName = getPatientName(patientId);
      return `${patientName} - 用药提醒`;
    }
    return '用药提醒';
  };

  /**
   * 计算下次提醒时间
   * 修复：添加防御性编程，处理 reminderTimes 可能为 undefined 的情况
   */
  const getNextReminderTime = (reminder: MedicationReminder): Date | null => {
    if (!reminder.isActive) return null;

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // 修复：检查 reminderTimes 是否存在且为数组，否则使用 reminderTime 作为备选
    let timeStrings: string[] = [];
    
    if (reminder.reminderTimes && Array.isArray(reminder.reminderTimes) && reminder.reminderTimes.length > 0) {
      // 使用 reminderTimes 数组
      timeStrings = reminder.reminderTimes;
    } else if (reminder.reminderTime) {
      // 使用单个 reminderTime 作为备选
      timeStrings = [reminder.reminderTime];
    } else {
      // 如果都没有，返回 null
      return null;
    }
    
    // 解析提醒时间，添加错误处理
    const times = timeStrings
      .filter(time => time && typeof time === 'string') // 过滤无效时间
      .map(time => {
        try {
          const [hours, minutes] = time.split(':').map(Number);
          // 验证时间格式是否有效
          if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
            return null;
          }
          const reminderTime = new Date(today);
          reminderTime.setHours(hours, minutes, 0, 0);
          return reminderTime;
        } catch (error) {
          console.warn('解析提醒时间失败:', time, error);
          return null;
        }
      })
      .filter(time => time !== null) as Date[]; // 过滤解析失败的时间

    // 如果没有有效的时间，返回 null
    if (times.length === 0) {
      return null;
    }

    // 按时间排序
    times.sort((a, b) => a.getTime() - b.getTime());

    // 找到今天最近的未来时间
    const todayFutureTimes = times.filter(time => time > now);
    if (todayFutureTimes.length > 0) {
      return todayFutureTimes[0];
    }

    // 如果今天没有未来时间，返回明天的第一个时间
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const firstTime = times[0];
    if (firstTime) {
      const tomorrowTime = new Date(tomorrow);
      tomorrowTime.setHours(firstTime.getHours(), firstTime.getMinutes(), 0, 0);
      return tomorrowTime;
    }

    return null;
  };

  /**
   * 格式化下次提醒时间显示
   */
  const formatNextReminderTime = (reminder: MedicationReminder): string => {
    const nextTime = getNextReminderTime(reminder);
    if (!nextTime) return '已停用';

    const now = new Date();
    const diffMs = nextTime.getTime() - now.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffMs < 0) return '已过期';
    if (diffHours < 1) return `${diffMinutes}分钟后`;
    if (diffHours < 24) return `${diffHours}小时${diffMinutes}分钟后`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}天后`;
  };



  /**
   * 处理返回操作
   * 如果有patientId参数，返回到患者详情页面；否则返回到特殊用药管理页面
   */
  const handleGoBack = () => {
    if (patientId) {
      // 如果是从患者详情页面进入的，返回到患者详情页面
      navigate(`/app/special-medicine/patient-detail/${patientId}`);
    } else {
      // 否则返回到特殊用药管理页面
      navigate('/app/special-medicine');
    }
  };

  /**
   * 处理添加提醒
   * 如果有patientId参数，自动填充患者信息
   */
  const handleAddReminder = () => {
    if (patientId) {
      navigate(`/app/special-medicine/reminder-form?patientId=${patientId}`);
    } else {
      navigate('/app/special-medicine/reminder-form');
    }
  };

  /**
   * 处理编辑提醒
   */
  const handleEditReminder = (reminderId: string) => {
    navigate(`/app/special-medicine/reminder-form?id=${reminderId}`);
  };

  /**
   * 处理删除提醒
   */
  const handleDeleteReminder = async (reminderId: string) => {
    if (window.confirm('确定要删除这个用药提醒吗？')) {
      try {
        // 清除调度的提醒
        await reminderService.clearReminder(reminderId);
        
        // 删除数据库记录
        await deleteMedicationReminder(reminderId);
        
        toast.success('提醒已删除');
      } catch (error) {
        console.error('删除提醒失败:', error);
        toast.error('删除失败，请重试');
      }
    }
  };

  /**
   * 切换提醒状态
   */
  const toggleReminderStatus = async (reminder: MedicationReminder) => {
    try {
      const updatedReminder = {
        ...reminder,
        isActive: !reminder.isActive
      };
      
      await updateMedicationReminder(reminder.id, updatedReminder);
      
      // 更新提醒调度
      if (updatedReminder.isActive) {
        await reminderService.scheduleReminder(updatedReminder);
        toast.success('提醒已启用');
      } else {
        await reminderService.clearReminder(reminder.id);
        toast.success('提醒已禁用');
      }
    } catch (error) {
      console.error('更新提醒状态失败:', error);
      toast.error('操作失败，请重试');
    }
  };

  /**
   * 格式化时间显示
   */
  const formatTime = (time: string): string => {
    return time;
  };

  /**
   * 格式化日期显示
   */
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('zh-CN');
  };



  return (
    <PageContainer
      title={getPageTitle()}
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <Plus className="w-5 h-5" />,
          onClick: handleAddReminder,
          label: "添加提醒"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 通知权限组件 */}
        <div className="mx-4 mt-4">
          <NotificationPermission />
        </div>

        {/* 今日统计 */}
        {notificationPermission === 'granted' && (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 mx-4 mt-4 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    今日提醒统计
                  </p>
                  <div className="flex items-center space-x-4 mt-1 text-xs text-blue-600 dark:text-blue-300">
                    <span>总计: {todayStats.total}</span>
                    <span>已发送: {todayStats.sent}</span>
                    <span>已服药: {todayStats.taken}</span>
                    <span>已忽略: {todayStats.dismissed}</span>
                  </div>
                </div>
              </div>
              {todayStats.total > 0 && (
                <div className="text-right">
                  <div className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    {Math.round((todayStats.taken / todayStats.total) * 100)}%
                  </div>
                  <div className="text-xs text-blue-600 dark:text-blue-300">
                    依从率
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 搜索和过滤栏 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center space-x-3 mb-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="搜索药品名称、剂量或备注..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`
                  w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600
                  rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                  placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500
                  focus:border-transparent transition-colors
                  ${isMobile ? 'text-sm' : 'text-base'}
                `}
              />
            </div>
          </div>

          {/* 状态过滤 */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600 dark:text-gray-400">状态:</span>
            <div className="flex items-center space-x-1">
              {[
                // 修复：使用 reminders 字段并添加防御性编程，确保数组不为空
                { key: 'all', label: '全部', count: (reminders || []).length },
                { key: 'active', label: '启用', count: (reminders || []).filter(r => r.isActive).length },
                { key: 'inactive', label: '停用', count: (reminders || []).filter(r => !r.isActive).length }
              ].map((filter) => (
                <button
                  key={filter.key}
                  onClick={() => setFilterStatus(filter.key as any)}
                  className={`
                    px-3 py-1 rounded-full text-xs transition-colors
                    ${filterStatus === filter.key
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                    }
                  `}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 提醒列表 */}
        <div className="flex-1 overflow-y-auto">
          {filteredReminders.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <Bell className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {searchTerm || filterStatus !== 'all' ? '未找到匹配的提醒' : '暂无用药提醒'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  {searchTerm || filterStatus !== 'all' 
                    ? '请尝试调整搜索条件或过滤器'
                    : '点击右上角按钮添加第一个用药提醒'
                  }
                </p>
                {!searchTerm && filterStatus === 'all' && (
                  <button
                    onClick={handleAddReminder}
                    className="px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                  >
                    添加提醒
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className={`
              ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
              space-y-4
            `}>
              {filteredReminders.map((reminder) => (
                <div
                  key={reminder.id}
                  className={`
                    bg-white dark:bg-gray-800 rounded-xl shadow-sm border
                    ${reminder.isActive 
                      ? 'border-gray-200 dark:border-gray-700' 
                      : 'border-gray-300 dark:border-gray-600 opacity-60'
                    }
                    p-4 hover:shadow-md transition-shadow
                  `}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        {reminder.isActive ? (
                          <Bell className="w-5 h-5 text-green-500" />
                        ) : (
                          <BellOff className="w-5 h-5 text-gray-400" />
                        )}
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {reminder.medicineName || reminder.medicationName}
                        </h3>
                        <span className={`
                          px-2 py-1 rounded-full text-xs
                          ${reminder.isActive 
                            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                          }
                        `}>
                          {reminder.isActive ? '启用' : '停用'}
                        </span>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <Pill className="w-4 h-4" />
                          <span>剂量: {reminder.dosage}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <User className="w-4 h-4" />
                          <span>{getPatientName(reminder.patientId)}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <Clock className="w-4 h-4" />
                          <span>
                            提醒时间: {(reminder.reminderTimes || []).map(formatTime).join(', ') || '未设置'}
                          </span>
                        </div>

                        {reminder.isActive && (
                          <div className="flex items-center space-x-2 text-sm">
                            <Calendar className="w-4 h-4 text-blue-500" />
                            <span className="text-blue-600 dark:text-blue-400 font-medium">
                              下次提醒: {formatNextReminderTime(reminder)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => toggleReminderStatus(reminder)}
                        onTouchStart={handleTouchStart}
                        onTouchEnd={handleTouchEnd}
                        className={`
                          p-2 rounded-lg transition-colors
                          ${reminder.isActive
                            ? 'text-green-500 hover:bg-green-50 dark:hover:bg-green-900/30'
                            : 'text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                          }
                        `}
                        title={reminder.isActive ? "停用提醒" : "启用提醒"}
                      >
                        {reminder.isActive ? <CheckCircle className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => handleEditReminder(reminder.id)}
                        onTouchStart={handleTouchStart}
                        onTouchEnd={handleTouchEnd}
                        className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
                        title="编辑"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteReminder(reminder.id)}
                        onTouchStart={handleTouchStart}
                        onTouchEnd={handleTouchEnd}
                        className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {reminder.notes && (
                    <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {reminder.notes}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 底部统计信息 */}
        <div className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className={`
                text-gray-600 dark:text-gray-300
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                共 {filteredReminders.length} 个提醒
              </span>
              <span className={`
                text-green-600 dark:text-green-400
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                启用: {filteredReminders.filter(r => r.isActive).length}
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Settings className="w-4 h-4 text-gray-400" />
              <span className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                通知: {notificationPermission === 'granted' ? '已开启' : '未开启'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default MedicationReminders;