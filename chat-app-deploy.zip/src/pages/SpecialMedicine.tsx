import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft,
  Pill,
  Plus,
  Search,
  Calendar,
  Clock,
  User,
  Users,
  FileText,
  Bell,
  BarChart3,
  Activity,
  ChevronRight
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';

/**
 * 特药管理页面组件
 * 重新设计为以患者为中心的交互流程
 */
const SpecialMedicine: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 获取状态管理中的数据
  const { 
    patients, 
    medicationRecords, 
    reminders,
    loadPatients,
    loadMedicationRecords,
    loadReminders
  } = useSpecialMedicineStore();

  const [stats, setStats] = useState({
    totalPatients: 0,
    totalMedications: 0,
    activeReminders: 0,
    todayRecords: 0
  });

  /**
   * 加载数据和统计信息
   */
  useEffect(() => {
    const loadData = async () => {
      await Promise.all([
        loadPatients(),
        loadMedicationRecords(),
        loadReminders()
      ]);
    };
    
    loadData();
  }, [loadPatients, loadMedicationRecords, loadReminders]);

  /**
   * 计算统计数据
   */
  useEffect(() => {
    const today = new Date().toDateString();
    const todayRecords = medicationRecords.filter(record => 
      new Date(record.recordDate).toDateString() === today
    ).length;
    
    const activeReminders = reminders.filter(reminder => 
      reminder.isActive
    ).length;

    setStats({
      totalPatients: patients.length,
      totalMedications: medicationRecords.length,
      activeReminders,
      todayRecords
    });
  }, [patients, medicationRecords, reminders]);

  /**
   * 处理返回到工作管理页面
   */
  const handleGoBack = () => {
    navigate('/app/work-management');
  };

  /**
   * 处理添加新患者
   */
  const handleAddPatient = () => {
    navigate('/app/special-medicine/patient-form');
  };

  /**
   * 处理进入患者管理
   */
  const handlePatientManagement = () => {
    navigate('/app/special-medicine/patients');
  };

  /**
   * 处理模块点击
   */
  const handleModuleClick = (path: string) => {
    navigate(path);
  };

  /**
   * 其他功能模块配置（次要功能）
   */
  const secondaryModules = [
    {
      id: 'records',
      title: '用药记录',
      description: '记录和查看用药情况',
      icon: <FileText className="w-5 h-5" />,
      color: 'from-green-500 to-green-600',
      count: stats.totalMedications,
      path: '/app/special-medicine/records'
    },
    {
      id: 'reminders',
      title: '用药提醒',
      description: '设置和管理用药提醒',
      icon: <Bell className="w-5 h-5" />,
      color: 'from-orange-500 to-orange-600',
      count: stats.activeReminders,
      path: '/app/special-medicine/reminders'
    },
    {
      id: 'statistics',
      title: '统计分析',
      description: '查看用药数据统计',
      icon: <BarChart3 className="w-5 h-5" />,
      color: 'from-purple-500 to-purple-600',
      count: stats.todayRecords,
      path: '/app/special-medicine/statistics'
    }
  ];

  return (
    <PageContainer
      title="特药管理"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 欢迎区域和引导 */}
        <div className={`
          bg-gradient-to-r from-blue-500 to-blue-600 text-white
          ${isMobile ? 'px-4 py-6' : 'px-6 py-8'}
        `}>
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-white/20 rounded-full p-2">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h1 className={`font-bold ${isMobile ? 'text-xl' : 'text-2xl'}`}>
                患者管理中心
              </h1>
              <p className={`opacity-90 ${isMobile ? 'text-sm' : 'text-base'}`}>
                从患者开始，管理所有用药信息
              </p>
            </div>
          </div>
          
          {/* 统计概览 */}
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <div className="text-2xl font-bold">{stats.totalPatients}</div>
              <div className="text-sm opacity-90">管理患者</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <div className="text-2xl font-bold">{stats.todayRecords}</div>
              <div className="text-sm opacity-90">今日记录</div>
            </div>
          </div>
        </div>

        {/* 主要操作区域 - 患者管理 */}
        <div className={`bg-white dark:bg-gray-800 ${isMobile ? 'mx-4 mt-4' : 'mx-6 mt-6'} rounded-xl shadow-sm border border-gray-200 dark:border-gray-700`}>
          <div className={`${isMobile ? 'p-4' : 'p-6'}`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className={`font-semibold text-gray-900 dark:text-white ${isMobile ? 'text-lg' : 'text-xl'}`}>
                开始管理患者
              </h2>
              <div className="text-sm text-gray-500 dark:text-gray-400">
                {stats.totalPatients} 位患者
              </div>
            </div>
            
            <p className={`text-gray-600 dark:text-gray-400 mb-6 ${isMobile ? 'text-sm' : 'text-base'}`}>
              选择现有患者或添加新患者，然后管理他们的用药记录、提醒和统计信息
            </p>

            {/* 主要操作按钮 */}
            <div className="grid grid-cols-1 gap-3">
              {/* 患者管理按钮 */}
              <button
                onClick={handlePatientManagement}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700
                  text-white rounded-lg p-4 flex items-center justify-between
                  transition-all duration-300 transform hover:scale-105 active:scale-95
                  shadow-md hover:shadow-lg
                `}
              >
                <div className="flex items-center space-x-3">
                  <Users className="w-6 h-6" />
                  <div className="text-left">
                    <div className={`font-semibold ${isMobile ? 'text-base' : 'text-lg'}`}>
                      查看所有患者
                    </div>
                    <div className={`opacity-90 ${isMobile ? 'text-xs' : 'text-sm'}`}>
                      管理患者档案和基本信息
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5" />
              </button>

              {/* 添加患者按钮 */}
              <button
                onClick={handleAddPatient}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  bg-white dark:bg-gray-700 border-2 border-dashed border-blue-300 dark:border-blue-600
                  text-blue-600 dark:text-blue-400 rounded-lg p-4 flex items-center justify-center space-x-3
                  transition-all duration-300 hover:border-blue-400 dark:hover:border-blue-500
                  hover:bg-blue-50 dark:hover:bg-blue-900/20
                `}
              >
                <Plus className="w-5 h-5" />
                <span className={`font-medium ${isMobile ? 'text-sm' : 'text-base'}`}>
                  添加新患者
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* 其他功能模块 */}
        <div className={`${isMobile ? 'px-4 py-4' : 'px-6 py-6'}`}>
          <h3 className={`
            font-semibold text-gray-900 dark:text-white mb-4
            ${isMobile ? 'text-base' : 'text-lg'}
          `}>
            其他功能
          </h3>
          
          <div className={`grid gap-3 ${isMobile ? 'grid-cols-1' : 'grid-cols-3'}`}>
            {secondaryModules.map((module) => (
              <div
                key={module.id}
                onClick={() => handleModuleClick(module.path)}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md
                  border border-gray-200 dark:border-gray-700
                  p-4 cursor-pointer transition-all duration-300
                  hover:border-gray-300 dark:hover:border-gray-600
                  transform hover:scale-105 active:scale-95
                `}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className={`
                    bg-gradient-to-r ${module.color} 
                    rounded-lg p-2 text-white
                  `}>
                    {module.icon}
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-gray-900 dark:text-white">
                      {module.count}
                    </div>
                  </div>
                </div>
                
                <h4 className={`
                  font-medium text-gray-900 dark:text-white mb-1
                  ${isMobile ? 'text-sm' : 'text-base'}
                `}>
                  {module.title}
                </h4>
                
                <p className={`
                  text-gray-600 dark:text-gray-400
                  ${isMobile ? 'text-xs' : 'text-sm'}
                `}>
                  {module.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* 底部提示信息 */}
        <div className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400">
              <User className="w-4 h-4" />
              <span className={`${isMobile ? 'text-xs' : 'text-sm'}`}>
                建议工作流程：选择患者 → 管理用药记录 → 设置提醒 → 查看统计
              </span>
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default SpecialMedicine;