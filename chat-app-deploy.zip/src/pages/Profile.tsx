/**
 * 飞鸽风格即时通讯App - 个人中心页面
 * 显示用户个人信息，提供设置和功能入口
 */

import React, { useState } from 'react';
import { 
  Settings, 
  Moon, 
  Sun, 
  User, 
  Bell, 
  Shield, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Camera,
  Edit3
} from 'lucide-react';
import { useAppStore } from '../store';
import { getInitials, getAvatarColor } from '../utils';
import PageContainer from '../components/Layout/PageContainer';
import { useIsMobile } from '../hooks/useResponsive';
import { useSafeArea } from '../hooks/useSafeArea';
import { useTouchFeedback } from '../hooks/useTouch';

/**
 * 菜单项组件
 */
interface MenuItemProps {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  onClick?: () => void;
  rightElement?: React.ReactNode;
  showArrow?: boolean;
  isMobile: boolean;
}

const MenuItem: React.FC<MenuItemProps> = ({ 
  icon, 
  title, 
  subtitle, 
  onClick, 
  rightElement, 
  showArrow = true,
  isMobile 
}) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  return (
    <button
      onClick={onClick}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className={`w-full flex items-center justify-between transition-colors ${
        isMobile 
          ? 'p-5 active:bg-gray-100 dark:active:bg-gray-700 touch-optimized' 
          : 'p-4 hover:bg-gray-50 dark:hover:bg-gray-800'
      }`}
    >
      <div className="flex items-center space-x-3">
        <div className="text-gray-600 dark:text-gray-400">
          {icon}
        </div>
        <div className="text-left">
          <div className={`text-gray-900 dark:text-white font-medium ${
            isMobile ? 'text-lg' : 'text-base'
          }`}>
            {title}
          </div>
          {subtitle && (
            <div className={`text-gray-500 dark:text-gray-400 ${
              isMobile ? 'text-base' : 'text-sm'
            }`}>
              {subtitle}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center space-x-2">
        {rightElement}
        {showArrow && (
          <ChevronRight className={`text-gray-400 ${
            isMobile ? 'w-5 h-5' : 'w-4 h-4'
          }`} />
        )}
      </div>
    </button>
  );
};

/**
 * 个人中心页面组件
 */
const Profile: React.FC = () => {
  const { currentUser, theme, toggleTheme, logout } = useAppStore();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editForm, setEditForm] = useState({
    username: currentUser?.username || '',
    bio: currentUser?.bio || '',
    phone: currentUser?.phone || ''
  });

  // 移动端优化Hooks
  const isMobile = useIsMobile();
  const { top: safeAreaTop } = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  /**
   * 处理主题切换
   */
  const handleThemeToggle = () => {
    toggleTheme();
  };

  /**
   * 处理退出登录
   */
  const handleLogout = () => {
    logout();
    setShowLogoutConfirm(false);
  };

  /**
   * 处理个人信息编辑
   */
  const handleEditProfile = () => {
    // 这里可以添加更新用户信息的逻辑
    console.log('更新用户信息:', editForm);
    setShowEditProfile(false);
  };

  return (
    <>
      <PageContainer
        title="我"
        headerActions={
          <button
            onClick={() => setShowEditProfile(true)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`text-gray-600 dark:text-gray-400 transition-colors ${
              isMobile 
                ? 'p-3 active:text-gray-900 dark:active:text-white touch-optimized' 
                : 'p-2 hover:text-gray-900 dark:hover:text-white'
            }`}
            aria-label="编辑个人信息"
          >
            <Edit3 className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />
          </button>
        }
        contentClassName="px-0 py-0 bg-gray-50 dark:bg-gray-900"
      >

      {/* 个人信息卡片 */}
      <div className={`bg-white dark:bg-gray-800 overflow-hidden ${
        isMobile 
          ? 'mx-4 mt-6 rounded-3xl mobile-shadow' 
          : 'mx-4 mt-4 rounded-2xl'
      }`}>
        <div className={`${isMobile ? 'p-8' : 'p-6'}`}>
          <div className="flex items-center space-x-4">
            {/* 头像 */}
            <div className="relative">
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.username}
                  className={`object-cover ${
                    isMobile 
                      ? 'w-20 h-20 rounded-3xl' 
                      : 'w-16 h-16 rounded-2xl'
                  }`}
                />
              ) : (
                <div
                  className={`flex items-center justify-center text-white font-medium ${
                    isMobile 
                      ? 'w-20 h-20 rounded-3xl text-2xl' 
                      : 'w-16 h-16 rounded-2xl text-xl'
                  }`}
                  style={{ backgroundColor: getAvatarColor(currentUser?.username || '') }}
                >
                  {getInitials(currentUser?.username || '')}
                </div>
              )}
              <button 
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`absolute bg-green-500 text-white rounded-full transition-colors ${
                  isMobile 
                    ? '-bottom-2 -right-2 p-2 active:bg-green-600 touch-optimized' 
                    : '-bottom-1 -right-1 p-1.5 hover:bg-green-600'
                }`}
              >
                <Camera className={`${isMobile ? 'w-4 h-4' : 'w-3 h-3'}`} />
              </button>
            </div>

            {/* 用户信息 */}
            <div className="flex-1">
              <h2 className={`font-semibold text-gray-900 dark:text-white mb-1 ${
                isMobile ? 'text-2xl' : 'text-xl'
              }`}>
                {currentUser?.username}
              </h2>
              <p className={`text-gray-500 dark:text-gray-400 mb-2 ${
                isMobile ? 'text-base' : 'text-sm'
              }`}>
                飞鸽号: {currentUser?.id?.slice(0, 8)}
              </p>
              {currentUser?.bio && (
                <p className={`text-gray-600 dark:text-gray-300 ${
                  isMobile ? 'text-base' : 'text-sm'
                }`}>
                  {currentUser.bio}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 功能菜单 */}
      <div className={`flex-1 ${isMobile ? 'mt-6' : 'mt-4'} ${
        isMobile ? 'scroll-smooth-mobile' : ''
      } overflow-y-auto`}>
        {/* 账户设置 */}
        <div className={`bg-white dark:bg-gray-800 overflow-hidden mb-4 ${
          isMobile 
            ? 'mx-4 rounded-3xl mobile-shadow' 
            : 'mx-4 rounded-2xl'
        }`}>
          <MenuItem
            icon={<User className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
            title="个人信息"
            subtitle="编辑个人资料"
            onClick={() => setShowEditProfile(true)}
            isMobile={isMobile}
          />
          <div className="border-t border-gray-100 dark:border-gray-700">
            <MenuItem
              icon={<Bell className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
              title="消息通知"
              subtitle="管理通知设置"
              isMobile={isMobile}
            />
          </div>
          <div className="border-t border-gray-100 dark:border-gray-700">
            <MenuItem
              icon={<Shield className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
              title="隐私设置"
              subtitle="保护您的隐私"
              isMobile={isMobile}
            />
          </div>
        </div>

        {/* 应用设置 */}
        <div className={`bg-white dark:bg-gray-800 overflow-hidden mb-4 ${
          isMobile 
            ? 'mx-4 rounded-3xl mobile-shadow' 
            : 'mx-4 rounded-2xl'
        }`}>
          <MenuItem
            icon={theme === 'dark' ? 
              <Sun className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} /> : 
              <Moon className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />
            }
            title="深色模式"
            subtitle={theme === 'dark' ? "已开启" : "已关闭"}
            onClick={handleThemeToggle}
            rightElement={
              <div className={`rounded-full p-1 transition-colors ${
                isMobile ? 'w-14 h-7' : 'w-12 h-6'
              } ${theme === 'dark' ? 'bg-green-500' : 'bg-gray-300'}`}>
                <div className={`bg-white rounded-full transition-transform ${
                  isMobile ? 'w-5 h-5' : 'w-4 h-4'
                } ${theme === 'dark' ? 
                  (isMobile ? 'translate-x-7' : 'translate-x-6') : 
                  'translate-x-0'
                }`} />
              </div>
            }
            showArrow={false}
            isMobile={isMobile}
          />
          <div className="border-t border-gray-100 dark:border-gray-700">
            <MenuItem
              icon={<Settings className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
              title="通用设置"
              subtitle="语言、字体等"
              isMobile={isMobile}
            />
          </div>
        </div>

        {/* 开发者工具 */}
        <div className={`bg-white dark:bg-gray-800 overflow-hidden mb-4 ${
          isMobile 
            ? 'mx-4 rounded-3xl mobile-shadow' 
            : 'mx-4 rounded-2xl'
        }`}>
          <MenuItem
            icon={<Settings className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
            title="原生功能测试"
            subtitle="测试相机、通知等原生功能"
            onClick={() => window.location.href = '/app/native-test'}
            isMobile={isMobile}
          />
        </div>

        {/* 帮助与支持 */}
        <div className={`bg-white dark:bg-gray-800 overflow-hidden mb-4 ${
          isMobile 
            ? 'mx-4 rounded-3xl mobile-shadow' 
            : 'mx-4 rounded-2xl'
        }`}>
          <MenuItem
            icon={<HelpCircle className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
            title="帮助与反馈"
            subtitle="获取帮助或提供反馈"
            isMobile={isMobile}
          />
        </div>

        {/* 退出登录 */}
        <div className={`bg-white dark:bg-gray-800 overflow-hidden mb-4 ${
          isMobile 
            ? 'mx-4 rounded-3xl mobile-shadow' 
            : 'mx-4 rounded-2xl'
        }`}>
          <MenuItem
            icon={<LogOut className={`text-red-500 ${isMobile ? 'w-6 h-6' : 'w-5 h-5'}`} />}
            title="退出登录"
            onClick={() => setShowLogoutConfirm(true)}
            showArrow={false}
            isMobile={isMobile}
          />
        </div>
      </div>
    </PageContainer>

        {/* 退出登录确认对话框 */}
        {showLogoutConfirm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className={`bg-white dark:bg-gray-800 w-full max-w-sm ${
              isMobile ? 'rounded-3xl mobile-shadow' : 'rounded-2xl'
            }`}>
              <div className={`text-center ${isMobile ? 'p-8' : 'p-6'}`}>
                <h3 className={`font-semibold text-gray-900 dark:text-white mb-2 ${
                  isMobile ? 'text-xl' : 'text-lg'
                }`}>
                  确认退出登录？
                </h3>
                <p className={`text-gray-600 dark:text-gray-400 mb-6 ${
                  isMobile ? 'text-lg' : 'text-base'
                }`}>
                  退出后需要重新登录才能使用
                </p>
                <div className="flex space-x-3">
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    onTouchStart={handleTouchStart}
                    onTouchEnd={handleTouchEnd}
                    className={`flex-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                      isMobile 
                        ? 'py-4 px-4 text-lg rounded-2xl active:bg-gray-200 dark:active:bg-gray-600 touch-optimized' 
                        : 'py-3 px-4 text-base rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600'
                    }`}
                  >
                    取消
                  </button>
                  <button
                    onClick={handleLogout}
                    onTouchStart={handleTouchStart}
                    onTouchEnd={handleTouchEnd}
                    className={`flex-1 bg-red-500 text-white transition-colors ${
                      isMobile 
                        ? 'py-4 px-4 text-lg rounded-2xl active:bg-red-600 touch-optimized' 
                        : 'py-3 px-4 text-base rounded-xl hover:bg-red-600'
                    }`}
                  >
                    退出
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 编辑个人信息对话框 */}
        {showEditProfile && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className={`bg-white dark:bg-gray-800 w-full max-w-md ${
              isMobile ? 'rounded-3xl mobile-shadow' : 'rounded-2xl'
            }`}>
              <div className={`flex items-center justify-between border-b border-gray-200 dark:border-gray-700 ${
                isMobile ? 'p-6' : 'p-4'
              }`}>
                <h2 className={`font-semibold text-gray-900 dark:text-white ${
                  isMobile ? 'text-xl' : 'text-lg'
                }`}>
                  编辑个人信息
                </h2>
                <button
                  onClick={() => setShowEditProfile(false)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`text-gray-500 transition-colors ${
                    isMobile 
                      ? 'p-2 text-xl active:text-gray-700 dark:active:text-gray-300 touch-optimized' 
                      : 'hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  ✕
                </button>
              </div>
              
              <div className={`space-y-4 ${isMobile ? 'p-6' : 'p-4'}`}>
                <div>
                  <label className={`block font-medium text-gray-700 dark:text-gray-300 mb-2 ${
                    isMobile ? 'text-base' : 'text-sm'
                  }`}>
                    用户名
                  </label>
                  <input
                    type="text"
                    value={editForm.username}
                    onChange={(e) => setEditForm({ ...editForm, username: e.target.value })}
                    className={`w-full border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white ${
                      isMobile 
                        ? 'px-4 py-3 text-lg rounded-2xl mobile-border-radius' 
                        : 'px-3 py-2 text-base rounded-lg'
                    }`}
                  />
                </div>
                
                <div>
                  <label className={`block font-medium text-gray-700 dark:text-gray-300 mb-2 ${
                    isMobile ? 'text-base' : 'text-sm'
                  }`}>
                    个性签名
                  </label>
                  <textarea
                    value={editForm.bio}
                    onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                    rows={3}
                    className={`w-full border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none ${
                      isMobile 
                        ? 'px-4 py-3 text-lg rounded-2xl mobile-border-radius' 
                        : 'px-3 py-2 text-base rounded-lg'
                    }`}
                    placeholder="写点什么介绍一下自己..."
                  />
                </div>
                
                <div>
                  <label className={`block font-medium text-gray-700 dark:text-gray-300 mb-2 ${
                    isMobile ? 'text-base' : 'text-sm'
                  }`}>
                    手机号
                  </label>
                  <input
                    type="tel"
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    className={`w-full border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white ${
                      isMobile 
                        ? 'px-4 py-3 text-lg rounded-2xl mobile-border-radius' 
                        : 'px-3 py-2 text-base rounded-lg'
                    }`}
                  />
                </div>
              </div>
              
              <div className={`flex items-center justify-end space-x-3 border-t border-gray-200 dark:border-gray-700 ${
                isMobile ? 'p-6' : 'p-4'
              }`}>
                <button
                  onClick={() => setShowEditProfile(false)}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`text-gray-600 dark:text-gray-400 transition-colors ${
                    isMobile 
                      ? 'px-6 py-3 text-lg active:text-gray-900 dark:active:text-white touch-optimized' 
                      : 'px-4 py-2 text-base hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  取消
                </button>
                <button
                  onClick={handleEditProfile}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  className={`bg-green-500 text-white transition-colors ${
                    isMobile 
                      ? 'px-8 py-3 text-lg rounded-2xl active:bg-green-600 touch-optimized' 
                      : 'px-6 py-2 text-base rounded-lg hover:bg-green-600'
                  }`}
                >
                  保存
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  };

export default Profile;