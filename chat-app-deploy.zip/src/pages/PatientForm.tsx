import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft,
  Save,
  User,
  Phone,
  Calendar,
  MapPin,
  CreditCard,
  AlertCircle,
  Check,
  FileText
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { Patient } from '../types';

/**
 * 患者表单页面组件
 */
const PatientForm: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const patientId = searchParams.get('id');
  const isEdit = !!patientId;
  
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 获取状态管理中的数据
  const { 
    patients,
    createPatient,
    updatePatient,
    loadPatients
  } = useSpecialMedicineStore();

  // 表单状态
  const [formData, setFormData] = useState({
    name: '',
    gender: 'male' as 'male' | 'female',
    birthDate: '',
    phone: '',
    idCard: '',
    address: '',
    emergencyContact: '',
    emergencyPhone: '',
    medicalHistory: '',
    allergies: '',
    doctor: '',
    diagnosis: '',
    treatment: '',
    isActive: true
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  /**
   * 加载患者数据（编辑模式）
   */
  useEffect(() => {
    if (isEdit && patientId) {
      loadPatients().then(() => {
        const patient = patients.find(p => p.id === patientId);
        if (patient) {
          setFormData({
            name: patient.name,
            gender: patient.gender,
            birthDate: patient.birthDate || '',
            phone: patient.phone,
            idCard: patient.idCard || '',
            address: patient.address || '',
            emergencyContact: patient.emergencyContact || '',
            emergencyPhone: patient.emergencyPhone || '',
            medicalHistory: patient.medicalHistory || '',
            allergies: Array.isArray(patient.allergies) ? patient.allergies.join(', ') : (patient.allergies || ''),
            doctor: patient.doctor,
            diagnosis: patient.diagnosis,
            treatment: patient.treatment,
            isActive: patient.isActive
          });
        }
      });
    }
  }, [isEdit, patientId, patients, loadPatients]);

  /**
   * 处理返回
   */
  const handleGoBack = () => {
    navigate('/app/special-medicine/patients');
  };

  /**
   * 处理表单输入变化
   */
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // 清除对应字段的错误
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  /**
   * 验证表单
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // 必填字段验证
    if (!formData.name.trim()) {
      newErrors.name = '请输入患者姓名';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = '请输入联系电话';
    } else {
      // 支持多种电话格式：手机号、固定电话、400/800电话等
      const phonePattern = /^[\d\s-]{7,20}$/;
      const cleanPhone = formData.phone.replace(/[\s-]/g, '');
      if (!phonePattern.test(formData.phone) || cleanPhone.length < 7 || cleanPhone.length > 15) {
        newErrors.phone = '请输入正确的联系电话（支持手机号、固定电话、400/800电话等）';
      }
    }

    if (!formData.birthDate) {
      newErrors.birthDate = '请选择出生日期';
    } else {
      const birthDate = new Date(formData.birthDate);
      const today = new Date();
      if (birthDate > today) {
        newErrors.birthDate = '出生日期不能晚于今天';
      }
    }

    // 诊断信息验证 - 核心字段之一，必填
    if (!formData.diagnosis.trim()) {
      newErrors.diagnosis = '请输入诊断信息';
    }

    if (!formData.idCard.trim()) {
      newErrors.idCard = '请输入身份证号';
    } else if (!/^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/.test(formData.idCard)) {
      newErrors.idCard = '请输入正确的身份证号';
    }

    // 紧急联系人电话验证（如果填写了紧急联系人）
    if (formData.emergencyContact && !formData.emergencyPhone) {
      newErrors.emergencyPhone = '请输入紧急联系人电话';
    } else if (formData.emergencyPhone) {
      // 紧急联系人电话支持多种格式：
      // 1. 手机号：1[3-9]\d{9}
      // 2. 固定电话：010-12345678、0755-87654321
      // 3. 简化固定电话：01012345678
      // 4. 400/800电话：400-123-4567、8001234567
      // 5. 基本格式：只包含数字、短横线、空格的电话号码
      const phonePattern = /^[\d\s-]{7,20}$/;
      const cleanPhone = formData.emergencyPhone.replace(/[\s-]/g, '');
      
      if (!phonePattern.test(formData.emergencyPhone) || cleanPhone.length < 7 || cleanPhone.length > 15) {
        newErrors.emergencyPhone = '请输入正确的紧急联系人电话';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * 处理表单提交
   * 修复：正确处理 createPatient 返回值，添加错误处理和用户友好提示
   */
  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      const patientData: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'> = {
        ...formData,
        allergies: formData.allergies ? formData.allergies.split(',').map(item => item.trim()).filter(item => item) : []
      };

      if (isEdit && patientId) {
        // 更新现有患者
        const success = await updatePatient(patientId, {
          ...patientData,
          updatedAt: new Date()
        });
        
        if (success) {
          setShowSuccess(true);
          setTimeout(() => {
            navigate('/app/special-medicine/patients');
          }, 1500);
        } else {
          throw new Error('更新患者信息失败');
        }
      } else {
        // 创建新患者 - 修复：createPatient 现在直接返回患者ID字符串
        const newPatientId = await createPatient(patientData);
        console.log('新患者创建成功，ID:', newPatientId);
        
        setShowSuccess(true);
        setTimeout(() => {
          // 直接导航到新创建患者的详情页面
          navigate(`/app/special-medicine/patient-detail/${newPatientId}`);
        }, 1500);
      }
    } catch (error) {
      console.error('保存患者信息失败:', error);
      
      // 用户友好的错误提示
      const errorMessage = error instanceof Error ? error.message : '保存患者信息失败，请重试';
      setErrors(prev => ({
        ...prev,
        submit: errorMessage
      }));
      
      // 3秒后清除错误信息
      setTimeout(() => {
        setErrors(prev => {
          const { submit, ...rest } = prev;
          return rest;
        });
      }, 3000);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <PageContainer
      title={isEdit ? '编辑患者' : '添加患者'}
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <Save className="w-5 h-5" />,
          onClick: handleSubmit,
          label: "保存",
          disabled: isSubmitting
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        <div className="flex-1 overflow-y-auto">
          <div className={`
            ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
          `}>
            <form className="space-y-6">
              {/* 基本信息 - 调整为突出显示核心五个字段：姓名、年龄、性别、联系电话、诊断 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className={`
                  font-semibold text-gray-900 dark:text-white mb-4
                  ${isMobile ? 'text-base' : 'text-lg'}
                `}>
                  基本信息
                </h3>
                
                <div className="space-y-4">
                  {/* 姓名 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      患者姓名 <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="请输入患者姓名"
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.name ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.name}
                      </p>
                    )}
                  </div>

                  {/* 性别 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      性别 <span className="text-red-500">*</span>
                    </label>
                    <div className="flex space-x-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="gender"
                          value="male"
                          checked={formData.gender === 'male'}
                          onChange={(e) => handleInputChange('gender', e.target.value)}
                          className="mr-2 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-gray-700 dark:text-gray-300">男</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="gender"
                          value="female"
                          checked={formData.gender === 'female'}
                          onChange={(e) => handleInputChange('gender', e.target.value)}
                          className="mr-2 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-gray-700 dark:text-gray-300">女</span>
                      </label>
                    </div>
                  </div>

                  {/* 出生日期 - 用于计算年龄 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      出生日期 <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="date"
                        value={formData.birthDate}
                        onChange={(e) => handleInputChange('birthDate', e.target.value)}
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.birthDate ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                    {errors.birthDate && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.birthDate}
                      </p>
                    )}
                  </div>

                  {/* 联系电话 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      联系电话 <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        placeholder="请输入手机号码"
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.phone ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                    {errors.phone && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.phone}
                      </p>
                    )}
                  </div>

                  {/* 诊断信息 - 核心字段之一 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      诊断信息 <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                      <textarea
                        value={formData.diagnosis}
                        onChange={(e) => handleInputChange('diagnosis', e.target.value)}
                        placeholder="请输入患者诊断信息"
                        rows={3}
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.diagnosis ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                          resize-none
                        `}
                      />
                    </div>
                    {errors.diagnosis && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.diagnosis}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* 补充信息 - 将身份证号和地址移到这里 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className={`
                  font-semibold text-gray-900 dark:text-white mb-4
                  ${isMobile ? 'text-base' : 'text-lg'}
                `}>
                  补充信息
                </h3>
                
                <div className="space-y-4">
                  {/* 身份证号 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      身份证号 <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={formData.idCard}
                        onChange={(e) => handleInputChange('idCard', e.target.value)}
                        placeholder="请输入身份证号"
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.idCard ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                    {errors.idCard && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.idCard}
                      </p>
                    )}
                  </div>

                  {/* 地址 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      联系地址
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                      <textarea
                        value={formData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        placeholder="请输入详细地址"
                        rows={3}
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border border-gray-200 dark:border-gray-600
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                          resize-none
                        `}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* 紧急联系人 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className={`
                  font-semibold text-gray-900 dark:text-white mb-4
                  ${isMobile ? 'text-base' : 'text-lg'}
                `}>
                  紧急联系人
                </h3>
                
                <div className="space-y-4">
                  {/* 紧急联系人姓名 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      联系人姓名
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={formData.emergencyContact}
                        onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                        placeholder="请输入紧急联系人姓名"
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border border-gray-200 dark:border-gray-600
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                  </div>

                  {/* 紧急联系人电话 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      联系人电话
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        value={formData.emergencyPhone}
                        onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
                        placeholder="请输入紧急联系人电话"
                        className={`
                          w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700
                          border ${errors.emergencyPhone ? 'border-red-500' : 'border-gray-200 dark:border-gray-600'}
                          rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                          text-gray-900 dark:text-white placeholder-gray-500
                          ${isMobile ? 'text-sm' : 'text-base'}
                        `}
                      />
                    </div>
                    {errors.emergencyPhone && (
                      <p className="mt-1 text-sm text-red-500 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        {errors.emergencyPhone}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* 医疗信息 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className={`
                  font-semibold text-gray-900 dark:text-white mb-4
                  ${isMobile ? 'text-base' : 'text-lg'}
                `}>
                  医疗信息
                </h3>
                
                <div className="space-y-4">
                  {/* 病史 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      既往病史
                    </label>
                    <textarea
                      value={formData.medicalHistory}
                      onChange={(e) => handleInputChange('medicalHistory', e.target.value)}
                      placeholder="请输入患者既往病史，如高血压、糖尿病等"
                      rows={4}
                      className={`
                        w-full px-4 py-3 bg-gray-50 dark:bg-gray-700
                        border border-gray-200 dark:border-gray-600
                        rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                        text-gray-900 dark:text-white placeholder-gray-500
                        ${isMobile ? 'text-sm' : 'text-base'}
                        resize-none
                      `}
                    />
                  </div>

                  {/* 过敏史 */}
                  <div>
                    <label className={`
                      block text-gray-700 dark:text-gray-300 mb-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}>
                      过敏史
                    </label>
                    <textarea
                      value={formData.allergies}
                      onChange={(e) => handleInputChange('allergies', e.target.value)}
                      placeholder="请输入患者过敏史，如药物过敏、食物过敏等"
                      rows={3}
                      className={`
                        w-full px-4 py-3 bg-gray-50 dark:bg-gray-700
                        border border-gray-200 dark:border-gray-600
                        rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
                        text-gray-900 dark:text-white placeholder-gray-500
                        ${isMobile ? 'text-sm' : 'text-base'}
                        resize-none
                      `}
                    />
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>

        {/* 底部操作按钮 */}
        <div className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
        `}>
          {/* 错误提示显示区域 */}
          {errors.submit && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-center text-red-600 dark:text-red-400">
                <AlertCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className={`${isMobile ? 'text-sm' : 'text-base'}`}>
                  {errors.submit}
                </span>
              </div>
            </div>
          )}
          
          <div className="flex space-x-4">
            <button
              onClick={handleGoBack}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`
                flex-1 px-6 py-3 bg-gray-100 dark:bg-gray-700 
                text-gray-700 dark:text-gray-300 rounded-lg
                hover:bg-gray-200 dark:hover:bg-gray-600
                transition-colors duration-200
                ${isMobile ? 'text-sm' : 'text-base'}
              `}
            >
              取消
            </button>
            <button
              onClick={handleSubmit}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              disabled={isSubmitting}
              className={`
                flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 
                hover:from-blue-600 hover:to-blue-700
                disabled:from-gray-400 disabled:to-gray-500
                text-white rounded-lg transition-all duration-200
                ${isMobile ? 'text-sm' : 'text-base'}
                flex items-center justify-center space-x-2
                ${isSubmitting ? 'cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>保存中...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{isEdit ? '更新' : '保存'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 成功提示 */}
      {showSuccess && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6 max-w-sm w-full text-center">
            <div className="bg-green-100 dark:bg-green-900/30 rounded-full p-3 w-16 h-16 mx-auto mb-4">
              <Check className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {isEdit ? '更新成功' : '添加成功'}
            </h3>
            <p className="text-gray-600 dark:text-gray-300">
              患者信息已{isEdit ? '更新' : '保存'}
            </p>
          </div>
        </div>
      )}
    </PageContainer>
  );
};

export default PatientForm;