/**
 * 原生功能测试页面
 * 用于测试和验证所有Capacitor原生功能的可用性
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Camera, Image, FileText, Bell, Smartphone, Wifi, Battery, Vibrate } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CapacitorService } from '../services/capacitorService';
import { fileService } from '../services/fileService';
import { notificationService } from '../services/notificationService';
import { toast } from 'sonner';
import { useIsMobile } from '../hooks';

interface TestResult {
  name: string;
  status: 'pending' | 'success' | 'error';
  message: string;
}

/**
 * 原生功能测试页面组件
 */
const NativeFeaturesTest: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isNative, setIsNative] = useState(false);
  const [platform, setPlatform] = useState('');
  const [deviceInfo, setDeviceInfo] = useState<any>(null);
  const [networkStatus, setNetworkStatus] = useState<any>(null);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);

  /**
   * 初始化页面
   */
  useEffect(() => {
    const init = async () => {
      setIsNative(CapacitorService.isNative());
      setPlatform(CapacitorService.getPlatform());
      
      // 获取设备信息
      try {
        const info = await CapacitorService.getDeviceInfo();
        setDeviceInfo(info);
      } catch (error) {
        console.error('获取设备信息失败:', error);
      }
      
      // 获取网络状态
      try {
        const status = await CapacitorService.getNetworkStatus();
        setNetworkStatus(status);
      } catch (error) {
        console.error('获取网络状态失败:', error);
      }
    };
    
    init();
  }, []);

  /**
   * 更新测试结果
   */
  const updateTestResult = (name: string, status: 'pending' | 'success' | 'error', message: string) => {
    setTestResults(prev => {
      const existing = prev.find(r => r.name === name);
      if (existing) {
        existing.status = status;
        existing.message = message;
        return [...prev];
      } else {
        return [...prev, { name, status, message }];
      }
    });
  };

  /**
   * 测试相机功能
   */
  const testCamera = async () => {
    updateTestResult('相机拍照', 'pending', '正在测试...');
    try {
      const imageInfo = await fileService.capturePhoto();
      if (imageInfo && imageInfo.data) {
        updateTestResult('相机拍照', 'success', '拍照功能正常');
        toast.success('相机拍照测试成功');
      } else {
        updateTestResult('相机拍照', 'error', '拍照失败');
        toast.error('相机拍照测试失败');
      }
    } catch (error) {
      updateTestResult('相机拍照', 'error', `拍照失败: ${error}`);
      toast.error('相机拍照测试失败');
    }
  };

  /**
   * 测试相册功能
   */
  const testGallery = async () => {
    updateTestResult('相册选择', 'pending', '正在测试...');
    try {
      const imageInfo = await fileService.selectFromGallery();
      if (imageInfo && imageInfo.data) {
        updateTestResult('相册选择', 'success', '相册选择功能正常');
        toast.success('相册选择测试成功');
      } else {
        updateTestResult('相册选择', 'error', '相册选择失败');
        toast.error('相册选择测试失败');
      }
    } catch (error) {
      updateTestResult('相册选择', 'error', `相册选择失败: ${error}`);
      toast.error('相册选择测试失败');
    }
  };

  /**
   * 测试文件选择功能
   */
  const testFileSelect = async () => {
    updateTestResult('文件选择', 'pending', '正在测试...');
    try {
      const fileInfo = await fileService.selectFile();
      if (fileInfo && fileInfo.data) {
        updateTestResult('文件选择', 'success', `文件选择功能正常 (${fileInfo.name})`);
        toast.success('文件选择测试成功');
      } else {
        updateTestResult('文件选择', 'error', '文件选择失败');
        toast.error('文件选择测试失败');
      }
    } catch (error) {
      updateTestResult('文件选择', 'error', `文件选择失败: ${error}`);
      toast.error('文件选择测试失败');
    }
  };

  /**
   * 测试本地通知功能
   */
  const testLocalNotification = async () => {
    updateTestResult('本地通知', 'pending', '正在测试...');
    try {
      await notificationService.sendLocalNotification({
        title: '测试通知',
        body: '这是一个测试通知，用于验证通知功能是否正常工作。',
        icon: '/favicon.ico'
      });
      updateTestResult('本地通知', 'success', '本地通知功能正常');
      toast.success('本地通知测试成功');
    } catch (error) {
      updateTestResult('本地通知', 'error', `本地通知失败: ${error}`);
      toast.error('本地通知测试失败');
    }
  };

  /**
   * 测试触觉反馈功能
   */
  const testHapticFeedback = async () => {
    updateTestResult('触觉反馈', 'pending', '正在测试...');
    try {
      await CapacitorService.vibrate('medium');
      updateTestResult('触觉反馈', 'success', '触觉反馈功能正常');
      toast.success('触觉反馈测试成功');
    } catch (error) {
      updateTestResult('触觉反馈', 'error', `触觉反馈失败: ${error}`);
      toast.error('触觉反馈测试失败');
    }
  };

  /**
   * 运行所有测试
   */
  const runAllTests = async () => {
    setIsRunningTests(true);
    setTestResults([]);
    
    try {
      // 依次运行所有测试
      await testLocalNotification();
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      await testHapticFeedback();
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 相机和文件测试需要用户交互，不在自动测试中运行
      toast.success('自动测试完成，请手动测试相机和文件功能');
    } catch (error) {
      console.error('测试过程中出现错误:', error);
      toast.error('测试过程中出现错误');
    } finally {
      setIsRunningTests(false);
    }
  };

  /**
   * 返回上一页
   */
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className={`min-h-screen bg-gray-50 dark:bg-gray-900 ${isMobile ? 'pb-20' : ''}`}>
      {/* 头部 */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center px-4 py-3">
          <button
            onClick={handleBack}
            className="p-2 -ml-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="ml-2 text-lg font-semibold text-gray-900 dark:text-white">
            原生功能测试
          </h1>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* 环境信息 */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">环境信息</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">运行环境:</span>
              <span className={`font-medium ${isNative ? 'text-green-600' : 'text-blue-600'}`}>
                {isNative ? '原生应用' : 'Web浏览器'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">平台:</span>
              <span className="font-medium text-gray-900 dark:text-white">{platform}</span>
            </div>
            {deviceInfo && (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">设备型号:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{deviceInfo.model}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">操作系统:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {deviceInfo.operatingSystem} {deviceInfo.osVersion}
                  </span>
                </div>
              </>
            )}
            {networkStatus && (
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">网络状态:</span>
                <span className={`font-medium ${networkStatus.connected ? 'text-green-600' : 'text-red-600'}`}>
                  {networkStatus.connected ? '已连接' : '未连接'} ({networkStatus.connectionType})
                </span>
              </div>
            )}
          </div>
        </div>

        {/* 功能测试按钮 */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">功能测试</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            <button
              onClick={testCamera}
              className="flex items-center justify-center p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
            >
              <Camera className="w-5 h-5 mr-2" />
              测试相机拍照
            </button>
            
            <button
              onClick={testGallery}
              className="flex items-center justify-center p-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
            >
              <Image className="w-5 h-5 mr-2" />
              测试相册选择
            </button>
            
            <button
              onClick={testFileSelect}
              className="flex items-center justify-center p-3 bg-purple-500 hover:bg-purple-600 text-white rounded-lg transition-colors"
            >
              <FileText className="w-5 h-5 mr-2" />
              测试文件选择
            </button>
            
            <button
              onClick={testLocalNotification}
              className="flex items-center justify-center p-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors"
            >
              <Bell className="w-5 h-5 mr-2" />
              测试本地通知
            </button>
            
            <button
              onClick={testHapticFeedback}
              className="flex items-center justify-center p-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
            >
              <Vibrate className="w-5 h-5 mr-2" />
              测试触觉反馈
            </button>
          </div>
          
          <button
            onClick={runAllTests}
            disabled={isRunningTests}
            className="w-full p-3 bg-gray-800 hover:bg-gray-900 disabled:bg-gray-400 text-white rounded-lg transition-colors"
          >
            {isRunningTests ? '正在运行测试...' : '运行自动测试'}
          </button>
        </div>

        {/* 测试结果 */}
        {testResults.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">测试结果</h2>
            <div className="space-y-2">
              {testResults.map((result, index) => (
                <div key={index} className="flex items-center justify-between p-2 rounded border border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-900 dark:text-white">{result.name}</span>
                  <div className="flex items-center">
                    <span className={`text-sm mr-2 ${
                      result.status === 'success' ? 'text-green-600' : 
                      result.status === 'error' ? 'text-red-600' : 'text-yellow-600'
                    }`}>
                      {result.message}
                    </span>
                    <div className={`w-3 h-3 rounded-full ${
                      result.status === 'success' ? 'bg-green-500' : 
                      result.status === 'error' ? 'bg-red-500' : 'bg-yellow-500'
                    }`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NativeFeaturesTest;