/**
 * 飞鸽风格即时通讯App - 产品进销存管理详情页面
 * 提供单个产品的进销存数据管理功能，包含表格形式的数据展示和编辑
 */

import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { 
  ArrowLeft, 
  Package, 
  Plus, 
  Save, 
  Trash2, 
  Calendar,
  ShoppingCart,
  TrendingUp,
  TrendingDown,
  Edit3
} from 'lucide-react';
import PageContainer from '../components/Layout/PageContainer';
import { useIsMobile } from '../hooks/useIsMobile';
import { useTouchFeedback } from '../hooks/useTouch';
import { inventoryDB, Product, InventoryRecord, initInventoryDB } from '../utils/indexedDB';





/**
 * 表格行数据接口定义
 */
interface TableRowData {
  id: string;
  date: string;
  purchaseQuantity: string;
  stockQuantity: string;
  netSales: number;
  isEditing: boolean;
}

/**
 * 表格行组件属性接口
 */
interface TableRowProps {
  row: TableRowData;
  previousStock: number;
  onUpdate: (id: string, field: keyof TableRowData, value: string) => void;
  onDelete: (id: string) => void;
  onToggleEdit: (id: string) => void;
  isMobile: boolean;
}

/**
 * 表格行组件
 * 用于显示和编辑单行进销存数据
 */
const TableRow: React.FC<TableRowProps> = ({ 
  row, 
  previousStock, 
  onUpdate, 
  onDelete, 
  onToggleEdit, 
  isMobile 
}) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();

  /**
   * 计算纯销量
   * 公式：纯销 = 上一次库存量 + 本次采购量 - 本次库存量
   */
  const calculateNetSales = (): number => {
    const purchase = parseFloat(row.purchaseQuantity) || 0;
    const stock = parseFloat(row.stockQuantity) || 0;
    return previousStock + purchase - stock;
  };

  /**
   * 处理输入变化
   */
  const handleInputChange = (field: keyof TableRowData, value: string) => {
    onUpdate(row.id, field, value);
  };

  /**
   * 处理保存
   */
  const handleSave = () => {
    const netSales = calculateNetSales();
    onUpdate(row.id, 'netSales', netSales.toString());
    onToggleEdit(row.id);
  };

  /**
   * 处理取消编辑
   */
  const handleCancel = () => {
    onToggleEdit(row.id);
  };

  const netSales = row.isEditing ? calculateNetSales() : row.netSales;

  return (
    <tr className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors">
      <td className={`px-4 py-3 ${isMobile ? 'text-sm' : 'text-xs'}`}>
        {row.isEditing ? (
          <input
            type="date"
            value={row.date}
            onChange={(e) => handleInputChange('date', e.target.value)}
            className={`
              w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
              rounded-lg px-2 py-1 text-gray-900 dark:text-white
              focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}
          />
        ) : (
          <span className="text-gray-900 dark:text-white">
            {new Date(row.date).toLocaleDateString('zh-CN')}
          </span>
        )}
      </td>
      <td className={`px-4 py-3 ${isMobile ? 'text-sm' : 'text-xs'}`}>
        {row.isEditing ? (
          <input
            type="number"
            min="0"
            step="1"
            value={row.purchaseQuantity}
            onChange={(e) => handleInputChange('purchaseQuantity', e.target.value)}
            className={`
              w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
              rounded-lg px-2 py-1 text-gray-900 dark:text-white
              focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}
            placeholder="0"
          />
        ) : (
          <span className="text-blue-600 dark:text-blue-400 font-medium">
            {row.purchaseQuantity || '0'}
          </span>
        )}
      </td>
      <td className={`px-4 py-3 ${isMobile ? 'text-sm' : 'text-xs'}`}>
        {row.isEditing ? (
          <input
            type="number"
            min="0"
            step="1"
            value={row.stockQuantity}
            onChange={(e) => handleInputChange('stockQuantity', e.target.value)}
            className={`
              w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600
              rounded-lg px-2 py-1 text-gray-900 dark:text-white
              focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}
            placeholder="0"
          />
        ) : (
          <span className="text-green-600 dark:text-green-400 font-medium">
            {row.stockQuantity || '0'}
          </span>
        )}
      </td>
      <td className={`px-4 py-3 ${isMobile ? 'text-sm' : 'text-xs'}`}>
        <span className={`
          font-medium
          ${netSales > 0 
            ? 'text-red-600 dark:text-red-400' 
            : netSales < 0 
              ? 'text-orange-600 dark:text-orange-400'
              : 'text-gray-600 dark:text-gray-400'
          }
        `}>
          {netSales}
        </span>
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center space-x-2">
          {row.isEditing ? (
            <>
              <button
                onClick={handleSave}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  p-1 text-green-600 dark:text-green-400 rounded transition-colors
                  ${isMobile 
                    ? 'active:bg-green-50 dark:active:bg-green-900' 
                    : 'hover:bg-green-50 dark:hover:bg-green-900'
                  }
                `}
                title="保存"
              >
                <Save className="w-4 h-4" />
              </button>
              <button
                onClick={handleCancel}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                className={`
                  p-1 text-gray-400 rounded transition-colors
                  ${isMobile 
                    ? 'active:bg-gray-100 dark:active:bg-gray-700' 
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                  }
                `}
                title="取消"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            </>
          ) : (
            <button
              onClick={() => onToggleEdit(row.id)}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`
                p-1 text-gray-400 rounded transition-colors
                ${isMobile 
                  ? 'active:bg-gray-100 dark:active:bg-gray-700' 
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }
              `}
              title="编辑"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => onDelete(row.id)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`
              p-1 text-red-400 rounded transition-colors
              ${isMobile 
                ? 'active:bg-red-50 dark:active:bg-red-900' 
                : 'hover:bg-red-50 dark:hover:bg-red-900'
              }
            `}
            title="删除"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </td>
    </tr>
  );
};

/**
 * 产品进销存管理详情页面组件
 */
const ProductInventoryDetail: React.FC = () => {
  const navigate = useNavigate();
  const { productId } = useParams<{ productId: string }>();
  const location = useLocation();
  const isMobile = useIsMobile();
  
  const [product, setProduct] = useState<Product | null>(null);
  const [tableRows, setTableRows] = useState<TableRowData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  /**
   * 初始化产品和进销存数据
   */
  useEffect(() => {
    const initializeData = async () => {
      setIsLoading(true);
      
      try {
        await initInventoryDB();
        
        // 从路由状态获取产品信息，或从数据库加载
        if (location.state?.product) {
          setProduct(location.state.product);
        } else if (productId) {
          const productData = await inventoryDB.getProduct(productId);
          if (productData) {
            setProduct(productData);
          }
        }

        // 加载进销存记录
        if (productId) {
          const records = await inventoryDB.getInventoryRecordsByProduct(productId);
          const tableData: TableRowData[] = records.map(record => ({
            id: record.id,
            date: record.date,
            purchaseQuantity: record.purchaseQuantity.toString(),
            stockQuantity: record.stockQuantity.toString(),
            netSales: record.netSales,
            isEditing: false
          }));
          setTableRows(tableData);
        }
      } catch (error) {
        console.error('Failed to initialize product inventory data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeData();
  }, [productId, location.state]);

  /**
   * 处理返回
   */
  const handleGoBack = () => {
    navigate('/app/inventory-management');
  };

  /**
   * 添加新行
   */
  const handleAddRow = async () => {
    const newRow: TableRowData = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      purchaseQuantity: '',
      stockQuantity: '',
      netSales: 0,
      isEditing: true
    };
    setTableRows(prev => [...prev, newRow]);
  };

  /**
   * 更新行数据
   */
  const handleUpdateRow = (id: string, field: keyof TableRowData, value: string) => {
    setTableRows(prev => prev.map(row => 
      row.id === id 
        ? { ...row, [field]: field === 'netSales' ? parseFloat(value) : value }
        : row
    ));
  };

  /**
   * 删除行
   */
  const handleDeleteRow = async (id: string) => {
    if (window.confirm('确定要删除这条记录吗？')) {
      try {
        await inventoryDB.deleteInventoryRecord(id);
        setTableRows(prev => prev.filter(row => row.id !== id));
      } catch (error) {
        console.error('Failed to delete inventory record:', error);
        alert('删除记录失败，请重试');
      }
    }
  };

  /**
   * 切换编辑状态并保存到数据库
   */
  const handleToggleEdit = async (id: string) => {
    const row = tableRows.find(r => r.id === id);
    if (!row || !productId) return;

    if (row.isEditing) {
      // 保存数据到数据库
      try {
        const previousStock = getPreviousStock(tableRows.findIndex(r => r.id === id));
        const purchaseQuantity = parseFloat(row.purchaseQuantity) || 0;
        const stockQuantity = parseFloat(row.stockQuantity) || 0;
        const netSales = previousStock + purchaseQuantity - stockQuantity;

        const recordData = {
          id: row.id,
          productId: productId,
          date: row.date,
          purchaseQuantity: purchaseQuantity,
          stockQuantity: stockQuantity,
          netSales: netSales,
          previousStock: previousStock
        };

        // 检查记录是否已存在
        const existingRecord = await inventoryDB.getInventoryRecord(id);
        if (existingRecord) {
          await inventoryDB.updateInventoryRecord(id, recordData);
        } else {
          await inventoryDB.addInventoryRecord(recordData);
        }

        // 更新本地状态
        setTableRows(prev => prev.map(r => 
          r.id === id 
            ? { ...r, netSales: netSales, isEditing: false }
            : r
        ));
      } catch (error) {
        console.error('Failed to save inventory record:', error);
        alert('保存记录失败，请重试');
      }
    } else {
      // 进入编辑模式
      setTableRows(prev => prev.map(row => 
        row.id === id 
          ? { ...row, isEditing: true }
          : row
      ));
    }
  };

  /**
   * 获取上一次库存量
   */
  const getPreviousStock = (currentIndex: number): number => {
    if (currentIndex === 0) {
      return 0; // 第一条记录的上一次库存为0
    }
    const previousRow = tableRows[currentIndex - 1];
    return parseFloat(previousRow.stockQuantity) || 0;
  };

  /**
   * 计算统计数据
   */
  const totalPurchase = tableRows.reduce((sum, row) => sum + (parseFloat(row.purchaseQuantity) || 0), 0);
  const totalSales = tableRows.reduce((sum, row) => sum + row.netSales, 0);
  const currentStock = tableRows.length > 0 
    ? parseFloat(tableRows[tableRows.length - 1].stockQuantity) || 0 
    : product?.stock || 0;

  if (isLoading) {
    return (
      <PageContainer title="加载中...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
        </div>
      </PageContainer>
    );
  }

  if (!product) {
    return (
      <PageContainer title="产品未找到">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              产品未找到
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4">
              请检查产品ID是否正确
            </p>
            <button
              onClick={handleGoBack}
              className="bg-green-500 hover:bg-green-600 text-white rounded-xl px-6 py-3 font-medium"
            >
              返回列表
            </button>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title={`${product.name} - 进销存管理`}
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 产品信息概览 */}
        <div className="bg-white dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-blue-100 dark:bg-blue-900 rounded-xl p-3 w-12 h-12 flex items-center justify-center">
              <Package className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="flex-1">
              <h2 className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {product.name}
              </h2>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                SKU: {product.sku} | 分类: {product.category} | 单价: ¥{product.price}
              </p>
            </div>
          </div>

          {/* 统计数据 */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <ShoppingCart className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {totalPurchase}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                总采购量
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="w-5 h-5 text-red-600 dark:text-red-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {totalSales}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                总销售量
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Package className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <p className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                {currentStock}
              </p>
              <p className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-sm' : 'text-xs'}
              `}>
                当前库存
              </p>
            </div>
          </div>
        </div>

        {/* 操作栏 */}
        <div className="bg-white dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className={`
              font-semibold text-gray-900 dark:text-white
              ${isMobile ? 'text-base' : 'text-sm'}
            `}>
              进销存记录
            </h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleAddRow}
                className={`
                  bg-green-500 hover:bg-green-600 text-white rounded-xl px-4 py-2
                  flex items-center space-x-2 font-medium transition-colors
                  ${isMobile 
                    ? 'text-sm active:bg-green-700' 
                    : 'text-xs hover:shadow-md'
                  }
                `}
              >
                <Plus className="w-4 h-4" />
                <span>添加记录</span>
              </button>
            </div>
          </div>
        </div>

        {/* 进销存表格 */}
        <div className={`
          flex-1 overflow-auto
          ${isMobile ? 'px-2 py-4' : 'px-4 py-4'}
        `}>
          {tableRows.length > 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className={`
                        px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300
                        ${isMobile ? 'text-sm' : 'text-xs'}
                      `}>
                        查询日期
                      </th>
                      <th className={`
                        px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300
                        ${isMobile ? 'text-sm' : 'text-xs'}
                      `}>
                        采购量
                      </th>
                      <th className={`
                        px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300
                        ${isMobile ? 'text-sm' : 'text-xs'}
                      `}>
                        库存量
                      </th>
                      <th className={`
                        px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300
                        ${isMobile ? 'text-sm' : 'text-xs'}
                      `}>
                        纯销
                      </th>
                      <th className={`
                        px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300
                        ${isMobile ? 'text-sm' : 'text-xs'}
                      `}>
                        操作
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableRows.map((row, index) => (
                      <TableRow
                        key={row.id}
                        row={row}
                        previousStock={getPreviousStock(index)}
                        onUpdate={handleUpdateRow}
                        onDelete={handleDeleteRow}
                        onToggleEdit={handleToggleEdit}
                        isMobile={isMobile}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="text-center py-16">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className={`
                font-medium text-gray-900 dark:text-white mb-2
                ${isMobile ? 'text-lg' : 'text-base'}
              `}>
                暂无进销存记录
              </h3>
              <p className={`
                text-gray-500 dark:text-gray-400 mb-4
                ${isMobile ? 'text-base' : 'text-sm'}
              `}>
                点击添加记录按钮开始记录进销存数据
              </p>
              <button
                onClick={handleAddRow}
                className={`
                  bg-green-500 hover:bg-green-600 text-white rounded-xl px-6 py-3
                  font-medium transition-colors
                  ${isMobile 
                    ? 'text-base active:bg-green-700' 
                    : 'text-sm hover:shadow-md'
                  }
                `}
              >
                添加记录
              </button>
            </div>
          )}
        </div>

        {/* 计算说明 */}
        <div className="bg-white dark:bg-gray-800 p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2 mb-2">
            <TrendingDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
            <span className={`
              font-medium text-gray-700 dark:text-gray-300
              ${isMobile ? 'text-sm' : 'text-xs'}
            `}>
              计算公式
            </span>
          </div>
          <p className={`
            text-gray-600 dark:text-gray-400
            ${isMobile ? 'text-sm' : 'text-xs'}
          `}>
            纯销 = 上一次库存量 + 本次采购量 - 本次库存量
          </p>
        </div>
      </div>
    </PageContainer>
  );
};

export default ProductInventoryDetail;