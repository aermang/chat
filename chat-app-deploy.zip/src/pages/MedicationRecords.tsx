import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft,
  Plus,
  Search,
  Filter,
  Calendar,
  Pill,
  User,
  FileText,
  Edit,
  Trash2,
  Clock,
  AlertCircle
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { MedicationRecord, Patient } from '../types';

/**
 * 用药记录管理页面组件
 */
const MedicationRecords: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const patientId = searchParams.get('patientId');
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 获取状态管理中的数据
  const { 
    medicationRecords,
    patients,
    loadMedicationRecords,
    loadPatients,
    deleteMedicationRecord
  } = useSpecialMedicineStore();

  const [filteredRecords, setFilteredRecords] = useState<MedicationRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  /**
   * 加载数据
   */
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        await Promise.all([
          loadMedicationRecords(),
          loadPatients()
        ]);
      } catch (error) {
        console.error('加载数据失败:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [loadMedicationRecords, loadPatients]);

  /**
   * 过滤记录
   */
  useEffect(() => {
    let filtered = [...medicationRecords];

    // 如果指定了患者ID，只显示该患者的记录
    if (patientId) {
      filtered = filtered.filter(record => record.patientId === patientId);
    }

    // 搜索过滤
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(record => 
        record.medicineName.toLowerCase().includes(term) ||
        record.dosage.toLowerCase().includes(term) ||
        record.frequency.toLowerCase().includes(term) ||
        (record.notes && record.notes.toLowerCase().includes(term))
      );
    }

    // 患者过滤
    if (selectedPatient) {
      filtered = filtered.filter(record => record.patientId === selectedPatient);
    }

    // 日期过滤
    if (dateFilter) {
      const filterDate = new Date(dateFilter);
      filtered = filtered.filter(record => {
        const recordDate = new Date(record.recordDate);
        return recordDate.toDateString() === filterDate.toDateString();
      });
    }

    // 按日期排序（最新的在前）
    filtered.sort((a, b) => 
      new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime()
    );

    setFilteredRecords(filtered);
  }, [medicationRecords, searchTerm, selectedPatient, dateFilter, patientId]);

  /**
   * 获取患者姓名
   */
  const getPatientName = (patientId: string): string => {
    const patient = patients.find(p => p.id === patientId);
    return patient ? patient.name : '未知患者';
  };

  /**
   * 处理返回操作
   * 如果有patientId参数，返回到患者详情页面；否则返回到特殊用药管理页面
   */
  const handleGoBack = () => {
    if (patientId) {
      navigate(`/app/special-medicine/patient-detail/${patientId}`);
    } else {
      navigate('/app/special-medicine');
    }
  };

  /**
   * 处理添加记录
   */
  const handleAddRecord = () => {
    const url = patientId 
      ? `/app/special-medicine/medication-form?patientId=${patientId}`
      : '/app/special-medicine/medication-form';
    navigate(url);
  };

  /**
   * 处理编辑记录
   */
  const handleEditRecord = (recordId: string) => {
    navigate(`/app/special-medicine/medication-form?id=${recordId}`);
  };

  /**
   * 处理删除记录
   */
  const handleDeleteRecord = async (recordId: string) => {
    if (window.confirm('确定要删除这条用药记录吗？')) {
      try {
        await deleteMedicationRecord(recordId);
      } catch (error) {
        console.error('删除记录失败:', error);
        alert('删除失败，请重试');
      }
    }
  };

  /**
   * 清除所有过滤条件
   */
  const clearFilters = () => {
    setSearchTerm('');
    setSelectedPatient('');
    setDateFilter('');
    setShowFilters(false);
  };

  /**
   * 格式化日期显示
   */
  const formatDate = (date: string | Date | undefined): string => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('zh-CN');
  };

  /**
   * 格式化时间显示
   */
  const formatDateTime = (date: string | Date | undefined): string => {
    if (!date) return '';
    return new Date(date).toLocaleString('zh-CN');
  };

  if (loading) {
    return (
      <PageContainer title="用药记录">
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">加载中...</p>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title={patientId ? `${getPatientName(patientId)} - 用药记录` : "用药记录"}
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <Plus className="w-5 h-5" />,
          onClick: handleAddRecord,
          label: "添加记录"
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        {/* 搜索和过滤栏 */}
        <div className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          {/* 搜索框 */}
          <div className="flex items-center space-x-3 mb-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="搜索药品名称、剂量、频次或备注..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`
                  w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600
                  rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                  placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500
                  focus:border-transparent transition-colors
                  ${isMobile ? 'text-sm' : 'text-base'}
                `}
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              className={`
                p-2 border border-gray-300 dark:border-gray-600 rounded-lg
                bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600
                transition-colors ${showFilters ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-300 dark:border-blue-600' : ''}
              `}
            >
              <Filter className="w-4 h-4 text-gray-600 dark:text-gray-300" />
            </button>
          </div>

          {/* 过滤选项 */}
          {showFilters && (
            <div className="space-y-3 pt-3 border-t border-gray-200 dark:border-gray-600">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* 患者选择 */}
                {!patientId && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      患者
                    </label>
                    <select
                      value={selectedPatient}
                      onChange={(e) => setSelectedPatient(e.target.value)}
                      className={`
                        w-full px-3 py-2 border border-gray-300 dark:border-gray-600
                        rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                        focus:ring-2 focus:ring-blue-500 focus:border-transparent
                        ${isMobile ? 'text-sm' : 'text-base'}
                      `}
                    >
                      <option value="">全部患者</option>
                      {patients.map((patient) => (
                        <option key={patient.id} value={patient.id}>
                          {patient.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* 日期过滤 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    记录日期
                  </label>
                  <input
                    type="date"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className={`
                      w-full px-3 py-2 border border-gray-300 dark:border-gray-600
                      rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                      focus:ring-2 focus:ring-blue-500 focus:border-transparent
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}
                  />
                </div>
              </div>

              {/* 清除过滤按钮 */}
              <div className="flex justify-end">
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
                >
                  清除过滤
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 记录列表 */}
        <div className="flex-1 overflow-y-auto">
          {filteredRecords.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <Pill className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {searchTerm || selectedPatient || dateFilter ? '未找到匹配的记录' : '暂无用药记录'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  {searchTerm || selectedPatient || dateFilter 
                    ? '请尝试调整搜索条件或过滤器'
                    : '点击右上角按钮添加第一条用药记录'
                  }
                </p>
                {(searchTerm || selectedPatient || dateFilter) && (
                  <button
                    onClick={clearFilters}
                    className="px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                  >
                    清除过滤条件
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className={`
              ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
              space-y-4
            `}>
              {filteredRecords.map((record) => (
                <div
                  key={record.id}
                  className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Pill className="w-5 h-5 text-blue-500" />
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {record.medicineName}
                        </h3>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <span>剂量: {record.dosage}</span>
                          <span>•</span>
                          <span>频次: {record.frequency}</span>
                        </div>
                        
                        {!patientId && (
                          <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                            <User className="w-4 h-4" />
                            <span>{getPatientName(record.patientId)}</span>
                          </div>
                        )}
                        
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <Calendar className="w-4 h-4" />
                          <span>{formatDate(record.recordDate)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => handleEditRecord(record.id)}
                        onTouchStart={handleTouchStart}
                        onTouchEnd={handleTouchEnd}
                        className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
                        title="编辑"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteRecord(record.id)}
                        onTouchStart={handleTouchStart}
                        onTouchEnd={handleTouchEnd}
                        className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {record.notes && (
                    <div className="flex items-start space-x-2 mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                      <FileText className="w-4 h-4 text-gray-400 mt-0.5" />
                      <p className="text-sm text-gray-600 dark:text-gray-400 flex-1">
                        {record.notes}
                      </p>
                    </div>
                  )}

                  {/* 记录时间 */}
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                    <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                      <Clock className="w-3 h-3" />
                      <span>记录时间: {formatDateTime(record.createdAt)}</span>
                    </div>
                    
                    {record.updatedAt !== record.createdAt && (
                      <div className="flex items-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
                        <AlertCircle className="w-3 h-3" />
                        <span>已修改</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 底部统计信息 */}
        <div className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3' : 'px-6 py-4'}
        `}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className={`
                text-gray-600 dark:text-gray-300
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                共 {filteredRecords.length} 条记录
              </span>
              {(searchTerm || selectedPatient || dateFilter) && (
                <span className={`
                  text-blue-600 dark:text-blue-400
                  ${isMobile ? 'text-xs' : 'text-sm'}
                `}>
                  (已过滤)
                </span>
              )}
            </div>
            
            {filteredRecords.length > 0 && (
              <span className={`
                text-gray-500 dark:text-gray-400
                ${isMobile ? 'text-xs' : 'text-sm'}
              `}>
                最新记录: {formatDate(filteredRecords[0].recordDate)}
              </span>
            )}
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default MedicationRecords;