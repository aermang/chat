/**
 * 飞鸽风格即时通讯App - Excel工作簿风格进销存管理页面
 * 完全模拟Excel界面的进销存管理系统
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Save, 
  Upload, 
  Download, 
  Plus, 
  X, 
  Copy, 
  Scissors, 
  Clipboard,
  MoreHorizontal,
  File,
  Edit,
  Eye,
  Settings,
  ChevronDown,
  FileText,
  FolderOpen,
  Printer,
  Undo,
  Redo,
  Search,
  ZoomIn,
  ZoomOut
} from 'lucide-react';
import { useIsMobile } from '../hooks/useIsMobile';
import { useTouchFeedback } from '../hooks/useTouch';

/**
 * 单元格数据类型
 */
interface CellData {
  value: string | number;
  formula?: string;
  type: 'text' | 'number' | 'date' | 'formula';
}

/**
 * 工作表数据类型
 */
interface WorksheetData {
  id: string;
  name: string;
  cells: { [key: string]: CellData };
  rows: number;
  cols: number;
}

/**
 * 选中区域类型
 */
interface Selection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

/**
 * 右键菜单项类型
 */
interface ContextMenuItem {
  label: string;
  action: () => void;
  icon?: React.ReactNode;
  separator?: boolean;
}

/**
 * 下拉菜单项类型
 */
interface DropdownMenuItem {
  label: string;
  action: () => void;
  icon?: React.ReactNode;
  separator?: boolean;
  shortcut?: string;
}

/**
 * Excel工作簿风格的进销存管理组件
 */
const PurchaseSalesInventory: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { handleTouchStart: touchFeedbackStart, handleTouchEnd: touchFeedbackEnd } = useTouchFeedback();
  
  // 工作表相关状态
  const [worksheets, setWorksheets] = useState<WorksheetData[]>([]);
  const [activeWorksheet, setActiveWorksheet] = useState<string>('');
  
  // 选中状态
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [isSelecting, setIsSelecting] = useState(false);
  
  // 编辑状态
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null);
  const [editValue, setEditValue] = useState('');
  
  // 右键菜单状态
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; items: ContextMenuItem[] } | null>(null);
  
  // 下拉菜单状态
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  
  // 长按状态（移动端）
  const [longPressTimer, setLongPressTimer] = useState<NodeJS.Timeout | null>(null);
  const [isLongPressing, setIsLongPressing] = useState(false);
  
  // 引用
  const tableRef = useRef<HTMLDivElement>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  /**
   * 列标题生成函数
   */
  const getColumnLabel = (index: number): string => {
    let result = '';
    while (index >= 0) {
      result = String.fromCharCode(65 + (index % 26)) + result;
      index = Math.floor(index / 26) - 1;
    }
    return result;
  };

  /**
   * 获取单元格键值
   */
  const getCellKey = (row: number, col: number): string => {
    return `${getColumnLabel(col)}${row + 1}`;
  };

  /**
   * 初始化默认工作表
   */
  useEffect(() => {
    const savedData = localStorage.getItem('excel-inventory-data');
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        setWorksheets(data.worksheets || []);
        setActiveWorksheet(data.activeWorksheet || '');
      } catch (error) {
        console.error('加载数据失败:', error);
        initializeDefaultWorksheets();
      }
    } else {
      initializeDefaultWorksheets();
    }
  }, []);

  /**
   * 初始化默认工作表
   */
  const initializeDefaultWorksheets = () => {
    const defaultWorksheet: WorksheetData = {
      id: 'product1',
      name: '产品1',
      cells: {
        'A1': { value: '序号', type: 'text' },
        'B1': { value: '日期', type: 'text' },
        'C1': { value: '采购量', type: 'text' },
        'D1': { value: '库存量', type: 'text' },
        'E1': { value: '纯销量', type: 'text' },
        'F1': { value: '产品信息', type: 'text' },
        'G1': { value: '分类', type: 'text' },
        'H1': { value: '单价', type: 'text' },
        'I1': { value: '备注', type: 'text' },
        'A2': { value: 1, type: 'number' },
        'B2': { value: '2024-01-15', type: 'date' },
        'C2': { value: 100, type: 'number' },
        'D2': { value: 80, type: 'number' },
        'E2': { value: 20, type: 'number' },
        'F2': { value: '示例产品', type: 'text' },
        'G2': { value: '电子产品', type: 'text' },
        'H2': { value: 99.99, type: 'number' },
        'I2': { value: '示例备注', type: 'text' }
      },
      rows: 20,
      cols: 15
    };
    
    setWorksheets([defaultWorksheet]);
    setActiveWorksheet('product1');
  };

  /**
   * 保存数据到localStorage
   */
  const saveData = useCallback(() => {
    const data = {
      worksheets,
      activeWorksheet
    };
    localStorage.setItem('excel-inventory-data', JSON.stringify(data));
  }, [worksheets, activeWorksheet]);

  /**
   * 自动保存
   */
  useEffect(() => {
    const timer = setTimeout(saveData, 1000);
    return () => clearTimeout(timer);
  }, [worksheets, activeWorksheet, saveData]);

  /**
   * 获取当前工作表
   */
  const getCurrentWorksheet = (): WorksheetData | null => {
    return worksheets.find(ws => ws.id === activeWorksheet) || null;
  };

  /**
   * 获取单元格值
   */
  const getCellValue = (row: number, col: number): string => {
    const worksheet = getCurrentWorksheet();
    if (!worksheet) return '';
    
    const cellKey = getCellKey(row, col);
    const cell = worksheet.cells[cellKey];
    return cell ? String(cell.value) : '';
  };

  /**
   * 设置单元格值
   */
  const setCellValue = (row: number, col: number, value: string) => {
    const worksheet = getCurrentWorksheet();
    if (!worksheet) return;

    const cellKey = getCellKey(row, col);
    const newWorksheets = worksheets.map(ws => {
      if (ws.id === activeWorksheet) {
        return {
          ...ws,
          cells: {
            ...ws.cells,
            [cellKey]: {
              value: value,
              type: isNaN(Number(value)) ? 'text' : 'number'
            } as CellData
          }
        };
      }
      return ws;
    });
    
    setWorksheets(newWorksheets);
  };

  /**
   * 插入新行功能
   * @param insertAtRow 在指定行位置插入新行
   */
  const insertRow = (insertAtRow: number) => {
    const worksheet = getCurrentWorksheet();
    if (!worksheet) return;

    const newWorksheets = worksheets.map(ws => {
      if (ws.id === activeWorksheet) {
        const newCells = { ...ws.cells };
        
        // 将插入位置及以下的所有行向下移动
        for (let row = ws.rows - 1; row >= insertAtRow; row--) {
          for (let col = 0; col < ws.cols; col++) {
            const oldKey = getCellKey(row, col);
            const newKey = getCellKey(row + 1, col);
            if (newCells[oldKey]) {
              newCells[newKey] = newCells[oldKey];
              delete newCells[oldKey];
            }
          }
        }
        
        return {
          ...ws,
          cells: newCells,
          rows: ws.rows + 1
        };
      }
      return ws;
    });
    
    setWorksheets(newWorksheets);
  };

  /**
   * 删除行功能
   * @param deleteRow 要删除的行索引
   */
  const deleteRow = (deleteRow: number) => {
    const worksheet = getCurrentWorksheet();
    if (!worksheet || worksheet.rows <= 1) return; // 至少保留一行

    const newWorksheets = worksheets.map(ws => {
      if (ws.id === activeWorksheet) {
        const newCells = { ...ws.cells };
        
        // 删除指定行的所有单元格
        for (let col = 0; col < ws.cols; col++) {
          const deleteKey = getCellKey(deleteRow, col);
          delete newCells[deleteKey];
        }
        
        // 将删除行以下的所有行向上移动
        for (let row = deleteRow + 1; row < ws.rows; row++) {
          for (let col = 0; col < ws.cols; col++) {
            const oldKey = getCellKey(row, col);
            const newKey = getCellKey(row - 1, col);
            if (newCells[oldKey]) {
              newCells[newKey] = newCells[oldKey];
              delete newCells[oldKey];
            }
          }
        }
        
        return {
          ...ws,
          cells: newCells,
          rows: ws.rows - 1
        };
      }
      return ws;
    });
    
    setWorksheets(newWorksheets);
    
    // 如果删除的行是当前选中的行，清除选中状态
    if (selectedCell && selectedCell.row === deleteRow) {
      setSelectedCell(null);
    } else if (selectedCell && selectedCell.row > deleteRow) {
      // 如果选中行在删除行之下，调整选中行位置
      setSelectedCell({ ...selectedCell, row: selectedCell.row - 1 });
    }
  };

  /**
   * 处理移动端长按开始
   * @param row 行索引
   * @param event 触摸事件
   */
  const handleTouchStart = (row: number, event: React.TouchEvent) => {
    if (!isMobile) return;
    
    setIsLongPressing(false);
    const timer = setTimeout(() => {
      setIsLongPressing(true);
      // 触发震动反馈（如果设备支持）
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
      
      // 显示行操作菜单
      const touch = event.touches[0];
      const items: ContextMenuItem[] = [
        {
          label: '插入行',
          action: () => {
            insertRow(row);
            setContextMenu(null);
          },
          icon: <Plus className="w-4 h-4" />
        },
        {
          label: '删除行',
          action: () => {
            deleteRow(row);
            setContextMenu(null);
          },
          icon: <X className="w-4 h-4" />
        }
      ];

      setContextMenu({
        x: touch.clientX,
        y: touch.clientY,
        items
      });
    }, 500); // 500ms 长按时间
    
    setLongPressTimer(timer);
  };

  /**
   * 处理移动端长按结束
   */
  const handleTouchEnd = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
    setIsLongPressing(false);
  };

  /**
   * 处理单元格点击
   */
  const handleCellClick = (row: number, col: number, event: React.MouseEvent) => {
    event.preventDefault();
    setSelectedCell({ row, col });
    setSelection(null);
    setEditingCell(null);
    // 触发触摸反馈
    if (isMobile && navigator.vibrate) {
      navigator.vibrate(10);
    }
  };

  /**
   * 处理单元格双击
   */
  const handleCellDoubleClick = (row: number, col: number) => {
    setEditingCell({ row, col });
    setEditValue(getCellValue(row, col));
    setTimeout(() => {
      editInputRef.current?.focus();
    }, 0);
  };

  /**
   * 处理编辑完成
   */
  const handleEditComplete = () => {
    if (editingCell) {
      setCellValue(editingCell.row, editingCell.col, editValue);
      setEditingCell(null);
      setEditValue('');
    }
  };

  /**
   * 处理键盘事件
   */
  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (!selectedCell) return;

    const { row, col } = selectedCell;
    
    switch (event.key) {
      case 'ArrowUp':
        if (row > 0) setSelectedCell({ row: row - 1, col });
        event.preventDefault();
        break;
      case 'ArrowDown':
        setSelectedCell({ row: row + 1, col });
        event.preventDefault();
        break;
      case 'ArrowLeft':
        if (col > 0) setSelectedCell({ row, col: col - 1 });
        event.preventDefault();
        break;
      case 'ArrowRight':
        setSelectedCell({ row, col: col + 1 });
        event.preventDefault();
        break;
      case 'Enter':
        handleCellDoubleClick(row, col);
        event.preventDefault();
        break;
      case 'Delete':
        setCellValue(row, col, '');
        event.preventDefault();
        break;
    }
  };

  /**
   * 处理右键菜单
   * @param event 鼠标事件
   * @param row 行索引（可选）
   * @param col 列索引（可选）
   * @param isRowHeader 是否为行标题
   */
  const handleContextMenu = (event: React.MouseEvent, row?: number, col?: number, isRowHeader?: boolean) => {
    event.preventDefault();
    
    let items: ContextMenuItem[];
    
    if (isRowHeader && row !== undefined) {
      // 行标题右键菜单
      items = [
        {
          label: '插入行',
          action: () => {
            insertRow(row);
            setContextMenu(null);
          },
          icon: <Plus className="w-4 h-4" />
        },
        {
          label: '删除行',
          action: () => {
            deleteRow(row);
            setContextMenu(null);
          },
          icon: <X className="w-4 h-4" />
        }
      ];
    } else {
      // 普通单元格右键菜单
      items = [
        {
          label: '复制',
          action: () => {
            // 复制逻辑
            setContextMenu(null);
          },
          icon: <Copy className="w-4 h-4" />
        },
        {
          label: '粘贴',
          action: () => {
            // 粘贴逻辑
            setContextMenu(null);
          },
          icon: <Clipboard className="w-4 h-4" />
        },
        { separator: true, label: '', action: () => {} },
        {
          label: '插入行',
          action: () => {
            if (row !== undefined) insertRow(row);
            setContextMenu(null);
          },
          icon: <Plus className="w-4 h-4" />
        },
        {
          label: '删除行',
          action: () => {
            if (row !== undefined) deleteRow(row);
            setContextMenu(null);
          },
          icon: <X className="w-4 h-4" />
        }
      ];
    }

    setContextMenu({
      x: event.clientX,
      y: event.clientY,
      items
    });
  };

  /**
   * 添加新工作表
   */
  const addNewWorksheet = () => {
    const newId = `product${worksheets.length + 1}`;
    const newWorksheet: WorksheetData = {
      id: newId,
      name: `产品${worksheets.length + 1}`,
      cells: {
        'A1': { value: '序号', type: 'text' },
        'B1': { value: '日期', type: 'text' },
        'C1': { value: '采购量', type: 'text' },
        'D1': { value: '库存量', type: 'text' },
        'E1': { value: '纯销量', type: 'text' },
        'F1': { value: '产品信息', type: 'text' },
        'G1': { value: '分类', type: 'text' },
        'H1': { value: '单价', type: 'text' },
        'I1': { value: '备注', type: 'text' }
      },
      rows: 20,
      cols: 15
    };
    
    setWorksheets([...worksheets, newWorksheet]);
    setActiveWorksheet(newId);
  };

  /**
   * 删除工作表
   */
  const deleteWorksheet = (worksheetId: string) => {
    if (worksheets.length <= 1) return; // 至少保留一个工作表
    
    const newWorksheets = worksheets.filter(ws => ws.id !== worksheetId);
    setWorksheets(newWorksheets);
    
    if (activeWorksheet === worksheetId) {
      setActiveWorksheet(newWorksheets[0]?.id || '');
    }
  };

  /**
   * 导出数据
   */
  const exportData = () => {
    const dataStr = JSON.stringify({ worksheets, activeWorksheet }, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'inventory-data.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  /**
   * 导入数据
   */
  const importData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = JSON.parse(e.target?.result as string);
            if (data.worksheets && Array.isArray(data.worksheets)) {
              setWorksheets(data.worksheets);
              setActiveWorksheet(data.activeWorksheet || data.worksheets[0]?.id || '');
            }
          } catch (error) {
            console.error('导入数据失败:', error);
            alert('导入数据失败，请检查文件格式');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  /**
   * 打印功能
   */
  const handlePrint = () => {
    window.print();
  };

  /**
   * 获取文件菜单项
   */
  const getFileMenuItems = (): DropdownMenuItem[] => [
    {
      label: '新建',
      action: () => {
        initializeDefaultWorksheets();
        setActiveDropdown(null);
      },
      icon: <FileText className="w-4 h-4" />,
      shortcut: 'Ctrl+N'
    },
    {
      label: '打开',
      action: () => {
        importData();
        setActiveDropdown(null);
      },
      icon: <FolderOpen className="w-4 h-4" />,
      shortcut: 'Ctrl+O'
    },
    { separator: true, label: '', action: () => {} },
    {
      label: '保存',
      action: () => {
        saveData();
        setActiveDropdown(null);
      },
      icon: <Save className="w-4 h-4" />,
      shortcut: 'Ctrl+S'
    },
    {
      label: '导出',
      action: () => {
        exportData();
        setActiveDropdown(null);
      },
      icon: <Download className="w-4 h-4" />
    },
    { separator: true, label: '', action: () => {} },
    {
      label: '打印',
      action: () => {
        handlePrint();
        setActiveDropdown(null);
      },
      icon: <Printer className="w-4 h-4" />,
      shortcut: 'Ctrl+P'
    }
  ];

  /**
   * 获取编辑菜单项
   */
  const getEditMenuItems = (): DropdownMenuItem[] => [
    {
      label: '撤销',
      action: () => {
        // 撤销逻辑
        setActiveDropdown(null);
      },
      icon: <Undo className="w-4 h-4" />,
      shortcut: 'Ctrl+Z'
    },
    {
      label: '重做',
      action: () => {
        // 重做逻辑
        setActiveDropdown(null);
      },
      icon: <Redo className="w-4 h-4" />,
      shortcut: 'Ctrl+Y'
    },
    { separator: true, label: '', action: () => {} },
    {
      label: '复制',
      action: () => {
        // 复制逻辑
        setActiveDropdown(null);
      },
      icon: <Copy className="w-4 h-4" />,
      shortcut: 'Ctrl+C'
    },
    {
      label: '剪切',
      action: () => {
        // 剪切逻辑
        setActiveDropdown(null);
      },
      icon: <Scissors className="w-4 h-4" />,
      shortcut: 'Ctrl+X'
    },
    {
      label: '粘贴',
      action: () => {
        // 粘贴逻辑
        setActiveDropdown(null);
      },
      icon: <Clipboard className="w-4 h-4" />,
      shortcut: 'Ctrl+V'
    },
    { separator: true, label: '', action: () => {} },
    {
      label: '查找',
      action: () => {
        // 查找逻辑
        setActiveDropdown(null);
      },
      icon: <Search className="w-4 h-4" />,
      shortcut: 'Ctrl+F'
    }
  ];

  /**
   * 获取视图菜单项
   */
  const getViewMenuItems = (): DropdownMenuItem[] => [
    {
      label: '放大',
      action: () => {
        // 放大逻辑
        setActiveDropdown(null);
      },
      icon: <ZoomIn className="w-4 h-4" />,
      shortcut: 'Ctrl++'
    },
    {
      label: '缩小',
      action: () => {
        // 缩小逻辑
        setActiveDropdown(null);
      },
      icon: <ZoomOut className="w-4 h-4" />,
      shortcut: 'Ctrl+-'
    },
    { separator: true, label: '', action: () => {} },
    {
      label: '全屏',
      action: () => {
        if (document.fullscreenElement) {
          document.exitFullscreen();
        } else {
          document.documentElement.requestFullscreen();
        }
        setActiveDropdown(null);
      },
      icon: <Eye className="w-4 h-4" />,
      shortcut: 'F11'
    }
  ];

  /**
   * 渲染下拉菜单
   */
  const renderDropdownMenu = (menuType: string, items: DropdownMenuItem[]) => {
    if (activeDropdown !== menuType) return null;

    return (
      <>
        <div
          className="fixed inset-0 z-40"
          onClick={() => setActiveDropdown(null)}
        />
        <div className="absolute top-full left-0 z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-1 min-w-48">
          {items.map((item, index) => (
            item.separator ? (
              <div key={index} className="h-px bg-gray-200 dark:bg-gray-700 my-1" />
            ) : (
              <button
                key={index}
                onClick={item.action}
                className="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <div className="flex items-center space-x-2">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {item.shortcut && (
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {item.shortcut}
                  </span>
                )}
              </button>
            )
          ))}
        </div>
      </>
    );
  };

  const currentWorksheet = getCurrentWorksheet();

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900 overflow-hidden">
      {/* 顶部工具栏 */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
        {/* 菜单栏 */}
        <div className="flex items-center px-4 py-2 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => navigate(-1)}
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg mr-4"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="flex items-center space-x-6 text-sm">
            {/* 文件菜单 */}
            <div className="relative">
              <div 
                className="flex items-center space-x-1 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 px-2 py-1 rounded"
                onClick={() => setActiveDropdown(activeDropdown === 'file' ? null : 'file')}
              >
                <File className="w-4 h-4" />
                <span>文件</span>
                <ChevronDown className="w-3 h-3" />
              </div>
              {renderDropdownMenu('file', getFileMenuItems())}
            </div>

            {/* 编辑菜单 */}
            <div className="relative">
              <div 
                className="flex items-center space-x-1 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 px-2 py-1 rounded"
                onClick={() => setActiveDropdown(activeDropdown === 'edit' ? null : 'edit')}
              >
                <Edit className="w-4 h-4" />
                <span>编辑</span>
                <ChevronDown className="w-3 h-3" />
              </div>
              {renderDropdownMenu('edit', getEditMenuItems())}
            </div>

            {/* 视图菜单 */}
            <div className="relative">
              <div 
                className="flex items-center space-x-1 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 px-2 py-1 rounded"
                onClick={() => setActiveDropdown(activeDropdown === 'view' ? null : 'view')}
              >
                <Eye className="w-4 h-4" />
                <span>视图</span>
                <ChevronDown className="w-3 h-3" />
              </div>
              {renderDropdownMenu('view', getViewMenuItems())}
            </div>
          </div>
        </div>

        {/* 工具栏 */}
        <div className="flex items-center px-4 py-2 space-x-2">
          <button
            onClick={saveData}
            className="flex items-center space-x-1 px-3 py-1.5 text-sm bg-green-600 text-white rounded hover:bg-green-700"
          >
            <Save className="w-4 h-4" />
            <span>保存</span>
          </button>
          
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />
          
          <button
            onClick={exportData}
            className="flex items-center space-x-1 px-3 py-1.5 text-sm border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            <Download className="w-4 h-4" />
            <span>导出</span>
          </button>
          
          <button 
            onClick={importData}
            className="flex items-center space-x-1 px-3 py-1.5 text-sm border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            <Upload className="w-4 h-4" />
            <span>导入</span>
          </button>
        </div>

        {/* 公式栏 */}
        <div className="flex items-center px-4 py-2 border-t border-gray-200 dark:border-gray-700">
          <div className="w-20 text-sm font-mono text-gray-600 dark:text-gray-300">
            {selectedCell ? getCellKey(selectedCell.row, selectedCell.col) : ''}
          </div>
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />
          <div className="flex-1 text-sm font-mono text-gray-800 dark:text-gray-200">
            {selectedCell ? getCellValue(selectedCell.row, selectedCell.col) : ''}
          </div>
        </div>
      </div>

      {/* 主要工作区域 - 修复布局确保工作表标签栏可见 */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* 表格容器 - 优化滚动条显示 */}
        <div className="flex-1 bg-white dark:bg-gray-800 min-h-0 overflow-hidden">
          <div 
            ref={tableRef}
            className="h-full overflow-auto"
            onKeyDown={handleKeyDown}
            tabIndex={0}
            onContextMenu={handleContextMenu}
            style={{ 
              scrollbarWidth: 'auto',
              scrollbarColor: '#94a3b8 #e2e8f0'
            }}
          >
            {currentWorksheet && (
              <div className="min-w-max">
                <table className="border-collapse">
                  <thead className="sticky top-0 z-10">
                    <tr>
                      {/* 左上角空白单元格 */}
                      <th className="w-12 h-8 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-xs font-normal sticky left-0 z-20"></th>
                      {/* 列标题 */}
                      {Array.from({ length: currentWorksheet.cols }, (_, colIndex) => (
                        <th
                          key={colIndex}
                          className="min-w-20 h-8 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-xs font-normal text-center text-gray-700 dark:text-gray-300"
                        >
                          {getColumnLabel(colIndex)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Array.from({ length: currentWorksheet.rows }, (_, rowIndex) => (
                      <tr key={rowIndex}>
                        {/* 行号 - 固定在左侧，添加右键和长按支持 */}
                        <td 
                          className="w-12 h-8 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-xs text-center text-gray-700 dark:text-gray-300 font-normal sticky left-0 z-10 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600 select-none"
                          onContextMenu={(e) => handleContextMenu(e, rowIndex, undefined, true)}
                          onTouchStart={(e) => handleTouchStart(rowIndex, e)}
                          onTouchEnd={handleTouchEnd}
                          onTouchCancel={handleTouchEnd}
                          title={isMobile ? "长按显示菜单" : "右键显示菜单"}
                        >
                          {rowIndex + 1}
                        </td>
                        {/* 数据单元格 */}
                        {Array.from({ length: currentWorksheet.cols }, (_, colIndex) => {
                          const isSelected = selectedCell?.row === rowIndex && selectedCell?.col === colIndex;
                          const isEditing = editingCell?.row === rowIndex && editingCell?.col === colIndex;
                          
                          return (
                            <td
                              key={colIndex}
                              className={`
                                min-w-20 h-8 border border-gray-300 dark:border-gray-600 text-xs relative cursor-cell
                                ${isSelected ? 'bg-blue-100 dark:bg-blue-900 ring-2 ring-blue-500' : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700'}
                              `}
                              onClick={(e) => handleCellClick(rowIndex, colIndex, e)}
                              onDoubleClick={() => handleCellDoubleClick(rowIndex, colIndex)}
                              onContextMenu={(e) => handleContextMenu(e, rowIndex, colIndex)}
                            >
                              {isEditing ? (
                                <input
                                  ref={editInputRef}
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  onBlur={handleEditComplete}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      handleEditComplete();
                                    } else if (e.key === 'Escape') {
                                      setEditingCell(null);
                                      setEditValue('');
                                    }
                                  }}
                                  className="w-full h-full px-1 bg-transparent border-none outline-none text-gray-900 dark:text-white"
                                />
                              ) : (
                                <div className="px-1 py-1 text-gray-900 dark:text-white truncate">
                                  {getCellValue(rowIndex, colIndex)}
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 工作表标签栏 - 确保固定在底部且始终可见 */}
      <div className="bg-gray-100 dark:bg-gray-700 border-t border-gray-300 dark:border-gray-600 flex-shrink-0 z-30">
        <div className="flex items-center px-4 py-3 h-12">
          <div className="flex items-center space-x-1 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 flex-1">
            {worksheets.map((worksheet) => (
              <div
                key={worksheet.id}
                className={`
                  flex items-center space-x-2 px-3 py-2 rounded-t-lg cursor-pointer text-sm whitespace-nowrap
                  transition-colors duration-200 group min-h-[32px] flex-shrink-0
                  ${activeWorksheet === worksheet.id 
                    ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-t-2 border-l border-r border-blue-500 dark:border-blue-400 shadow-sm' 
                    : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500 border border-transparent'
                  }
                `}
                onClick={() => setActiveWorksheet(worksheet.id)}
              >
                <span className="select-none">{worksheet.name}</span>
                {worksheets.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteWorksheet(worksheet.id);
                    }}
                    className="text-gray-500 hover:text-red-500 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                    title="删除工作表"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
            
            <button
              onClick={addNewWorksheet}
              className="flex items-center justify-center w-8 h-8 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-colors duration-200 flex-shrink-0 ml-2"
              title="添加新工作表"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 右键菜单 */}
      {contextMenu && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setContextMenu(null)}
          />
          <div
            className="fixed z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-1 min-w-32"
            style={{ left: contextMenu.x, top: contextMenu.y }}
          >
            {contextMenu.items.map((item, index) => (
              item.separator ? (
                <div key={index} className="h-px bg-gray-200 dark:bg-gray-700 my-1" />
              ) : (
                <button
                  key={index}
                  onClick={item.action}
                  className="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              )
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default PurchaseSalesInventory;