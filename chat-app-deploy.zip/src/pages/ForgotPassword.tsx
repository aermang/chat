/**
 * 飞鸽风格即时通讯App - 忘记密码页面
 * 提供密码找回功能，通过邮箱发送重置链接
 */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, MessageCircle, ArrowLeft } from 'lucide-react';
import { DatabaseService } from '../lib/database';

/**
 * 忘记密码表单数据接口
 */
interface ForgotPasswordFormData {
  email: string;
}

/**
 * 忘记密码页面组件
 */
const ForgotPassword: React.FC = () => {
  const navigate = useNavigate();
  
  // 表单状态
  const [formData, setFormData] = useState<ForgotPasswordFormData>({
    email: ''
  });
  
  // UI状态
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [formErrors, setFormErrors] = useState<Partial<ForgotPasswordFormData>>({});
  
  /**
   * 验证邮箱格式
   */
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  /**
   * 处理输入框变化
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 清除对应字段的错误
    if (formErrors[name as keyof ForgotPasswordFormData]) {
      setFormErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
    
    // 清除全局错误
    if (error) {
      setError(null);
    }
  };
  
  /**
   * 验证表单数据
   */
  const validateForm = (): boolean => {
    const errors: Partial<ForgotPasswordFormData> = {};
    
    // 验证邮箱
    if (!formData.email) {
      errors.email = '请输入邮箱地址';
    } else if (!validateEmail(formData.email)) {
      errors.email = '请输入有效的邮箱地址';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  /**
   * 处理表单提交
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      // 生成密码重置令牌
      const token = await DatabaseService.generatePasswordResetToken(formData.email);
      
      if (!token) {
        setError('该邮箱地址未注册');
        return;
      }
      
      // 在实际应用中，这里应该发送邮件
      // 现在我们模拟发送成功并显示重置链接
      console.log('密码重置链接:', `/reset-password?token=${token}`);
      
      setSuccess(true);
    } catch (error) {
      console.error('发送重置邮件失败:', error);
      setError('发送重置邮件失败，请稍后重试');
    } finally {
      setIsLoading(false);
    }
  };
  
  /**
   * 返回登录页面
   */
  const handleBackToLogin = () => {
    navigate('/login');
  };
  
  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo区域 */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mb-4">
              <MessageCircle className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              邮件已发送
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              请查收您的邮箱
            </p>
          </div>
          
          {/* 成功信息 */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full mb-4">
                <Mail className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                重置链接已发送
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                我们已向 <span className="font-medium">{formData.email}</span> 发送了密码重置链接。
                请查收邮件并点击链接重置您的密码。
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                如果您没有收到邮件，请检查垃圾邮件文件夹，或稍后重试。
              </p>
              
              <button
                onClick={handleBackToLogin}
                className="w-full bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
              >
                返回登录
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo区域 */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mb-4">
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            忘记密码
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            输入您的邮箱地址，我们将发送重置链接
          </p>
        </div>
        
        {/* 忘记密码表单 */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* 邮箱输入框 */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                邮箱地址
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`block w-full pl-10 pr-3 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors ${
                    formErrors.email
                      ? 'border-red-300 bg-red-50 dark:bg-red-900/20 dark:border-red-500'
                      : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700'
                  } text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400`}
                  placeholder="请输入注册时使用的邮箱地址"
                />
              </div>
              {formErrors.email && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                  {formErrors.email}
                </p>
              )}
            </div>
            
            {/* 错误信息显示 */}
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
                <p className="text-sm text-red-600 dark:text-red-400">
                  {error}
                </p>
              </div>
            )}
            
            {/* 发送重置邮件按钮 */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-green-500 hover:bg-green-600 disabled:bg-green-300 text-white font-medium py-3 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  发送中...
                </div>
              ) : (
                '发送重置邮件'
              )}
            </button>
          </form>
          
          {/* 返回登录链接 */}
          <div className="mt-6 text-center">
            <Link
              to="/login"
              className="inline-flex items-center text-sm text-green-600 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              返回登录
            </Link>
          </div>
        </div>
        
        {/* 底部信息 */}
        <div className="mt-8 text-center">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            如果您遇到问题，请联系客服获取帮助
          </p>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;