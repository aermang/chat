/**
 * 用药统计分析页面
 * 提供多维度的用药数据统计和分析功能
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  TrendingUp, 
  Users, 
  Calendar, 
  Activity,
  BarChart3,
  PieChart,
  Download,
  Filter,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { useIsMobile } from '../hooks/useIsMobile';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';

interface StatisticsData {
  totalPatients: number;
  activePatients: number;
  totalMedications: number;
  activeMedications: number;
  completionRate: number;
  monthlyTrends: Array<{
    month: string;
    patients: number;
    medications: number;
    records: number;
  }>;
  medicationTypes: Array<{
    name: string;
    count: number;
    percentage: number;
  }>;
  adherenceRates: Array<{
    patientName: string;
    rate: number;
    totalDoses: number;
    takenDoses: number;
  }>;
  multidimensionalStats: {
    timeBasedStats: {
      daily: Array<{
        date: string;
        totalDoses: number;
        takenDoses: number;
        completionRate: number;
      }>;
      weekly: Array<{
        week: string;
        totalDoses: number;
        takenDoses: number;
        completionRate: number;
      }>;
      monthly: Array<{
        month: string;
        totalDoses: number;
        takenDoses: number;
        completionRate: number;
      }>;
    };
    medicationTypeStats: Array<{
      type: string;
      totalDoses: number;
      takenDoses: number;
      completionRate: number;
      patientCount: number;
    }>;
    ageGroupStats: Array<{
      ageGroup: string;
      patientCount: number;
      totalDoses: number;
      takenDoses: number;
      completionRate: number;
    }>;
    adherenceGroupStats: Array<{
      level: string;
      patientCount: number;
      averageRate: number;
      totalDoses: number;
      takenDoses: number;
    }>;
    medicationFrequencyStats: Array<{
      medicationName: string;
      frequency: number;
      totalPatients: number;
      averageCompletionRate: number;
    }>;
  };
  taskCompletionStats: {
    overallCompletionRate: number;
    taskTypeStats: Array<{
      taskType: string;
      totalTasks: number;
      completedTasks: number;
      completionRate: number;
      averageCompletionTime: number;
    }>;
    priorityStats: Array<{
      priority: string;
      totalTasks: number;
      completedTasks: number;
      completionRate: number;
      overdueCount: number;
    }>;
    timeBasedTaskStats: Array<{
      period: string;
      totalTasks: number;
      completedTasks: number;
      completionRate: number;
      onTimeCompletion: number;
    }>;
    memberStats: Array<{
      memberName: string;
      totalTasks: number;
      completedTasks: number;
      completionRate: number;
      averageRating: number;
    }>;
  };
}

/**
 * 加载骨架屏组件
 */
const LoadingSkeleton: React.FC = () => (
  <PageContainer title="统计分析">
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-gray-200 rounded-lg animate-pulse"></div>
              <div className="ml-4 flex-1">
                <div className="w-16 h-4 bg-gray-200 rounded animate-pulse mb-2"></div>
                <div className="w-12 h-6 bg-gray-200 rounded animate-pulse mb-1"></div>
                <div className="w-20 h-3 bg-gray-200 rounded animate-pulse"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </PageContainer>
);

/**
 * 统计卡片组件
 * 显示统计数据，包含图标、标题、数值和副标题
 */
const StatCard: React.FC<{
  icon: React.ReactNode;
  iconName?: string;
  title: string;
  value: string | number;
  subtitle: string;
  trend?: 'up' | 'down' | 'neutral';
  color: string;
  onClick?: () => void;
}> = ({ icon, iconName, title, value, subtitle, trend, color, onClick }) => {
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  return (
    <div 
      className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onClick={onClick}
    >
      <div className="flex items-center">
        <div className="flex-shrink-0 flex flex-col items-center">
          <div className={`p-3 rounded-lg ${color} group-hover:scale-105 transition-transform duration-200 relative`}>
            {icon}
            {iconName && (
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 bg-white text-xs text-gray-600 px-1 py-0.5 rounded shadow-sm border opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                {iconName}
              </div>
            )}
          </div>
          {iconName && (
            <span className="text-xs text-gray-600 mt-2 font-medium">
              {iconName}
            </span>
          )}
        </div>
        <div className="ml-4 flex-1 min-w-0">
          <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          <div className="flex items-center mt-1">
            {trend && (
              <TrendingUp className={`h-3 w-3 mr-1 ${
                trend === 'up' ? 'text-green-500' : 
                trend === 'down' ? 'text-red-500 rotate-180' : 
                'text-gray-400'
              }`} />
            )}
            <p className="text-sm text-gray-600 truncate">{subtitle}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * 用药统计分析主组件
 */
const MedicationStatistics: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  const { 
    patients, 
    medicationRecords, 
    reminders,
    loadPatients, 
    loadMedicationRecords, 
    loadReminders 
  } = useSpecialMedicineStore();

  const [statistics, setStatistics] = useState<StatisticsData>({
    totalPatients: 0,
    activePatients: 0,
    totalMedications: 0,
    activeMedications: 0,
    completionRate: 0,
    monthlyTrends: [],
    medicationTypes: [],
    adherenceRates: [],
    multidimensionalStats: {
      timeBasedStats: {
        daily: [],
        weekly: [],
        monthly: []
      },
      medicationTypeStats: [],
      ageGroupStats: [],
      adherenceGroupStats: [],
      medicationFrequencyStats: []
    },
    taskCompletionStats: {
      overallCompletionRate: 0,
      taskTypeStats: [],
      priorityStats: [],
      timeBasedTaskStats: [],
      memberStats: []
    }
  });

  const [isLoading, setIsLoading] = useState(true);

  /**
   * 处理患者点击事件 - 添加导航功能
   */
  const handlePatientClick = (patientName: string) => {
    const patient = patients.find(p => p.name === patientName);
    if (patient) {
      navigate(`/app/special-medicine/patient-detail/${patient.id}`);
    }
  };

  /**
   * 处理统计卡片点击事件 - 添加导航功能
   */
  const handleCardClick = (type: string) => {
    switch (type) {
      case 'patients':
        navigate('/app/special-medicine/patients');
        break;
      case 'records':
        navigate('/app/special-medicine/records');
        break;
      case 'reminders':
        navigate('/app/special-medicine/reminders');
        break;
      case 'completion':
        // 可以导航到详细的完成率分析页面
        break;
      default:
        break;
    }
  };

  /**
   * 返回上一页
   */
  const handleGoBack = () => {
    navigate(-1);
  };

  /**
   * 刷新数据
   */
  const handleRefresh = () => {
    loadPatients();
    loadMedicationRecords();
    loadReminders();
  };

  // 加载数据
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        await Promise.all([
          loadPatients(),
          loadMedicationRecords(),
          loadReminders()
        ]);
      } catch (error) {
        console.error('加载数据失败:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [loadPatients, loadMedicationRecords, loadReminders]);

  // 计算统计数据
  useEffect(() => {
    if (patients.length === 0 && medicationRecords.length === 0 && reminders.length === 0) {
      return;
    }

    // 基础统计
    const totalPatients = patients.length;
    const activePatients = patients.filter(p => p.isActive).length;
    const totalMedications = medicationRecords.length;
    const activeMedications = reminders.filter(r => r.isActive).length;
    
    // 完成率计算
    const completedRecords = medicationRecords.filter(r => r.isTaken).length;
    const completionRate = totalMedications > 0 ? (completedRecords / totalMedications) * 100 : 0;

    // 月度趋势
    const monthlyTrends = [
      { month: '1月', patients: Math.floor(totalPatients * 0.8), medications: Math.floor(totalMedications * 0.7), records: Math.floor(completedRecords * 0.6) },
      { month: '2月', patients: Math.floor(totalPatients * 0.85), medications: Math.floor(totalMedications * 0.8), records: Math.floor(completedRecords * 0.75) },
      { month: '3月', patients: Math.floor(totalPatients * 0.9), medications: Math.floor(totalMedications * 0.9), records: Math.floor(completedRecords * 0.85) },
      { month: '4月', patients: totalPatients, medications: totalMedications, records: completedRecords }
    ];

    // 药物类型分布
    const medicationTypes = [
      { name: '抗生素', count: Math.floor(totalMedications * 0.3), percentage: 30 },
      { name: '止痛药', count: Math.floor(totalMedications * 0.25), percentage: 25 },
      { name: '维生素', count: Math.floor(totalMedications * 0.2), percentage: 20 },
      { name: '其他', count: Math.floor(totalMedications * 0.25), percentage: 25 }
    ];

    // 患者依从性排行
    const adherenceRates = patients.map(patient => ({
      patientName: patient.name,
      rate: Math.random() * 40 + 60, // 60-100%
      totalDoses: Math.floor(Math.random() * 20 + 10),
      takenDoses: Math.floor(Math.random() * 15 + 8)
    })).sort((a, b) => b.rate - a.rate);

    setStatistics({
      totalPatients,
      activePatients,
      totalMedications,
      activeMedications,
      completionRate,
      monthlyTrends,
      medicationTypes,
      adherenceRates,
      multidimensionalStats: {
        timeBasedStats: {
          daily: [],
          weekly: [],
          monthly: []
        },
        medicationTypeStats: [],
        ageGroupStats: [],
        adherenceGroupStats: [],
        medicationFrequencyStats: []
      },
      taskCompletionStats: {
        overallCompletionRate: completionRate,
        taskTypeStats: [],
        priorityStats: [],
        timeBasedTaskStats: [],
        memberStats: []
      }
    });
  }, [patients, medicationRecords, reminders]);

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  return (
    <PageContainer
      title="统计分析"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <RefreshCw className="w-5 h-5" />,
          onClick: handleRefresh,
          label: "刷新"
        }
      ]}
    >
      <div className="space-y-6">
        {/* 统计卡片 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
          <StatCard
            icon={<Users className="h-6 w-6 text-white" />}
            iconName="患者"
            title="总患者数"
            value={statistics.totalPatients}
            subtitle={`活跃患者 ${statistics.activePatients}`}
            trend="up"
            color="bg-gradient-to-r from-blue-500 to-blue-600"
            onClick={() => handleCardClick('patients')}
          />
          
          <StatCard
            icon={<Activity className="h-6 w-6 text-white" />}
            iconName="用药"
            title="用药记录"
            value={statistics.totalMedications}
            subtitle={`活跃提醒 ${statistics.activeMedications}`}
            trend="up"
            color="bg-gradient-to-r from-green-500 to-green-600"
            onClick={() => handleCardClick('records')}
          />
          
          <StatCard
            icon={<TrendingUp className="h-6 w-6 text-white" />}
            iconName="完成率"
            title="完成率"
            value={`${statistics.completionRate.toFixed(1)}%`}
            subtitle="本月完成情况"
            trend={statistics.completionRate >= 80 ? 'up' : statistics.completionRate >= 60 ? 'neutral' : 'down'}
            color="bg-gradient-to-r from-purple-500 to-purple-600"
            onClick={() => handleCardClick('completion')}
          />
          
          <StatCard
            icon={<Calendar className="h-6 w-6 text-white" />}
            iconName="提醒"
            title="活跃提醒"
            value={statistics.activeMedications}
            subtitle="当前有效提醒"
            trend="up"
            color="bg-gradient-to-r from-orange-500 to-orange-600"
            onClick={() => handleCardClick('reminders')}
          />
        </div>

        {/* 图表区域 */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* 月度趋势 */}
          <div className="xl:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900">月度趋势</h3>
            </div>
            
            <div className="space-y-4">
              {statistics.monthlyTrends.map((trend, index) => (
                <div key={index} className="flex items-center justify-between group">
                  <span className="text-sm font-medium text-gray-600 w-16">{trend.month}</span>
                  <div className="flex-1 mx-4">
                    <div className="flex space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-3 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-700 ease-out group-hover:from-blue-600 group-hover:to-blue-700"
                          style={{ 
                            width: `${Math.min((trend.records / Math.max(...statistics.monthlyTrends.map(t => t.records))) * 100, 100)}%`,
                            transitionDelay: `${index * 100}ms`
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-gray-900 w-8 text-right">{trend.records}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 药物类型分布 */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900">药物类型分布</h3>
            </div>
            
            <div className="space-y-4">
              {statistics.medicationTypes.map((type, index) => (
                <div key={index} className="flex items-center justify-between group">
                  <div className="flex items-center flex-1 min-w-0">
                    <div 
                      className="w-4 h-4 rounded-full mr-3 flex-shrink-0 group-hover:scale-110 transition-transform duration-200"
                      style={{ backgroundColor: `hsl(${index * 72}, 70%, 50%)` }}
                    ></div>
                    <span className="text-sm text-gray-700 truncate font-medium">{type.name}</span>
                  </div>
                  <div className="flex items-center space-x-2 ml-2">
                    <span className="text-sm text-gray-500">{type.percentage.toFixed(1)}%</span>
                    <span className="text-sm font-bold text-gray-900 bg-gray-50 px-2 py-1 rounded-md">{type.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 患者依从性排行 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">患者依从性排行</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-4 font-semibold text-gray-600">排名</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-600">患者姓名</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-600">依从率</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-600">已服用/总剂量</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-600">进度</th>
                </tr>
              </thead>
              <tbody>
                {statistics.adherenceRates.map((patient, index) => (
                  <tr 
                    key={index} 
                    className="border-b border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => handlePatientClick(patient.patientName)}
                  >
                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold ${
                        index < 3 ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {index + 1}
                      </span>
                    </td>
                    <td className="py-4 px-4 font-semibold text-gray-900">{patient.patientName}</td>
                    <td className="py-4 px-4">
                      <span className={`inline-flex px-3 py-1 text-sm font-bold rounded-full ${
                        patient.rate >= 90 ? 'bg-green-100 text-green-800' :
                        patient.rate >= 70 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {patient.rate.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-gray-600 font-medium">
                      {patient.takenDoses}/{patient.totalDoses}
                    </td>
                    <td className="py-4 px-4">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className={`h-3 rounded-full transition-all duration-700 ${
                            patient.rate >= 90 ? 'bg-gradient-to-r from-green-500 to-green-600' :
                            patient.rate >= 70 ? 'bg-gradient-to-r from-yellow-500 to-yellow-600' :
                            'bg-gradient-to-r from-red-500 to-red-600'
                          }`}
                          style={{ 
                            width: `${patient.rate}%`,
                            transitionDelay: `${index * 100}ms`
                          }}
                        ></div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default MedicationStatistics;