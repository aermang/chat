/**
 * 飞鸽风格即时通讯App - 聊天页面
 * 显示与特定好友的聊天对话界面
 */

import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Plus, Smile, Mic } from 'lucide-react';
import MobileToolbar from '../components/MobileToolbar';
import { useAppStore } from '../store';
import { formatTime, getInitials, getAvatarColor } from '../utils';
import { useIsMobile, useSafeArea, useTouchFeedback, useViewport, useMobile, useMobileStyles } from '../hooks';

/**
 * 聊天页面组件
 */
const Chat: React.FC = () => {
  const { friendId } = useParams<{ friendId: string }>();
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const {
    currentUser,
    friends,
    messages,
    loadMessages,
    sendMessage,
  } = useAppStore();
  
  // 移动端优化 Hooks
  const isMobile = useIsMobile();
  const { top, bottom } = useSafeArea();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  const mobileInfo = useMobile();

  /**
   * 处理移动端工具栏的显示/隐藏
   */
  const handleToggleMobileToolbar = () => {
    setShowMobileToolbar(!showMobileToolbar);
  };

  /**
   * 处理移动端工具栏的文件选择
   */
  const handleMobileFileSelect = (file: File) => {
    console.log('选择的文件:', file);
    // TODO: 实现文件发送逻辑
    setShowMobileToolbar(false);
  };

  /**
   * 处理移动端工具栏的图片选择
   */
  const handleMobileImageSelect = (imageUrl: string) => {
    console.log('选择的图片:', imageUrl);
    // TODO: 实现图片发送逻辑
    setShowMobileToolbar(false);
  };
  const { orientation } = useViewport();
  
  // 消息输入状态
  const [messageInput, setMessageInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [textareaHeight, setTextareaHeight] = useState(40);
  const [touchStartTime, setTouchStartTime] = useState(0);
  const [showMobileToolbar, setShowMobileToolbar] = useState(false);
  
  /**
   * 获取当前聊天的好友信息
   */
  const currentFriend = friends.find(friend => friend.id === friendId);
  
  /**
   * 加载聊天消息
   */
  useEffect(() => {
    if (friendId) {
      console.log('设置当前聊天:', friendId);
      loadMessages(friendId);
    }
    
    return () => {
      clearCurrentChat();
    };
  }, [friendId, loadMessages]);
  
  /**
   * 清空当前聊天
   */
  const clearCurrentChat = () => {
    console.log('清空当前聊天');
  };
  
  /**
   * 自动滚动到底部
   */
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  /**
   * 自动调整输入框高度
   */
  useEffect(() => {
    if (textareaRef.current) {
      const textarea = textareaRef.current;
      textarea.style.height = 'auto';
      const newHeight = Math.min(Math.max(textarea.scrollHeight, 40), isMobile ? 100 : 120);
      textarea.style.height = `${newHeight}px`;
      setTextareaHeight(newHeight);
    }
  }, [messageInput, isMobile]);
  
  /**
   * 滚动到消息底部
   */
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  /**
   * 处理发送消息
   */
  const handleSendMessage = async () => {
    if (!messageInput.trim() || !friendId || isSending) {
      return;
    }
    
    setIsSending(true);
    const content = messageInput.trim();
    setMessageInput('');
    
    try {
      await sendMessage(content, friendId);
    } catch (error) {
      console.error('发送消息失败:', error);
      setMessageInput(content); // 恢复输入内容
    } finally {
      setIsSending(false);
    }
  };
  
  /**
   * 处理键盘事件
   */
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  /**
   * 返回聊天列表
   */
  const handleBack = () => {
    navigate('/app/chats');
  };

  /**
   * 消息气泡组件 - 优化移动端显示
   */
  const MessageBubble: React.FC<{ message: any; isOwn: boolean; sender: any }> = ({ 
    message, 
    isOwn, 
    sender 
  }) => (
    <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
      <div className={`
        flex ${isOwn ? 'flex-row-reverse' : 'flex-row'}
        ${isMobile ? 'max-w-[85%]' : 'max-w-[80%]'}
      `}>
        {/* 头像 */}
        <div className={`flex-shrink-0 ${isOwn ? 'ml-2' : 'mr-2'}`}>
          {sender?.avatar ? (
            <img
              src={sender.avatar}
              alt={sender.username}
              className={`rounded-full object-cover ${isMobile ? 'w-8 h-8 sm:w-9 sm:h-9' : 'w-8 h-8'}`}
            />
          ) : (
            <div
              className={`
                rounded-full flex items-center justify-center text-white font-medium
                ${isMobile ? 'w-8 h-8 sm:w-9 sm:h-9 text-xs sm:text-sm' : 'w-8 h-8 text-sm'}
              `}
              style={{ backgroundColor: getAvatarColor(sender?.username || '') }}
            >
              {getInitials(sender?.username || '')}
            </div>
          )}
        </div>
        
        {/* 消息内容 */}
        <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
          <div
            className={`
              px-4 py-2 rounded-2xl max-w-full break-words
              ${isMobile ? 'px-3 py-2 sm:px-4' : 'px-4 py-2'}
              ${isOwn
                ? 'bg-green-500 text-white rounded-br-md'
                : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 rounded-bl-md'
              }
            `}
          >
            {message.message_type === 'text' ? (
              <p className={`
                leading-relaxed whitespace-pre-wrap
                ${isMobile ? 'text-sm sm:text-base' : 'text-sm'}
              `}>
                {message.content}
              </p>
            ) : (
              <div className={`
                text-gray-500
                ${isMobile ? 'text-sm' : 'text-sm'}
              `}>
                [不支持的消息类型]
              </div>
            )}
          </div>
          
          {/* 消息时间 */}
          <span className={`
            text-gray-500 dark:text-gray-400 mt-1
            ${isMobile ? 'text-xs' : 'text-xs'}
          `}>
            {formatTime(message.created_at)}
          </span>
        </div>
      </div>
    </div>
  );
  
  // 如果没有找到好友信息，显示错误页面
  if (!currentFriend) {
    return (
      <div className={`
        flex flex-col items-center justify-center h-full bg-white dark:bg-gray-900
        ${isMobile ? 'p-6' : 'p-8'}
      `}>
        <h2 className={`
          font-semibold text-gray-900 dark:text-white mb-4
          ${isMobile ? 'text-lg' : 'text-xl'}
        `}>
          用户不存在
        </h2>
        <button
          onClick={handleBack}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          className={`
            bg-green-500 hover:bg-green-600 active:bg-green-700 text-white 
            rounded-lg transition-colors touch-optimized
            ${isMobile ? 'px-8 py-4 text-base min-h-touch' : 'px-6 py-2 text-sm'}
          `}
        >
          返回聊天列表
        </button>
      </div>
    );
  }
  
  return (
    <div className={`
      flex flex-col h-full bg-gray-50 dark:bg-gray-900
      ${isMobile ? 'mobile-layout' : ''}
    `}>
      {/* 顶部标题栏 */}
      <header 
        className={`
          bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700
          ${isMobile ? 'px-4 py-3 safe-area-top' : 'px-4 py-3'}
        `}
        style={isMobile ? { paddingTop: `calc(12px + ${top}px)` } : {}}
      >
        <div className="flex items-center">
          <button
            onClick={handleBack}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className={`
              text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
              transition-colors touch-optimized
              ${isMobile ? 'p-3 -ml-3 min-h-touch min-w-touch' : 'p-2 -ml-2'}
            `}
          >
            <ArrowLeft className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
          </button>
          
          <div className="flex items-center ml-2">
            {/* 好友头像 */}
            {currentFriend.avatar ? (
              <img
                src={currentFriend.avatar}
                alt={currentFriend.username}
                className={`rounded-full object-cover ${isMobile ? 'w-9 h-9' : 'w-8 h-8'}`}
              />
            ) : (
              <div
                className={`
                  rounded-full flex items-center justify-center text-white font-medium
                  ${isMobile ? 'w-9 h-9 text-sm' : 'w-8 h-8 text-sm'}
                `}
                style={{ backgroundColor: getAvatarColor(currentFriend.username) }}
              >
                {getInitials(currentFriend.username)}
              </div>
            )}
            
            <div className="ml-3">
              <h1 className={`
                font-semibold text-gray-900 dark:text-white
                ${isMobile ? 'text-base sm:text-lg' : 'text-lg'}
              `}>
                {currentFriend.username}
              </h1>
            </div>
          </div>
        </div>
      </header>
      
      {/* 消息列表 */}
      <div className={`
        flex-1 overflow-y-auto space-y-4
        ${isMobile 
          ? 'p-3 sm:p-4 scroll-smooth-mobile overscroll-none' 
          : 'p-4'
        }
        ${orientation === 'landscape' && isMobile ? 'landscape-mode' : ''}
      `}>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className={`
              bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4
              ${isMobile ? 'w-20 h-20' : 'w-16 h-16'}
            `}>
              <Smile className={`text-gray-400 ${isMobile ? 'w-10 h-10' : 'w-8 h-8'}`} />
            </div>
            <p className={`
              text-gray-500 dark:text-gray-400
              ${isMobile ? 'text-base' : 'text-sm'}
            `}>
              开始聊天吧！
            </p>
          </div>
        ) : (
          <>
            {messages.map((message) => {
              const isOwn = message.sender_id === currentUser?.id;
              const sender = isOwn ? currentUser : currentFriend;
              
              return (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isOwn={isOwn}
                  sender={sender}
                />
              );
            })}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>
      
      {/* 消息输入区域 */}
      <div 
        className={`
          bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700
          ${isMobile ? 'p-3 sm:p-4 safe-area-bottom' : 'p-4'}
        `}
        style={isMobile ? { paddingBottom: `calc(12px + ${bottom}px)` } : {}}
      >
        <div className={`
          flex items-end
          ${isMobile ? 'space-x-2 sm:space-x-3' : 'space-x-3'}
        `}>
          {/* 更多功能按钮 */}
          <button 
            onClick={isMobile ? handleToggleMobileToolbar : undefined}
            className={`
              text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
              transition-colors touch-optimized
              ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
              ${showMobileToolbar && isMobile ? 'text-green-500 dark:text-green-400' : ''}
            `}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            <Plus className={`${isMobile ? 'w-6 h-6' : 'w-5 h-5'} ${showMobileToolbar && isMobile ? 'rotate-45' : ''} transition-transform`} />
          </button>
          
          {/* 消息输入框 */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="输入消息..."
              className={`
                w-full border border-gray-300 dark:border-gray-600 rounded-lg resize-none 
                focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent 
                bg-white dark:bg-gray-700 text-gray-900 dark:text-white 
                placeholder-gray-500 dark:placeholder-gray-400
                ${isMobile 
                  ? 'px-3 py-2 sm:px-4 sm:py-2 text-base' 
                  : 'px-4 py-2 text-sm'
                }
              `}
              rows={1}
              style={{ 
                height: `${textareaHeight}px`,
                minHeight: isMobile ? '44px' : '40px',
                maxHeight: isMobile ? '100px' : '120px'
              }}
            />
          </div>
          
          {/* 表情按钮 */}
          <button 
            className={`
              text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
              transition-colors touch-optimized
              ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
            `}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            <Smile className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
          </button>
          
          {/* 语音/发送按钮 */}
          {messageInput.trim() ? (
            <button
              onClick={handleSendMessage}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              disabled={isSending}
              className={`
                bg-green-500 hover:bg-green-600 active:bg-green-700 disabled:bg-green-300 
                text-white rounded-lg transition-colors touch-optimized
                ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
              `}
            >
              {isSending ? (
                <div className={`
                  animate-spin rounded-full border-b-2 border-white
                  ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}
                `}></div>
              ) : (
                <Send className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
              )}
            </button>
          ) : (
            <button 
              className={`
                text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white 
                transition-colors touch-optimized
                ${isMobile ? 'p-3 min-h-touch min-w-touch' : 'p-2'}
              `}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
            >
              <Mic className={isMobile ? 'w-6 h-6' : 'w-5 h-5'} />
            </button>
          )}
        </div>
        
        {/* 移动端工具栏 */}
        {isMobile && showMobileToolbar && (
          <MobileToolbar
            onFileSelect={handleMobileFileSelect}
            onImageSelect={handleMobileImageSelect}
            onClose={() => setShowMobileToolbar(false)}
          />
        )}
      </div>
    </div>
  );
};

export default Chat;