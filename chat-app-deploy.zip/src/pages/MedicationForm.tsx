import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft,
  Save,
  User,
  Pill,
  Calendar,
  Clock,
  FileText,
  AlertCircle
} from 'lucide-react';
import { useIsMobile } from '../hooks/useResponsive';
import { useTouchFeedback } from '../hooks/useTouch';
import PageContainer from '../components/Layout/PageContainer';
import { useSpecialMedicineStore } from '../hooks/useSpecialMedicineStore';
import { MedicationRecord, Patient } from '../types';

/**
 * 用药记录表单页面组件
 */
const MedicationForm: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const recordId = searchParams.get('id');
  const patientId = searchParams.get('patientId');
  const isEditing = !!recordId;
  
  const isMobile = useIsMobile();
  const { handleTouchStart, handleTouchEnd } = useTouchFeedback();
  
  // 获取状态管理中的数据和方法
  const { 
    medicationRecords,
    patients,
    loadMedicationRecords,
    loadPatients,
    createMedicationRecord,
    updateMedicationRecord
  } = useSpecialMedicineStore();

  // 表单状态
  const [formData, setFormData] = useState({
    patientId: patientId || '',
    medicineName: '',
    dosage: '',
    frequency: '',
    takenDate: new Date(),
    takenTime: '08:00',
    isTaken: false,
    notes: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);

  /**
   * 加载数据
   */
  useEffect(() => {
    const loadData = async () => {
      setDataLoading(true);
      try {
        await Promise.all([
          loadMedicationRecords(),
          loadPatients()
        ]);
      } catch (error) {
        console.error('加载数据失败:', error);
      } finally {
        setDataLoading(false);
      }
    };

    loadData();
  }, [loadMedicationRecords, loadPatients]);

  /**
   * 加载编辑数据
   */
  useEffect(() => {
    if (isEditing && recordId && medicationRecords.length > 0) {
      const record = medicationRecords.find(r => r.id === recordId);
      if (record) {
        setFormData({
          patientId: record.patientId,
          medicineName: record.medicineName,
          dosage: record.dosage,
          frequency: record.frequency,
          takenDate: record.takenDate,
          takenTime: record.takenTime,
          isTaken: record.isTaken,
          notes: record.notes || ''
        });
      }
    }
  }, [isEditing, recordId, medicationRecords]);

  /**
   * 处理输入变化
   */
  const handleInputChange = (field: string, value: string | Date | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // 清除对应字段的错误
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  /**
   * 验证表单
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.patientId) {
      newErrors.patientId = '请选择患者';
    }

    if (!formData.medicineName.trim()) {
      newErrors.medicineName = '请输入药品名称';
    }

    if (!formData.dosage.trim()) {
      newErrors.dosage = '请输入用药剂量';
    }

    if (!formData.frequency.trim()) {
      newErrors.frequency = '请输入用药频次';
    }

    if (!formData.takenDate) {
      newErrors.takenDate = '请选择用药日期';
    }

    if (!formData.takenTime) {
      newErrors.takenTime = '请选择用药时间';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * 处理保存
   */
  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      if (isEditing && recordId) {
        await updateMedicationRecord(recordId, formData);
      } else {
        await createMedicationRecord(formData);
      }
      
      // 修复：保存成功后返回到患者用药记录页面，而不是患者详情页面
      if (formData.patientId) {
        navigate(`/app/special-medicine/records?patientId=${formData.patientId}`);
      } else {
        navigate('/app/special-medicine/records');
      }
    } catch (error) {
      console.error('保存失败:', error);
      alert('保存失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  /**
   * 处理返回操作
   * 如果有patientId参数，返回到患者用药记录页面；否则返回到用药记录列表页面
   */
  const handleGoBack = () => {
    if (formData.patientId) {
      navigate(`/app/special-medicine/records?patientId=${formData.patientId}`);
    } else {
      navigate('/app/special-medicine/records');
    }
  };

  /**
   * 获取患者姓名
   */
  const getPatientName = (patientId: string): string => {
    const patient = patients.find(p => p.id === patientId);
    return patient ? patient.name : '';
  };

  if (dataLoading) {
    return (
      <PageContainer title={isEditing ? "编辑用药记录" : "添加用药记录"}>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">加载中...</p>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title={isEditing ? "编辑用药记录" : "添加用药记录"}
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleGoBack,
          label: "返回"
        },
        {
          icon: <Save className="w-5 h-5" />,
          onClick: handleSave,
          label: "保存",
          disabled: loading
        }
      ]}
    >
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
        <div className="flex-1 overflow-y-auto">
          <div className={`
            ${isMobile ? 'px-4 py-4' : 'px-6 py-6'}
          `}>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
                {/* 患者选择 */}
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <User className="w-4 h-4" />
                    <span>患者 *</span>
                  </label>
                  <select
                    value={formData.patientId}
                    onChange={(e) => handleInputChange('patientId', e.target.value)}
                    disabled={!!patientId} // 如果从患者详情页进入，禁用选择
                    className={`
                      w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                      text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500
                      focus:border-transparent transition-colors
                      ${errors.patientId ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                      ${patientId ? 'bg-gray-50 dark:bg-gray-600 cursor-not-allowed' : ''}
                      ${isMobile ? 'text-base' : 'text-sm'}
                    `}
                  >
                    <option value="">请选择患者</option>
                    {patients.map((patient) => (
                      <option key={patient.id} value={patient.id}>
                        {patient.name} - {patient.phone}
                      </option>
                    ))}
                  </select>
                  {errors.patientId && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.patientId}</span>
                    </p>
                  )}
                </div>

                {/* 药品名称 */}
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Pill className="w-4 h-4" />
                    <span>药品名称 *</span>
                  </label>
                  <input
                    type="text"
                    value={formData.medicineName}
                    onChange={(e) => handleInputChange('medicineName', e.target.value)}
                    placeholder="请输入药品名称"
                    className={`
                      w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                      text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400
                      focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors
                      ${errors.medicineName ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                      ${isMobile ? 'text-base' : 'text-sm'}
                    `}
                  />
                  {errors.medicineName && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.medicineName}</span>
                    </p>
                  )}
                </div>

                {/* 用药剂量和频次 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      用药剂量 *
                    </label>
                    <input
                      type="text"
                      value={formData.dosage}
                      onChange={(e) => handleInputChange('dosage', e.target.value)}
                      placeholder="如：100mg"
                      className={`
                        w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                        text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400
                        focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors
                        ${errors.dosage ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                        ${isMobile ? 'text-base' : 'text-sm'}
                      `}
                    />
                    {errors.dosage && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.dosage}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      <Clock className="w-4 h-4" />
                      <span>用药频次 *</span>
                    </label>
                    <input
                      type="text"
                      value={formData.frequency}
                      onChange={(e) => handleInputChange('frequency', e.target.value)}
                      placeholder="如：每日3次"
                      className={`
                        w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                        text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400
                        focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors
                        ${errors.frequency ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                        ${isMobile ? 'text-base' : 'text-sm'}
                      `}
                    />
                    {errors.frequency && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.frequency}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* 用药日期和时间 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      <Calendar className="w-4 h-4" />
                      <span>用药日期 *</span>
                    </label>
                    <input
                      type="date"
                      value={formData.takenDate instanceof Date ? formData.takenDate.toISOString().split('T')[0] : formData.takenDate}
                      onChange={(e) => handleInputChange('takenDate', new Date(e.target.value))}
                      className={`
                        w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                        text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500
                        focus:border-transparent transition-colors
                        ${errors.takenDate ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                        ${isMobile ? 'text-base' : 'text-sm'}
                      `}
                    />
                    {errors.takenDate && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.takenDate}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      <Clock className="w-4 h-4" />
                      <span>用药时间 *</span>
                    </label>
                    <input
                      type="time"
                      value={formData.takenTime}
                      onChange={(e) => handleInputChange('takenTime', e.target.value)}
                      className={`
                        w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                        text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500
                        focus:border-transparent transition-colors
                        ${errors.takenTime ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}
                        ${isMobile ? 'text-base' : 'text-sm'}
                      `}
                    />
                    {errors.takenTime && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.takenTime}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* 是否已服用 */}
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <span>服用状态</span>
                  </label>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="isTaken"
                        checked={formData.isTaken === true}
                        onChange={() => handleInputChange('isTaken', true)}
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                      />
                      <span className="text-sm text-gray-700 dark:text-gray-300">已服用</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="isTaken"
                        checked={formData.isTaken === false}
                        onChange={() => handleInputChange('isTaken', false)}
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                      />
                      <span className="text-sm text-gray-700 dark:text-gray-300">未服用</span>
                    </label>
                  </div>
                </div>

                {/* 备注 */}
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <FileText className="w-4 h-4" />
                    <span>备注</span>
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                    placeholder="请输入备注信息（可选）"
                    rows={4}
                    className={`
                      w-full px-4 py-3 border rounded-lg bg-white dark:bg-gray-700
                      text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400
                      focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors
                      border-gray-300 dark:border-gray-600 resize-none
                      ${isMobile ? 'text-base' : 'text-sm'}
                    `}
                  />
                </div>

                {/* 提交按钮 */}
                <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200 dark:border-gray-600">
                  <button
                    type="button"
                    onClick={handleGoBack}
                    onTouchStart={handleTouchStart}
                    onTouchEnd={handleTouchEnd}
                    className={`
                      px-6 py-3 border border-gray-300 dark:border-gray-600 rounded-lg
                      text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700
                      hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    onTouchStart={handleTouchStart}
                    onTouchEnd={handleTouchEnd}
                    className={`
                      px-6 py-3 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-300
                      text-white rounded-lg transition-colors flex items-center space-x-2
                      ${isMobile ? 'text-sm' : 'text-base'}
                    `}
                  >
                    {loading && (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    )}
                    <Save className="w-4 h-4" />
                    <span>{isEditing ? '更新记录' : '保存记录'}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </PageContainer>
  );
};

export default MedicationForm;

/**
 * 用药记录表单数据类型
 */
interface MedicationRecordForm {
  medicationId?: string;
  patientId: string;
  medicationName: string;
  dosage: string;
  frequency: string;
  recordDate: string;
  notes?: string;
}