/**
 * 飞鸽风格即时通讯App - 添加好友页面
 * 提供用户搜索和好友申请功能
 */

import React, { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, UserPlus, ArrowLeft, Loader2, User as UserIcon, Mail } from 'lucide-react';
import { useAppStore } from '../store';
import { User } from '../types';
import { getInitials, getAvatarColor } from '../utils';
import PageContainer from '../components/Layout/PageContainer';
import { useIsMobile } from '../hooks/useIsMobile';
import { toast } from 'sonner';

/**
 * 用户搜索结果卡片组件
 */
interface UserCardProps {
  user: User;
  onAddFriend: (userId: string) => void;
  isLoading: boolean;
  isAlreadyFriend: boolean;
  hasPendingRequest: boolean;
}

const UserCard: React.FC<UserCardProps> = ({ 
  user, 
  onAddFriend, 
  isLoading, 
  isAlreadyFriend, 
  hasPendingRequest 
}) => {
  const isMobile = useIsMobile();

  /**
   * 处理添加好友按钮点击
   */
  const handleAddClick = () => {
    if (!isLoading && !isAlreadyFriend && !hasPendingRequest) {
      onAddFriend(user.id);
    }
  };

  /**
   * 获取按钮状态和文本
   */
  const getButtonState = () => {
    if (isLoading) return { text: '发送中...', disabled: true, className: 'bg-gray-400' };
    if (isAlreadyFriend) return { text: '已是好友', disabled: true, className: 'bg-gray-400' };
    if (hasPendingRequest) return { text: '已发送', disabled: true, className: 'bg-gray-400' };
    return { text: '添加', disabled: false, className: 'bg-blue-500 hover:bg-blue-600' };
  };

  const buttonState = getButtonState();

  return (
    <div className={`
      bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700
      ${isMobile ? 'mx-4' : ''}
    `}>
      <div className="flex items-center space-x-4">
        {/* 用户头像 */}
        <div className="flex-shrink-0">
          {user.avatar_url ? (
            <img
              src={user.avatar_url}
              alt={user.username}
              className="w-12 h-12 rounded-full object-cover"
              onError={(e) => {
                // 头像加载失败时显示默认头像
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.nextElementSibling?.classList.remove('hidden');
              }}
            />
          ) : null}
          <div
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold ${
              user.avatar_url ? 'hidden' : ''
            }`}
            style={{ backgroundColor: getAvatarColor(user.username) }}
          >
            {getInitials(user.username)}
          </div>
        </div>

        {/* 用户信息 */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <h3 className="font-medium text-gray-900 dark:text-white truncate">
              {user.nickname || user.username}
            </h3>
            {user.is_online && (
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            )}
          </div>
          <div className="flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400 mt-1">
            <UserIcon className="w-3 h-3" />
            <span className="truncate">{user.username}</span>
          </div>
          {user.email && (
            <div className="flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400">
              <Mail className="w-3 h-3" />
              <span className="truncate">{user.email}</span>
            </div>
          )}
          {user.bio && (
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">
              {user.bio}
            </p>
          )}
        </div>

        {/* 添加按钮 */}
        <button
          onClick={handleAddClick}
          disabled={buttonState.disabled}
          className={`
            px-4 py-2 rounded-lg text-white font-medium transition-colors
            flex items-center space-x-2 min-w-[80px] justify-center
            ${buttonState.className}
            ${buttonState.disabled ? 'cursor-not-allowed' : 'cursor-pointer'}
          `}
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <UserPlus className="w-4 h-4" />
          )}
          <span>{buttonState.text}</span>
        </button>
      </div>
    </div>
  );
};

/**
 * 添加好友页面组件
 */
const AddFriend: React.FC = () => {
  const navigate = useNavigate();
  const { 
    currentUser,
    searchUsers,
    sendFriendRequest,
    friends,
    friendRequests,
    loadFriends,
    loadFriendRequests
  } = useAppStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [loadingUserId, setLoadingUserId] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  
  const isMobile = useIsMobile();

  // 加载好友列表和好友申请
  useEffect(() => {
    loadFriends();
    loadFriendRequests();
  }, [loadFriends, loadFriendRequests]);

  /**
   * 执行用户搜索
   */
  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim() || !currentUser) return;

    setIsSearching(true);
    setHasSearched(true);
    
    try {
      const results = await searchUsers(searchQuery.trim(), currentUser.id);
      setSearchResults(results);
      
      if (results.length === 0) {
        toast.info('未找到匹配的用户');
      }
    } catch (error) {
      console.error('搜索用户失败:', error);
      toast.error('搜索失败，请重试');
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, currentUser, searchUsers]);

  /**
   * 处理搜索输入框回车事件
   */
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  /**
   * 处理添加好友请求
   */
  const handleAddFriend = async (userId: string) => {
    if (!currentUser) return;

    setLoadingUserId(userId);
    
    try {
      const success = await sendFriendRequest(userId, '你好，我想添加你为好友');
      
      if (success) {
        toast.success('好友申请已发送');
        // 重新加载好友申请列表以更新状态
        await loadFriendRequests();
      } else {
        toast.error('发送好友申请失败');
      }
    } catch (error) {
      console.error('发送好友申请失败:', error);
      toast.error('发送好友申请失败，请重试');
    } finally {
      setLoadingUserId(null);
    }
  };

  /**
   * 检查用户是否已经是好友
   */
  const isAlreadyFriend = (userId: string): boolean => {
    return friends.some(friend => friend.id === userId);
  };

  /**
   * 检查是否有待处理的好友申请
   */
  const hasPendingRequest = (userId: string): boolean => {
    return friendRequests.some(
      request => request.to_user_id === userId && request.status === 'pending'
    );
  };

  /**
   * 处理返回按钮点击
   */
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <PageContainer
      title="添加好友"
      actions={[
        {
          icon: <ArrowLeft className="w-5 h-5" />,
          onClick: handleBack,
          label: "返回"
        }
      ]}
    >
      <div className="flex flex-col h-full">
        {/* 搜索区域 */}
        <div className={`bg-white dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700 ${
          isMobile ? '' : 'rounded-t-lg'
        }`}>
          <div className="flex space-x-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="输入用户名或邮箱搜索用户"
                className="
                  w-full px-4 py-3 pr-10 border border-gray-300 dark:border-gray-600 
                  rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent
                  bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                  placeholder-gray-500 dark:placeholder-gray-400
                "
                disabled={isSearching}
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            <button
              onClick={handleSearch}
              disabled={isSearching || !searchQuery.trim()}
              className="
                px-6 py-3 bg-blue-500 text-white rounded-lg font-medium
                hover:bg-blue-600 disabled:bg-gray-400 disabled:cursor-not-allowed
                transition-colors flex items-center space-x-2
              "
            >
              {isSearching ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
              <span className={isMobile ? 'hidden' : 'block'}>搜索</span>
            </button>
          </div>
        </div>

        {/* 搜索结果区域 */}
        <div className="flex-1 overflow-y-auto">
          {isSearching ? (
            // 加载状态
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin text-blue-500 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">搜索中...</p>
              </div>
            </div>
          ) : hasSearched ? (
            searchResults.length > 0 ? (
              // 搜索结果列表
              <div className="py-4 space-y-3">
                {searchResults.map((user) => (
                  <UserCard
                    key={user.id}
                    user={user}
                    onAddFriend={handleAddFriend}
                    isLoading={loadingUserId === user.id}
                    isAlreadyFriend={isAlreadyFriend(user.id)}
                    hasPendingRequest={hasPendingRequest(user.id)}
                  />
                ))}
              </div>
            ) : (
              // 无搜索结果
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <UserIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">未找到匹配的用户</p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                    请尝试其他搜索关键词
                  </p>
                </div>
              </div>
            )
          ) : (
            // 初始状态
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <UserPlus className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">输入用户名或邮箱搜索用户</p>
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                  找到心仪的朋友，发送好友申请吧
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </PageContainer>
  );
};

export default AddFriend;