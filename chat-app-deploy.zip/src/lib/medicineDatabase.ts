import Dexie, { Table } from 'dexie';

/**
 * 患者信息接口
 */
export interface Patient {
  id: string;
  name: string;
  gender: 'male' | 'female';
  birthDate?: string;
  age?: number;
  idCard?: string;
  phone: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  address?: string;
  doctor: string;
  hospital?: string;
  diagnosis: string;
  treatment: string;
  allergies?: string[];
  medicalHistory?: string;
  isActive: boolean;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * 用药信息接口
 */
export interface Medication {
  id?: string;
  patientId: string;
  medicineName: string;
  cycleDays: number;
  dailyFrequency: number;
  startDate: Date;
  endDate?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * 用药记录接口
 */
export interface MedicationRecord {
  id: string;
  medicationId: string;
  /** 患者ID */
  patientId: string;
  /** 药品名称 */
  medicineName: string;
  /** 剂量 */
  dosage: string;
  /** 用药频次 */
  frequency: string;
  takenDate: Date;
  /** 记录日期 */
  recordDate?: Date;
  takenTime: string;
  isTaken: boolean;
  notes?: string;
  createdAt: Date;
  /** 更新时间 */
  updatedAt: Date;
}

/**
 * 用药提醒接口
 */
export interface Reminder {
  id?: string;
  medicationId: string;
  enabled: boolean;
  advanceDays: number;
  reminderTime: string;
  soundEnabled: boolean;
  nextReminderDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * 特药管理数据库类
 */
export class MedicineDatabase extends Dexie {
  patients!: Table<Patient>;
  medications!: Table<Medication>;
  medicationRecords!: Table<MedicationRecord>;
  reminders!: Table<Reminder>;

  constructor() {
    super('MedicineDatabase');
    
    this.version(1).stores({
      patients: '++id, name, phone, doctor, createdAt',
      medications: '++id, patientId, medicineName, startDate, isActive, createdAt',
      medicationRecords: '++id, medicationId, patientId, medicineName, takenDate, createdAt',
      reminders: '++id, medicationId, enabled, nextReminderDate, createdAt'
    });
  }
}

// 创建数据库实例
export const medicineDb = new MedicineDatabase();

/**
 * 初始化特药管理数据库
 */
export async function initializeMedicineDatabase() {
  try {
    await medicineDb.open();
    console.log('特药管理数据库初始化成功');
    
    // 检查是否需要初始化测试数据
    const patientCount = await medicineDb.patients.count();
    if (patientCount === 0) {
      await initializeTestData();
    }
  } catch (error) {
    console.error('特药管理数据库初始化失败:', error);
  }
}

/**
 * 初始化测试数据
 */
async function initializeTestData() {
  try {
    // 添加测试患者
    const testPatients: Patient[] = [
      {
        id: '1',
        name: '张三',
        gender: 'male',
        birthDate: '1990-01-01',
        age: 34,
        idCard: '110101199001011234',
        phone: '13800138000',
        emergencyContact: '张夫人',
        emergencyPhone: '13800138001',
        address: '北京市朝阳区',
        doctor: '李医生',
        hospital: '北京协和医院',
        diagnosis: '高血压',
        treatment: '降压药物治疗',
        allergies: ['青霉素'],
        medicalHistory: '无重大疾病史',
        isActive: true,
        notes: '定期复查',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '2',
        name: '李四',
        gender: 'female',
        birthDate: '1990-02-02',
        age: 34,
        idCard: '110101199002022345',
        phone: '13900139000',
        emergencyContact: '李先生',
        emergencyPhone: '13900139001',
        address: '北京市海淀区',
        doctor: '王医生',
        hospital: '北京大学第一医院',
        diagnosis: '糖尿病',
        treatment: '胰岛素治疗',
        allergies: ['磺胺类药物'],
        medicalHistory: '家族糖尿病史',
        isActive: true,
        notes: '血糖监测',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    const patientIds = await medicineDb.patients.bulkAdd(testPatients, { allKeys: true });
    
    // 添加测试用药记录
    const testMedications: Medication[] = [
      {
        patientId: patientIds[0] as string,
        medicineName: '降压药',
        cycleDays: 30,
        dailyFrequency: 2,
        startDate: new Date(),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        patientId: patientIds[1] as string,
        medicineName: '胰岛素',
        cycleDays: 30,
        dailyFrequency: 3,
        startDate: new Date(),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    const medicationIds = await medicineDb.medications.bulkAdd(testMedications, { allKeys: true });

    // 添加测试提醒
    const testReminders: Reminder[] = [
      {
        medicationId: medicationIds[0] as string,
        enabled: true,
        advanceDays: 1,
        reminderTime: '08:00',
        soundEnabled: true,
        nextReminderDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        medicationId: medicationIds[1] as string,
        enabled: true,
        advanceDays: 1,
        reminderTime: '09:00',
        soundEnabled: true,
        nextReminderDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    await medicineDb.reminders.bulkAdd(testReminders);
    
    console.log('特药管理测试数据初始化完成');
  } catch (error) {
    console.error('初始化测试数据失败:', error);
  }
}

/**
 * 患者信息管理服务
 */
export class PatientService {
  /**
   * 获取患者列表
   */
  static async getPatients(options?: {
    page?: number;
    limit?: number;
    search?: string;
  }): Promise<{
    patients: Patient[];
    total: number;
    hasMore: boolean;
  }> {
    const { page = 1, limit = 10, search } = options || {};
    
    let query = medicineDb.patients.orderBy('createdAt').reverse();
    
    if (search) {
      query = query.filter(patient => 
        patient.name.includes(search) || 
        patient.phone.includes(search) ||
        patient.doctor.includes(search)
      );
    }
    
    const total = await query.count();
    const patients = await query.offset((page - 1) * limit).limit(limit).toArray();
    
    return {
      patients,
      total,
      hasMore: page * limit < total
    };
  }

  /**
   * 根据ID获取患者信息
   */
  static async getPatientById(id: string): Promise<Patient | undefined> {
    return await medicineDb.patients.get(id);
  }

  /**
   * 创建患者
   */
  static async createPatient(patientData: {
    name: string;
    gender: 'male' | 'female';
    phone: string;
    doctor: string;
    diagnosis: string;
    treatment: string;
  }): Promise<Patient> {
    const patient: Patient = {
      id: Date.now().toString(),
      ...patientData,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    await medicineDb.patients.add(patient);
    return patient;
  }

  /**
   * 更新患者信息
   */
  static async updatePatient(id: string, updates: Partial<Patient>): Promise<boolean> {
    const updateData = {
      ...updates,
      updatedAt: new Date()
    };
    
    const result = await medicineDb.patients.update(id, updateData);
    return result > 0;
  }

  /**
   * 删除患者
   */
  static async deletePatient(id: string): Promise<boolean> {
    // 先删除相关的用药记录和提醒
    const medications = await medicineDb.medications.where('patientId').equals(id).toArray();
    const medicationIds = medications.map(m => m.id!);
    
    await medicineDb.transaction('rw', [medicineDb.patients, medicineDb.medications, medicineDb.medicationRecords, medicineDb.reminders], async () => {
      // 删除用药记录
      for (const medicationId of medicationIds) {
        await medicineDb.medicationRecords.where('medicationId').equals(medicationId).delete();
        await medicineDb.reminders.where('medicationId').equals(medicationId).delete();
      }
      
      // 删除用药信息
      await medicineDb.medications.where('patientId').equals(id).delete();
      
      // 删除患者
      await medicineDb.patients.delete(id);
    });
    
    return true;
  }
}

/**
 * 用药记录管理服务
 */
export class MedicationService {
  /**
   * 创建用药记录
   */
  static async createMedication(medicationData: {
    patientId: string;
    medicineName: string;
    cycleDays: number;
    dailyFrequency: number;
    startDate: Date;
    endDate?: Date;
  }): Promise<Medication> {
    const medication: Medication = {
      ...medicationData,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const id = await medicineDb.medications.add(medication);
    return { ...medication, id: id as string };
  }

  /**
   * 获取患者用药记录
   */
  static async getPatientMedications(patientId: string): Promise<Medication[]> {
    const medications = await medicineDb.medications
      .where('patientId')
      .equals(patientId)
      .toArray();
    
    // 按创建时间倒序排列
    return medications.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  /**
   * 获取所有活跃的用药记录
   */
  static async getActiveMedications(): Promise<Medication[]> {
    return await medicineDb.medications
      .where('isActive')
      .equals(1)
      .toArray();
  }

  /**
   * 记录用药情况
   */
  static async recordMedicationTaken(medicationId: string, takenData: {
    takenDate: Date;
    takenTime: string;
    isTaken: boolean;
    notes?: string;
  }): Promise<MedicationRecord> {
    // 获取用药信息来填充必需字段
    const medication = await medicineDb.medications.get(medicationId);
    if (!medication) {
      throw new Error('用药记录不存在');
    }

    const recordData: Omit<MedicationRecord, 'id'> = {
      medicationId,
      patientId: medication.patientId,
      medicineName: medication.medicineName,
      dosage: '1片', // 默认剂量，实际应该从medication中获取
      frequency: `每日${medication.dailyFrequency}次`,
      ...takenData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const id = await medicineDb.medicationRecords.add(recordData as any);
    const record: MedicationRecord = { ...recordData, id: id as string };
    return record;
  }

  /**
   * 获取用药记录
   */
  static async getMedicationRecords(medicationId: string): Promise<MedicationRecord[]> {
    return await medicineDb.medicationRecords
      .where('medicationId')
      .equals(medicationId)
      .reverse()
      .toArray();
  }

  /**
   * 更新用药信息
   */
  static async updateMedication(id: string, updates: Partial<Medication>): Promise<boolean> {
    const updateData = {
      ...updates,
      updatedAt: new Date()
    };
    
    const result = await medicineDb.medications.update(id, updateData);
    return result > 0;
  }

  /**
   * 添加用药记录
   */
  static async addMedicationRecord(recordData: {
    patientId: string;
    medicationName: string;
    dosage: string;
    frequency: string;
    recordDate: string;
    notes?: string;
  }): Promise<MedicationRecord> {
    const record: Omit<MedicationRecord, 'id'> = {
      medicationId: 'default', // 默认值，实际应该从参数中获取
      patientId: recordData.patientId,
      medicineName: recordData.medicationName,
      dosage: recordData.dosage,
      frequency: recordData.frequency,
      takenDate: new Date(recordData.recordDate),
      recordDate: new Date(recordData.recordDate),
      takenTime: '00:00', // 默认时间
      isTaken: true, // 默认已服用
      notes: recordData.notes || '',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const id = await medicineDb.medicationRecords.add(record as any);
    return { ...record, id: id as string };
  }

  /**
   * 更新用药记录
   */
  static async updateMedicationRecord(id: string, updates: {
    patientId?: string;
    medicationName?: string;
    dosage?: string;
    frequency?: string;
    recordDate?: string;
    notes?: string;
  }): Promise<boolean> {
    const updateData: Partial<MedicationRecord> = {
      updatedAt: new Date()
    };

    if (updates.patientId) updateData.patientId = updates.patientId;
    if (updates.medicationName) updateData.medicineName = updates.medicationName;
    if (updates.dosage) updateData.dosage = updates.dosage;
    if (updates.frequency) updateData.frequency = updates.frequency;
    if (updates.recordDate) {
      updateData.takenDate = new Date(updates.recordDate);
      (updateData as any).recordDate = new Date(updates.recordDate);
    }
    if (updates.notes !== undefined) updateData.notes = updates.notes;

    const result = await medicineDb.medicationRecords.update(id, updateData);
    return result > 0;
  }

  /**
   * 获取所有用药记录
   */
  static async getAllMedicationRecords(): Promise<MedicationRecord[]> {
    return await medicineDb.medicationRecords
      .orderBy('createdAt')
      .reverse()
      .toArray();
  }
}

/**
 * 用药提醒管理服务
 */
export class ReminderService {
  /**
   * 设置用药提醒
   */
  static async setMedicationReminder(medicationId: string, settings: {
    enabled: boolean;
    advanceDays: number;
    reminderTime: string;
    soundEnabled: boolean;
  }): Promise<Reminder> {
    // 检查是否已存在提醒
    const existingReminder = await medicineDb.reminders
      .where('medicationId')
      .equals(medicationId)
      .first();

    const reminderData: Reminder = {
      medicationId,
      ...settings,
      nextReminderDate: this.calculateNextReminderDate(settings.advanceDays, settings.reminderTime),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    if (existingReminder) {
      await medicineDb.reminders.update(existingReminder.id!, reminderData);
      return { ...reminderData, id: existingReminder.id };
    } else {
      const id = await medicineDb.reminders.add(reminderData as any);
      return { ...reminderData, id: id as string };
    }
  }

  /**
   * 获取待提醒列表
   */
  static async getPendingReminders(): Promise<Reminder[]> {
    const now = new Date();
    return await medicineDb.reminders
      .where('enabled')
      .equals(1)
      .and(reminder => 
        reminder.nextReminderDate ? reminder.nextReminderDate <= now : false
      )
      .toArray();
  }

  /**
   * 标记提醒已处理
   */
  static async markReminderProcessed(reminderId: string): Promise<boolean> {
    const reminder = await medicineDb.reminders.get(reminderId);
    if (!reminder) return false;

    const nextReminderDate = this.calculateNextReminderDate(
      reminder.advanceDays, 
      reminder.reminderTime
    );

    const result = await medicineDb.reminders.update(reminderId, {
      nextReminderDate,
      updatedAt: new Date()
    });

    return result > 0;
  }

  /**
   * 获取用药提醒设置
   */
  static async getMedicationReminder(medicationId: string): Promise<Reminder | undefined> {
    return await medicineDb.reminders
      .where('medicationId')
      .equals(medicationId)
      .first();
  }

  /**
   * 计算下次提醒时间
   */
  private static calculateNextReminderDate(advanceDays: number, reminderTime: string): Date {
    const [hours, minutes] = reminderTime.split(':').map(Number);
    const nextDate = new Date();
    nextDate.setDate(nextDate.getDate() + advanceDays);
    nextDate.setHours(hours, minutes, 0, 0);
    return nextDate;
  }
}

/**
 * 统计分析服务
 */
export class StatisticsService {
  /**
   * 获取患者统计信息
   */
  static async getPatientStatistics(): Promise<{
    totalPatients: number;
    activePatients: number;
    totalMedications: number;
    activeMedications: number;
  }> {
    const totalPatients = await medicineDb.patients.count();
    const totalMedications = await medicineDb.medications.count();
    const activeMedications = await medicineDb.medications.where('isActive').equals(1).count();
    
    // 计算活跃患者（有活跃用药记录的患者）
    const activeMedicationsList = await medicineDb.medications.where('isActive').equals(1).toArray();
    const activePatientIds = new Set(activeMedicationsList.map(m => m.patientId));
    const activePatients = activePatientIds.size;

    return {
      totalPatients,
      activePatients,
      totalMedications,
      activeMedications
    };
  }

  /**
   * 获取用药统计数据
   */
  static async getMedicationStatistics(days: number = 30): Promise<{
    medicationUsage: Array<{
      medicineName: string;
      totalTaken: number;
      totalMissed: number;
      adherenceRate: number;
    }>;
    dailyAdherence: Array<{
      date: string;
      taken: number;
      missed: number;
    }>;
  }> {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // 获取指定时间范围内的用药记录
    const records = await medicineDb.medicationRecords
      .where('takenDate')
      .between(startDate, endDate)
      .toArray();

    // 获取相关的用药信息
    const medicationIds = [...new Set(records.map(r => r.medicationId))];
    const medications = await medicineDb.medications.bulkGet(medicationIds);
    const medicationMap = new Map(medications.filter(m => m).map(m => [m!.id!, m!]));

    // 统计用药使用情况
    const medicationUsage = new Map<string, {
      medicineName: string;
      totalTaken: number;
      totalMissed: number;
    }>();

    records.forEach(record => {
      const medication = medicationMap.get(record.medicationId);
      if (!medication) return;

      const key = medication.medicineName;
      if (!medicationUsage.has(key)) {
        medicationUsage.set(key, {
          medicineName: key,
          totalTaken: 0,
          totalMissed: 0
        });
      }

      const usage = medicationUsage.get(key)!;
      if (record.isTaken) {
        usage.totalTaken++;
      } else {
        usage.totalMissed++;
      }
    });

    // 计算依从性
    const medicationUsageArray = Array.from(medicationUsage.values()).map(usage => ({
      ...usage,
      adherenceRate: usage.totalTaken + usage.totalMissed > 0 
        ? (usage.totalTaken / (usage.totalTaken + usage.totalMissed)) * 100 
        : 0
    }));

    // 统计每日依从性
    const dailyAdherence = new Map<string, { taken: number; missed: number }>();
    
    records.forEach(record => {
      const dateKey = record.takenDate.toISOString().split('T')[0];
      if (!dailyAdherence.has(dateKey)) {
        dailyAdherence.set(dateKey, { taken: 0, missed: 0 });
      }

      const daily = dailyAdherence.get(dateKey)!;
      if (record.isTaken) {
        daily.taken++;
      } else {
        daily.missed++;
      }
    });

    const dailyAdherenceArray = Array.from(dailyAdherence.entries())
      .map(([date, data]) => ({
        date,
        ...data
      }))
      .sort((a, b) => a.date.localeCompare(b.date));

    return {
      medicationUsage: medicationUsageArray,
      dailyAdherence: dailyAdherenceArray
    };
  }
}