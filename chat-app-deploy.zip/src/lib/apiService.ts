/**
 * API服务 - 与后端MongoDB服务器通信
 * 替代IndexedDB，使用HTTP API进行数据操作
 */

import { User, Message, Friendship, Moment, Like, Comment, ChatSession, FriendRequest, Notification } from '../types';

const API_BASE_URL = 'http://localhost:5000/api';

/**
 * HTTP请求工具类
 */
class HttpClient {
  private static async request<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const defaultOptions: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    // 获取存储的token
    const token = localStorage.getItem('auth_token');
    if (token) {
      defaultOptions.headers = {
        ...defaultOptions.headers,
        'Authorization': `Bearer ${token}`,
      };
    }

    const config = { ...defaultOptions, ...options };
    
    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error(`API请求失败 ${endpoint}:`, error);
      throw error;
    }
  }

  static async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  static async post<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  static async put<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  static async delete<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

/**
 * API服务类 - 替代DatabaseService
 */
export class ApiService {
  
  /**
   * 初始化数据库连接测试
   */
  static async initializeDatabase(): Promise<void> {
    try {
      const response = await HttpClient.get<{ status: string; message: string; database: string }>('/health');
      console.log('后端服务器连接成功:', response);
      
      if (response.database !== '已连接') {
        throw new Error('数据库未连接');
      }
    } catch (error) {
      console.error('初始化数据库连接失败:', error);
      throw error;
    }
  }

  /**
   * 用户认证相关
   */
  
  /**
   * 用户登录
   */
  static async login(username: string, password: string): Promise<{ user: User; token: string }> {
    const response = await HttpClient.post<{ success: boolean; data: { user: User; token: string } }>('/auth/login', {
      username,
      password
    });
    
    if (response.success && response.data) {
      // 存储token
      localStorage.setItem('auth_token', response.data.token);
      return response.data;
    }
    
    throw new Error('登录失败');
  }

  /**
   * 用户注册
   */
  static async register(userData: {
    username: string;
    email: string;
    password: string;
    nickname?: string;
  }): Promise<{ user: User; token: string }> {
    const response = await HttpClient.post<{ success: boolean; data: { user: User; token: string } }>('/auth/register', userData);
    
    if (response.success && response.data) {
      // 存储token
      localStorage.setItem('auth_token', response.data.token);
      return response.data;
    }
    
    throw new Error('注册失败');
  }

  /**
   * 用户登出
   */
  static async logout(): Promise<void> {
    try {
      await HttpClient.post('/auth/logout');
    } finally {
      // 清除本地token
      localStorage.removeItem('auth_token');
    }
  }

  /**
   * 用户相关操作
   */
  
  /**
   * 获取当前用户信息
   */
  static async getCurrentUser(): Promise<User> {
    const response = await HttpClient.get<{ success: boolean; data: { user: User } }>('/auth/me');
    
    if (response.success && response.data) {
      return response.data.user;
    }
    
    throw new Error('获取用户信息失败');
  }

  /**
   * 搜索用户
   */
  static async searchUsers(query: string, currentUserId?: string): Promise<User[]> {
    const response = await HttpClient.get<{ success: boolean; data: { users: User[] } }>(`/users/search?q=${encodeURIComponent(query)}`);
    
    if (response.success && response.data) {
      return response.data.users;
    }
    
    return [];
  }

  /**
   * 获取用户信息
   */
  static async getUserById(userId: string): Promise<User | null> {
    try {
      const response = await HttpClient.get<{ success: boolean; data: { user: User } }>(`/users/${userId}`);
      
      if (response.success && response.data) {
        return response.data.user;
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
    }
    
    return null;
  }

  /**
   * 好友相关操作
   */
  
  /**
   * 获取好友列表
   */
  static async getFriends(userId: string): Promise<Friendship[]> {
    const response = await HttpClient.get<{ success: boolean; data: { friends: Friendship[] } }>('/friends');
    
    if (response.success && response.data) {
      return response.data.friends;
    }
    
    return [];
  }

  /**
   * 发送好友申请
   */
  static async sendFriendRequest(fromUserId: string, toUserId: string, message?: string): Promise<FriendRequest> {
    const response = await HttpClient.post<{ success: boolean; data: { request: FriendRequest } }>('/friends/requests', {
      target_user_id: toUserId,
      message: message || '我想加你为好友'
    });
    
    if (response.success && response.data) {
      return response.data.request;
    }
    
    throw new Error('发送好友申请失败');
  }

  /**
   * 获取好友申请列表
   */
  static async getFriendRequests(userId: string): Promise<FriendRequest[]> {
    const response = await HttpClient.get<{ success: boolean; data: { requests: FriendRequest[] } }>('/friends/requests');
    
    if (response.success && response.data) {
      return response.data.requests;
    }
    
    return [];
  }

  /**
   * 处理好友申请
   */
  static async handleFriendRequest(requestId: string, action: 'accept' | 'reject' | 'ignore'): Promise<void> {
    await HttpClient.post(`/friends/requests/${requestId}/${action}`);
  }

  /**
   * 添加好友（直接添加，不需要申请）
   */
  static async addFriend(userId: string, friendId: string): Promise<boolean> {
    try {
      await HttpClient.post('/friends/add', { friend_id: friendId });
      return true;
    } catch (error) {
      console.error('添加好友失败:', error);
      return false;
    }
  }

  /**
   * 获取未读好友申请数量
   */
  static async getUnreadRequestCount(userId: string): Promise<number> {
    const response = await HttpClient.get<{ success: boolean; data: { count: number } }>('/friends/requests/unread-count');
    
    if (response.success && response.data) {
      return response.data.count;
    }
    
    return 0;
  }

  /**
   * 消息相关操作
   */
  
  /**
   * 获取聊天消息
   */
  static async getMessages(sessionId: string, page: number = 1, limit: number = 50): Promise<Message[]> {
    const response = await HttpClient.get<{ success: boolean; data: { messages: Message[] } }>(`/messages/${sessionId}?page=${page}&limit=${limit}`);
    
    if (response.success && response.data) {
      return response.data.messages;
    }
    
    return [];
  }

  /**
   * 发送消息
   */
  static async sendMessage(messageData: {
    receiver_id: string;
    content: string;
    message_type?: string;
  }): Promise<Message> {
    const response = await HttpClient.post<{ success: boolean; data: { message: Message } }>('/messages', messageData);
    
    if (response.success && response.data) {
      return response.data.message;
    }
    
    throw new Error('发送消息失败');
  }

  /**
   * 获取聊天会话列表
   */
  static async getChatSessions(userId: string): Promise<ChatSession[]> {
    const response = await HttpClient.get<{ success: boolean; data: { sessions: ChatSession[] } }>('/messages/sessions');
    
    if (response.success && response.data) {
      return response.data.sessions;
    }
    
    return [];
  }

  /**
   * 通知相关操作
   */
  
  /**
   * 获取通知列表
   */
  static async getNotifications(userId: string): Promise<Notification[]> {
    const response = await HttpClient.get<{ success: boolean; data: { notifications: Notification[] } }>('/notifications');
    
    if (response.success && response.data) {
      return response.data.notifications;
    }
    
    return [];
  }

  /**
   * 获取未读通知数量
   */
  static async getUnreadNotificationCount(userId: string, type?: string): Promise<number> {
    let endpoint = '/notifications/unread-count';
    if (type) {
      endpoint += `?type=${type}`;
    }
    
    const response = await HttpClient.get<{ success: boolean; data: { count: number } }>(endpoint);
    
    if (response.success && response.data) {
      return response.data.count;
    }
    
    return 0;
  }

  /**
   * 标记通知为已读
   */
  static async markNotificationAsRead(notificationId: string): Promise<void> {
    await HttpClient.put(`/notifications/${notificationId}/read`);
  }

  /**
   * 标记好友申请为已读
   */
  static async markRequestAsRead(requestId: string): Promise<void> {
    await HttpClient.put(`/friends/requests/${requestId}/read`);
  }

  /**
   * 清除通知徽章
   */
  static async clearNotificationBadge(userId: string, type?: string): Promise<void> {
    let endpoint = '/notifications/clear-badge';
    if (type) {
      endpoint += `?type=${type}`;
    }
    await HttpClient.post(endpoint);
  }

  /**
   * 验证用户数据完整性
   */
  static async validateUserDataIntegrity(userId: string): Promise<boolean> {
    try {
      const response = await HttpClient.get<{ success: boolean; data: { isValid: boolean } }>(`/users/${userId}/validate-integrity`);
      return response.success && response.data?.isValid;
    } catch (error) {
      console.error('验证数据完整性失败:', error);
      return false;
    }
  }

  /**
   * 朋友圈相关操作
   */
  
  /**
   * 获取朋友圈动态
   */
  static async getMoments(userId: string, page: number = 1, limit: number = 20): Promise<Moment[]> {
    const response = await HttpClient.get<{ success: boolean; data: { moments: Moment[] } }>(`/moments/timeline?page=${page}&limit=${limit}`);
    
    if (response.success && response.data) {
      return response.data.moments;
    }
    
    return [];
  }

  /**
   * 发布朋友圈动态
   */
  static async createMoment(momentData: {
    content: string;
    images?: string[];
    location?: string;
  }): Promise<Moment> {
    const response = await HttpClient.post<{ success: boolean; data: { moment: Moment } }>('/moments', momentData);
    
    if (response.success && response.data) {
      return response.data.moment;
    }
    
    throw new Error('发布动态失败');
  }

  /**
   * 数据备份和恢复（暂时保留接口，实际由服务器处理）
   */
  
  static async backupUserDataToStorage(userId: string): Promise<boolean> {
    // 服务器端数据自动备份，这里返回true
    return true;
  }

  static async restoreUserDataFromStorage(userId: string): Promise<boolean> {
    // 服务器端数据自动恢复，这里返回true
    return true;
  }

  static async clearCorruptedUserData(userId: string): Promise<void> {
    // 服务器端处理数据清理
    console.log('数据清理由服务器端处理');
  }

  /**
   * 获取备份信息
   */
  static async getBackupInfo(): Promise<{ hasBackup: boolean; lastBackupTime?: Date }> {
    try {
      const response = await HttpClient.get<{ success: boolean; data: { hasBackup: boolean; lastBackupTime?: string } }>('/backup/info');
      
      if (response.success && response.data) {
        return {
          hasBackup: response.data.hasBackup,
          lastBackupTime: response.data.lastBackupTime ? new Date(response.data.lastBackupTime) : undefined
        };
      }
    } catch (error) {
      console.error('获取备份信息失败:', error);
    }
    
    return { hasBackup: false };
  }
}

// 导出兼容的DatabaseService别名
export const DatabaseService = ApiService;