/**
 * 飞鸽风格即时通讯App - 数据库管理
 * 使用IndexedDB和Dexie.js进行本地数据存储
 */

import Dexie, { Table } from 'dexie';
import { User, Message, Friendship, Moment, Like, Comment, ChatSession, FriendRequest, Notification } from '../types';

/**
 * 数据库类，继承自Dexie
 * 定义所有数据表和索引
 */
export class WeChatDatabase extends Dexie {
  // 数据表定义
  users!: Table<User>;
  messages!: Table<Message>;
  friendships!: Table<Friendship>;
  moments!: Table<Moment>;
  likes!: Table<Like>;
  comments!: Table<Comment>;
  chatSessions!: Table<ChatSession>;
  friendRequests!: Table<FriendRequest>;
  notifications!: Table<Notification>;

  constructor() {
    super('WeChatDatabase');
    
    // 定义数据库版本和表结构
    this.version(4).stores({
      users: 'id, username, email, nickname, created_at, is_online',
      messages: 'id, sender_id, receiver_id, created_at, is_read, message_type',
      friendships: 'id, user_id, friend_id, status, created_at, [user_id+friend_id]',
      moments: 'id, user_id, created_at, likes_count, comments_count',
      likes: 'id, moment_id, user_id, created_at',
      comments: 'id, moment_id, user_id, created_at',
      chatSessions: 'id, user_id, friend_id, updated_at, unread_count',
      friendRequests: 'id, from_user_id, to_user_id, status, created_at, is_read, [from_user_id+to_user_id]',
      notifications: 'id, user_id, type, created_at, is_read'
    });
  }
}

// 创建数据库实例
export const db = new WeChatDatabase();

/**
 * 数据库操作类
 * 封装常用的数据库操作方法
 */
export class DatabaseService {
  
  /**
   * 初始化数据库，创建测试数据
   */
  static async initializeDatabase(): Promise<void> {
    try {
      // 检查是否已有用户数据
      const userCount = await db.users.count();
      if (userCount > 0) {
        return; // 已有数据，不需要初始化
      }

      // 创建测试用户
      const testUsers: User[] = [
        {
          id: 'user-1',
          username: 'zhangsan',
          email: 'demo1@example.com',
          nickname: '张三',
          password: '123456', // 添加密码字段
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20young%20man&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: true
        },
        {
          id: 'user-2',
          username: 'lisi',
          email: 'demo2@example.com',
          nickname: '李四',
          password: '123456', // 添加密码字段
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20young%20woman&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: false
        },
        {
          id: 'user-3',
          username: 'wangwu',
          email: 'demo3@example.com',
          nickname: '王五',
          password: '123456', // 添加密码字段
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20middle%20aged%20person&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: true
        },
        {
          id: 'user-4',
          username: 'xiaoming',
          email: 'xiaoming@example.com',
          nickname: '小明',
          password: '123456',
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20student&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: true
        },
        {
          id: 'user-5',
          username: 'xiaohong',
          email: 'xiaohong@example.com',
          nickname: '小红',
          password: '123456',
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20young%20girl&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: false
        },
        {
          id: 'user-6',
          username: 'admin',
          email: 'admin@example.com',
          nickname: '管理员',
          password: '123456',
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20an%20administrator&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: true
        },
        {
          id: 'user-7',
          username: 'test123',
          email: 'test123@example.com',
          nickname: '测试用户',
          password: '123456',
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20tester&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: false
        },
        {
          id: 'user-8',
          username: 'developer',
          email: 'dev@example.com',
          nickname: '开发者',
          password: '123456',
          avatar_url: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=professional%20avatar%20portrait%20of%20a%20developer&image_size=square',
          created_at: new Date(),
          updated_at: new Date(),
          is_online: true
        }
      ];

      // 插入测试用户
      await db.users.bulkAdd(testUsers);

      // 创建好友关系
      const friendships: Friendship[] = [
        {
          id: 'friendship-1',
          user_id: 'user-1',
          friend_id: 'user-2',
          status: 'accepted',
          created_at: new Date()
        },
        {
          id: 'friendship-2',
          user_id: 'user-1',
          friend_id: 'user-3',
          status: 'accepted',
          created_at: new Date()
        }
      ];

      await db.friendships.bulkAdd(friendships);

      // 创建测试消息
      const messages: Message[] = [
        {
          id: 'msg-1',
          sender_id: 'user-2',
          receiver_id: 'user-1',
          content: '你好！很高兴认识你！',
          message_type: 'text',
          created_at: new Date(Date.now() - 3600000), // 1小时前
          is_read: false
        },
        {
          id: 'msg-2',
          sender_id: 'user-3',
          receiver_id: 'user-1',
          content: '今天天气不错呢～',
          message_type: 'text',
          created_at: new Date(Date.now() - 1800000), // 30分钟前
          is_read: false
        }
      ];

      await db.messages.bulkAdd(messages);

      // 创建测试聊天会话
      await db.chatSessions.bulkAdd([
        {
          id: 'session-1',
          user_id: 'user-1',
          friend_id: 'user-2',
          unread_count: 2,
          last_message_time: new Date(Date.now() - 3600000),
          updated_at: new Date(Date.now() - 3600000)
        },
        {
          id: 'session-2',
          user_id: 'user-1',
          friend_id: 'user-3',
          unread_count: 0,
          last_message_time: new Date(Date.now() - 1800000),
          updated_at: new Date(Date.now() - 1800000)
        }
      ]);

      // 创建朋友圈动态
      const moments: Moment[] = [
        {
          id: 'moment-1',
          user_id: 'user-2',
          content: '今天的阳光真好！☀️',
          images: ['https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=beautiful%20sunny%20day%20landscape&image_size=landscape_4_3'],
          created_at: new Date(Date.now() - 7200000), // 2小时前
          likes_count: 2,
          comments_count: 1
        },
        {
          id: 'moment-2',
          user_id: 'user-3',
          content: '分享一张美食照片 🍜',
          images: ['https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=delicious%20chinese%20noodle%20soup%20food%20photography&image_size=square'],
          created_at: new Date(Date.now() - 10800000), // 3小时前
          likes_count: 1,
          comments_count: 0
        }
      ];

      await db.moments.bulkAdd(moments);

      console.log('数据库初始化完成');
    } catch (error) {
      console.error('数据库初始化失败:', error);
    }
  }

  /**
   * 用户认证相关方法
   */
  /**
   * 用户认证方法
   * 支持用户名或邮箱登录，验证密码
   */
  static async authenticateUser(username: string, password: string): Promise<User | null> {
    try {
      console.log('Database: 开始用户认证，用户名:', username);
      
      // 使用用户名进行认证，支持向后兼容（也可以使用邮箱）
      let user = await db.users.where('username').equals(username).first();
      
      // 如果用户名未找到，尝试使用邮箱查找（向后兼容）
      if (!user) {
        user = await db.users.where('email').equals(username).first();
      }
      
      console.log('Database: 找到用户:', user ? user.username : '未找到');
      
      // 验证密码（简单实现，实际应用中应该使用加密）
      if (user && user.password && user.password === password) {
        console.log('Database: 密码验证成功');
        return user;
      } else if (user && !user.password && password === '123456') {
        // 向后兼容：如果用户没有密码字段，使用默认密码
        console.log('Database: 使用默认密码验证成功');
        return user;
      }
      
      console.log('Database: 密码验证失败');
      return null;
    } catch (error) {
      console.error('Database: 用户认证失败:', error);
      return null;
    }
  }

  /**
   * 注册新用户
   */
  static async registerUser(userData: Omit<User, 'id' | 'created_at' | 'updated_at'>): Promise<User> {
    console.log('Database: 开始注册用户，输入数据:', userData);
    
    // 检查用户名是否已存在
    const existingUserByUsername = await db.users.where('username').equals(userData.username).first();
    if (existingUserByUsername) {
      console.log('Database: 用户名已存在:', userData.username);
      throw new Error('用户名已被注册');
    }
    
    // 如果提供了邮箱，检查邮箱是否已存在
    if (userData.email) {
      const existingUserByEmail = await db.users.where('email').equals(userData.email).first();
      if (existingUserByEmail) {
        console.log('Database: 邮箱已存在:', userData.email);
        throw new Error('邮箱已被注册');
      }
    }

    try {
      const newUser: User = {
        ...userData,
        // 如果没有提供邮箱，生成一个临时邮箱以保持数据库兼容性
        email: userData.email || `${userData.username}@temp.local`,
        // 如果没有提供昵称，使用用户名作为昵称
        nickname: userData.nickname || userData.username,
        id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        created_at: new Date(),
        updated_at: new Date()
      };

      console.log('Database: 准备添加用户到数据库:', newUser);
      
      const userId = await db.users.add(newUser);
      console.log('Database: 用户添加成功，ID:', userId);
      
      // 返回完整的用户对象
      const savedUser = await db.users.get(newUser.id);
      if (!savedUser) {
        throw new Error('保存用户后无法找到用户记录');
      }
      
      console.log('Database: 注册完成，返回用户:', savedUser);
      return savedUser;
    } catch (error) {
      console.error('Database: 用户注册失败:', error);
      throw new Error('注册失败，请稍后重试');
    }
  }

  /**
   * 通过邮箱查找用户（用于密码找回）
   */
  static async findUserByEmail(email: string): Promise<User | null> {
    try {
      const user = await db.users.where('email').equals(email).first();
      return user || null;
    } catch (error) {
      console.error('查找用户失败:', error);
      return null;
    }
  }

  /**
   * 重置用户密码
   */
  static async resetUserPassword(userId: string, newPassword: string): Promise<boolean> {
    try {
      const user = await db.users.get(userId);
      if (!user) {
        return false;
      }

      await db.users.update(userId, {
        updated_at: new Date()
        // 注意：实际应用中应该有专门的密码字段和加密处理
      });

      return true;
    } catch (error) {
      console.error('重置密码失败:', error);
      return false;
    }
  }

  /**
   * 生成密码重置令牌（模拟）
   */
  static async generatePasswordResetToken(email: string): Promise<string | null> {
    try {
      const user = await this.findUserByEmail(email);
      if (!user) {
        return null;
      }

      // 生成简单的重置令牌（实际应用中应该使用更安全的方法）
      const token = `reset-${user.id}-${Date.now()}`;
      
      // 在实际应用中，应该将令牌存储到数据库并设置过期时间
      // 这里只是模拟返回令牌
      return token;
    } catch (error) {
      console.error('生成重置令牌失败:', error);
      return null;
    }
  }

  /**
   * 验证密码重置令牌
   */
  static async validatePasswordResetToken(token: string): Promise<string | null> {
    try {
      // 解析令牌获取用户ID（简单实现）
      const parts = token.split('-');
      if (parts.length !== 3 || parts[0] !== 'reset') {
        return null;
      }

      const userId = parts[1];
      const timestamp = parseInt(parts[2]);
      
      // 检查令牌是否过期（24小时）
      const now = Date.now();
      const tokenAge = now - timestamp;
      const maxAge = 24 * 60 * 60 * 1000; // 24小时
      
      if (tokenAge > maxAge) {
        return null;
      }

      // 验证用户是否存在
      const user = await db.users.get(userId);
      if (!user) {
        return null;
      }

      return userId;
    } catch (error) {
      console.error('验证重置令牌失败:', error);
      return null;
    }
  }

  /**
   * 获取用户的好友列表
   */
  static async getFriends(userId: string): Promise<User[]> {
    try {
      const friendships = await db.friendships
        .where('user_id')
        .equals(userId)
        .and(f => f.status === 'accepted')
        .toArray();

      const friendIds = friendships.map(f => f.friend_id);
      const friends = await db.users.where('id').anyOf(friendIds).toArray();
      
      return friends;
    } catch (error) {
      console.error('获取好友列表失败:', error);
      return [];
    }
  }

  /**
   * 获取聊天会话列表
   */
  static async getChatSessions(userId: string): Promise<ChatSession[]> {
    try {
      const sessions = await db.chatSessions
        .where('user_id')
        .equals(userId)
        .reverse()
        .sortBy('updated_at');

      // 为每个会话添加最后一条消息
      for (const session of sessions) {
        const lastMessage = await db.messages
          .where('[sender_id+receiver_id]')
          .anyOf([
            [userId, session.friend_id],
            [session.friend_id, userId]
          ])
          .reverse()
          .sortBy('created_at')
          .then(messages => messages[messages.length - 1]);
        
        session.last_message = lastMessage;
      }

      return sessions;
    } catch (error) {
      console.error('获取聊天会话失败:', error);
      return [];
    }
  }

  /**
   * 获取两个用户之间的消息
   */
  static async getMessages(userId1: string, userId2: string): Promise<Message[]> {
    try {
      const messages = await db.messages
        .where('[sender_id+receiver_id]')
        .anyOf([
          [userId1, userId2],
          [userId2, userId1]
        ])
        .sortBy('created_at');

      return messages;
    } catch (error) {
      console.error('获取消息失败:', error);
      return [];
    }
  }

  /**
   * 发送消息
   */
  static async sendMessage(messageData: Omit<Message, 'id' | 'created_at'>): Promise<Message | null> {
    try {
      const newMessage: Message = {
        ...messageData,
        id: `msg-${Date.now()}`,
        created_at: new Date()
      };

      await db.messages.add(newMessage);

      // 更新或创建聊天会话
      await this.updateChatSession(messageData.sender_id, messageData.receiver_id, newMessage);

      return newMessage;
    } catch (error) {
      console.error('发送消息失败:', error);
      return null;
    }
  }

  /**
   * 更新聊天会话
   */
  private static async updateChatSession(senderId: string, receiverId: string, message: Message): Promise<void> {
    try {
      // 更新发送者的会话
      let senderSession = await db.chatSessions
        .where('[user_id+friend_id]')
        .equals([senderId, receiverId])
        .first();

      if (senderSession) {
        await db.chatSessions.update(senderSession.id, {
          updated_at: message.created_at,
          last_message_time: message.created_at,
          last_message: message
        });
      } else {
        await db.chatSessions.add({
          id: `session-${Date.now()}-sender`,
          user_id: senderId,
          friend_id: receiverId,
          unread_count: 0,
          updated_at: message.created_at,
          last_message_time: message.created_at,
          last_message: message
        });
      }

      // 更新接收者的会话
      let receiverSession = await db.chatSessions
        .where('[user_id+friend_id]')
        .equals([receiverId, senderId])
        .first();

      if (receiverSession) {
        await db.chatSessions.update(receiverSession.id, {
          updated_at: message.created_at,
          last_message_time: message.created_at,
          unread_count: receiverSession.unread_count + 1,
          last_message: message
        });
      } else {
        await db.chatSessions.add({
          id: `session-${Date.now()}-receiver`,
          user_id: receiverId,
          friend_id: senderId,
          unread_count: 1,
          updated_at: message.created_at,
          last_message_time: message.created_at,
          last_message: message
        });
      }
    } catch (error) {
      console.error('更新聊天会话失败:', error);
    }
  }

  /**
   * 获取朋友圈动态
   */
  static async getMoments(userId: string): Promise<Moment[]> {
    try {
      // 获取用户的好友ID列表
      const friends = await this.getFriends(userId);
      const friendIds = friends.map(f => f.id);
      friendIds.push(userId); // 包含自己的动态

      const moments = await db.moments
        .where('user_id')
        .anyOf(friendIds)
        .reverse()
        .sortBy('created_at');

      return moments.reverse(); // 最新的在前面
    } catch (error) {
      console.error('获取朋友圈动态失败:', error);
      return [];
    }
  }

  /**
   * 发布朋友圈动态
   */
  static async createMoment(momentData: Omit<Moment, 'id' | 'created_at' | 'likes_count' | 'comments_count'>): Promise<Moment | null> {
    try {
      const newMoment: Moment = {
        ...momentData,
        id: `moment-${Date.now()}`,
        created_at: new Date(),
        likes_count: 0,
        comments_count: 0
      };

      await db.moments.add(newMoment);
      return newMoment;
    } catch (error) {
      console.error('发布动态失败:', error);
      return null;
    }
  }

  /**
   * 好友申请相关方法
   */

  /**
   * 发送好友申请
   */
  static async sendFriendRequest(fromUserId: string, toUserId: string, message: string = ''): Promise<FriendRequest | null> {
    try {
      // 检查是否已经是好友
      const existingFriendship = await db.friendships
        .where('[user_id+friend_id]')
        .equals([fromUserId, toUserId])
        .first();
      
      if (existingFriendship && existingFriendship.status === 'accepted') {
        throw new Error('已经是好友关系');
      }

      // 检查是否已有待处理的申请
      const existingRequest = await db.friendRequests
        .where('[from_user_id+to_user_id]')
        .equals([fromUserId, toUserId])
        .and(req => req.status === 'pending')
        .first();
      
      if (existingRequest) {
        throw new Error('已发送好友申请，请等待对方处理');
      }

      // 创建好友申请
      const newRequest: FriendRequest = {
        id: `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        from_user_id: fromUserId,
        to_user_id: toUserId,
        message,
        status: 'pending',
        is_read: false,
        created_at: new Date(),
        updated_at: new Date()
      };

      await db.friendRequests.add(newRequest);

      // 创建通知
      await this.createNotification({
        user_id: toUserId,
        type: 'friend_request',
        content: '收到新的好友申请',
        related_id: newRequest.id,
        is_read: false
      });

      console.log('好友申请发送成功:', newRequest);
      return newRequest;
    } catch (error) {
      console.error('发送好友申请失败:', error);
      throw error;
    }
  }

  /**
   * 获取好友申请列表
   */
  static async getFriendRequests(userId: string, status?: 'pending' | 'accepted' | 'rejected' | 'ignored'): Promise<FriendRequest[]> {
    try {
      let query = db.friendRequests.where('to_user_id').equals(userId);
      
      if (status) {
        query = query.and(req => req.status === status);
      }

      const requests = await query.reverse().sortBy('created_at');
      return requests.reverse(); // 最新的在前面
    } catch (error) {
      console.error('获取好友申请列表失败:', error);
      return [];
    }
  }

  /**
   * 处理好友申请
   */
  static async handleFriendRequest(requestId: string, action: 'accept' | 'reject' | 'ignore'): Promise<boolean> {
    try {
      const request = await db.friendRequests.get(requestId);
      if (!request) {
        throw new Error('好友申请不存在');
      }

      // 更新申请状态
      await db.friendRequests.update(requestId, {
        status: action === 'accept' ? 'accepted' : action === 'reject' ? 'rejected' : 'ignored',
        updated_at: new Date()
      });

      // 如果同意申请，创建好友关系
      if (action === 'accept') {
        const friendship1: Friendship = {
          id: `friendship-${Date.now()}-1`,
          user_id: request.from_user_id,
          friend_id: request.to_user_id,
          status: 'accepted',
          created_at: new Date()
        };

        const friendship2: Friendship = {
          id: `friendship-${Date.now()}-2`,
          user_id: request.to_user_id,
          friend_id: request.from_user_id,
          status: 'accepted',
          created_at: new Date()
        };

        await db.friendships.bulkAdd([friendship1, friendship2]);

        // 通知申请发送者
        await this.createNotification({
          user_id: request.from_user_id,
          type: 'friend_request',
          content: '好友申请已通过',
          related_id: requestId,
          is_read: false
        });
      }

      console.log('好友申请处理成功:', action);
      return true;
    } catch (error) {
      console.error('处理好友申请失败:', error);
      return false;
    }
  }

  /**
   * 获取未读好友申请数量
   */
  static async getUnreadRequestCount(userId: string): Promise<number> {
    try {
      const count = await db.friendRequests
        .where('to_user_id')
        .equals(userId)
        .and(req => req.status === 'pending' && !req.is_read)
        .count();
      
      return count;
    } catch (error) {
      console.error('获取未读申请数量失败:', error);
      return 0;
    }
  }

  /**
   * 标记好友申请为已读
   */
  static async markRequestAsRead(requestId: string): Promise<boolean> {
    try {
      await db.friendRequests.update(requestId, {
        is_read: true,
        updated_at: new Date()
      });
      return true;
    } catch (error) {
      console.error('标记申请已读失败:', error);
      return false;
    }
  }

  /**
   * 通知相关方法
   */

  /**
   * 创建通知
   */
  static async createNotification(notificationData: Omit<Notification, 'id' | 'created_at'>): Promise<Notification | null> {
    try {
      const newNotification: Notification = {
        ...notificationData,
        id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        created_at: new Date()
      };

      await db.notifications.add(newNotification);
      console.log('通知创建成功:', newNotification);
      return newNotification;
    } catch (error) {
      console.error('创建通知失败:', error);
      return null;
    }
  }

  /**
   * 获取用户通知列表
   */
  static async getNotifications(userId: string, type?: string): Promise<Notification[]> {
    try {
      let query = db.notifications.where('user_id').equals(userId);
      
      if (type) {
        query = query.and(notif => notif.type === type);
      }

      const notifications = await query.reverse().sortBy('created_at');
      return notifications.reverse(); // 最新的在前面
    } catch (error) {
      console.error('获取通知列表失败:', error);
      return [];
    }
  }

  /**
   * 获取未读通知数量
   */
  static async getUnreadNotificationCount(userId: string, type?: string): Promise<number> {
    try {
      let query = db.notifications
        .where('user_id')
        .equals(userId)
        .and(notif => !notif.is_read);
      
      if (type) {
        query = query.and(notif => notif.type === type);
      }

      const count = await query.count();
      return count;
    } catch (error) {
      console.error('获取未读通知数量失败:', error);
      return 0;
    }
  }

  /**
   * 标记通知为已读
   */
  static async markNotificationAsRead(notificationId: string): Promise<boolean> {
    try {
      await db.notifications.update(notificationId, {
        is_read: true
      });
      return true;
    } catch (error) {
      console.error('标记通知已读失败:', error);
      return false;
    }
  }

  /**
   * 清除用户的所有未读通知徽章
   */
  static async clearNotificationBadge(userId: string, type?: string): Promise<boolean> {
    try {
      let query = db.notifications
        .where('user_id')
        .equals(userId)
        .and(notif => !notif.is_read);
      
      if (type) {
        query = query.and(notif => notif.type === type);
      }

      const notifications = await query.toArray();
      const updatePromises = notifications.map(notif => 
        db.notifications.update(notif.id, { is_read: true })
      );

      await Promise.all(updatePromises);
      console.log(`清除了 ${notifications.length} 个未读通知`);
      return true;
    } catch (error) {
      console.error('清除通知徽章失败:', error);
      return false;
    }
  }

  /**
   * 搜索用户（用于添加好友）
   * 支持用户名、昵称、邮箱的模糊搜索
   */
  static async searchUsers(query: string, currentUserId: string): Promise<User[]> {
    try {
      if (!query || !query.trim()) {
        console.log('搜索查询为空');
        return [];
      }

      const searchQuery = query.trim().toLowerCase();
      console.log('开始搜索用户:', searchQuery, '当前用户ID:', currentUserId);

      // 获取所有用户（除了当前用户）
      const allUsers = await db.users
        .filter(user => user.id !== currentUserId)
        .toArray();

      console.log('数据库中总用户数（除当前用户）:', allUsers.length);

      // 客户端模糊搜索，支持多种匹配方式
      const matchedUsers = allUsers.filter(user => {
        const username = (user.username || '').toLowerCase();
        const nickname = (user.nickname || '').toLowerCase();
        const email = (user.email || '').toLowerCase();
        
        // 支持多种匹配方式：
        // 1. 完全匹配
        // 2. 开头匹配
        // 3. 包含匹配
        const isMatch = 
          username === searchQuery ||
          nickname === searchQuery ||
          email === searchQuery ||
          username.startsWith(searchQuery) ||
          nickname.startsWith(searchQuery) ||
          email.startsWith(searchQuery) ||
          username.includes(searchQuery) ||
          nickname.includes(searchQuery) ||
          email.includes(searchQuery);

        if (isMatch) {
          console.log('找到匹配用户:', {
            id: user.id,
            username: user.username,
            nickname: user.nickname,
            email: user.email
          });
        }

        return isMatch;
      });

      // 按匹配优先级排序：完全匹配 > 开头匹配 > 包含匹配
      const sortedUsers = matchedUsers.sort((a, b) => {
        const aUsername = (a.username || '').toLowerCase();
        const aNickname = (a.nickname || '').toLowerCase();
        const aEmail = (a.email || '').toLowerCase();
        
        const bUsername = (b.username || '').toLowerCase();
        const bNickname = (b.nickname || '').toLowerCase();
        const bEmail = (b.email || '').toLowerCase();

        // 完全匹配优先级最高
        const aExactMatch = aUsername === searchQuery || aNickname === searchQuery || aEmail === searchQuery;
        const bExactMatch = bUsername === searchQuery || bNickname === searchQuery || bEmail === searchQuery;
        
        if (aExactMatch && !bExactMatch) return -1;
        if (!aExactMatch && bExactMatch) return 1;

        // 开头匹配优先级次之
        const aStartsMatch = aUsername.startsWith(searchQuery) || aNickname.startsWith(searchQuery) || aEmail.startsWith(searchQuery);
        const bStartsMatch = bUsername.startsWith(searchQuery) || bNickname.startsWith(searchQuery) || bEmail.startsWith(searchQuery);
        
        if (aStartsMatch && !bStartsMatch) return -1;
        if (!aStartsMatch && bStartsMatch) return 1;

        // 按用户名字母顺序排序
        return aUsername.localeCompare(bUsername);
      });

      const result = sortedUsers.slice(0, 10); // 限制返回10个结果
      console.log('搜索完成，找到用户数:', result.length);
      
      return result;
    } catch (error) {
      console.error('搜索用户失败:', error);
      return [];
    }
  }

  /**
   * 备份用户数据到localStorage
   * @param userId 用户ID
   * @returns 备份是否成功
   */
  static async backupUserDataToStorage(userId: string): Promise<boolean> {
    try {
      console.log('开始备份用户数据到localStorage:', userId);
      
      // 获取用户相关的所有数据
      const [
        user,
        friends,
        chatSessions,
        messages,
        moments,
        friendRequests,
        notifications
      ] = await Promise.all([
        db.users.get(userId),
        this.getFriends(userId),
        this.getChatSessions(userId),
        db.messages.where('sender_id').equals(userId).or('receiver_id').equals(userId).toArray(),
        this.getMoments(userId),
        this.getFriendRequests(userId),
        this.getNotifications(userId)
      ]);

      const backupData = {
        user,
        friends,
        chatSessions,
        messages,
        moments,
        friendRequests,
        notifications,
        timestamp: Date.now(),
        version: '1.0.0'
      };

      // 保存到localStorage
      const backupKey = `user_backup_${userId}`;
      localStorage.setItem(backupKey, JSON.stringify(backupData));
      
      // 保存备份索引
      const backupIndex = JSON.parse(localStorage.getItem('backup_index') || '{}');
      backupIndex[userId] = {
        timestamp: Date.now(),
        key: backupKey,
        version: '1.0.0'
      };
      localStorage.setItem('backup_index', JSON.stringify(backupIndex));

      console.log('用户数据备份成功');
      return true;
    } catch (error) {
      console.error('备份用户数据失败:', error);
      return false;
    }
  }

  /**
   * 从localStorage恢复用户数据到IndexedDB
   * @param userId 用户ID
   * @returns 恢复是否成功
   */
  static async restoreUserDataFromStorage(userId: string): Promise<boolean> {
    try {
      console.log('开始从localStorage恢复用户数据:', userId);
      
      const backupKey = `user_backup_${userId}`;
      const backupDataStr = localStorage.getItem(backupKey);
      
      if (!backupDataStr) {
        console.log('未找到用户备份数据');
        return false;
      }

      const backupData = JSON.parse(backupDataStr);
      
      // 验证备份数据完整性
      if (!backupData.user || !backupData.timestamp) {
        console.error('备份数据不完整');
        return false;
      }

      // 使用事务恢复数据
      await db.transaction('rw', [
        db.users,
        db.messages,
        db.chatSessions,
        db.friendships,
        db.moments,
        db.friendRequests,
        db.notifications
      ], async () => {
        // 恢复用户信息
        if (backupData.user) {
          await db.users.put(backupData.user);
        }

        // 恢复聊天会话
        if (backupData.chatSessions && backupData.chatSessions.length > 0) {
          await db.chatSessions.bulkPut(backupData.chatSessions);
        }

        // 恢复消息
        if (backupData.messages && backupData.messages.length > 0) {
          await db.messages.bulkPut(backupData.messages);
        }

        // 恢复朋友圈动态
        if (backupData.moments && backupData.moments.length > 0) {
          await db.moments.bulkPut(backupData.moments);
        }

        // 恢复好友请求
        if (backupData.friendRequests && backupData.friendRequests.length > 0) {
          await db.friendRequests.bulkPut(backupData.friendRequests);
        }

        // 恢复通知
        if (backupData.notifications && backupData.notifications.length > 0) {
          await db.notifications.bulkPut(backupData.notifications);
        }

        // 恢复好友关系
        if (backupData.friends && backupData.friends.length > 0) {
          const friendships = backupData.friends.map((friend: User) => ({
            id: `${userId}_${friend.id}`,
            user_id: userId,
            friend_id: friend.id,
            status: 'accepted' as const,
            created_at: new Date()
          }));
          await db.friendships.bulkPut(friendships);
        }
      });

      console.log('用户数据恢复成功');
      return true;
    } catch (error) {
      console.error('恢复用户数据失败:', error);
      return false;
    }
  }

  /**
   * 检查用户数据完整性
   * @param userId 用户ID
   * @returns 数据是否完整
   */
  static async validateUserDataIntegrity(userId: string): Promise<boolean> {
    try {
      // 检查用户是否存在
      const user = await db.users.get(userId);
      if (!user) {
        console.log('用户数据不存在:', userId);
        return false;
      }

      // 检查关键数据表是否可访问
      const [chatSessions, friendships] = await Promise.all([
        db.chatSessions.where('user_id').equals(userId).count(),
        db.friendships.where('user_id').equals(userId).count()
      ]);

      console.log('数据完整性检查通过:', {
        userId,
        chatSessions,
        friendships
      });

      return true;
    } catch (error) {
      console.error('数据完整性检查失败:', error);
      return false;
    }
  }

  /**
   * 清理损坏的数据
   * @param userId 用户ID
   * @returns 清理是否成功
   */
  static async clearCorruptedUserData(userId: string): Promise<boolean> {
    try {
      console.log('开始清理损坏的用户数据:', userId);
      
      await db.transaction('rw', [
        db.users,
        db.messages,
        db.chatSessions,
        db.friendships,
        db.moments,
        db.friendRequests,
        db.notifications
      ], async () => {
        // 删除用户相关的所有数据
        await db.messages.where('sender_id').equals(userId).delete();
        await db.messages.where('receiver_id').equals(userId).delete();
        await db.chatSessions.where('user_id').equals(userId).delete();
        await db.friendships.where('user_id').equals(userId).delete();
        await db.friendships.where('friend_id').equals(userId).delete();
        await db.moments.where('user_id').equals(userId).delete();
        await db.friendRequests.where('from_user_id').equals(userId).delete();
        await db.friendRequests.where('to_user_id').equals(userId).delete();
        await db.notifications.where('user_id').equals(userId).delete();
        await db.users.delete(userId);
      });

      // 清理localStorage中的备份数据
      const backupKey = `user_backup_${userId}`;
      localStorage.removeItem(backupKey);
      
      const backupIndex = JSON.parse(localStorage.getItem('backup_index') || '{}');
      delete backupIndex[userId];
      localStorage.setItem('backup_index', JSON.stringify(backupIndex));

      console.log('损坏的用户数据清理完成');
      return true;
    } catch (error) {
      console.error('清理损坏数据失败:', error);
      return false;
    }
  }

  /**
   * 获取所有备份信息
   * @returns 备份信息列表
   */
  static getBackupInfo(): Array<{userId: string, timestamp: number, key: string, version: string}> {
    try {
      const backupIndex = JSON.parse(localStorage.getItem('backup_index') || '{}');
      return Object.entries(backupIndex).map(([userId, info]: [string, any]) => ({
        userId,
        ...info
      }));
    } catch (error) {
      console.error('获取备份信息失败:', error);
      return [];
    }
  }
}