# Git 自动安装脚本 - 简化版 (更新)
# 解决编码问题的版本

param(
    [switch]$AutoInstall = $false
)

# 设置控制台编码为UTF-8
$OutputEncoding = [console]::InputEncoding = [console]::OutputEncoding = New-Object System.Text.UTF8Encoding

Write-Host "Git Installation Tool" -ForegroundColor Green
Write-Host "=====================" -ForegroundColor Cyan

# 检查Git是否已安装
function Test-GitInstalled {
    try {
        $gitVersion = git --version 2>$null
        if ($gitVersion) {
            Write-Host "Git is already installed: $gitVersion" -ForegroundColor Green
            return $true
        }
    } catch {
        Write-Host "Git is not installed" -ForegroundColor Red
        return $false
    }
    return $false
}

# 检查Chocolatey是否已安装
function Test-ChocolateyInstalled {
    try {
        choco --version 2>$null | Out-Null
        return $true
    } catch {
        return $false
    }
}

# 安装Chocolatey
function Install-Chocolatey {
    Write-Host "Installing Chocolatey package manager..." -ForegroundColor Yellow
    
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "Chocolatey installed successfully" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "Chocolatey installation failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 使用Chocolatey安装Git
function Install-GitWithChocolatey {
    Write-Host "Installing Git using Chocolatey..." -ForegroundColor Yellow
    
    try {
        choco install git -y
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "Git installed successfully" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "Git installation failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 手动下载Git
function Install-GitManually {
    Write-Host "Opening Git download page..." -ForegroundColor Yellow
    Start-Process "https://git-scm.com/download/win"
    Write-Host "Please download and install Git manually, then run this script again for configuration" -ForegroundColor Yellow
}

# 配置Git用户信息
function Set-GitConfig {
    Write-Host "Configuring Git user information..." -ForegroundColor Yellow
    
    # 检查现有配置
    $existingName = git config --global user.name 2>$null
    $existingEmail = git config --global user.email 2>$null
    
    if ($existingName -and $existingEmail) {
        Write-Host "Git user information already configured:" -ForegroundColor Green
        Write-Host "   Name: $existingName" -ForegroundColor Cyan
        Write-Host "   Email: $existingEmail" -ForegroundColor Cyan
        return
    }
    
    # 获取用户输入
    do {
        $userName = Read-Host "Please enter your GitHub username"
    } while ([string]::IsNullOrWhiteSpace($userName))
    
    do {
        $userEmail = Read-Host "Please enter your GitHub email"
    } while ([string]::IsNullOrWhiteSpace($userEmail))
    
    try {
        git config --global user.name "$userName"
        git config --global user.email "$userEmail"
        git config --global init.defaultBranch main
        git config --global core.autocrlf true
        
        Write-Host "Git configuration completed:" -ForegroundColor Green
        Write-Host "   Name: $userName" -ForegroundColor Cyan
        Write-Host "   Email: $userEmail" -ForegroundColor Cyan
    } catch {
        Write-Host "Git configuration failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 主程序
Write-Host ""
Write-Host "Checking current environment..." -ForegroundColor Yellow

# 检查Git是否已安装
if (Test-GitInstalled) {
    Write-Host "Git is already installed, proceeding to configuration..." -ForegroundColor Green
    Set-GitConfig
    Write-Host "Setup completed!" -ForegroundColor Green
    return
}

Write-Host ""
Write-Host "Git Installation Options:" -ForegroundColor Cyan
Write-Host "1. Automatic installation (using Chocolatey, recommended)" -ForegroundColor Green
Write-Host "2. Manual download" -ForegroundColor Yellow
Write-Host "3. Cancel" -ForegroundColor Red

if (-not $AutoInstall) {
    $choice = Read-Host "Please select installation method (1-3)"
} else {
    $choice = "1"
    Write-Host "Auto-selected: Option 1 (Automatic installation)" -ForegroundColor Green
}

switch ($choice) {
    "1" {
        Write-Host "Starting automatic installation..." -ForegroundColor Green
        
        # 检查并安装Chocolatey
        if (-not (Test-ChocolateyInstalled)) {
            if (-not (Install-Chocolatey)) {
                Write-Host "Chocolatey installation failed, opening manual download page" -ForegroundColor Red
                Install-GitManually
                return
            }
        }
        
        # 使用Chocolatey安装Git
        if (Test-ChocolateyInstalled) {
            if (Install-GitWithChocolatey) {
                Write-Host "Verifying Git installation..." -ForegroundColor Yellow
                Start-Sleep -Seconds 3
                
                if (Test-GitInstalled) {
                    Write-Host "Git installation successful!" -ForegroundColor Green
                    Set-GitConfig
                    Write-Host "Setup completed! You can now run the deployment script." -ForegroundColor Green
                } else {
                    Write-Host "Git installation verification failed" -ForegroundColor Red
                }
            }
        }
    }
    "2" {
        Install-GitManually
    }
    "3" {
        Write-Host "Installation cancelled" -ForegroundColor Red
        return
    }
    default {
        Write-Host "Invalid selection" -ForegroundColor Red
        return
    }
}

Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")