/**
 * 全面的注册功能测试脚本 - 增强版
 * 用于排查注册失败问题并验证数据持久化
 * 包含详细的调试信息和问题分析
 */

console.log('=== 开始全面注册功能测试 ===');

// 测试配置
const TEST_USER = {
    username: 'testuser_' + Date.now(),
    email: 'test_' + Date.now() + '@example.com',
    password: 'TestPassword123!'
};

// 工具函数：等待指定时间
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 工具函数：检查IndexedDB支持
function checkIndexedDBSupport() {
    console.log('\n--- 检查IndexedDB支持 ---');
    if (!window.indexedDB) {
        console.error('❌ IndexedDB不支持');
        return false;
    }
    console.log('✅ IndexedDB支持正常');
    return true;
}

// 工具函数：检查数据库连接
async function checkDatabaseConnection() {
    console.log('\n--- 检查数据库连接 ---');
    try {
        // 尝试打开数据库
        const request = indexedDB.open('WeChatDB', 1);
        
        return new Promise((resolve, reject) => {
            request.onerror = () => {
                console.error('❌ 数据库连接失败:', request.error);
                resolve(false);
            };
            
            request.onsuccess = () => {
                console.log('✅ 数据库连接成功');
                const db = request.result;
                
                // 检查对象存储
                const storeNames = Array.from(db.objectStoreNames);
                console.log('📊 数据库对象存储:', storeNames);
                
                if (storeNames.includes('users')) {
                    console.log('✅ users表存在');
                } else {
                    console.warn('⚠️ users表不存在');
                }
                
                db.close();
                resolve(true);
            };
            
            request.onupgradeneeded = (event) => {
                console.log('🔄 数据库需要升级');
                resolve(true);
            };
        });
    } catch (error) {
        console.error('❌ 数据库连接异常:', error);
        return false;
    }
}

// 工具函数：检查现有用户
async function checkExistingUsers() {
    console.log('\n--- 检查现有用户 ---');
    try {
        const request = indexedDB.open('WeChatDB', 1);
        
        return new Promise((resolve) => {
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['users'], 'readonly');
                const store = transaction.objectStore('users');
                const getAllRequest = store.getAll();
                
                getAllRequest.onsuccess = () => {
                    const users = getAllRequest.result;
                    console.log('👥 现有用户数量:', users.length);
                    users.forEach(user => {
                        console.log(`  - ${user.username} (${user.email}) - 密码字段: ${user.password ? '✅' : '❌'}`);
                    });
                    db.close();
                    resolve(users);
                };
                
                getAllRequest.onerror = () => {
                    console.error('❌ 获取用户列表失败');
                    db.close();
                    resolve([]);
                };
            };
        });
    } catch (error) {
        console.error('❌ 检查现有用户异常:', error);
        return [];
    }
}

// 工具函数：测试用户注册
async function testUserRegistration() {
    console.log('\n--- 测试用户注册 ---');
    console.log('📝 测试用户信息:', TEST_USER);
    
    try {
        // 检查store是否存在
        if (!window.store) {
            console.error('❌ store对象不存在');
            return false;
        }
        
        console.log('🔄 开始注册...');
        const result = await window.store.register(TEST_USER.username, TEST_USER.email, TEST_USER.password);
        
        if (result.success) {
            console.log('✅ 注册成功:', result);
            return true;
        } else {
            console.error('❌ 注册失败:', result.error);
            return false;
        }
    } catch (error) {
        console.error('❌ 注册过程异常:', error);
        return false;
    }
}

// 工具函数：验证用户数据持久化
async function verifyUserPersistence() {
    console.log('\n--- 验证用户数据持久化 ---');
    
    // 等待一段时间确保数据写入
    await sleep(1000);
    
    try {
        const request = indexedDB.open('WeChatDB', 1);
        
        return new Promise((resolve) => {
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['users'], 'readonly');
                const store = transaction.objectStore('users');
                
                // 通过用户名查找
                const usernameIndex = store.index('username');
                const getUserRequest = usernameIndex.get(TEST_USER.username);
                
                getUserRequest.onsuccess = () => {
                    const user = getUserRequest.result;
                    if (user) {
                        console.log('✅ 用户数据已持久化:', user);
                        console.log('  - 用户名:', user.username);
                        console.log('  - 邮箱:', user.email);
                        console.log('  - 密码字段:', user.password ? '✅ 存在' : '❌ 缺失');
                        console.log('  - 创建时间:', user.createdAt);
                        db.close();
                        resolve(true);
                    } else {
                        console.error('❌ 用户数据未找到');
                        db.close();
                        resolve(false);
                    }
                };
                
                getUserRequest.onerror = () => {
                    console.error('❌ 查询用户数据失败');
                    db.close();
                    resolve(false);
                };
            };
        });
    } catch (error) {
        console.error('❌ 验证数据持久化异常:', error);
        return false;
    }
}

// 工具函数：测试用户认证
async function testUserAuthentication() {
    console.log('\n--- 测试用户认证 ---');
    
    try {
        // 检查DatabaseService是否存在
        if (!window.DatabaseService) {
            console.error('❌ DatabaseService不存在');
            return false;
        }
        
        console.log('🔄 测试用户认证...');
        const authResult = await window.DatabaseService.authenticateUser(TEST_USER.username, TEST_USER.password);
        
        if (authResult.success) {
            console.log('✅ 用户认证成功:', authResult);
            return true;
        } else {
            console.error('❌ 用户认证失败:', authResult.error);
            return false;
        }
    } catch (error) {
        console.error('❌ 用户认证异常:', error);
        return false;
    }
}

// 工具函数：检查localStorage状态
function checkLocalStorageState() {
    console.log('\n--- 检查localStorage状态 ---');
    
    try {
        const userState = localStorage.getItem('user');
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        
        console.log('📱 localStorage内容:');
        console.log('  - user:', userState ? JSON.parse(userState) : '无');
        console.log('  - isLoggedIn:', isLoggedIn);
        
        // 检查其他相关状态
        const keys = Object.keys(localStorage);
        const relevantKeys = keys.filter(key => 
            key.includes('user') || 
            key.includes('login') || 
            key.includes('auth') ||
            key.includes('chat')
        );
        
        if (relevantKeys.length > 0) {
            console.log('🔍 相关localStorage键值:');
            relevantKeys.forEach(key => {
                console.log(`  - ${key}:`, localStorage.getItem(key));
            });
        }
        
        return true;
    } catch (error) {
        console.error('❌ 检查localStorage异常:', error);
        return false;
    }
}

// 工具函数：测试登录流程
async function testLoginFlow() {
    console.log('\n--- 测试登录流程 ---');
    
    try {
        if (!window.store) {
            console.error('❌ store对象不存在');
            return false;
        }
        
        console.log('🔄 测试登录...');
        const loginResult = await window.store.login(TEST_USER.username, TEST_USER.password);
        
        if (loginResult.success) {
            console.log('✅ 登录成功:', loginResult);
            
            // 检查登录后的状态
            await sleep(500);
            checkLocalStorageState();
            
            return true;
        } else {
            console.error('❌ 登录失败:', loginResult.error);
            return false;
        }
    } catch (error) {
        console.error('❌ 登录流程异常:', error);
        return false;
    }
}

// 主测试函数
async function runComprehensiveTest() {
    console.log('🚀 开始全面测试...\n');
    
    const results = {
        indexedDBSupport: false,
        databaseConnection: false,
        existingUsers: [],
        userRegistration: false,
        dataPersistence: false,
        userAuthentication: false,
        loginFlow: false,
        localStorageState: false
    };
    
    try {
        // 1. 检查IndexedDB支持
        results.indexedDBSupport = checkIndexedDBSupport();
        
        // 2. 检查数据库连接
        results.databaseConnection = await checkDatabaseConnection();
        
        // 3. 检查现有用户
        results.existingUsers = await checkExistingUsers();
        
        // 4. 测试用户注册
        results.userRegistration = await testUserRegistration();
        
        // 5. 验证数据持久化
        if (results.userRegistration) {
            results.dataPersistence = await verifyUserPersistence();
        }
        
        // 6. 测试用户认证
        if (results.dataPersistence) {
            results.userAuthentication = await testUserAuthentication();
        }
        
        // 7. 测试登录流程
        if (results.userAuthentication) {
            results.loginFlow = await testLoginFlow();
        }
        
        // 8. 检查localStorage状态
        results.localStorageState = checkLocalStorageState();
        
        // 输出测试结果摘要
        console.log('\n=== 测试结果摘要 ===');
        console.log('IndexedDB支持:', results.indexedDBSupport ? '✅' : '❌');
        console.log('数据库连接:', results.databaseConnection ? '✅' : '❌');
        console.log('现有用户数量:', results.existingUsers.length);
        console.log('用户注册:', results.userRegistration ? '✅' : '❌');
        console.log('数据持久化:', results.dataPersistence ? '✅' : '❌');
        console.log('用户认证:', results.userAuthentication ? '✅' : '❌');
        console.log('登录流程:', results.loginFlow ? '✅' : '❌');
        console.log('localStorage状态:', results.localStorageState ? '✅' : '❌');
        
        // 分析问题
        console.log('\n=== 问题分析 ===');
        if (!results.userRegistration) {
            console.log('🔍 注册失败可能原因:');
            console.log('  - 表单验证失败');
            console.log('  - 数据库写入失败');
            console.log('  - 用户名或邮箱已存在');
            console.log('  - store.register方法异常');
        }
        
        if (!results.dataPersistence) {
            console.log('🔍 数据持久化失败可能原因:');
            console.log('  - IndexedDB事务失败');
            console.log('  - 数据库结构问题');
            console.log('  - 异步操作时序问题');
        }
        
        if (!results.userAuthentication) {
            console.log('🔍 用户认证失败可能原因:');
            console.log('  - 密码验证逻辑错误');
            console.log('  - 用户数据不完整');
            console.log('  - authenticateUser方法异常');
        }
        
        return results;
        
    } catch (error) {
        console.error('❌ 测试过程中发生异常:', error);
        return results;
    }
}

// 启动测试
runComprehensiveTest().then(results => {
    console.log('\n=== 测试完成 ===');
    window.testResults = results;
    console.log('测试结果已保存到 window.testResults');
});