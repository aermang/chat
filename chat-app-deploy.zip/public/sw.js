/**
 * Service Worker for handling medication reminders
 * 用于处理用药提醒的 Service Worker
 */

const CACHE_NAME = 'medication-reminders-v1';
const urlsToCache = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json'
];

/**
 * Service Worker 安装事件
 */
self.addEventListener('install', (event) => {
  console.log('Service Worker installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
      .catch((error) => {
        console.error('Cache installation failed:', error);
      })
  );
  
  // 强制激活新的 Service Worker
  self.skipWaiting();
});

/**
 * Service Worker 激活事件
 */
self.addEventListener('activate', (event) => {
  console.log('Service Worker activating...');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  
  // 立即控制所有客户端
  self.clients.claim();
});

/**
 * 处理网络请求
 */
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // 如果缓存中有响应，则返回缓存的版本
        if (response) {
          return response;
        }
        
        // 否则从网络获取
        return fetch(event.request);
      })
  );
});

/**
 * 处理推送消息（用于后台提醒）
 */
self.addEventListener('push', (event) => {
  console.log('Push message received:', event);
  
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'Medication Reminder', body: event.data.text() };
    }
  }
  
  const options = {
    body: data.body || '是时候服药了',
    icon: '/icon-192x192.png',
    badge: '/badge-72x72.png',
    tag: data.tag || 'medication-reminder',
    requireInteraction: true,
    actions: [
      {
        action: 'taken',
        title: '已服药',
        icon: '/icons/check.png'
      },
      {
        action: 'dismiss',
        title: '稍后提醒',
        icon: '/icons/clock.png'
      }
    ],
    data: data
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title || '用药提醒', options)
  );
});

/**
 * 处理通知点击事件
 */
self.addEventListener('notificationclick', (event) => {
  console.log('Notification clicked:', event);
  
  const notification = event.notification;
  const action = event.action;
  const data = notification.data || {};
  
  // 关闭通知
  notification.close();
  
  if (action === 'taken') {
    // 用户点击"已服药"
    console.log('User marked medication as taken');
    
    // 向所有客户端发送消息
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'MEDICATION_TAKEN',
            data: {
              notificationId: data.notificationId,
              reminderId: data.reminderId,
              timestamp: new Date().toISOString()
            }
          });
        });
      })
    );
  } else if (action === 'dismiss') {
    // 用户点击"稍后提醒"
    console.log('User dismissed reminder');
    
    // 向所有客户端发送消息
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'MEDICATION_DISMISSED',
            data: {
              notificationId: data.notificationId,
              reminderId: data.reminderId,
              timestamp: new Date().toISOString()
            }
          });
        });
      })
    );
  } else {
    // 用户点击通知本身
    console.log('User clicked notification');
    
    // 打开应用程序
    event.waitUntil(
      self.clients.matchAll({ type: 'window' }).then((clients) => {
        // 如果已经有窗口打开，则聚焦到该窗口
        for (let client of clients) {
          if (client.url.includes('/app/special-medicine') && 'focus' in client) {
            return client.focus();
          }
        }
        
        // 否则打开新窗口
        if (self.clients.openWindow) {
          return self.clients.openWindow('/app/special-medicine/medication-reminders');
        }
      })
    );
    
    // 向所有客户端发送消息
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'NOTIFICATION_CLICKED',
            data: {
              notificationId: data.notificationId,
              reminderId: data.reminderId,
              timestamp: new Date().toISOString()
            }
          });
        });
      })
    );
  }
});

/**
 * 处理通知关闭事件
 */
self.addEventListener('notificationclose', (event) => {
  console.log('Notification closed:', event);
  
  const notification = event.notification;
  const data = notification.data || {};
  
  // 向所有客户端发送消息
  event.waitUntil(
    self.clients.matchAll().then((clients) => {
      clients.forEach((client) => {
        client.postMessage({
          type: 'NOTIFICATION_CLOSED',
          data: {
            notificationId: data.notificationId,
            reminderId: data.reminderId,
            timestamp: new Date().toISOString()
          }
        });
      });
    })
  );
});

/**
 * 处理来自主线程的消息
 */
self.addEventListener('message', (event) => {
  console.log('Service Worker received message:', event.data);
  
  const { type, data } = event.data;
  
  switch (type) {
    case 'SCHEDULE_REMINDER':
      // 调度提醒
      scheduleReminder(data);
      break;
      
    case 'CLEAR_REMINDER':
      // 清除提醒
      clearReminder(data.reminderId);
      break;
      
    case 'GET_SCHEDULED_REMINDERS':
      // 获取已调度的提醒
      event.ports[0].postMessage({
        type: 'SCHEDULED_REMINDERS',
        data: getScheduledReminders()
      });
      break;
      
    default:
      console.log('Unknown message type:', type);
  }
});

// 存储已调度的提醒
let scheduledReminders = new Map();

/**
 * 调度提醒
 */
function scheduleReminder(reminderData) {
  const { reminder, nextTriggerTime } = reminderData;
  
  // 清除之前的调度
  if (scheduledReminders.has(reminder.id)) {
    clearTimeout(scheduledReminders.get(reminder.id).timeoutId);
  }
  
  const now = new Date().getTime();
  const triggerTime = new Date(nextTriggerTime).getTime();
  const delay = triggerTime - now;
  
  if (delay > 0) {
    const timeoutId = setTimeout(() => {
      // 发送通知
      const notificationData = {
        title: '用药提醒',
        body: `${reminder.medicationName} - ${reminder.dosage}`,
        tag: `reminder-${reminder.id}`,
        notificationId: `${reminder.id}-${Date.now()}`,
        reminderId: reminder.id,
        patientId: reminder.patientId,
        medicationName: reminder.medicationName,
        dosage: reminder.dosage
      };
      
      self.registration.showNotification(notificationData.title, {
        body: notificationData.body,
        icon: '/icon-192x192.png',
        badge: '/badge-72x72.png',
        tag: notificationData.tag,
        requireInteraction: true,
        actions: [
          {
            action: 'taken',
            title: '已服药',
            icon: '/icons/check.png'
          },
          {
            action: 'dismiss',
            title: '稍后提醒',
            icon: '/icons/clock.png'
          }
        ],
        data: notificationData
      });
      
      // 从调度列表中移除
      scheduledReminders.delete(reminder.id);
      
      // 向客户端发送事件
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'REMINDER_TRIGGERED',
            data: notificationData
          });
        });
      });
      
    }, delay);
    
    // 存储调度信息
    scheduledReminders.set(reminder.id, {
      timeoutId,
      reminder,
      nextTriggerTime,
      scheduledAt: new Date().toISOString()
    });
    
    console.log(`Reminder scheduled for ${reminder.medicationName} at ${nextTriggerTime}`);
  }
}

/**
 * 清除提醒
 */
function clearReminder(reminderId) {
  if (scheduledReminders.has(reminderId)) {
    const { timeoutId } = scheduledReminders.get(reminderId);
    clearTimeout(timeoutId);
    scheduledReminders.delete(reminderId);
    console.log(`Reminder ${reminderId} cleared`);
  }
}

/**
 * 获取已调度的提醒
 */
function getScheduledReminders() {
  const reminders = [];
  scheduledReminders.forEach((value, key) => {
    reminders.push({
      id: key,
      reminder: value.reminder,
      nextTriggerTime: value.nextTriggerTime,
      scheduledAt: value.scheduledAt
    });
  });
  return reminders;
}