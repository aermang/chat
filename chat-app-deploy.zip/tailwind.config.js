/** @type {import('tailwindcss').Config} */

export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    // 移动端优先的响应式断点配置
    screens: {
      'xs': '320px',    // 小屏手机
      'sm': '480px',    // 大屏手机
      'md': '768px',    // 平板
      'lg': '1024px',   // 小桌面
      'xl': '1280px',   // 大桌面
      '2xl': '1536px',  // 超大桌面
    },
    container: {
      center: true,
      padding: {
        DEFAULT: '1rem',
        sm: '1.5rem',
        md: '2rem',
        lg: '2.5rem',
        xl: '3rem',
      },
    },
    extend: {
      // 安全区域支持
      spacing: {
        'safe-top': 'env(safe-area-inset-top)',
        'safe-bottom': 'env(safe-area-inset-bottom)',
        'safe-left': 'env(safe-area-inset-left)',
        'safe-right': 'env(safe-area-inset-right)',
      },
      // 移动端触控区域最小尺寸
      minHeight: {
        'touch': '44px',  // 最小触控区域高度
        'touch-lg': '48px', // 大触控区域高度
      },
      minWidth: {
        'touch': '44px',  // 最小触控区域宽度
        'touch-lg': '48px', // 大触控区域宽度
      },
      // 移动端优化的字体大小
      fontSize: {
        'mobile-xs': ['12px', { lineHeight: '16px' }],
        'mobile-sm': ['14px', { lineHeight: '20px' }],
        'mobile-base': ['16px', { lineHeight: '24px' }],
        'mobile-lg': ['18px', { lineHeight: '28px' }],
        'mobile-xl': ['20px', { lineHeight: '32px' }],
      },
      // 移动端优化的间距
      gap: {
        'mobile': '0.75rem', // 12px
        'mobile-lg': '1rem',  // 16px
      },
      // 移动端优化的圆角
      borderRadius: {
        'mobile': '0.5rem',   // 8px
        'mobile-lg': '0.75rem', // 12px
      },
      // 移动端优化的阴影
      boxShadow: {
        'mobile': '0 2px 8px rgba(0, 0, 0, 0.1)',
        'mobile-lg': '0 4px 12px rgba(0, 0, 0, 0.15)',
      },
      // 移动端优化的动画时长
      transitionDuration: {
        'mobile': '200ms',
        'mobile-fast': '150ms',
      },
      // 移动端优化的z-index层级
      zIndex: {
        'mobile-nav': '50',
        'mobile-modal': '100',
        'mobile-toast': '200',
      },
    },
  },
  plugins: [],
};
