# Git 自动安装脚本 (更新版)
# 适用于 Windows 系统 - 检测到 Git 未安装，提供完整安装方案

param(
    [switch]$AutoInstall = $false,
    [switch]$SkipConfig = $false
)

# 设置控制台编码
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "🚀 Git 安装和配置工具" -ForegroundColor Green
Write-Host "===========================================" -ForegroundColor Cyan

# 检查是否以管理员身份运行
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# 检查 Git 是否已安装
function Test-GitInstalled {
    try {
        $gitVersion = git --version 2>$null
        if ($gitVersion) {
            Write-Host "✅ Git 已安装: $gitVersion" -ForegroundColor Green
            return $true
        }
    } catch {
        Write-Host "❌ Git 未安装" -ForegroundColor Red
        return $false
    }
    return $false
}

# 检查 Chocolatey 是否已安装
function Test-ChocolateyInstalled {
    try {
        choco --version 2>$null | Out-Null
        return $true
    } catch {
        return $false
    }
}

# 安装 Chocolatey
function Install-Chocolatey {
    Write-Host "📦 安装 Chocolatey 包管理器..." -ForegroundColor Yellow
    
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "✅ Chocolatey 安装成功" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "❌ Chocolatey 安装失败: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 使用 Chocolatey 安装 Git
function Install-GitWithChocolatey {
    Write-Host "📥 使用 Chocolatey 安装 Git..." -ForegroundColor Yellow
    
    try {
        choco install git -y
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "✅ Git 安装成功" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "❌ Git 安装失败: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 手动下载并安装 Git
function Install-GitManually {
    Write-Host "📥 手动下载并安装 Git..." -ForegroundColor Yellow
    
    $gitUrl = "https://github.com/git-scm/git/releases/download/v2.43.0.windows.1/Git-2.43.0-64-bit.exe"
    $downloadPath = "$env:TEMP\Git-installer.exe"
    
    try {
        Write-Host "⬇️ 下载 Git 安装程序..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri $gitUrl -OutFile $downloadPath -UseBasicParsing
        
        Write-Host "🔧 启动 Git 安装程序..." -ForegroundColor Cyan
        Write-Host "💡 请在安装向导中使用默认设置" -ForegroundColor Yellow
        
        Start-Process -FilePath $downloadPath -Wait
        
        # 清理下载文件
        Remove-Item $downloadPath -ErrorAction SilentlyContinue
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "✅ Git 安装完成" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "❌ Git 手动安装失败: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# 配置 Git 用户信息
function Set-GitConfig {
    if ($SkipConfig) {
        Write-Host "⏭️ 跳过 Git 配置" -ForegroundColor Yellow
        return
    }
    
    Write-Host "⚙️ 配置 Git 用户信息..." -ForegroundColor Yellow
    
    # 检查现有配置
    $existingName = git config --global user.name 2>$null
    $existingEmail = git config --global user.email 2>$null
    
    if ($existingName -and $existingEmail) {
        Write-Host "✅ Git 用户信息已配置:" -ForegroundColor Green
        Write-Host "   用户名: $existingName" -ForegroundColor Cyan
        Write-Host "   邮箱: $existingEmail" -ForegroundColor Cyan
        
        $reconfigure = Read-Host "是否重新配置？(y/N)"
        if ($reconfigure -ne 'y' -and $reconfigure -ne 'Y') {
            return
        }
    }
    
    # 获取用户输入
    do {
        $userName = Read-Host "请输入您的 GitHub 用户名"
    } while ([string]::IsNullOrWhiteSpace($userName))
    
    do {
        $userEmail = Read-Host "请输入您的 GitHub 邮箱"
    } while ([string]::IsNullOrWhiteSpace($userEmail))
    
    try {
        git config --global user.name "$userName"
        git config --global user.email "$userEmail"
        
        # 设置其他有用的配置
        git config --global init.defaultBranch main
        git config --global core.autocrlf true
        git config --global core.safecrlf false
        
        Write-Host "✅ Git 配置完成:" -ForegroundColor Green
        Write-Host "   用户名: $userName" -ForegroundColor Cyan
        Write-Host "   邮箱: $userEmail" -ForegroundColor Cyan
        Write-Host "   默认分支: main" -ForegroundColor Cyan
    } catch {
        Write-Host "❌ Git 配置失败: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 检查 GitHub CLI
function Test-GitHubCLI {
    try {
        gh --version 2>$null | Out-Null
        Write-Host "✅ GitHub CLI 已安装" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "⚠️ GitHub CLI 未安装 (可选)" -ForegroundColor Yellow
        return $false
    }
}

# 主程序
function Main {
    Write-Host ""
    Write-Host "🔍 检查当前环境..." -ForegroundColor Yellow
    
    # 检查 Git 是否已安装
    if (Test-GitInstalled) {
        Write-Host "Git 已经安装，跳过安装步骤" -ForegroundColor Green
        Set-GitConfig
        Test-GitHubCLI
        return
    }
    
    # 检查管理员权限
    if (-not (Test-Administrator)) {
        Write-Host "⚠️ 建议以管理员身份运行此脚本以获得最佳体验" -ForegroundColor Yellow
    }
    
    Write-Host ""
    Write-Host "📋 Git 安装选项:" -ForegroundColor Cyan
    Write-Host "1. 🚀 自动安装 (使用 Chocolatey，推荐)" -ForegroundColor Green
    Write-Host "2. 📥 手动下载安装" -ForegroundColor Yellow
    Write-Host "3. 🌐 打开官网手动下载" -ForegroundColor Cyan
    Write-Host "4. ❌ 取消安装" -ForegroundColor Red
    
    if (-not $AutoInstall) {
        $choice = Read-Host "请选择安装方式 (1-4)"
    } else {
        $choice = "1"
        Write-Host "自动选择: 选项 1 (自动安装)" -ForegroundColor Green
    }
    
    switch ($choice) {
        "1" {
            Write-Host "🚀 开始自动安装..." -ForegroundColor Green
            
            # 检查并安装 Chocolatey
            if (-not (Test-ChocolateyInstalled)) {
                if (-not (Install-Chocolatey)) {
                    Write-Host "❌ Chocolatey 安装失败，尝试手动安装" -ForegroundColor Red
                    Install-GitManually
                }
            }
            
            # 使用 Chocolatey 安装 Git
            if (Test-ChocolateyInstalled) {
                Install-GitWithChocolatey
            }
        }
        "2" {
            Install-GitManually
        }
        "3" {
            Write-Host "🌐 打开 Git 官网..." -ForegroundColor Cyan
            Start-Process "https://git-scm.com/download/win"
            Write-Host "📝 请下载并安装 Git，然后重新运行此脚本进行配置" -ForegroundColor Yellow
            return
        }
        "4" {
            Write-Host "❌ 取消安装" -ForegroundColor Red
            return
        }
        default {
            Write-Host "❌ 无效选择" -ForegroundColor Red
            return
        }
    }
    
    # 验证安装
    Write-Host ""
    Write-Host "🔍 验证 Git 安装..." -ForegroundColor Yellow
    
    if (Test-GitInstalled) {
        Write-Host "🎉 Git 安装成功！" -ForegroundColor Green
        
        # 配置 Git
        Set-GitConfig
        
        # 检查 GitHub CLI
        Write-Host ""
        Write-Host "🔍 检查 GitHub CLI..." -ForegroundColor Yellow
        if (-not (Test-GitHubCLI)) {
            Write-Host "💡 建议安装 GitHub CLI 以获得更好的 GitHub 集成体验" -ForegroundColor Cyan
            $installGH = Read-Host "是否现在安装 GitHub CLI？(y/N)"
            
            if ($installGH -eq 'y' -or $installGH -eq 'Y') {
                if (Test-ChocolateyInstalled) {
                    Write-Host "📥 安装 GitHub CLI..." -ForegroundColor Yellow
                    choco install gh -y
                } else {
                    Write-Host "🌐 打开 GitHub CLI 下载页面..." -ForegroundColor Cyan
                    Start-Process "https://cli.github.com/"
                }
            }
        }
        
        Write-Host ""
        Write-Host "🎊 安装和配置完成！" -ForegroundColor Green
        Write-Host "📋 下一步:" -ForegroundColor Cyan
        Write-Host "   1. 重新运行 deploy-to-github.bat 进行自动部署" -ForegroundColor Yellow
        Write-Host "   2. 或者按照手动部署指南操作" -ForegroundColor Yellow
        
    } else {
        Write-Host "❌ Git 安装失败" -ForegroundColor Red
        Write-Host "💡 请尝试手动安装或联系技术支持" -ForegroundColor Yellow
    }
}

# 运行主程序
Main

Write-Host ""
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")