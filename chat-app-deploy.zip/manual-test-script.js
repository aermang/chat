/**
 * 手动测试脚本 - 用户注册和好友互动功能
 * 在浏览器控制台中运行此脚本来测试功能
 */

// 测试用户注册功能
async function testUserRegistration() {
  console.log('=== 开始测试用户注册功能 ===');
  
  // 清理本地存储
  localStorage.clear();
  if ('indexedDB' in window) {
    const databases = await indexedDB.databases();
    for (const db of databases) {
      indexedDB.deleteDatabase(db.name);
    }
  }
  
  console.log('本地存储已清理');
  
  // 刷新页面到注册页面
  window.location.href = '/register';
  
  // 等待页面加载
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  console.log('请手动测试以下步骤：');
  console.log('1. 注册用户test1，密码123456');
  console.log('2. 注册用户test2，密码123456');
  console.log('3. 测试重复用户名注册');
  console.log('4. 测试密码不匹配情况');
}

// 测试登录功能
async function testUserLogin(username, password) {
  console.log(`=== 测试用户登录: ${username} ===`);
  
  // 跳转到登录页面
  window.location.href = '/login';
  
  // 等待页面加载
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // 自动填写表单（如果页面已加载）
  const usernameInput = document.querySelector('input[name="username"]');
  const passwordInput = document.querySelector('input[type="password"]');
  const submitButton = document.querySelector('button[type="submit"]');
  
  if (usernameInput && passwordInput && submitButton) {
    usernameInput.value = username;
    passwordInput.value = password;
    
    // 触发输入事件
    usernameInput.dispatchEvent(new Event('input', { bubbles: true }));
    passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
    
    console.log(`已填写登录信息: ${username}`);
    console.log('请点击登录按钮完成登录');
  } else {
    console.log('页面元素未找到，请手动填写登录信息');
  }
}

// 测试好友添加功能
async function testAddFriend() {
  console.log('=== 测试好友添加功能 ===');
  console.log('请按以下步骤操作：');
  console.log('1. 确保已登录test1账号');
  console.log('2. 进入通讯录页面');
  console.log('3. 点击添加好友按钮');
  console.log('4. 搜索并添加test2用户');
  console.log('5. 切换到test2账号，接受好友请求');
}

// 测试聊天功能
async function testChat() {
  console.log('=== 测试聊天功能 ===');
  console.log('请按以下步骤操作：');
  console.log('1. 确保test1和test2已互为好友');
  console.log('2. 在test1账号中进入与test2的聊天');
  console.log('3. 发送测试消息');
  console.log('4. 切换到test2账号查看消息');
  console.log('5. 在test2账号中回复消息');
  console.log('6. 切换回test1账号验证消息接收');
}

// 导出测试函数到全局作用域
window.testUserRegistration = testUserRegistration;
window.testUserLogin = testUserLogin;
window.testAddFriend = testAddFriend;
window.testChat = testChat;

console.log('测试脚本已加载，可用函数：');
console.log('- testUserRegistration(): 测试用户注册');
console.log('- testUserLogin(username, password): 测试用户登录');
console.log('- testAddFriend(): 测试好友添加');
console.log('- testChat(): 测试聊天功能');