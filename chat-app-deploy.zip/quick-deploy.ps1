# GitHub Actions 云端APK构建 - 快速部署脚本 (更新版)
# 适用于没有Git的环境 - 检测到Git未安装
# 适用于没有Git的环境

Write-Host "🚀 GitHub Actions云端APK构建 - 快速部署" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Cyan

# 检查Node.js
Write-Host "🔍 检查环境..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js未安装" -ForegroundColor Red
    exit 1
}

# 检查项目文件
if (Test-Path "package.json") {
    Write-Host "✅ 项目文件完整" -ForegroundColor Green
} else {
    Write-Host "❌ 未找到package.json" -ForegroundColor Red
    exit 1
}

# 检查Git
try {
    git --version | Out-Null
    $hasGit = $true
    Write-Host "✅ Git已安装" -ForegroundColor Green
} catch {
    $hasGit = $false
    Write-Host "⚠️ Git未安装" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "📋 部署选项:" -ForegroundColor Cyan

if ($hasGit) {
    Write-Host "1. 🚀 自动部署 (推荐)" -ForegroundColor Green
    Write-Host "2. 📖 查看手动部署指南" -ForegroundColor Yellow
    
    $choice = Read-Host "请选择 (1/2)"
    
    if ($choice -eq "1") {
        Write-Host "🚀 启动自动部署..." -ForegroundColor Green
        & ".\deploy-to-github.bat"
    } else {
        Write-Host "📖 请查看 manual-deploy-guide.md 文件" -ForegroundColor Yellow
        Start-Process "manual-deploy-guide.md"
    }
} else {
    Write-Host "由于Git未安装，请选择以下选项:" -ForegroundColor Yellow
    Write-Host "1. 🔧 安装Git (推荐)" -ForegroundColor Green
    Write-Host "2. 📖 查看手动部署指南" -ForegroundColor Yellow
    Write-Host "3. 🌐 使用GitHub Desktop (简单)" -ForegroundColor Cyan
    
    $choice = Read-Host "请选择 (1/2/3)"
    
    switch ($choice) {
        "1" {
            Write-Host "🔧 正在打开Git下载页面..." -ForegroundColor Green
            Start-Process "https://git-scm.com/download/win"
            Write-Host "📝 安装Git后，请重新运行此脚本" -ForegroundColor Yellow
        }
        "2" {
            Write-Host "📖 打开手动部署指南..." -ForegroundColor Yellow
            Start-Process "manual-deploy-guide.md"
        }
        "3" {
            Write-Host "🌐 正在打开GitHub Desktop下载页面..." -ForegroundColor Cyan
            Start-Process "https://desktop.github.com/"
            Write-Host "📝 GitHub Desktop包含Git，安装后可使用图形界面部署" -ForegroundColor Yellow
        }
        default {
            Write-Host "❌ 无效选择" -ForegroundColor Red
        }
    }
}

Write-Host ""
Write-Host "💡 提示: 部署完成后，APK将在GitHub Actions中自动构建" -ForegroundColor Cyan
Write-Host "📱 构建时间约10-15分钟，请耐心等待" -ForegroundColor Cyan

Read-Host "按回车键退出"